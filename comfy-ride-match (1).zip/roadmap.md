# Roadmap

- [x] Redesign the admin home page (Live Dispatch Board at /) — Navy Trust palette, Space Grotesk + DM Sans, bento grid

- [x] Admin home: show only upcoming reservations, Create Invoices, Pay Drivers, upcoming-reservations calendar, weekly booked reservation count/value, and completed reservation count
- [x] Apply a modern professional visual redesign to the reservation-focused admin home
- [x] Widen the admin home into three columns with paid-invoice totals, direct New Reservation, and live map
- [x] Add private pop-up messaging between company admins, signed-in chauffeurs, and signed-in clients
- [x] Make invoice and chauffeur-payment actions compact and group upcoming reservations by Today, Tomorrow, and Later
- [x] Keep the calendar and live map in the left two columns, with upcoming reservations and actions on the right
- [x] Match the dispatcher home to the supplied operations-dashboard reference using live Blackwave data
- [x] Redesign Reservations and Accounting to match the supplied dashboard references while preserving live data and actions

- [x] Redesign Drivers to match the supplied modern crew-roster reference while preserving all driver actions

- [x] Redesign Chauffeur Pay to match the supplied payout-dashboard reference while preserving live payment actions
- [x] Redesign Subscription to match the supplied plan-and-usage dashboard reference
- [x] Redesign Clients to match the supplied account-book dashboard reference
- [x] Add past-seven-day ride counts to the dispatcher home
- [x] Redesign the reservation editor as a compact three-column booking workspace
