CREATE TABLE public.client_cards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  stripe_customer_id text NOT NULL,
  stripe_payment_method_id text NOT NULL,
  brand text NOT NULL DEFAULT 'card',
  last4 text NOT NULL DEFAULT '',
  exp_month integer NOT NULL DEFAULT 0,
  exp_year integer NOT NULL DEFAULT 0,
  cardholder_name text NOT NULL DEFAULT '',
  cardholder_email text,
  cardholder_phone text,
  billing_line1 text,
  billing_line2 text,
  billing_city text,
  billing_state text,
  billing_postal_code text,
  billing_country text NOT NULL DEFAULT 'US',
  is_default boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (client_id, stripe_payment_method_id)
);

GRANT SELECT, DELETE ON public.client_cards TO authenticated;
GRANT ALL ON public.client_cards TO service_role;

ALTER TABLE public.client_cards ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Staff can view saved cards"
  ON public.client_cards FOR SELECT TO authenticated
  USING (private.has_role(auth.uid(), 'admin'::app_role) OR private.has_role(auth.uid(), 'dispatcher'::app_role));

CREATE POLICY "Staff can remove saved cards"
  ON public.client_cards FOR DELETE TO authenticated
  USING (private.has_role(auth.uid(), 'admin'::app_role) OR private.has_role(auth.uid(), 'dispatcher'::app_role));

CREATE INDEX client_cards_client_id_idx ON public.client_cards (client_id);

CREATE TRIGGER client_cards_set_updated_at
  BEFORE UPDATE ON public.client_cards
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();