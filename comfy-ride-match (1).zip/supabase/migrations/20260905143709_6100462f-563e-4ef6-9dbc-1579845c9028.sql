ALTER TABLE public.reservations
  ADD COLUMN IF NOT EXISTS driver_pay numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS driver_airport_fee numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS driver_parking_fee numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS driver_waiting_pay numeric NOT NULL DEFAULT 0;