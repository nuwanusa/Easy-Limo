CREATE TABLE public.ride_disputes (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  reservation_id uuid NOT NULL REFERENCES public.reservations(id) ON DELETE CASCADE,
  client_id uuid REFERENCES public.clients(id) ON DELETE SET NULL,
  invoice_id uuid REFERENCES public.invoices(id) ON DELETE SET NULL,
  message text NOT NULL,
  amount numeric NOT NULL DEFAULT 0,
  contact_email text,
  status text NOT NULL DEFAULT 'open',
  staff_reply text,
  resolved_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.ride_disputes TO authenticated;
GRANT ALL ON public.ride_disputes TO service_role;

ALTER TABLE public.ride_disputes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Staff manage ride disputes"
ON public.ride_disputes FOR ALL TO authenticated
USING (EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id = auth.uid() AND ur.role IN ('admin','dispatcher')))
WITH CHECK (EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id = auth.uid() AND ur.role IN ('admin','dispatcher')));

CREATE POLICY "Client users read their disputes"
ON public.ride_disputes FOR SELECT TO authenticated
USING (EXISTS (SELECT 1 FROM public.client_users cu WHERE cu.user_id = auth.uid() AND cu.client_id = ride_disputes.client_id));

CREATE INDEX ride_disputes_reservation_idx ON public.ride_disputes (reservation_id);

CREATE TRIGGER ride_disputes_updated_at BEFORE UPDATE ON public.ride_disputes
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();