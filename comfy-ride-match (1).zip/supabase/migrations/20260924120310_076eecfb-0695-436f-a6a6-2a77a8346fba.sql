CREATE OR REPLACE FUNCTION public.auto_hourly_total_on_complete()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE hrs numeric;
BEGIN
  IF NEW.booking_type = 'hourly' AND NEW.status = 'completed'
     AND COALESCE(OLD.status,'') <> 'completed' THEN
    NEW.dropoff_at := now();
    hrs := round(GREATEST(EXTRACT(EPOCH FROM (NEW.dropoff_at - NEW.pickup_at)) / 3600.0, 0)::numeric, 2);
    NEW.hours := hrs;
    NEW.driver_total_hours := hrs;
    NEW.waiting_minutes := 0;
    NEW.driver_waiting_hours := 0;
    NEW.driver_waiting_pay := 0;
  END IF;
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS trg_auto_hourly_total ON public.reservations;
CREATE TRIGGER trg_auto_hourly_total BEFORE UPDATE OF status ON public.reservations
FOR EACH ROW EXECUTE FUNCTION public.auto_hourly_total_on_complete();