ALTER TABLE public.reservations
  ADD COLUMN IF NOT EXISTS auth_payment_intent_id text,
  ADD COLUMN IF NOT EXISTS auth_amount numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS auth_status text,
  ADD COLUMN IF NOT EXISTS authorized_at timestamptz,
  ADD COLUMN IF NOT EXISTS auth_captured_amount numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS auth_captured_at timestamptz,
  ADD COLUMN IF NOT EXISTS auth_card_last4 text,
  ADD COLUMN IF NOT EXISTS auth_card_brand text;