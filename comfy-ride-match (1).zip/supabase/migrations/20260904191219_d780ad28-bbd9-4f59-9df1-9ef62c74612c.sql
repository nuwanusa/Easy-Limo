ALTER TABLE public.reservations
  ADD COLUMN parking_fee numeric NOT NULL DEFAULT 0;