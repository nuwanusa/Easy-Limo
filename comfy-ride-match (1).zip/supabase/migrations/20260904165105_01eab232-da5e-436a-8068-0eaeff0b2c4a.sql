ALTER TABLE public.reservations
  ADD COLUMN IF NOT EXISTS airport_name text,
  ADD COLUMN IF NOT EXISTS flight_direction text NOT NULL DEFAULT 'none',
  ADD COLUMN IF NOT EXISTS terminal_level text,
  ADD COLUMN IF NOT EXISTS door_number text;