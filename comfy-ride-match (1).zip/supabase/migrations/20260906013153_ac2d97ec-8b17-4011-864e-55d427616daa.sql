ALTER TABLE public.reservations
  ADD COLUMN IF NOT EXISTS airline text,
  ADD COLUMN IF NOT EXISTS payment_method text;