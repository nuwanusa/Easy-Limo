INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::public.app_role FROM auth.users WHERE email = 'nuwanusa@gmail.com'
ON CONFLICT (user_id, role) DO NOTHING;

DELETE FROM public.user_roles
WHERE role = 'dispatcher'::public.app_role
  AND user_id IN (SELECT id FROM auth.users WHERE email = 'nuwanusa@gmail.com');