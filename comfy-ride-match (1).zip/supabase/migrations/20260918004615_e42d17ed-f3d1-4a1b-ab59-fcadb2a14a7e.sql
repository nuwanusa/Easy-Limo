CREATE TABLE public.ride_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reservation_id uuid NOT NULL REFERENCES public.reservations(id) ON DELETE CASCADE,
  client_id uuid REFERENCES public.clients(id) ON DELETE SET NULL,
  company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating BETWEEN 1 AND 5),
  tags text[] NOT NULL DEFAULT '{}',
  comment text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (reservation_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.ride_reviews TO authenticated;
GRANT ALL ON public.ride_reviews TO service_role;

ALTER TABLE public.ride_reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Client users read their reviews" ON public.ride_reviews
FOR SELECT TO authenticated
USING (EXISTS (SELECT 1 FROM public.client_users cu WHERE cu.user_id = auth.uid() AND cu.client_id = ride_reviews.client_id));

CREATE POLICY "Staff manage ride reviews" ON public.ride_reviews
FOR ALL TO authenticated
USING ((EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id = auth.uid() AND ur.role = ANY (ARRAY['admin'::app_role,'dispatcher'::app_role]))) AND company_id = private.current_company_id())
WITH CHECK ((EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id = auth.uid() AND ur.role = ANY (ARRAY['admin'::app_role,'dispatcher'::app_role]))) AND company_id = private.current_company_id());

CREATE TRIGGER ride_reviews_updated_at BEFORE UPDATE ON public.ride_reviews
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();