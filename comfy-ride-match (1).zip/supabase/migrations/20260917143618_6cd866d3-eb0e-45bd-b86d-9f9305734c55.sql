-- 1. Companies
CREATE TABLE public.companies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text NOT NULL UNIQUE,
  contact_email text,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.companies TO authenticated;
GRANT ALL ON public.companies TO service_role;
ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER companies_updated_at BEFORE UPDATE ON public.companies
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.company_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  must_change_password boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id)
);
GRANT SELECT, UPDATE ON public.company_users TO authenticated;
GRANT ALL ON public.company_users TO service_role;
ALTER TABLE public.company_users ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER company_users_updated_at BEFORE UPDATE ON public.company_users
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.platform_owners (
  user_id uuid PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.platform_owners TO authenticated;
GRANT ALL ON public.platform_owners TO service_role;
ALTER TABLE public.platform_owners ENABLE ROW LEVEL SECURITY;

-- 2. Helper functions
CREATE OR REPLACE FUNCTION private.current_company_id()
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = private, public AS $$
  SELECT company_id FROM public.company_users WHERE user_id = auth.uid()
$$;

CREATE OR REPLACE FUNCTION private.is_platform_owner()
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = private, public AS $$
  SELECT EXISTS (SELECT 1 FROM public.platform_owners WHERE user_id = auth.uid())
$$;

-- 3. Seed the first company and its members
INSERT INTO public.companies (id, name, code, contact_email)
VALUES ('00000000-0000-0000-0000-000000000001', 'Blackwave Transportation LLC', 'BLACKWAVE', 'info@rideblackwave.com');

INSERT INTO public.company_users (user_id, company_id)
SELECT DISTINCT ur.user_id, '00000000-0000-0000-0000-000000000001'::uuid
FROM public.user_roles ur
ON CONFLICT (user_id) DO NOTHING;

INSERT INTO public.company_users (user_id, company_id)
SELECT DISTINCT cu.user_id, '00000000-0000-0000-0000-000000000001'::uuid
FROM public.client_users cu
ON CONFLICT (user_id) DO NOTHING;

INSERT INTO public.company_users (user_id, company_id)
SELECT DISTINCT d.user_id, '00000000-0000-0000-0000-000000000001'::uuid
FROM public.drivers d WHERE d.user_id IS NOT NULL
ON CONFLICT (user_id) DO NOTHING;

INSERT INTO public.platform_owners (user_id)
SELECT DISTINCT user_id FROM public.user_roles WHERE role = 'admin'
ON CONFLICT (user_id) DO NOTHING;

-- 4. Company column on every top-level table
ALTER TABLE public.clients        ADD COLUMN company_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001' REFERENCES public.companies(id);
ALTER TABLE public.drivers        ADD COLUMN company_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001' REFERENCES public.companies(id);
ALTER TABLE public.vehicles       ADD COLUMN company_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001' REFERENCES public.companies(id);
ALTER TABLE public.reservations   ADD COLUMN company_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001' REFERENCES public.companies(id);
ALTER TABLE public.invoices       ADD COLUMN company_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001' REFERENCES public.companies(id);
ALTER TABLE public.quote_requests ADD COLUMN company_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001' REFERENCES public.companies(id);
ALTER TABLE public.zone_rates     ADD COLUMN company_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001' REFERENCES public.companies(id);
ALTER TABLE public.ride_disputes  ADD COLUMN company_id uuid NOT NULL DEFAULT '00000000-0000-0000-0000-000000000001' REFERENCES public.companies(id);

CREATE INDEX idx_clients_company ON public.clients(company_id);
CREATE INDEX idx_drivers_company ON public.drivers(company_id);
CREATE INDEX idx_vehicles_company ON public.vehicles(company_id);
CREATE INDEX idx_reservations_company ON public.reservations(company_id);
CREATE INDEX idx_invoices_company ON public.invoices(company_id);
CREATE INDEX idx_quote_requests_company ON public.quote_requests(company_id);
CREATE INDEX idx_zone_rates_company ON public.zone_rates(company_id);
CREATE INDEX idx_ride_disputes_company ON public.ride_disputes(company_id);

-- 5. Policies on the new tables
CREATE POLICY "members read their company" ON public.companies FOR SELECT TO authenticated
  USING (id = private.current_company_id() OR private.is_platform_owner());
CREATE POLICY "platform owners read owners" ON public.platform_owners FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR private.is_platform_owner());
CREATE POLICY "read own membership" ON public.company_users FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR company_id = private.current_company_id() OR private.is_platform_owner());
CREATE POLICY "clear own password flag" ON public.company_users FOR UPDATE TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- 6. Scope staff policies to the caller's company
DROP POLICY "staff manage clients" ON public.clients;
CREATE POLICY "staff manage clients" ON public.clients FOR ALL TO authenticated
  USING ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid())) AND company_id = private.current_company_id())
  WITH CHECK ((NOT private.is_driver(auth.uid())) AND company_id = private.current_company_id());

DROP POLICY "staff manage drivers" ON public.drivers;
CREATE POLICY "staff manage drivers" ON public.drivers FOR ALL TO authenticated
  USING ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid())) AND company_id = private.current_company_id())
  WITH CHECK ((NOT private.is_driver(auth.uid())) AND company_id = private.current_company_id());

DROP POLICY "staff manage vehicles" ON public.vehicles;
CREATE POLICY "staff manage vehicles" ON public.vehicles FOR ALL TO authenticated
  USING ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid())) AND company_id = private.current_company_id())
  WITH CHECK ((NOT private.is_driver(auth.uid())) AND company_id = private.current_company_id());

DROP POLICY "staff manage reservations" ON public.reservations;
CREATE POLICY "staff manage reservations" ON public.reservations FOR ALL TO authenticated
  USING ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid())) AND company_id = private.current_company_id())
  WITH CHECK ((NOT private.is_driver(auth.uid())) AND company_id = private.current_company_id());

DROP POLICY "staff manage invoices" ON public.invoices;
CREATE POLICY "staff manage invoices" ON public.invoices FOR ALL TO authenticated
  USING ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid())) AND company_id = private.current_company_id())
  WITH CHECK ((NOT private.is_driver(auth.uid())) AND company_id = private.current_company_id());

DROP POLICY "staff manage zone rates" ON public.zone_rates;
CREATE POLICY "staff manage zone rates" ON public.zone_rates FOR ALL TO authenticated
  USING ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid())) AND company_id = private.current_company_id())
  WITH CHECK ((NOT private.is_driver(auth.uid())) AND company_id = private.current_company_id());

DROP POLICY "Staff can read quote requests" ON public.quote_requests;
CREATE POLICY "Staff can read quote requests" ON public.quote_requests FOR SELECT TO authenticated
  USING ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid())) AND company_id = private.current_company_id());
DROP POLICY "Staff can update quote requests" ON public.quote_requests;
CREATE POLICY "Staff can update quote requests" ON public.quote_requests FOR UPDATE TO authenticated
  USING ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid())) AND company_id = private.current_company_id());
DROP POLICY "Staff can delete quote requests" ON public.quote_requests;
CREATE POLICY "Staff can delete quote requests" ON public.quote_requests FOR DELETE TO authenticated
  USING ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid())) AND company_id = private.current_company_id());

DROP POLICY "Staff manage ride disputes" ON public.ride_disputes;
CREATE POLICY "Staff manage ride disputes" ON public.ride_disputes FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id = auth.uid() AND ur.role = ANY (ARRAY['admin'::app_role,'dispatcher'::app_role])) AND company_id = private.current_company_id())
  WITH CHECK (EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id = auth.uid() AND ur.role = ANY (ARRAY['admin'::app_role,'dispatcher'::app_role])) AND company_id = private.current_company_id());

DROP POLICY "Staff can view saved cards" ON public.client_cards;
CREATE POLICY "Staff can view saved cards" ON public.client_cards FOR SELECT TO authenticated
  USING ((private.has_role(auth.uid(),'admin'::app_role) OR private.has_role(auth.uid(),'dispatcher'::app_role))
    AND EXISTS (SELECT 1 FROM public.clients c WHERE c.id = client_cards.client_id AND c.company_id = private.current_company_id()));
DROP POLICY "Staff can remove saved cards" ON public.client_cards;
CREATE POLICY "Staff can remove saved cards" ON public.client_cards FOR DELETE TO authenticated
  USING ((private.has_role(auth.uid(),'admin'::app_role) OR private.has_role(auth.uid(),'dispatcher'::app_role))
    AND EXISTS (SELECT 1 FROM public.clients c WHERE c.id = client_cards.client_id AND c.company_id = private.current_company_id()));