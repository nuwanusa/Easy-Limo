ALTER TABLE public.clients ADD COLUMN IF NOT EXISTS portal_token text UNIQUE;

CREATE TABLE IF NOT EXISTS public.client_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  email text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.client_users TO authenticated;
GRANT ALL ON public.client_users TO service_role;

ALTER TABLE public.client_users ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION private.current_client_id()
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = private, public AS $$
  SELECT client_id FROM public.client_users WHERE user_id = auth.uid() LIMIT 1
$$;

CREATE OR REPLACE FUNCTION private.is_client(_uid uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = private, public AS $$
  SELECT EXISTS (SELECT 1 FROM public.client_users WHERE user_id = _uid)
$$;

CREATE POLICY "staff manage client users" ON public.client_users FOR ALL TO authenticated
  USING (NOT private.is_driver(auth.uid()) AND NOT private.is_client(auth.uid()))
  WITH CHECK (NOT private.is_driver(auth.uid()) AND NOT private.is_client(auth.uid()));

CREATE POLICY "client reads own link" ON public.client_users FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE TRIGGER client_users_updated_at BEFORE UPDATE ON public.client_users
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Keep client accounts out of every staff-managed table
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT tablename, policyname FROM pg_policies
    WHERE schemaname = 'public' AND qual::text = '(NOT private.is_driver(auth.uid()))'
  LOOP
    EXECUTE format(
      'ALTER POLICY %I ON public.%I USING (NOT private.is_driver(auth.uid()) AND NOT private.is_client(auth.uid()))',
      r.policyname, r.tablename);
  END LOOP;
END $$;

CREATE POLICY "client reads own company" ON public.clients FOR SELECT TO authenticated
  USING (id = private.current_client_id());

CREATE POLICY "client reads own invoices" ON public.invoices FOR SELECT TO authenticated
  USING (client_id = private.current_client_id());

CREATE POLICY "client reads own rides" ON public.reservations FOR SELECT TO authenticated
  USING (client_id = private.current_client_id());

CREATE POLICY "client reads own ride stops" ON public.reservation_stops FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.reservations r
                 WHERE r.id = reservation_stops.reservation_id
                   AND r.client_id = private.current_client_id()));