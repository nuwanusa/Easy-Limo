ALTER TABLE public.clients
  ADD COLUMN IF NOT EXISTS booking_contact_name text,
  ADD COLUMN IF NOT EXISTS booking_contact_phone text,
  ADD COLUMN IF NOT EXISTS booking_contact_email text,
  ADD COLUMN IF NOT EXISTS billing_contact_phone text,
  ADD COLUMN IF NOT EXISTS billing_contact_email text;

CREATE TABLE IF NOT EXISTS public.client_passengers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  phone text,
  email text,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.client_passengers TO authenticated;
GRANT ALL ON public.client_passengers TO service_role;

ALTER TABLE public.client_passengers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "staff manage client passengers" ON public.client_passengers
  FOR ALL TO authenticated
  USING (NOT private.is_driver(auth.uid()))
  WITH CHECK (NOT private.is_driver(auth.uid()));

CREATE INDEX IF NOT EXISTS client_passengers_client_id_idx ON public.client_passengers(client_id);

CREATE TRIGGER client_passengers_updated_at BEFORE UPDATE ON public.client_passengers
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();