CREATE TABLE public.message_threads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  party_type text NOT NULL CHECK (party_type IN ('client', 'driver')),
  client_id uuid REFERENCES public.clients(id) ON DELETE CASCADE,
  driver_id uuid REFERENCES public.drivers(id) ON DELETE CASCADE,
  last_message_at timestamptz NOT NULL DEFAULT now(),
  admin_read_at timestamptz,
  participant_read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT message_thread_party_matches CHECK (
    (party_type = 'client' AND client_id IS NOT NULL AND driver_id IS NULL)
    OR (party_type = 'driver' AND driver_id IS NOT NULL AND client_id IS NULL)
  )
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.message_threads TO authenticated;
GRANT ALL ON public.message_threads TO service_role;

ALTER TABLE public.message_threads ENABLE ROW LEVEL SECURITY;

CREATE UNIQUE INDEX message_threads_client_unique
  ON public.message_threads (company_id, client_id)
  WHERE client_id IS NOT NULL;
CREATE UNIQUE INDEX message_threads_driver_unique
  ON public.message_threads (company_id, driver_id)
  WHERE driver_id IS NOT NULL;
CREATE INDEX message_threads_company_activity_idx
  ON public.message_threads (company_id, last_message_at DESC);

CREATE POLICY "Company staff can view message threads"
ON public.message_threads FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.company_users cu
    JOIN public.user_roles ur ON ur.user_id = cu.user_id
    WHERE cu.user_id = auth.uid()
      AND cu.company_id = message_threads.company_id
      AND ur.role IN ('admin', 'dispatcher')
  )
);

CREATE POLICY "Drivers can view their message thread"
ON public.message_threads FOR SELECT TO authenticated
USING (
  party_type = 'driver'
  AND EXISTS (
    SELECT 1 FROM public.drivers d
    WHERE d.id = message_threads.driver_id
      AND d.user_id = auth.uid()
      AND d.company_id = message_threads.company_id
  )
);

CREATE POLICY "Clients can view their message thread"
ON public.message_threads FOR SELECT TO authenticated
USING (
  party_type = 'client'
  AND EXISTS (
    SELECT 1 FROM public.client_users cu
    JOIN public.clients c ON c.id = cu.client_id
    WHERE cu.user_id = auth.uid()
      AND cu.client_id = message_threads.client_id
      AND c.company_id = message_threads.company_id
  )
);

CREATE POLICY "Company staff can create message threads"
ON public.message_threads FOR INSERT TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.company_users cu
    JOIN public.user_roles ur ON ur.user_id = cu.user_id
    WHERE cu.user_id = auth.uid()
      AND cu.company_id = message_threads.company_id
      AND ur.role IN ('admin', 'dispatcher')
  )
);

CREATE POLICY "Drivers can create their message thread"
ON public.message_threads FOR INSERT TO authenticated
WITH CHECK (
  party_type = 'driver'
  AND EXISTS (
    SELECT 1 FROM public.drivers d
    WHERE d.id = message_threads.driver_id
      AND d.user_id = auth.uid()
      AND d.company_id = message_threads.company_id
  )
);

CREATE POLICY "Clients can create their message thread"
ON public.message_threads FOR INSERT TO authenticated
WITH CHECK (
  party_type = 'client'
  AND EXISTS (
    SELECT 1 FROM public.client_users cu
    JOIN public.clients c ON c.id = cu.client_id
    WHERE cu.user_id = auth.uid()
      AND cu.client_id = message_threads.client_id
      AND c.company_id = message_threads.company_id
  )
);

CREATE POLICY "Company staff can update message threads"
ON public.message_threads FOR UPDATE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.company_users cu
    JOIN public.user_roles ur ON ur.user_id = cu.user_id
    WHERE cu.user_id = auth.uid()
      AND cu.company_id = message_threads.company_id
      AND ur.role IN ('admin', 'dispatcher')
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.company_users cu
    JOIN public.user_roles ur ON ur.user_id = cu.user_id
    WHERE cu.user_id = auth.uid()
      AND cu.company_id = message_threads.company_id
      AND ur.role IN ('admin', 'dispatcher')
  )
);

CREATE POLICY "Drivers can update their message thread"
ON public.message_threads FOR UPDATE TO authenticated
USING (
  party_type = 'driver'
  AND EXISTS (
    SELECT 1 FROM public.drivers d
    WHERE d.id = message_threads.driver_id
      AND d.user_id = auth.uid()
      AND d.company_id = message_threads.company_id
  )
)
WITH CHECK (
  party_type = 'driver'
  AND EXISTS (
    SELECT 1 FROM public.drivers d
    WHERE d.id = message_threads.driver_id
      AND d.user_id = auth.uid()
      AND d.company_id = message_threads.company_id
  )
);

CREATE POLICY "Clients can update their message thread"
ON public.message_threads FOR UPDATE TO authenticated
USING (
  party_type = 'client'
  AND EXISTS (
    SELECT 1 FROM public.client_users cu
    JOIN public.clients c ON c.id = cu.client_id
    WHERE cu.user_id = auth.uid()
      AND cu.client_id = message_threads.client_id
      AND c.company_id = message_threads.company_id
  )
)
WITH CHECK (
  party_type = 'client'
  AND EXISTS (
    SELECT 1 FROM public.client_users cu
    JOIN public.clients c ON c.id = cu.client_id
    WHERE cu.user_id = auth.uid()
      AND cu.client_id = message_threads.client_id
      AND c.company_id = message_threads.company_id
  )
);

CREATE TABLE public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id uuid NOT NULL REFERENCES public.message_threads(id) ON DELETE CASCADE,
  sender_user_id uuid NOT NULL,
  sender_type text NOT NULL CHECK (sender_type IN ('admin', 'client', 'driver')),
  body text NOT NULL CHECK (char_length(btrim(body)) BETWEEN 1 AND 2000),
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.messages TO authenticated;
GRANT ALL ON public.messages TO service_role;

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

CREATE INDEX messages_thread_created_idx ON public.messages (thread_id, created_at);

CREATE POLICY "Thread members can view messages"
ON public.messages FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.message_threads mt
    WHERE mt.id = messages.thread_id
  )
);

CREATE POLICY "Thread members can send messages"
ON public.messages FOR INSERT TO authenticated
WITH CHECK (
  sender_user_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM public.message_threads mt
    WHERE mt.id = messages.thread_id
  )
  AND (
    (sender_type = 'admin' AND EXISTS (
      SELECT 1 FROM public.message_threads mt
      JOIN public.company_users cu ON cu.company_id = mt.company_id AND cu.user_id = auth.uid()
      JOIN public.user_roles ur ON ur.user_id = auth.uid()
      WHERE mt.id = messages.thread_id AND ur.role IN ('admin', 'dispatcher')
    ))
    OR (sender_type = 'driver' AND EXISTS (
      SELECT 1 FROM public.message_threads mt
      JOIN public.drivers d ON d.id = mt.driver_id
      WHERE mt.id = messages.thread_id AND d.user_id = auth.uid()
    ))
    OR (sender_type = 'client' AND EXISTS (
      SELECT 1 FROM public.message_threads mt
      JOIN public.client_users cu ON cu.client_id = mt.client_id
      WHERE mt.id = messages.thread_id AND cu.user_id = auth.uid()
    ))
  )
);

CREATE TRIGGER message_threads_updated_at
BEFORE UPDATE ON public.message_threads
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE OR REPLACE FUNCTION public.touch_message_thread()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.message_threads
  SET last_message_at = NEW.created_at,
      admin_read_at = CASE WHEN NEW.sender_type = 'admin' THEN NEW.created_at ELSE admin_read_at END,
      participant_read_at = CASE WHEN NEW.sender_type IN ('client', 'driver') THEN NEW.created_at ELSE participant_read_at END
  WHERE id = NEW.thread_id;
  RETURN NEW;
END;
$$;

CREATE TRIGGER messages_touch_thread
AFTER INSERT ON public.messages
FOR EACH ROW EXECUTE FUNCTION public.touch_message_thread();

ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;