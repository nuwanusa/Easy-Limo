ALTER TABLE public.reservations
  ADD COLUMN IF NOT EXISTS driver_hourly_pay numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS driver_minimum_hours numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS driver_total_hours numeric NOT NULL DEFAULT 0;