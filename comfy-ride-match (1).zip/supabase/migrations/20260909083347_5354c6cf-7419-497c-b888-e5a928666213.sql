CREATE TABLE public.quote_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  email text NOT NULL,
  phone text,
  company text,
  service_type text NOT NULL DEFAULT 'transfer',
  pickup_address text,
  dropoff_address text,
  pickup_at timestamptz,
  passenger_count integer NOT NULL DEFAULT 1,
  vehicle_class text,
  notes text,
  status text NOT NULL DEFAULT 'new',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT INSERT ON public.quote_requests TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.quote_requests TO authenticated;
GRANT ALL ON public.quote_requests TO service_role;

ALTER TABLE public.quote_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit a quote request"
  ON public.quote_requests FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE POLICY "Staff can read quote requests"
  ON public.quote_requests FOR SELECT TO authenticated
  USING (NOT private.is_driver(auth.uid()) AND NOT private.is_client(auth.uid()));

CREATE POLICY "Staff can update quote requests"
  ON public.quote_requests FOR UPDATE TO authenticated
  USING (NOT private.is_driver(auth.uid()) AND NOT private.is_client(auth.uid()));

CREATE POLICY "Staff can delete quote requests"
  ON public.quote_requests FOR DELETE TO authenticated
  USING (NOT private.is_driver(auth.uid()) AND NOT private.is_client(auth.uid()));

CREATE TRIGGER quote_requests_updated_at BEFORE UPDATE ON public.quote_requests
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();