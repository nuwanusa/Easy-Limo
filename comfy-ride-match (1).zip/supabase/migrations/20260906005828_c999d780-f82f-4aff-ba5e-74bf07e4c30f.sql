ALTER TABLE public.clients
  ADD COLUMN IF NOT EXISTS notify_reservation boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS notify_driver_accepted boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS notify_ride_reminder boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS notify_invoice boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS notify_payment boolean NOT NULL DEFAULT true;

ALTER TABLE public.reservations
  ADD COLUMN IF NOT EXISTS reminder_sent_at timestamptz;