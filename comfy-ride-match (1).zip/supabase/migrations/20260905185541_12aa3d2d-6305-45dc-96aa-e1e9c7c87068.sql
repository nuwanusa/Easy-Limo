CREATE UNIQUE INDEX IF NOT EXISTS drivers_default_vehicle_unique
  ON public.drivers (default_vehicle_id)
  WHERE default_vehicle_id IS NOT NULL;