CREATE OR REPLACE FUNCTION public.guard_completed_reservation_delete()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF OLD.status = 'completed'
     AND NOT EXISTS (
       SELECT 1 FROM public.user_roles
       WHERE user_id = auth.uid() AND role = 'admin'
     ) THEN
    RAISE EXCEPTION 'Only the main admin can delete a completed reservation.';
  END IF;
  RETURN OLD;
END;
$$;

DROP TRIGGER IF EXISTS trg_guard_completed_reservation_delete ON public.reservations;
CREATE TRIGGER trg_guard_completed_reservation_delete
BEFORE DELETE ON public.reservations
FOR EACH ROW EXECUTE FUNCTION public.guard_completed_reservation_delete();