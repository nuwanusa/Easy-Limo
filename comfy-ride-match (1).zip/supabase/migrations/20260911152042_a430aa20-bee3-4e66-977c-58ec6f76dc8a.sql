ALTER TABLE public.quote_requests
  ADD COLUMN IF NOT EXISTS stops jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS luggage_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS round_trip boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS quote_amount numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS quote_message text,
  ADD COLUMN IF NOT EXISTS quote_valid_until date,
  ADD COLUMN IF NOT EXISTS quote_sent_at timestamptz;