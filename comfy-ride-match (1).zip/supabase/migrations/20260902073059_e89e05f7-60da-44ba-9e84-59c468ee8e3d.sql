-- Harden helper functions: no direct calls with arbitrary user ids
CREATE OR REPLACE FUNCTION public.is_driver(_uid uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.drivers d WHERE d.user_id = _uid AND _uid = auth.uid())
$$;

REVOKE EXECUTE ON FUNCTION public.is_driver(uuid) FROM authenticated, anon, public;
REVOKE EXECUTE ON FUNCTION public.current_driver_id() FROM authenticated, anon, public;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM authenticated, anon, public;

-- Vehicles: drivers only see vehicles tied to their own assigned trips
DROP POLICY IF EXISTS "drivers read vehicles" ON public.vehicles;
CREATE POLICY "drivers read assigned vehicles" ON public.vehicles
FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.reservations r
    WHERE r.vehicle_id = vehicles.id
      AND r.driver_id = public.current_driver_id()
  )
);
