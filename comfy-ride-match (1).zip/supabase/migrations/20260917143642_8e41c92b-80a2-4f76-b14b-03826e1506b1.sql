ALTER TABLE public.clients        ALTER COLUMN company_id SET DEFAULT private.current_company_id();
ALTER TABLE public.drivers        ALTER COLUMN company_id SET DEFAULT private.current_company_id();
ALTER TABLE public.vehicles       ALTER COLUMN company_id SET DEFAULT private.current_company_id();
ALTER TABLE public.reservations   ALTER COLUMN company_id SET DEFAULT private.current_company_id();
ALTER TABLE public.invoices       ALTER COLUMN company_id SET DEFAULT private.current_company_id();
ALTER TABLE public.zone_rates     ALTER COLUMN company_id SET DEFAULT private.current_company_id();
ALTER TABLE public.ride_disputes  ALTER COLUMN company_id SET DEFAULT private.current_company_id();
-- public quote requests come from the marketing site (Blackwave)
ALTER TABLE public.quote_requests ALTER COLUMN company_id SET DEFAULT
  COALESCE(private.current_company_id(), '00000000-0000-0000-0000-000000000001'::uuid);