DROP POLICY "staff manage client passengers" ON public.client_passengers;
CREATE POLICY "staff manage client passengers" ON public.client_passengers FOR ALL TO authenticated
  USING ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid()))
    AND EXISTS (SELECT 1 FROM public.clients c WHERE c.id = client_passengers.client_id AND c.company_id = private.current_company_id()))
  WITH CHECK ((NOT private.is_driver(auth.uid()))
    AND EXISTS (SELECT 1 FROM public.clients c WHERE c.id = client_passengers.client_id AND c.company_id = private.current_company_id()));

DROP POLICY "staff manage client rates" ON public.client_rates;
CREATE POLICY "staff manage client rates" ON public.client_rates FOR ALL TO authenticated
  USING ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid()))
    AND EXISTS (SELECT 1 FROM public.clients c WHERE c.id = client_rates.client_id AND c.company_id = private.current_company_id()))
  WITH CHECK ((NOT private.is_driver(auth.uid()))
    AND EXISTS (SELECT 1 FROM public.clients c WHERE c.id = client_rates.client_id AND c.company_id = private.current_company_id()));

DROP POLICY "staff manage client users" ON public.client_users;
CREATE POLICY "staff manage client users" ON public.client_users FOR ALL TO authenticated
  USING ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid()))
    AND EXISTS (SELECT 1 FROM public.clients c WHERE c.id = client_users.client_id AND c.company_id = private.current_company_id()))
  WITH CHECK ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid()))
    AND EXISTS (SELECT 1 FROM public.clients c WHERE c.id = client_users.client_id AND c.company_id = private.current_company_id()));

DROP POLICY "staff manage reservation stops" ON public.reservation_stops;
CREATE POLICY "staff manage reservation stops" ON public.reservation_stops FOR ALL TO authenticated
  USING ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid()))
    AND EXISTS (SELECT 1 FROM public.reservations r WHERE r.id = reservation_stops.reservation_id AND r.company_id = private.current_company_id()))
  WITH CHECK ((NOT private.is_driver(auth.uid()))
    AND EXISTS (SELECT 1 FROM public.reservations r WHERE r.id = reservation_stops.reservation_id AND r.company_id = private.current_company_id()));

DROP POLICY "staff manage trip events" ON public.reservation_status_events;
CREATE POLICY "staff manage trip events" ON public.reservation_status_events FOR ALL TO authenticated
  USING ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid()))
    AND EXISTS (SELECT 1 FROM public.reservations r WHERE r.id = reservation_status_events.reservation_id AND r.company_id = private.current_company_id()))
  WITH CHECK ((NOT private.is_driver(auth.uid()))
    AND EXISTS (SELECT 1 FROM public.reservations r WHERE r.id = reservation_status_events.reservation_id AND r.company_id = private.current_company_id()));

DROP POLICY "staff manage trip receipts" ON public.reservation_receipts;
CREATE POLICY "staff manage trip receipts" ON public.reservation_receipts FOR ALL TO authenticated
  USING ((NOT private.is_driver(auth.uid())) AND (NOT private.is_client(auth.uid()))
    AND EXISTS (SELECT 1 FROM public.reservations r WHERE r.id = reservation_receipts.reservation_id AND r.company_id = private.current_company_id()))
  WITH CHECK ((NOT private.is_driver(auth.uid()))
    AND EXISTS (SELECT 1 FROM public.reservations r WHERE r.id = reservation_receipts.reservation_id AND r.company_id = private.current_company_id()));

DROP POLICY "Signed-in users can view ride track points" ON public.ride_track_points;
CREATE POLICY "Signed-in users can view ride track points" ON public.ride_track_points FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.reservations r WHERE r.id = ride_track_points.reservation_id
    AND (r.company_id = private.current_company_id() OR r.driver_id = private.current_driver_id())));

DROP POLICY "Signed-in users can add ride track points" ON public.ride_track_points;
CREATE POLICY "Signed-in users can add ride track points" ON public.ride_track_points FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.reservations r WHERE r.id = ride_track_points.reservation_id
    AND (r.company_id = private.current_company_id() OR r.driver_id = private.current_driver_id())));