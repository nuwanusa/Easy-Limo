REVOKE EXECUTE ON FUNCTION public.is_driver(uuid) FROM anon, authenticated, public;
REVOKE EXECUTE ON FUNCTION public.current_driver_id() FROM anon, authenticated, public;