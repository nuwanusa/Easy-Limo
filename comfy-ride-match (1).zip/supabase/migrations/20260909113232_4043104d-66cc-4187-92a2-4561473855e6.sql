ALTER TABLE public.clients ADD COLUMN IF NOT EXISTS portal_code text;

UPDATE public.clients
SET portal_code = lpad((100000 + floor(random() * 900000))::int::text, 6, '0')
WHERE portal_code IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS clients_portal_code_key ON public.clients (portal_code) WHERE portal_code IS NOT NULL;