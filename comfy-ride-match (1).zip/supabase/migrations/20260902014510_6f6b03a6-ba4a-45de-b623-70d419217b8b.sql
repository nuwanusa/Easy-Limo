ALTER TABLE public.reservations
  ADD COLUMN IF NOT EXISTS booking_type text NOT NULL DEFAULT 'point_to_point',
  ADD COLUMN IF NOT EXISTS hourly_rate numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS hours numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS minimum_hours numeric NOT NULL DEFAULT 3,
  ADD COLUMN IF NOT EXISTS stop_fee numeric NOT NULL DEFAULT 15;

CREATE TABLE IF NOT EXISTS public.reservation_stops (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reservation_id uuid NOT NULL REFERENCES public.reservations(id) ON DELETE CASCADE,
  position integer NOT NULL DEFAULT 1,
  address text NOT NULL,
  stop_at timestamp with time zone,
  note text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.reservation_stops TO authenticated;
GRANT ALL ON public.reservation_stops TO service_role;

ALTER TABLE public.reservation_stops ENABLE ROW LEVEL SECURITY;

CREATE POLICY "staff manage reservation stops" ON public.reservation_stops
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE TRIGGER reservation_stops_updated_at
  BEFORE UPDATE ON public.reservation_stops
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX IF NOT EXISTS reservation_stops_reservation_idx
  ON public.reservation_stops (reservation_id, position);