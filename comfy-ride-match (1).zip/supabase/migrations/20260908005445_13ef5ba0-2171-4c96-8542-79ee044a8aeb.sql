ALTER TABLE public.drivers
  ADD COLUMN IF NOT EXISTS payout_method text,
  ADD COLUMN IF NOT EXISTS payout_handle text,
  ADD COLUMN IF NOT EXISTS payout_bank_name text,
  ADD COLUMN IF NOT EXISTS payout_routing_number text,
  ADD COLUMN IF NOT EXISTS payout_account_number text;