
create table public.affiliates (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  name text not null,
  kind text not null default 'operator',
  contact_name text,
  email text,
  phone text,
  address_line1 text,
  city text,
  state text,
  postal_code text,
  default_percent numeric not null default 0,
  referral_percent numeric not null default 0,
  status text not null default 'active',
  portal_code text not null default lpad((floor(random()*1000000))::int::text, 6, '0'),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index affiliates_portal_code_key on public.affiliates(portal_code);
create index affiliates_company_idx on public.affiliates(company_id);

create table public.affiliate_statements (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  affiliate_id uuid not null references public.affiliates(id) on delete cascade,
  statement_number text not null,
  period_start date,
  period_end date,
  total numeric not null default 0,
  status text not null default 'open',
  notes text,
  sent_at timestamptz,
  paid_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index affiliate_statements_affiliate_idx on public.affiliate_statements(affiliate_id);

create table public.affiliate_earnings (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  affiliate_id uuid not null references public.affiliates(id) on delete cascade,
  reservation_id uuid references public.reservations(id) on delete cascade,
  kind text not null default 'farm_out',
  amount numeric not null default 0,
  statement_id uuid references public.affiliate_statements(id) on delete set null,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index affiliate_earnings_unique_ride on public.affiliate_earnings(reservation_id, affiliate_id, kind) where reservation_id is not null;
create index affiliate_earnings_affiliate_idx on public.affiliate_earnings(affiliate_id);

alter table public.reservations
  add column affiliate_id uuid references public.affiliates(id) on delete set null,
  add column affiliate_payout numeric not null default 0,
  add column affiliate_percent numeric not null default 0,
  add column affiliate_status text,
  add column affiliate_driver_name text,
  add column affiliate_driver_phone text,
  add column affiliate_vehicle text,
  add column affiliate_notes text;

alter table public.clients
  add column referred_by_affiliate_id uuid references public.affiliates(id) on delete set null,
  add column referral_percent numeric not null default 0;

grant select, insert, update, delete on public.affiliates to authenticated;
grant all on public.affiliates to service_role;
grant select, insert, update, delete on public.affiliate_statements to authenticated;
grant all on public.affiliate_statements to service_role;
grant select, insert, update, delete on public.affiliate_earnings to authenticated;
grant all on public.affiliate_earnings to service_role;

alter table public.affiliates enable row level security;
alter table public.affiliate_statements enable row level security;
alter table public.affiliate_earnings enable row level security;

create policy "staff manage affiliates" on public.affiliates for all
  using (private.is_staff(auth.uid()) and company_id = private.current_company_id())
  with check (private.is_staff(auth.uid()) and company_id = private.current_company_id());

create policy "staff manage affiliate statements" on public.affiliate_statements for all
  using (private.is_staff(auth.uid()) and company_id = private.current_company_id())
  with check (private.is_staff(auth.uid()) and company_id = private.current_company_id());

create policy "staff manage affiliate earnings" on public.affiliate_earnings for all
  using (private.is_staff(auth.uid()) and company_id = private.current_company_id())
  with check (private.is_staff(auth.uid()) and company_id = private.current_company_id());

create trigger affiliates_updated_at before update on public.affiliates
  for each row execute function public.set_updated_at();
create trigger affiliate_statements_updated_at before update on public.affiliate_statements
  for each row execute function public.set_updated_at();
create trigger affiliate_earnings_updated_at before update on public.affiliate_earnings
  for each row execute function public.set_updated_at();
