
ALTER TABLE public.reservations ADD COLUMN IF NOT EXISTS driver_note text;

CREATE TABLE IF NOT EXISTS public.reservation_status_events (
  id uuid primary key default gen_random_uuid(),
  reservation_id uuid not null references public.reservations(id) on delete cascade,
  status text not null,
  occurred_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
CREATE INDEX IF NOT EXISTS reservation_status_events_res_idx ON public.reservation_status_events(reservation_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.reservation_status_events TO authenticated;
GRANT ALL ON public.reservation_status_events TO service_role;
ALTER TABLE public.reservation_status_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "drivers read own trip events" ON public.reservation_status_events FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.reservations r WHERE r.id = reservation_id AND r.driver_id = private.current_driver_id()));
CREATE POLICY "drivers add own trip events" ON public.reservation_status_events FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.reservations r WHERE r.id = reservation_id AND r.driver_id = private.current_driver_id()));
CREATE POLICY "staff manage trip events" ON public.reservation_status_events FOR ALL TO authenticated
  USING (NOT private.is_driver(auth.uid())) WITH CHECK (NOT private.is_driver(auth.uid()));

CREATE TABLE IF NOT EXISTS public.reservation_receipts (
  id uuid primary key default gen_random_uuid(),
  reservation_id uuid not null references public.reservations(id) on delete cascade,
  kind text not null default 'other',
  file_path text not null,
  amount numeric not null default 0,
  created_at timestamptz not null default now()
);
CREATE INDEX IF NOT EXISTS reservation_receipts_res_idx ON public.reservation_receipts(reservation_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.reservation_receipts TO authenticated;
GRANT ALL ON public.reservation_receipts TO service_role;
ALTER TABLE public.reservation_receipts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "drivers read own trip receipts" ON public.reservation_receipts FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.reservations r WHERE r.id = reservation_id AND r.driver_id = private.current_driver_id()));
CREATE POLICY "drivers add own trip receipts" ON public.reservation_receipts FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.reservations r WHERE r.id = reservation_id AND r.driver_id = private.current_driver_id()));
CREATE POLICY "staff manage trip receipts" ON public.reservation_receipts FOR ALL TO authenticated
  USING (NOT private.is_driver(auth.uid())) WITH CHECK (NOT private.is_driver(auth.uid()));

CREATE POLICY "authenticated read ride receipts" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'ride-receipts');
CREATE POLICY "authenticated upload ride receipts" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'ride-receipts');
