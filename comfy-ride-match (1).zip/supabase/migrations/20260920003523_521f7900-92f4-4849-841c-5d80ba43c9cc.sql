ALTER TABLE public.reservations
  ADD COLUMN IF NOT EXISTS driver_waiting_hours numeric NOT NULL DEFAULT 0;