CREATE OR REPLACE FUNCTION private.is_staff(_uid uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'private', 'public'
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _uid AND role IN ('admin','dispatcher')
  )
$$;

CREATE OR REPLACE FUNCTION private.is_client(_uid uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'private', 'public'
AS $$
  SELECT EXISTS (SELECT 1 FROM public.client_users WHERE user_id = _uid)
     AND NOT private.is_staff(_uid)
$$;

CREATE OR REPLACE FUNCTION private.is_driver(_uid uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'private', 'public'
AS $$
  SELECT EXISTS (SELECT 1 FROM public.drivers d WHERE d.user_id = _uid AND _uid = auth.uid())
     AND NOT private.is_staff(_uid)
$$;