GRANT EXECUTE ON FUNCTION public.is_driver(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.current_driver_id() TO authenticated;