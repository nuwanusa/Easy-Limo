ALTER TABLE public.drivers
  ADD COLUMN IF NOT EXISTS email text,
  ADD COLUMN IF NOT EXISTS user_id uuid UNIQUE;

CREATE OR REPLACE FUNCTION public.is_driver(_uid uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.drivers WHERE user_id = _uid)
$$;

CREATE OR REPLACE FUNCTION public.current_driver_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id FROM public.drivers WHERE user_id = auth.uid() LIMIT 1
$$;

-- Reservations: staff full access, drivers read/update own trips
DROP POLICY IF EXISTS "staff manage reservations" ON public.reservations;
CREATE POLICY "staff manage reservations" ON public.reservations
  FOR ALL TO authenticated
  USING (NOT public.is_driver(auth.uid()))
  WITH CHECK (NOT public.is_driver(auth.uid()));
CREATE POLICY "drivers read own trips" ON public.reservations
  FOR SELECT TO authenticated
  USING (driver_id = public.current_driver_id());
CREATE POLICY "drivers update own trips" ON public.reservations
  FOR UPDATE TO authenticated
  USING (driver_id = public.current_driver_id())
  WITH CHECK (driver_id = public.current_driver_id());

-- Stops for own trips
CREATE POLICY "drivers read own trip stops" ON public.reservation_stops
  FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.reservations r
                 WHERE r.id = reservation_id AND r.driver_id = public.current_driver_id()));
DROP POLICY IF EXISTS "staff manage reservation stops" ON public.reservation_stops;
CREATE POLICY "staff manage reservation stops" ON public.reservation_stops
  FOR ALL TO authenticated
  USING (NOT public.is_driver(auth.uid()))
  WITH CHECK (NOT public.is_driver(auth.uid()));

-- Drivers table: staff full access, driver reads own row
DROP POLICY IF EXISTS "staff manage drivers" ON public.drivers;
CREATE POLICY "staff manage drivers" ON public.drivers
  FOR ALL TO authenticated
  USING (NOT public.is_driver(auth.uid()))
  WITH CHECK (NOT public.is_driver(auth.uid()));
CREATE POLICY "drivers read own record" ON public.drivers
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

-- Vehicles readable by drivers, managed by staff
DROP POLICY IF EXISTS "staff manage vehicles" ON public.vehicles;
CREATE POLICY "staff manage vehicles" ON public.vehicles
  FOR ALL TO authenticated
  USING (NOT public.is_driver(auth.uid()))
  WITH CHECK (NOT public.is_driver(auth.uid()));
CREATE POLICY "drivers read vehicles" ON public.vehicles
  FOR SELECT TO authenticated
  USING (true);

-- Clients / invoices: staff only
DROP POLICY IF EXISTS "staff manage clients" ON public.clients;
CREATE POLICY "staff manage clients" ON public.clients
  FOR ALL TO authenticated
  USING (NOT public.is_driver(auth.uid()))
  WITH CHECK (NOT public.is_driver(auth.uid()));

DROP POLICY IF EXISTS "staff manage invoices" ON public.invoices;
CREATE POLICY "staff manage invoices" ON public.invoices
  FOR ALL TO authenticated
  USING (NOT public.is_driver(auth.uid()))
  WITH CHECK (NOT public.is_driver(auth.uid()));