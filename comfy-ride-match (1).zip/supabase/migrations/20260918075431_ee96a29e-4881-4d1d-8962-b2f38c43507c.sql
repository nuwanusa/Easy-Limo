CREATE TABLE public.subscription_plans (
  code text PRIMARY KEY,
  name text NOT NULL,
  price_cents integer NOT NULL DEFAULT 0,
  features jsonb NOT NULL DEFAULT '[]'::jsonb,
  sort integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.subscription_plans TO authenticated;
GRANT SELECT ON public.subscription_plans TO anon;
GRANT ALL ON public.subscription_plans TO service_role;
ALTER TABLE public.subscription_plans ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Plans are readable" ON public.subscription_plans FOR SELECT USING (true);
CREATE POLICY "Platform owners manage plans" ON public.subscription_plans FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.platform_owners po WHERE po.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.platform_owners po WHERE po.user_id = auth.uid()));
CREATE TRIGGER subscription_plans_updated_at BEFORE UPDATE ON public.subscription_plans
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.company_subscriptions (
  company_id uuid PRIMARY KEY REFERENCES public.companies(id) ON DELETE CASCADE,
  plan_code text NOT NULL REFERENCES public.subscription_plans(code),
  status text NOT NULL DEFAULT 'trialing',
  trial_ends_at timestamptz,
  wake_up_calls_enabled boolean NOT NULL DEFAULT false,
  wake_up_monthly_cents integer NOT NULL DEFAULT 4900,
  wake_up_per_call_cents integer NOT NULL DEFAULT 25,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.company_subscriptions TO authenticated;
GRANT ALL ON public.company_subscriptions TO service_role;
ALTER TABLE public.company_subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Company staff read their subscription" ON public.company_subscriptions FOR SELECT TO authenticated
  USING (
    EXISTS (SELECT 1 FROM public.company_users cu WHERE cu.user_id = auth.uid() AND cu.company_id = company_subscriptions.company_id)
    OR EXISTS (SELECT 1 FROM public.platform_owners po WHERE po.user_id = auth.uid())
  );
CREATE POLICY "Platform owners manage subscriptions" ON public.company_subscriptions FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.platform_owners po WHERE po.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.platform_owners po WHERE po.user_id = auth.uid()));
CREATE TRIGGER company_subscriptions_updated_at BEFORE UPDATE ON public.company_subscriptions
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.wake_up_calls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  reservation_id uuid NOT NULL REFERENCES public.reservations(id) ON DELETE CASCADE,
  driver_id uuid REFERENCES public.drivers(id),
  phone text,
  attempts integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending',
  last_attempt_at timestamptz,
  confirmed_at timestamptz,
  charge_cents integer NOT NULL DEFAULT 0,
  last_error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (reservation_id)
);
GRANT SELECT ON public.wake_up_calls TO authenticated;
GRANT ALL ON public.wake_up_calls TO service_role;
ALTER TABLE public.wake_up_calls ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Company staff read their wake-up calls" ON public.wake_up_calls FOR SELECT TO authenticated
  USING (
    EXISTS (SELECT 1 FROM public.company_users cu WHERE cu.user_id = auth.uid() AND cu.company_id = wake_up_calls.company_id)
    OR EXISTS (SELECT 1 FROM public.platform_owners po WHERE po.user_id = auth.uid())
  );
CREATE TRIGGER wake_up_calls_updated_at BEFORE UPDATE ON public.wake_up_calls
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX wake_up_calls_company_created_idx ON public.wake_up_calls (company_id, created_at DESC);

INSERT INTO public.subscription_plans (code, name, price_cents, features, sort) VALUES
  ('starter', 'Starter', 9900, '["Reservations and dispatch","Fleet and chauffeur management","Chauffeur mobile app","Email notifications"]'::jsonb, 1),
  ('pro', 'Pro', 19900, '["Everything in Starter","Invoicing and payments","Client portal and reviews","Quotes and marketing site","Accounting reports"]'::jsonb, 2),
  ('elite', 'Elite', 34900, '["Everything in Pro","Automatic chauffeur wake-up calls","Live tracking and toll capture","Priority support"]'::jsonb, 3);

INSERT INTO public.company_subscriptions (company_id, plan_code, status, wake_up_calls_enabled)
SELECT id, 'elite', 'active', true FROM public.companies;