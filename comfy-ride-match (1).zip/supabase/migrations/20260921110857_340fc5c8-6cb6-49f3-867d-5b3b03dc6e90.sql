ALTER TABLE public.reservations
  ADD COLUMN IF NOT EXISTS car_seat_count integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS car_seat_fee numeric NOT NULL DEFAULT 0;