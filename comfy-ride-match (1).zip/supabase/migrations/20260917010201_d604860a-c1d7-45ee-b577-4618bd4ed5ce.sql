ALTER TABLE public.reservations
  ADD COLUMN IF NOT EXISTS booked_by_name text,
  ADD COLUMN IF NOT EXISTS booked_by_phone text,
  ADD COLUMN IF NOT EXISTS booked_by_email text,
  ADD COLUMN IF NOT EXISTS billing_contact_name text,
  ADD COLUMN IF NOT EXISTS billing_contact_phone text,
  ADD COLUMN IF NOT EXISTS billing_contact_email text;