CREATE TABLE public.ride_track_points (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  reservation_id uuid NOT NULL REFERENCES public.reservations(id) ON DELETE CASCADE,
  driver_id uuid REFERENCES public.drivers(id) ON DELETE SET NULL,
  lat double precision NOT NULL,
  lng double precision NOT NULL,
  recorded_at timestamp with time zone NOT NULL DEFAULT now(),
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

CREATE INDEX ride_track_points_reservation_idx ON public.ride_track_points (reservation_id, recorded_at);

GRANT SELECT, INSERT ON public.ride_track_points TO authenticated;
GRANT ALL ON public.ride_track_points TO service_role;

ALTER TABLE public.ride_track_points ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Signed-in users can view ride track points"
  ON public.ride_track_points FOR SELECT TO authenticated USING (true);

CREATE POLICY "Signed-in users can add ride track points"
  ON public.ride_track_points FOR INSERT TO authenticated WITH CHECK (true);