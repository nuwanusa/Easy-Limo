ALTER TABLE public.reservations
  ADD COLUMN IF NOT EXISTS driver_confirmed_at timestamptz;