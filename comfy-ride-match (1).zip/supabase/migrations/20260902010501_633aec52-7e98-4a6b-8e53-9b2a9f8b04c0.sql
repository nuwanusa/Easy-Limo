CREATE OR REPLACE FUNCTION public.set_updated_at() RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql SET search_path = public;

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  full_name TEXT NOT NULL DEFAULT '',
  job_title TEXT NOT NULL DEFAULT 'Dispatcher',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own profile select" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "own profile insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "own profile update" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data ->> 'full_name', split_part(NEW.email, '@', 1)))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TABLE public.drivers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  phone TEXT,
  license_number TEXT,
  status TEXT NOT NULL DEFAULT 'available',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.drivers TO authenticated;
GRANT ALL ON public.drivers TO service_role;
ALTER TABLE public.drivers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staff manage drivers" ON public.drivers FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER drivers_updated_at BEFORE UPDATE ON public.drivers FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.vehicles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fleet_code TEXT NOT NULL,
  name TEXT NOT NULL,
  vehicle_class TEXT NOT NULL DEFAULT 'sedan',
  plate TEXT,
  capacity INTEGER NOT NULL DEFAULT 3,
  status TEXT NOT NULL DEFAULT 'ready',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vehicles TO authenticated;
GRANT ALL ON public.vehicles TO service_role;
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staff manage vehicles" ON public.vehicles FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER vehicles_updated_at BEFORE UPDATE ON public.vehicles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.reservations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference TEXT NOT NULL,
  passenger_name TEXT NOT NULL,
  passenger_phone TEXT,
  passenger_count INTEGER NOT NULL DEFAULT 1,
  pickup_address TEXT NOT NULL,
  pickup_at TIMESTAMPTZ NOT NULL,
  dropoff_address TEXT NOT NULL,
  dropoff_at TIMESTAMPTZ,
  flight_number TEXT,
  vehicle_class TEXT NOT NULL DEFAULT 'sedan',
  base_fare NUMERIC(10,2) NOT NULL DEFAULT 0,
  airport_fee NUMERIC(10,2) NOT NULL DEFAULT 0,
  tolls NUMERIC(10,2) NOT NULL DEFAULT 0,
  gratuity NUMERIC(10,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'quoted',
  notes TEXT,
  driver_id UUID REFERENCES public.drivers ON DELETE SET NULL,
  vehicle_id UUID REFERENCES public.vehicles ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.reservations TO authenticated;
GRANT ALL ON public.reservations TO service_role;
ALTER TABLE public.reservations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staff manage reservations" ON public.reservations FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER reservations_updated_at BEFORE UPDATE ON public.reservations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

INSERT INTO public.drivers (id, full_name, phone, license_number, status) VALUES
 ('11111111-1111-4111-8111-111111111101','Diego Torres','+1 415 555 0142','CDL-88210','available'),
 ('11111111-1111-4111-8111-111111111102','Karim Haddad','+1 415 555 0187','CDL-77431','on_trip'),
 ('11111111-1111-4111-8111-111111111103','Denise Okafor','+1 415 555 0110','CDL-55902','available'),
 ('11111111-1111-4111-8111-111111111104','Tomas Vargas','+1 415 555 0163','CDL-31288','off_duty');

INSERT INTO public.vehicles (id, fleet_code, name, vehicle_class, plate, capacity, status) VALUES
 ('22222222-2222-4222-8222-222222222201','FLT-08','Mercedes S 500','sedan','LMO 508',3,'ready'),
 ('22222222-2222-4222-8222-222222222202','FLT-03','Cadillac Escalade','suv','LMO 303',6,'ready'),
 ('22222222-2222-4222-8222-222222222203','FLT-11','Mercedes Sprinter','sprinter','LMO 111',12,'on_road'),
 ('22222222-2222-4222-8222-222222222204','FLT-02','Lincoln Continental','sedan','LMO 202',3,'maintenance');

INSERT INTO public.reservations (reference, passenger_name, passenger_phone, passenger_count, pickup_address, pickup_at, dropoff_address, dropoff_at, flight_number, vehicle_class, base_fare, airport_fee, tolls, gratuity, status, driver_id, vehicle_id) VALUES
 ('AUR-2049','V. Nakamura','+1 415 555 0901',2,'21 Harborview Dr', now() + interval '2 hours','Grand Meridian Hotel', now() + interval '3 hours', NULL,'sedan',180,35,28,42,'en_route','11111111-1111-4111-8111-111111111102','22222222-2222-4222-8222-222222222201'),
 ('AUR-2050','J. Okafor','+1 415 555 0912',3,'SFO Terminal 3', now() + interval '5 hours','550 Bush St', now() + interval '6 hours','UA 1122','suv',210,35,18,40,'confirmed','11111111-1111-4111-8111-111111111101','22222222-2222-4222-8222-222222222202'),
 ('AUR-2051','L. Bianchi','+1 415 555 0933',2,'OAK Terminal 1', now() + interval '8 hours','The Clift Royal Sonesta', now() + interval '9 hours','AS 402','sedan',160,25,12,30,'unassigned',NULL,NULL),
 ('AUR-2052','H. Beaumont','+1 415 555 0944',6,'1 Ferry Building', now() + interval '26 hours','SJC Terminal B', now() + interval '28 hours',NULL,'sprinter',320,0,22,60,'quoted',NULL,NULL),
 ('AUR-2053','T. Marchetti','+1 415 555 0955',1,'200 Spear St', now() - interval '4 hours','SFO Terminal 1', now() - interval '3 hours',NULL,'sedan',140,25,10,28,'completed','11111111-1111-4111-8111-111111111104','22222222-2222-4222-8222-222222222204');