create schema if not exists private;

create table if not exists private.cron_secret (
  id boolean primary key default true,
  token text not null default encode(gen_random_bytes(24), 'hex')
);
insert into private.cron_secret (id) values (true) on conflict (id) do nothing;

create or replace function public.cron_token_matches(_token text)
returns boolean
language sql
stable
security definer
set search_path = private, public
as $$
  select exists (select 1 from private.cron_secret where token = _token)
$$;

revoke all on function public.cron_token_matches(text) from public, anon, authenticated;
grant execute on function public.cron_token_matches(text) to service_role;

create extension if not exists pg_cron with schema extensions;
create extension if not exists pg_net with schema extensions;

select cron.unschedule('ride-reminders-hourly') where exists (select 1 from cron.job where jobname = 'ride-reminders-hourly');

select cron.schedule(
  'ride-reminders-hourly',
  '7 * * * *',
  $job$
  select net.http_post(
    url := 'https://project--554179f3-4fc3-4e60-a7bb-bec367e73d0b.lovable.app/api/public/ride-reminders',
    headers := jsonb_build_object('Content-Type','application/json','x-cron-secret',(select token from private.cron_secret limit 1)),
    body := '{}'::jsonb
  );
  $job$
);