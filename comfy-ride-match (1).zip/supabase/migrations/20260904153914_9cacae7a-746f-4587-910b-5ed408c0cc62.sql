CREATE TABLE public.client_rates (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  label text not null,
  rate_type text not null default 'flat',
  amount numeric not null default 0,
  vehicle_class text not null default 'sedan',
  minimum_hours numeric not null default 3,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.client_rates TO authenticated;
GRANT ALL ON public.client_rates TO service_role;
ALTER TABLE public.client_rates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staff manage client rates" ON public.client_rates FOR ALL TO authenticated
  USING (NOT private.is_driver(auth.uid())) WITH CHECK (NOT private.is_driver(auth.uid()));
CREATE TRIGGER client_rates_updated_at BEFORE UPDATE ON public.client_rates
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

ALTER TABLE public.drivers
  ADD COLUMN IF NOT EXISTS address_line1 text,
  ADD COLUMN IF NOT EXISTS address_line2 text,
  ADD COLUMN IF NOT EXISTS city text,
  ADD COLUMN IF NOT EXISTS state text,
  ADD COLUMN IF NOT EXISTS postal_code text,
  ADD COLUMN IF NOT EXISTS date_of_birth date,
  ADD COLUMN IF NOT EXISTS license_class text,
  ADD COLUMN IF NOT EXISTS license_state text,
  ADD COLUMN IF NOT EXISTS license_expiry date,
  ADD COLUMN IF NOT EXISTS tlc_number text,
  ADD COLUMN IF NOT EXISTS tlc_expiry date,
  ADD COLUMN IF NOT EXISTS badge_number text,
  ADD COLUMN IF NOT EXISTS hire_date date,
  ADD COLUMN IF NOT EXISTS emergency_contact_name text,
  ADD COLUMN IF NOT EXISTS emergency_contact_phone text,
  ADD COLUMN IF NOT EXISTS insurance_provider text,
  ADD COLUMN IF NOT EXISTS insurance_policy text,
  ADD COLUMN IF NOT EXISTS insurance_expiry date,
  ADD COLUMN IF NOT EXISTS default_vehicle_id uuid REFERENCES public.vehicles(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS pay_type text NOT NULL DEFAULT 'percentage',
  ADD COLUMN IF NOT EXISTS pay_rate numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS notes text,
  ADD COLUMN IF NOT EXISTS is_online boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS last_lat double precision,
  ADD COLUMN IF NOT EXISTS last_lng double precision,
  ADD COLUMN IF NOT EXISTS last_seen_at timestamptz;

DROP POLICY IF EXISTS "drivers update own record" ON public.drivers;
CREATE POLICY "drivers update own record" ON public.drivers FOR UPDATE TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());