ALTER TABLE public.reservations ADD COLUMN IF NOT EXISTS guest_link_token text;
CREATE UNIQUE INDEX IF NOT EXISTS reservations_guest_link_token_key ON public.reservations (guest_link_token) WHERE guest_link_token IS NOT NULL;
ALTER TABLE public.drivers ADD COLUMN IF NOT EXISTS is_guest boolean NOT NULL DEFAULT false;