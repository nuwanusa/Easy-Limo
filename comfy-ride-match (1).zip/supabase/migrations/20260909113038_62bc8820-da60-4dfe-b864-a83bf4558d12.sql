ALTER TABLE public.clients ADD COLUMN IF NOT EXISTS portal_slug text;

UPDATE public.clients c
SET portal_slug = s.slug
FROM (
  SELECT id,
         regexp_replace(lower(trim(name)), '[^a-z0-9]+', '-', 'g') ||
         CASE WHEN row_number() OVER (
                PARTITION BY regexp_replace(lower(trim(name)), '[^a-z0-9]+', '-', 'g')
                ORDER BY created_at
              ) > 1
              THEN '-' || row_number() OVER (
                PARTITION BY regexp_replace(lower(trim(name)), '[^a-z0-9]+', '-', 'g')
                ORDER BY created_at
              )::text
              ELSE '' END AS slug
  FROM public.clients
) s
WHERE c.id = s.id AND c.portal_slug IS NULL;

UPDATE public.clients SET portal_slug = trim(both '-' from portal_slug) WHERE portal_slug IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS clients_portal_slug_key ON public.clients (portal_slug) WHERE portal_slug IS NOT NULL;