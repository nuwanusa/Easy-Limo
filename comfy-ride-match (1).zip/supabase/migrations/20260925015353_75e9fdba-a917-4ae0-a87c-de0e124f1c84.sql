REVOKE ALL ON FUNCTION public.touch_message_thread() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.touch_message_thread() FROM anon;
REVOKE ALL ON FUNCTION public.touch_message_thread() FROM authenticated;
GRANT EXECUTE ON FUNCTION public.touch_message_thread() TO service_role;