CREATE SEQUENCE IF NOT EXISTS public.invoice_number_seq START 1001;

CREATE TABLE public.clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_number text NOT NULL DEFAULT '',
  name text NOT NULL,
  contact_name text,
  email text,
  phone text,
  address_line1 text,
  address_line2 text,
  terms text NOT NULL DEFAULT 'Due on receipt',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.clients TO authenticated;
GRANT ALL ON public.clients TO service_role;
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staff manage clients" ON public.clients FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER clients_updated_at BEFORE UPDATE ON public.clients FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_number text NOT NULL DEFAULT nextval('public.invoice_number_seq')::text,
  client_id uuid REFERENCES public.clients(id) ON DELETE SET NULL,
  period_start date,
  period_end date,
  issued_at timestamptz,
  sent_at timestamptz,
  paid_at timestamptz,
  discount numeric NOT NULL DEFAULT 0,
  payments numeric NOT NULL DEFAULT 0,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.invoices TO authenticated;
GRANT ALL ON public.invoices TO service_role;
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "staff manage invoices" ON public.invoices FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER invoices_updated_at BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

ALTER TABLE public.reservations
  ADD COLUMN client_id uuid REFERENCES public.clients(id) ON DELETE SET NULL,
  ADD COLUMN invoice_id uuid REFERENCES public.invoices(id) ON DELETE SET NULL;

CREATE INDEX reservations_client_idx ON public.reservations(client_id);
CREATE INDEX reservations_invoice_idx ON public.reservations(invoice_id);