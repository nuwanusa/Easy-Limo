create table public.payment_links (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  target text not null check (target in ('invoice','reservation')),
  target_id uuid not null,
  created_at timestamptz not null default now(),
  unique (target, target_id)
);

GRANT ALL ON public.payment_links TO service_role;

ALTER TABLE public.payment_links ENABLE ROW LEVEL SECURITY;