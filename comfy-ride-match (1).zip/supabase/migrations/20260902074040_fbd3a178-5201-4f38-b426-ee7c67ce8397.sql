ALTER TABLE public.reservations
  ADD COLUMN IF NOT EXISTS waiting_minutes numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS waiting_rate numeric NOT NULL DEFAULT 0;