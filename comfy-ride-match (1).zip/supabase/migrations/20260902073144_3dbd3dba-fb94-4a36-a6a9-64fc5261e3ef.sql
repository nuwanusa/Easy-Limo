CREATE SCHEMA IF NOT EXISTS private;
GRANT USAGE ON SCHEMA private TO authenticated, service_role;

CREATE OR REPLACE FUNCTION private.is_driver(_uid uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.drivers d WHERE d.user_id = _uid AND _uid = auth.uid())
$$;

CREATE OR REPLACE FUNCTION private.current_driver_id()
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT d.id FROM public.drivers d WHERE d.user_id = auth.uid() LIMIT 1
$$;

REVOKE EXECUTE ON FUNCTION private.is_driver(uuid), private.current_driver_id() FROM public;
GRANT EXECUTE ON FUNCTION private.is_driver(uuid), private.current_driver_id() TO authenticated, service_role;

-- Recreate policies against the private helpers
DROP POLICY IF EXISTS "staff manage drivers" ON public.drivers;
CREATE POLICY "staff manage drivers" ON public.drivers FOR ALL TO authenticated
USING (NOT private.is_driver(auth.uid())) WITH CHECK (NOT private.is_driver(auth.uid()));

DROP POLICY IF EXISTS "staff manage vehicles" ON public.vehicles;
CREATE POLICY "staff manage vehicles" ON public.vehicles FOR ALL TO authenticated
USING (NOT private.is_driver(auth.uid())) WITH CHECK (NOT private.is_driver(auth.uid()));

DROP POLICY IF EXISTS "drivers read assigned vehicles" ON public.vehicles;
CREATE POLICY "drivers read assigned vehicles" ON public.vehicles FOR SELECT TO authenticated
USING (EXISTS (SELECT 1 FROM public.reservations r WHERE r.vehicle_id = vehicles.id AND r.driver_id = private.current_driver_id()));

DROP POLICY IF EXISTS "staff manage reservations" ON public.reservations;
CREATE POLICY "staff manage reservations" ON public.reservations FOR ALL TO authenticated
USING (NOT private.is_driver(auth.uid())) WITH CHECK (NOT private.is_driver(auth.uid()));

DROP POLICY IF EXISTS "drivers read own trips" ON public.reservations;
CREATE POLICY "drivers read own trips" ON public.reservations FOR SELECT TO authenticated
USING (driver_id = private.current_driver_id());

DROP POLICY IF EXISTS "drivers update own trips" ON public.reservations;
CREATE POLICY "drivers update own trips" ON public.reservations FOR UPDATE TO authenticated
USING (driver_id = private.current_driver_id()) WITH CHECK (driver_id = private.current_driver_id());

DROP POLICY IF EXISTS "staff manage clients" ON public.clients;
CREATE POLICY "staff manage clients" ON public.clients FOR ALL TO authenticated
USING (NOT private.is_driver(auth.uid())) WITH CHECK (NOT private.is_driver(auth.uid()));

DROP POLICY IF EXISTS "staff manage invoices" ON public.invoices;
CREATE POLICY "staff manage invoices" ON public.invoices FOR ALL TO authenticated
USING (NOT private.is_driver(auth.uid())) WITH CHECK (NOT private.is_driver(auth.uid()));

DROP POLICY IF EXISTS "staff manage reservation stops" ON public.reservation_stops;
CREATE POLICY "staff manage reservation stops" ON public.reservation_stops FOR ALL TO authenticated
USING (NOT private.is_driver(auth.uid())) WITH CHECK (NOT private.is_driver(auth.uid()));

DROP POLICY IF EXISTS "drivers read own trip stops" ON public.reservation_stops;
CREATE POLICY "drivers read own trip stops" ON public.reservation_stops FOR SELECT TO authenticated
USING (EXISTS (SELECT 1 FROM public.reservations r WHERE r.id = reservation_stops.reservation_id AND r.driver_id = private.current_driver_id()));

DROP FUNCTION IF EXISTS public.is_driver(uuid);
DROP FUNCTION IF EXISTS public.current_driver_id();
