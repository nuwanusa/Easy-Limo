CREATE TABLE public.zone_rates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid REFERENCES public.clients(id) ON DELETE CASCADE,
  from_label text NOT NULL,
  from_type text NOT NULL DEFAULT 'city',
  to_label text NOT NULL,
  to_type text NOT NULL DEFAULT 'city',
  vehicle_class text NOT NULL DEFAULT 'sedan',
  amount numeric NOT NULL DEFAULT 0,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.zone_rates TO authenticated;
GRANT ALL ON public.zone_rates TO service_role;

ALTER TABLE public.zone_rates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "staff manage zone rates" ON public.zone_rates
  FOR ALL TO authenticated
  USING (NOT private.is_driver(auth.uid()))
  WITH CHECK (NOT private.is_driver(auth.uid()));

CREATE TRIGGER zone_rates_updated_at BEFORE UPDATE ON public.zone_rates
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();