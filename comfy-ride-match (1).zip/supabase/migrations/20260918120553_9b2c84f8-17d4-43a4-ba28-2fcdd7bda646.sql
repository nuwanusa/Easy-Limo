CREATE TABLE public.reservation_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES public.companies(id),
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  pickup_at timestamptz NOT NULL,
  pickup_address text NOT NULL,
  dropoff_address text NOT NULL DEFAULT '',
  vehicle_class text NOT NULL DEFAULT 'sedan',
  booking_type text NOT NULL DEFAULT 'transfer',
  hours numeric NOT NULL DEFAULT 0,
  passenger_count integer NOT NULL DEFAULT 1,
  luggage_count integer NOT NULL DEFAULT 0,
  passenger_name text,
  contact_phone text,
  contact_email text,
  notes text,
  status text NOT NULL DEFAULT 'pending',
  reservation_id uuid REFERENCES public.reservations(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.reservation_requests TO authenticated;
GRANT ALL ON public.reservation_requests TO service_role;

ALTER TABLE public.reservation_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Client users read their requests" ON public.reservation_requests
FOR SELECT TO authenticated
USING (EXISTS (SELECT 1 FROM public.client_users cu WHERE cu.user_id = auth.uid() AND cu.client_id = reservation_requests.client_id));

CREATE POLICY "Staff manage reservation requests" ON public.reservation_requests
FOR ALL TO authenticated
USING (EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id = auth.uid() AND ur.role = ANY (ARRAY['admin'::app_role,'dispatcher'::app_role])) AND company_id = private.current_company_id())
WITH CHECK (EXISTS (SELECT 1 FROM public.user_roles ur WHERE ur.user_id = auth.uid() AND ur.role = ANY (ARRAY['admin'::app_role,'dispatcher'::app_role])) AND company_id = private.current_company_id());

CREATE TRIGGER reservation_requests_updated_at BEFORE UPDATE ON public.reservation_requests
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE INDEX reservation_requests_company_status_idx ON public.reservation_requests (company_id, status, pickup_at);