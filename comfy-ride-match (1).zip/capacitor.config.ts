import type { CapacitorConfig } from "@capacitor/cli";

// The Android app loads the live Blackwave site, so every web update
// reaches drivers instantly without a new Play Store release.
const config: CapacitorConfig = {
  appId: "com.rideblackwave.driver",
  appName: "Blackwave Driver",
  webDir: "dist/client",
  server: {
    url: "https://rideblackwave.com/driver",
    cleartext: false,
  },
  android: { allowMixedContent: false },
};

export default config;
