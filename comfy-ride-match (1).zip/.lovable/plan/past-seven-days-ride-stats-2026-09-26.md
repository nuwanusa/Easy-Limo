# Past Seven Days Ride Stats

## What will change
- Replace the highlighted Driver status panel on the dispatcher home with a Past 7 days panel.
- Show one column for each day, including the date and number of non-cancelled rides.
- Keep the existing upcoming 7-day schedule above it and all other dashboard panels unchanged.

## Technical details
- Calculate the seven calendar days ending today from the existing company reservation data.
- Exclude cancelled reservations from each daily count.
- Keep the panel compact and responsive within the current dashboard layout.
