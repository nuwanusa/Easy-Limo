# Simplify single-ride invoice emails

## What will change
- Detect invoices containing exactly one ride.
- Replace the wide multi-ride table with a clear trip-detail section showing only date, pickup time, drop-off time, passenger name, and the full pickup-to-drop-off route.
- Add a compact charge section with up to four charge boxes per row.
- Show only charge items that contain a non-zero value, including base rate, flat rate, hourly rate with hours, tolls, parking, airport, meet-and-greet, waiting time, gratuity, extra stops, and car-seat fees when applicable.
- Keep the existing multi-ride invoice layout unchanged.

## Technical details
- Extend each invoice trip payload with a normalized list of populated charge items.
- Use the same fare calculations already used for invoice totals, so the displayed charge items reconcile with the total.
- Apply the behavior to every invoice-email sending path, including client, staff-forwarded, and single-ride emails.
- Verify the email template compiles after the change.
