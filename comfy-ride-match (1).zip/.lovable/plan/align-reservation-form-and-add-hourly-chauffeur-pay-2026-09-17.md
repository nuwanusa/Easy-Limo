# Align reservation form and add hourly chauffeur pay

## Changes
- Reflow the New Reservation cards into three balanced columns so sections stack tightly without large blank areas.
- Keep the fields and section order readable across desktop, tablet, and phone layouts.
- For hourly reservations, replace the single ride-pay input with **Hourly pay**, **Minimum hours**, and **Total hours** under Chauffeur pay.
- Calculate chauffeur ride pay from hourly pay × the greater of minimum hours or total hours, then include existing chauffeur extras in the displayed total.
- Save the three hourly chauffeur-pay values on each reservation and restore them when editing.

## Technical details
- Add three numeric reservation fields with safe zero defaults and preserve existing ride-pay behavior for non-hourly reservations.
- Update the shared reservation type and payout calculation so pay screens and confirmations use the saved hourly chauffeur total.
- Verify the form visually and run the project type check.
