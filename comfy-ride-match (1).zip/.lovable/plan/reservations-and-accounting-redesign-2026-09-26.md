# Reservations and Accounting Redesign

## What will change
- Redesign **Reservations** to match the supplied calendar-led operations view: compact title/actions, status filters with counts, a full monthly schedule, active rides, seven-day upcoming summary, upcoming reservations table, and completed reservations table.
- Redesign **Accounting** to match the supplied financial dashboard: date-range header, four summary cards, compact preset and advanced filters, revenue overview, rides-by-client breakdown, and detailed rides table.
- Keep the existing reservation editor, driver assignment, status changes, invoice links, ride sharing, deletion rules, searches, and accounting filters working.
- Use only live company data; no sample rows or invented financial figures.

## Visual direction
- Follow the references’ crisp white-and-ice workspace, navy headings, blue primary actions, thin borders, compact spacing, and restrained status colors.
- Preserve the existing shared navigation outside the dispatcher home.
- Make both screens responsive: desktop keeps the dense dashboard layout while smaller screens use compact scrolling grids and stacked sections without clipped controls.

## Technical details
- Reuse existing reservation, client, driver, vehicle, stop, and invoice queries.
- Extend the existing reservation calendar presentation rather than changing scheduling rules.
- Build accounting charts from the already-filtered ride totals and per-client totals, with accessible labels and empty states.
- Keep each route’s existing metadata and role restrictions.

## Verification
- Verify Reservations and Accounting signed in with real company data at desktop and phone widths.
- Confirm new reservation, edit, filters, driver assignment, calendar navigation, accounting presets, and search remain reachable.
- Check for horizontal overflow, overlapping text, runtime errors, and build errors.
