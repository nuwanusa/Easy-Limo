# Wide Three-Column Admin Home and Messenger

## What will change
- Expand the admin home to use the available screen width with a responsive three-column layout on desktop, two columns on medium screens, and one column on phones.
- Keep the current weekly reservation figures and add **Invoices paid** and **Amount received** for the same Sunday-to-Saturday period.
- Make **New reservation** open the reservation form directly instead of only opening the reservations list.
- Add the existing live chauffeur map to the home page, with current online-driver markers and a link to the full map.
- Rebalance the calendar, upcoming reservations, actions, financial figures, and live map into a clean professional dashboard without removing existing navigation.

## Built-in messenger
- Add a floating message button and pop-up conversation panel for:
  - admins on the admin screens;
  - signed-in chauffeurs on chauffeur screens;
  - signed-in clients on the client portal.
- Give admins an inbox of client and chauffeur conversations, unread indicators, conversation selection, replies, timestamps, and empty/error states.
- Give each chauffeur or client one private conversation with their own company’s admins.
- Keep six-digit-code portals, public tracking links, passengers, and guest-driver links out of messaging.
- Deliver new messages live while the page is open, with a refresh fallback if the live connection is interrupted.

## Data and security
- Add company-scoped conversation and message records in Lovable Cloud.
- Grant access only to authenticated users, enable row-level security, and enforce these rules in the database:
  - admins can read and reply only within their company;
  - chauffeurs can access only their own conversation;
  - signed-in clients can access only their linked client account conversation;
  - no anonymous access.
- Store message text as plain text, cap message length, set sender identity on the server, and track read state for unread badges.

## Technical details
- Extend the reservation page search state with a `new` option so `/reservations?new=1` opens a blank reservation form while existing edit links continue to work.
- Reuse the existing invoice query: paid count uses invoices whose `paid_at` falls within the current week; amount received sums payments on invoices paid or updated during that weekly period using the best available payment timestamp.
- Reuse the existing live-map implementation and chauffeur markers rather than creating a second map system.
- Add shared messenger data functions and one reusable pop-up component, then mount it in the admin shell, chauffeur shell, and signed-in client portal.

## Verification
- Verify the three-column home at wide desktop, tablet, and phone widths with no overlap or horizontal scrolling.
- Confirm New reservation opens a blank form, map markers render, and all weekly figures match company-scoped records.
- Test a complete admin ↔ chauffeur message exchange and admin ↔ signed-in client exchange, including unread badges and company isolation.
- Run database security checks and confirm the app builds without errors.
