# Admin Home Reservation Overview

## What will change
- Replace the current dispatch-heavy home page with a focused reservation overview.
- Show this week’s **Reservations booked** count and total dollar value.
- Show this week’s **Reservations completed** count.
- Add prominent **Create invoices** and **Pay drivers** actions.
- Add a monthly calendar containing only upcoming, non-cancelled reservations.
- Keep a compact upcoming-reservations list for quick access.
- Remove the selected trip detail, active-trip status cards, live map, and unrelated shortcuts from this home page.

## Visual direction
- Use the selected Navy Trust palette with Space Grotesk headings and DM Sans body text.
- Arrange the summary, actions, calendar, and upcoming list in a clean responsive bento grid.
- Preserve existing navigation and all underlying reservation, invoice, and driver-payment behavior.

## Technical details
- Reuse the current company-scoped reservation queries and fare calculations.
- Weekly totals use Sunday through Saturday and exclude cancelled reservations from booked count/value.
- Calendar entries link to the existing reservation editor; action cards link to Invoices and Pay Drivers.
- Verify the signed-in admin view on desktop and mobile-sized layouts.
