# Dispatcher Home — Reference-Matched Redesign

## What will change
- Rebuild the dispatcher home to closely match the supplied reference: dark left navigation, compact top utility bar, greeting, six summary tiles, a large ride queue, quick actions, alerts, seven-day schedule, live map, driver status, and recent activity.
- Keep every panel connected to the existing company-scoped reservations, invoices, drivers, map, email inbox, and payment workflows; no demo data will replace real records.
- Preserve direct actions for New Reservation, Create Invoice, Pay Driver, Inbox/compose, calendar, dispatch, editing, and full-map access.
- Use responsive behavior: fixed sidebar and dense dashboard on wide screens, compact header/navigation and stacked panels on phones.

## Visual direction
- Match the reference’s crisp white-and-ice workspace, navy sidebar, blue primary actions, restrained red/amber/green status accents, thin borders, compact spacing, and professional operations-console density.
- Keep Blackwave branding prominent in the sidebar and use the current Space Grotesk / DM Sans typography.
- Reuse the current live map rather than displaying a static reference image.

## Technical details
- Add a dashboard presentation mode to the shared admin shell so the reference-style sidebar and utility header appear on the dispatcher home without unexpectedly redesigning every other admin screen.
- Derive Today, Upcoming, Unassigned, Unpaid Invoices, Today’s Revenue, and This Week from existing records.
- Build the ride queue, weekly strip, driver availability list, alerts, and activity feed from available reservation, driver, invoice, and inbox data with honest empty states.
- Verify the signed-in dispatcher view at desktop and phone sizes, including navigation, no overlap, no horizontal scrolling, and successful loading when Outlook needs reconnection.
