# 1800px Downloadable Invoice

## Changes
- Render PDF, JPEG, and shared invoice exports at a fixed 1800px width.
- Keep the invoice table columns as Base rate, Flat rate, Others, and Total.
- Preserve the itemized Others breakdown, including named toll charges where available.
- Widen the staff invoice preview to match the export layout.

## Verification
- Check the exported invoice clone uses the 1800px layout and includes all four amount columns.
- Confirm the project validation passes.
