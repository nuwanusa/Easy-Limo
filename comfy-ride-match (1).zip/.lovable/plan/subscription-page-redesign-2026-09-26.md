# Subscription Page Redesign

## What will change
- Redesign the Subscription page to match the supplied operations-console reference while preserving live plan, billing, usage, and wake-up-call data.
- Add a compact page header with the current plan summary, followed by three clear plan cards for Starter, Pro, and Elite.
- Present the chauffeur wake-up-call add-on as a full-width control with its monthly cost, per-call cost, monthly usage, and estimated total.
- Restyle recent wake-up calls as a structured table with a month selector and a polished empty state.
- Keep the wake-up-call toggle functional and retain existing admin-only permissions.

## Visual direction
- Use the existing white-and-ice workspace, navy sidebar, bright blue actions, thin borders, restrained green/amber accents, and Space Grotesk / DM Sans typography.
- Match the reference's compact spacing, icon-led summaries, clear current-plan badge, and responsive card/table behavior.
- Use only live account data; do not invent plan status, usage, or call history.

## Technical details
- Bring `/billing` into the shared modern operations shell used by the other redesigned admin pages.
- Reuse the existing plan and company billing functions without changing pricing or subscription business logic.
- Use the existing design tokens and button components for all interactive controls.
- Verify the signed-in page at desktop and phone widths, including the wake-up toggle presentation, overflow, and build status.
