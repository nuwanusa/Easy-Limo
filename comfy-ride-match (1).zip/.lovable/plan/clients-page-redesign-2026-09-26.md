# Clients Page Redesign

## What will change
- Redesign Clients to match the supplied account-book reference with a compact page header, New Client action, four live summary tiles, filters, and a dense client table.
- Show each client’s account number, name, billing address, contact details, active status, and existing management actions.
- Keep client creation/editing, passengers, custom prices, portal access, saved cards, invoice history, frequent addresses, notifications, and guarded deletion unchanged.

## Visual direction
- Use the existing white-and-ice operations workspace, navy typography, bright blue actions, thin borders, and restrained green, amber, and red status accents.
- Match the reference’s icon-led summary tiles, compact search/filter row, initials avatars, and responsive table behavior.
- Use only live client, reservation, and invoice data; do not add sample records or invented balances.

## Technical details
- Add Clients to the shared modern operations shell.
- Derive total clients, active accounts, open invoices, and outstanding balance from the existing company-scoped queries.
- Add status and sort controls while preserving the existing text search.
- Use existing button components and semantic design tokens.
- Verify signed-in desktop and phone layouts, existing actions, overflow, and build status.
