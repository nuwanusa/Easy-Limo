# Standardize all invoice designs

## Changes
- Make the blue Blackwave invoice shown in the reference the single invoice design everywhere.
- Apply the same navy header, light-blue billing panels, table styling, payment-method box, totals panel, buttons, and footer to staff invoices, client-facing invoices, printable/PDF views, and invoice emails.
- Remove the invoice design selector and alternate invoice themes so staff previews and saved exports cannot drift from the emailed version.
- Preserve the existing invoice data rules: single-ride invoices use the compact trip-and-charges layout; multi-ride invoices keep the detailed ride table and itemized Others breakdown.
- Keep payment links, PDF/JPEG export, printing, forwarding, paid status, and invoice editing behavior unchanged.

## Technical details
- Use one fixed invoice class and shared semantic invoice styling for both single-ride and consolidated staff pages.
- Align the public printable view and email template to the same spacing, hierarchy, labels, and blue palette.
- Keep the 1800px export canvas and print-safe white background.

## Verification
- Check one single-ride invoice and one multi-ride invoice in staff, public/print, and email-compatible layouts.
- Confirm PDF/JPEG controls still target the standardized invoice sheet.
- Confirm project validation passes.
