# New Reservation pricing and chauffeur pay fields

## Changes
- Rename the point-to-point customer fare field from **Base fare** to **Flat fare** under Pricing.
- Keep **Tolls** visible under Chauffeur pay.
- Add **Total waiting hours** under Chauffeur pay.
- Rename **Driver waiting pay** to **Driver waiting rate per hour**.
- Calculate chauffeur waiting pay as waiting hours × waiting rate, and include it in the displayed driver total and payout calculations.
- Preserve existing saved waiting-pay values when older reservations are edited.

## Technical details
- Add a company-scoped reservation field for chauffeur waiting hours through a database migration.
- Update reservation form state, saved payloads, shared reservation types, and chauffeur payout calculations.
- Verify type safety and the New Reservation layout after implementation.
