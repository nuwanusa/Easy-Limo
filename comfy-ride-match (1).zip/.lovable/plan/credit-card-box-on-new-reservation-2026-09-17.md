# Credit card box on New Reservation

## Build
- Add a Payment section to the New Reservation form.
- Keep the existing payment-method selector in that section.
- When Credit card is selected, show the chosen client’s saved cards and the secure Add card form.
- Require a client account before a card can be added, because cards are securely attached to that client.
- Keep card numbers and security codes handled only by the secure payment screen; store only the existing safe card summary.

## Verify
- Check the three-column reservation layout at desktop size.
- Confirm selecting Credit card reveals the card box and selecting another method hides it.
- Confirm the project type-checks cleanly.
