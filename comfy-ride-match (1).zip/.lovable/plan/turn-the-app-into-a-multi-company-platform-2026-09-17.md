# Turn the app into a multi-company platform

Sell the same system to other transportation companies. Each company gets its own
sign-in code, its own people, and data that no other company can see.

## How it will work

**Sign in**
- The staff sign-in screen gets a **Company ID** box above email and password
  (for example `BLACKWAVE`). It is remembered on that device, so people only type it once.
- Signing in with the wrong company code for that account is refused.
- Chauffeur and client sign-in screens get the same box.

**Platform owner (you)**
- A new **Platform** page, visible only to you, lists every company.
- "Add company" asks for the company name, a short company ID, the admin's email,
  and generates a **temporary password** you can copy and send.
- You can also suspend a company (nobody from it can sign in) or reset its admin password.

**First sign-in for a new company admin**
- After signing in with the temporary password, the admin lands on a
  "Choose your password" screen and cannot use the app until a new password is set.
- After that, they run their own company: create dispatchers and chauffeurs, clients,
  invoices, the lot — exactly as Blackwave does today.

**Separation**
- Every reservation, client, chauffeur, vehicle, invoice, quote, rate and dispute belongs
  to one company. Lists, searches, the live map, accounting and the portals only ever show
  that company's records.
- All existing Blackwave data becomes company #1, so nothing you have today changes.

## Technical outline

1. **Migration**
   - `public.companies` (name, code unique uppercase, status, contact email, timestamps).
   - `public.company_users` (user_id, company_id, must_change_password flag).
   - `platform_owner` added to the `app_role` enum; the current main admin is granted it.
   - `company_id uuid` added to: `clients`, `drivers`, `vehicles`, `reservations`,
     `invoices`, `quote_requests`, `zone_rates`, `ride_disputes`, `profiles`, `user_roles`.
     Backfilled with the Blackwave company row, then set `NOT NULL`.
   - Child tables (`client_*`, `reservation_*`, `ride_track_points`) stay scoped through
     their parent's `company_id`.
   - `public.current_company_id()` and `public.is_platform_owner()` security-definer helpers.
   - Every existing RLS policy on the tables above gains
     `AND company_id = public.current_company_id()`, with platform-owner bypass.
   - GRANTs for the two new tables.

2. **Server functions**
   - `src/lib/platform.functions.ts` — platform-owner only: `listCompanies`,
     `createCompany` (creates the auth user, temp password, admin role, company row,
     `must_change_password = true`), `setCompanyStatus`, `resetCompanyAdminPassword`.
   - `staff-account.functions.ts`, `driver-account.functions.ts` and every admin-client
     write stamp `company_id` from the caller's company instead of trusting input.

3. **Client**
   - `src/lib/company.ts` — `useCompany()` hook plus the remembered company code.
   - `auth.tsx`, `driver.login.tsx`, `ClientCodeLogin.tsx` — Company ID field; after sign-in
     the code is verified against `company_users` and mismatches are signed out with a clear
     message.
   - `src/routes/set-password.tsx` — forced password change; `resolveLanding()` sends any
     account with `must_change_password` here first.
   - `src/routes/platform.tsx` — company list, add-company form with copyable temporary
     password, suspend and reset controls.
   - Existing pages need no query changes: row-level rules do the filtering.

4. **Verification**
   - `bunx tsgo --noEmit`.
   - Playwright: sign in as Blackwave admin and confirm reservations still load; create a
     second company, sign in as its admin, confirm the forced password screen and an empty
     reservation board.

## Notes

- The platform owner will be the account currently holding the main admin role
  (you can point it at a different email later from the Platform page).
- Temporary passwords are shown once when created; after that only a reset is possible.
