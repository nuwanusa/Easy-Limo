import { useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { driversQuery } from "@/lib/dispatch";
import { carMarkerHtml } from "@/lib/car-marker";

export function MiniLiveMap({ heightClass = "h-[320px]" }: { heightClass?: string }) {
  const { data: drivers = [] } = useQuery({ ...driversQuery, refetchInterval: 30_000 });
  const online = drivers.filter((d) => {
    const seenAt = d.last_seen_at ? new Date(d.last_seen_at).getTime() : 0;
    return d.is_online && d.last_lat != null && d.last_lng != null && Date.now() - seenAt <= 90_000;
  });
  const ref = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const layerRef = useRef<any>(null);
  const points = online
    .map((d) => `${d.id}:${d.last_lat},${d.last_lng}`)
    .sort()
    .join("|");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const L = (await import("leaflet")).default;
      await import("leaflet/dist/leaflet.css");
      if (cancelled || !ref.current) return;

      if (!mapRef.current) {
        mapRef.current = L.map(ref.current).setView([40.5795, -74.1502], 10);
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          maxZoom: 19,
          attribution: "© OpenStreetMap",
        }).addTo(mapRef.current);
      }

      layerRef.current?.remove();
      layerRef.current = L.layerGroup().addTo(mapRef.current);

      const latLngs: [number, number][] = [];
      online.forEach((d) => {
        const pos: [number, number] = [Number(d.last_lat), Number(d.last_lng)];
        latLngs.push(pos);
        L.marker(pos, {
          icon: L.divIcon({
            className: "",
            html: carMarkerHtml(d.full_name, "sm"),
            iconSize: [110, 38],
            iconAnchor: [55, 24],
          }),
        })
          .bindTooltip(d.full_name, { direction: "top" })
          .addTo(layerRef.current);
      });

      if (latLngs.length === 1) mapRef.current.setView(latLngs[0]!, 12);
      else if (latLngs.length > 1) mapRef.current.fitBounds(latLngs, { padding: [30, 30] });
      setTimeout(() => mapRef.current?.invalidateSize(), 100);
    })().catch(() => undefined);
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [points]);

  return (
    <div>
      <div ref={ref} className={`${heightClass} w-full rounded-md border border-border`} />
      <div className="mt-2 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
        {drivers.filter((d) => d.is_online).length} online · {drivers.length} on roster
      </div>
    </div>
  );
}
