import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  approveReservationRequest,
  declineReservationRequest,
  listReservationRequests,
} from "@/lib/reservation-requests.functions";

const when = (v: string) =>
  new Date(v).toLocaleString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
    timeZone: "America/New_York",
  });

/** Staff panel: client reservation requests waiting for approval. */
export function ReservationRequests() {
  const qc = useQueryClient();
  const list = useServerFn(listReservationRequests);
  const approveFn = useServerFn(approveReservationRequest);
  const declineFn = useServerFn(declineReservationRequest);

  const { data = [] } = useQuery({
    queryKey: ["reservation-requests"],
    queryFn: () => list(),
    refetchInterval: 60_000,
  });

  const refresh = () => {
    void qc.invalidateQueries({ queryKey: ["reservation-requests"] });
    void qc.invalidateQueries({ queryKey: ["reservations"] });
  };

  const approve = useMutation({
    mutationFn: (id: string) => approveFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Reservation created and confirmation emailed");
      refresh();
    },
    onError: (e: Error) => toast.error(e.message),
  });
  const decline = useMutation({
    mutationFn: (id: string) => declineFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Request declined");
      refresh();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const pending = data.filter((r) => r.status === "pending");
  if (!pending.length) return null;

  return (
    <div className="mb-6 rounded-xl border border-brand/40 bg-card p-5">
      <div className="font-cond text-[11px] uppercase tracking-widest text-brand">
        Client reservation requests · {pending.length}
      </div>
      <div className="mt-3 grid gap-3">
        {pending.map((r) => (
          <div key={r.id} className="rounded-lg border border-border bg-background p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="font-cond text-sm">
                <div className="font-semibold">{r.client_name ?? "Client"}</div>
                <div className="text-muted-foreground">{when(r.pickup_at)}</div>
                <div className="mt-1">
                  {r.pickup_address}
                  {r.dropoff_address ? ` → ${r.dropoff_address}` : ""}
                </div>
                <div className="mt-1 text-muted-foreground">
                  {r.vehicle_class} ·{" "}
                  {r.booking_type === "hourly" ? `Hourly · ${r.hours} hrs` : "Point to point"} ·{" "}
                  {r.passenger_count} pax · {r.luggage_count} luggage
                </div>
                {(r.passenger_name || r.contact_phone || r.contact_email) && (
                  <div className="mt-1 text-muted-foreground">
                    {[r.passenger_name, r.contact_phone, r.contact_email].filter(Boolean).join(" · ")}
                  </div>
                )}
                {r.notes && <div className="mt-1 text-muted-foreground">Notes: {r.notes}</div>}
              </div>
              <div className="flex gap-2">
                <button
                  type="button"
                  disabled={approve.isPending}
                  onClick={() => approve.mutate(r.id)}
                  className="rounded-md bg-emerald-600 px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-white disabled:opacity-60"
                >
                  Approve
                </button>
                <button
                  type="button"
                  disabled={decline.isPending}
                  onClick={() => decline.mutate(r.id)}
                  className="rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-muted-foreground"
                >
                  Decline
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
