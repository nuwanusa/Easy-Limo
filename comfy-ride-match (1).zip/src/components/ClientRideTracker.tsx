import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { CarFront, Clock3, LocateFixed, MessageSquare, Phone } from "lucide-react";
import { getMyRideTracking, type TrackedRide } from "@/lib/reservation-requests.functions";
import { carMarkerHtml } from "@/lib/car-marker";
import type { PortalAuth } from "@/components/PortalView";
import { Button } from "@/components/ui/button";

const statusLabel = (status: string) =>
  ({
    confirmed: "Confirmed",
    assigned: "Chauffeur assigned",
    en_route: "Chauffeur on the way",
    on_location: "Chauffeur on location",
    passenger_on_board: "On board",
  })[status] ?? status.replace(/_/g, " ");

const clock = (value: string | null) =>
  value
    ? new Date(value).toLocaleString("en-US", {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
        timeZone: "America/New_York",
      })
    : "—";

/** Chauffeur marker wrapped in a pulsing beacon so the car is easy to spot. */
const beaconMarkerHtml = (name: string) => `
<div style="position:relative;width:160px;height:96px;pointer-events:none">
  <div style="position:absolute;left:50%;top:38px;width:64px;height:64px;margin-left:-32px;margin-top:-32px;border-radius:9999px;background:rgba(45,138,158,.35);animation:portal-car-pulse 1.6s ease-out infinite"></div>
  <div style="position:absolute;left:50%;top:38px;width:64px;height:64px;margin-left:-32px;margin-top:-32px;border-radius:9999px;background:rgba(45,138,158,.22);animation:portal-car-pulse 1.6s ease-out .8s infinite"></div>
  <div style="position:absolute;left:50%;top:14px;transform:translateX(-50%)">${carMarkerHtml(name)}</div>
  <style>@keyframes portal-car-pulse{0%{transform:scale(.35);opacity:.9}100%{transform:scale(1.5);opacity:0}}</style>
</div>`;

function FullMap({ ride }: { ride: TrackedRide | null }) {
  const ref = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const layerRef = useRef<any>(null);
  const key = `${ride?.id ?? "none"}:${ride?.lat ?? ""},${ride?.lng ?? ""}`;

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const L = (await import("leaflet")).default;
      await import("leaflet/dist/leaflet.css");
      if (cancelled || !ref.current) return;
      const fallback: [number, number] = [40.5795, -74.1502];
      const position: [number, number] | null =
        ride?.lat != null && ride.lng != null ? [Number(ride.lat), Number(ride.lng)] : null;

      if (!mapRef.current) {
        mapRef.current = L.map(ref.current, { zoomControl: false }).setView(position ?? fallback, position ? 15 : 10);
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          maxZoom: 19,
          attribution: "© OpenStreetMap",
        }).addTo(mapRef.current);
        L.control.zoom({ position: "bottomright" }).addTo(mapRef.current);
      }

      layerRef.current?.remove();
      layerRef.current = L.layerGroup().addTo(mapRef.current);
      if (position && ride) {
        L.marker(position, {
          icon: L.divIcon({
            className: "",
            html: beaconMarkerHtml(ride.driver_name ?? "Chauffeur"),
            iconSize: [160, 96],
            iconAnchor: [80, 38],
          }),
        }).addTo(layerRef.current);
        mapRef.current.setView(position, Math.max(mapRef.current.getZoom() ?? 15, 15), { animate: true });
      } else {
        mapRef.current.setView(fallback, 10);
      }
      window.setTimeout(() => mapRef.current?.invalidateSize(), 150);
    })().catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [key, ride]);

  // Re-layout the tiles whenever the map container resizes (e.g. the side
  // panel is minimized), so no dead space is left beside the map.
  useEffect(() => {
    if (!ref.current) return;
    const observer = new ResizeObserver(() => {
      window.setTimeout(() => mapRef.current?.invalidateSize({ animate: false }), 100);
    });
    observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const recenter = () => {
    if (ride?.lat != null && ride?.lng != null && mapRef.current) {
      mapRef.current.setView([Number(ride.lat), Number(ride.lng)], 16, { animate: true });
    }
  };

  return (
    <>
      <div ref={ref} className="absolute inset-0 size-full" aria-label="Live chauffeur map" />
      {ride?.lat != null && ride?.lng != null && (
        <button
          type="button"
          onClick={recenter}
          className="absolute left-3 top-4 z-[500] flex items-center gap-2 rounded-full border border-portal-line bg-portal-panel/95 px-4 py-2 font-portal-body text-xs font-bold text-portal-blue shadow-portal backdrop-blur-md transition hover:bg-portal-mist"
        >
          <LocateFixed className="size-4" /> Find my chauffeur
        </button>
      )}
    </>
  );
}

/** Full-map client tracking workspace with one selectable map for each active ride. */
export function ClientRideTracker({ auth }: { auth?: PortalAuth | undefined }) {
  const load = useServerFn(getMyRideTracking);
  const { data = [], isLoading } = useQuery({
    queryKey: ["my-ride-tracking", auth?.token ?? "", auth?.code ?? ""],
    queryFn: () => load({ data: { token: auth?.token, code: auth?.code } }),
    refetchInterval: 20_000,
  });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const selected = useMemo(
    () => data.find((ride) => ride.id === selectedId) ?? data[0] ?? null,
    [data, selectedId],
  );

  return (
    <section className="relative min-h-[520px] flex-1 overflow-hidden bg-portal-mist lg:min-h-0" aria-label="Live ride tracking">
      <FullMap ride={selected} />

      {data.length > 1 && (
        <div className="absolute left-1/2 top-4 z-[500] flex max-w-[calc(100%-2rem)] -translate-x-1/2 gap-1 overflow-x-auto rounded-full border border-portal-line bg-portal-panel/95 p-1 shadow-portal backdrop-blur-md">
          {data.map((ride) => (
            <Button
              key={ride.id}
              type="button"
              variant={ride.id === selected?.id ? "default" : "ghost"}
              onClick={() => setSelectedId(ride.id)}
              className="h-9 rounded-full px-4 font-portal-body text-xs"
            >
              Ride {ride.reference}
            </Button>
          ))}
        </div>
      )}

      {!selected && (
        <div className="absolute inset-x-4 bottom-5 z-[500] mx-auto max-w-md border border-portal-line bg-portal-panel/95 p-5 text-center shadow-portal backdrop-blur-md sm:bottom-8">
          <LocateFixed className="mx-auto size-6 text-portal-teal" />
          <h2 className="mt-3 font-portal-display text-lg font-semibold text-portal-ink">
            {isLoading ? "Finding your chauffeur" : "No active vehicle yet"}
          </h2>
          <p className="mt-1 font-portal-body text-sm text-portal-muted">
            The live location appears here when a confirmed ride is getting underway.
          </p>
        </div>
      )}

      {selected && (
        <article className="absolute inset-x-3 bottom-3 z-[500] overflow-hidden border border-portal-line bg-portal-panel/95 shadow-portal backdrop-blur-xl sm:bottom-6 sm:left-auto sm:right-6 sm:w-[390px]">
          <div className="bg-portal-teal px-5 py-2 font-portal-body text-[10px] font-bold uppercase tracking-widest text-portal-deep">
            {statusLabel(selected.status)}
          </div>
          <div className="p-5">
            <div className="flex items-start gap-4">
              <div className="grid size-12 shrink-0 place-items-center rounded-md bg-portal-mist text-portal-blue">
                <CarFront className="size-6" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="font-portal-display text-2xl font-bold leading-none text-portal-ink">
                  {selected.eta_minutes != null
                    ? `${selected.eta_minutes} min`
                    : selected.lat != null && selected.lng != null
                      ? "Live location"
                      : "Waiting for GPS"}
                </div>
                <div className="mt-1 flex items-center gap-1 font-portal-body text-xs text-portal-muted">
                  <Clock3 className="size-3.5" />
                  {selected.eta_arrival
                    ? `Arriving about ${clock(selected.eta_arrival)}`
                    : selected.last_seen_at
                      ? `Updated ${clock(selected.last_seen_at)}`
                      : "The chauffeur’s phone has not sent a fresh location"}
                </div>
              </div>
            </div>

            <div className="mt-5 grid grid-cols-2 gap-4 border-t border-portal-line pt-4 font-portal-body">
              <div className="min-w-0">
                <div className="text-[10px] font-semibold uppercase tracking-widest text-portal-muted">Chauffeur</div>
                <div className="mt-1 truncate text-sm font-semibold text-portal-ink">
                  {selected.driver_name ?? "Being assigned"}
                </div>
              </div>
              <div className="min-w-0">
                <div className="text-[10px] font-semibold uppercase tracking-widest text-portal-muted">Vehicle</div>
                <div className="mt-1 text-sm font-semibold text-portal-ink">
                  {[selected.vehicle_color, selected.vehicle].filter(Boolean).join(" ") || "Being assigned"}
                </div>
                {selected.vehicle_plate && <div className="text-xs text-portal-muted">{selected.vehicle_plate}</div>}
              </div>
            </div>

            {selected.eta_destination && (
              <div className="mt-4 border-t border-portal-line pt-3 font-portal-body text-xs text-portal-muted">
                {selected.status === "passenger_on_board" ? "Drop-off" : "Pickup"}: {selected.eta_destination}
              </div>
            )}
          </div>
          <div className="flex items-center justify-between gap-3 border-t border-portal-line bg-portal-mist px-5 py-3">
            <span className="font-portal-body text-xs font-bold text-portal-muted">{selected.reference}</span>
            {selected.driver_phone && (
              <div className="flex gap-2">
                <Button asChild size="sm" variant="outline" className="border-portal-line bg-portal-panel text-portal-blue">
                  <a href={`tel:${selected.driver_phone.replace(/[^\d+]/g, "")}`}><Phone /> Call</a>
                </Button>
                <Button asChild size="sm" className="bg-portal-blue text-primary-foreground hover:bg-portal-ocean">
                  <a href={`sms:${selected.driver_phone.replace(/[^\d+]/g, "")}`}><MessageSquare /> Text</a>
                </Button>
              </div>
            )}
          </div>
        </article>
      )}
    </section>
  );
}