import { Link } from "@tanstack/react-router";
import type { PaymentTarget } from "@/lib/payments.functions";

/** Bottom-of-invoice link that sends the client to the secure card payment page. */
export function PayByCardLink({
  target,
  id,
  amount,
  paid,
  tone = "brand",
}: {
  target: PaymentTarget;
  id: string;
  amount: number;
  paid?: boolean;
  tone?: "brand" | "navy";
}) {
  if (paid || amount <= 0) return null;

  return (
    <div className="no-print mt-6 flex flex-col items-center gap-2 border-t border-border/60 pt-6 print:hidden">
      <Link
        to="/paycard/$target/$id"
        params={{ target, id }}
        className={
          tone === "navy"
            ? "pay-card-link inline-flex items-center gap-2 rounded-lg bg-[#0b3a75] px-7 py-3 text-sm font-bold text-white shadow-sm transition hover:bg-[#1665d8]"
            : "pay-card-link inline-flex items-center gap-2 rounded-lg bg-brand px-7 py-3 text-sm font-bold text-white shadow-sm transition hover:opacity-90"
        }
      >
        Pay ${amount.toFixed(2)} by credit card
      </Link>
      <span className="text-xs text-muted-foreground">
        Secure card payment — a 3% processing fee is added at checkout.
      </span>
    </div>
  );
}
