import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

/** Driver links are always handed out on the public company domain. */
const LINK_BASE = "https://rideblackwave.com";

/**
 * Creates (or reuses) the private one-time chauffeur link for a reservation and
 * offers quick ways to hand it to the driver: WhatsApp, text message or email.
 */
export function GuestLinkShare({
  reservationId,
  token,
  passenger,
  pickup,
  pickupAt,
  onCreated,
}: {
  reservationId: string;
  token?: string | null | undefined;
  passenger?: string | null | undefined;
  pickup?: string | null | undefined;
  pickupAt?: string | null | undefined;
  onCreated?: (() => void) | undefined;
}) {
  const [url, setUrl] = useState<string | null>(
    token ? `${LINK_BASE}/d/${token}` : null,
  );
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState(false);

  const ensure = async () => {
    if (url) return url;
    setBusy(true);
    try {
      let t = token ?? null;
      if (!t) {
        t = `${crypto.randomUUID()}${crypto.randomUUID()}`.replace(/-/g, "");
        const { error } = await supabase
          .from("reservations")
          .update({ guest_link_token: t })
          .eq("id", reservationId);
        if (error) throw error;
        onCreated?.();
      }
      const next = `${LINK_BASE}/d/${t}`;
      setUrl(next);
      return next;
    } finally {
      setBusy(false);
    }
  };

  const when = pickupAt ? new Date(pickupAt).toLocaleString() : "";
  const message = (link: string) =>
    [
      "Blackwave Transportation trip assignment.",
      passenger ? `Passenger: ${passenger}` : "",
      pickup ? `Pickup: ${pickup}` : "",
      when ? `Pickup time: ${when}` : "",
      `Open this link to add your details and start the trip: ${link}`,
    ]
      .filter(Boolean)
      .join("\n");

  const act = async (kind: "copy" | "whatsapp" | "sms" | "email") => {
    // Popup blockers kill window.open once we've awaited, so claim the tab
    // while the click gesture is still live and fill it in afterwards.
    const tab = kind === "whatsapp" ? window.open("", "_blank", "noopener") : null;
    try {
      const link = await ensure();
      const body = message(link);
      if (kind === "copy") {
        await navigator.clipboard.writeText(link);
        toast.success("Driver link copied", { description: link });
        return;
      }
      if (kind === "whatsapp") {
        const wa = `https://wa.me/?text=${encodeURIComponent(body)}`;
        if (tab && !tab.closed) {
          tab.location.href = wa;
        } else if (navigator.share) {
          await navigator.share({ text: body });
        } else {
          window.location.href = wa;
        }
        return;
      }
      if (kind === "sms") {
        window.location.href = `sms:?&body=${encodeURIComponent(body)}`;
        return;
      }
      window.location.href = `mailto:?subject=${encodeURIComponent(
        "Your Blackwave trip link",
      )}&body=${encodeURIComponent(body)}`;
    } catch (e) {
      tab?.close();
      toast.error(e instanceof Error ? e.message : "Could not create the link");
    }
  };

  const btn =
    "rounded border border-border px-2 py-1 font-cond text-[10px] uppercase tracking-widest hover:border-brand hover:text-brand disabled:opacity-50";

  return (
    <div className="mt-1">
      <button
        onClick={() => setOpen((v) => !v)}
        className="block font-cond text-[10px] uppercase tracking-widest text-brand hover:underline"
      >
        One-time driver link
      </button>
      {open && (
        <div className="mt-1 flex flex-wrap gap-1">
          <button disabled={busy} onClick={() => act("copy")} className={btn}>
            Copy
          </button>
          <button disabled={busy} onClick={() => act("whatsapp")} className={btn}>
            WhatsApp
          </button>
          <button disabled={busy} onClick={() => act("sms")} className={btn}>
            Text
          </button>
          <button disabled={busy} onClick={() => act("email")} className={btn}>
            Email
          </button>
        </div>
      )}
    </div>
  );
}
