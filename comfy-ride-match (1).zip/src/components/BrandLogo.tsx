import logoAsset from "@/assets/blackwave-logo.png.asset.json";

export const BRAND_LOGO_URL = logoAsset.url;

/** Blackwave mark. The artwork is white on black, so it sits on a black plate. */
export function BrandLogo({
  className = "h-10 w-10",
  alt = "Blackwave Transportation",
}: {
  className?: string;
  alt?: string;
}) {
  return (
    <img
      src={BRAND_LOGO_URL}
      alt={alt}
      loading="lazy"
      className={`shrink-0 rounded-md bg-black object-contain p-0.5 ${className}`}
    />
  );
}
