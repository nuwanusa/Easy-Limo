import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  createClientPortalLogin,
  ensureClientPortalAccess,
  listClientPortalLogins,
  removeClientPortalLogin,
  setClientPortalSlug,
} from "@/lib/client-portal.functions";

const SITE = "https://rideblackwave.com";

/** Staff controls: private portal link + client sign-in accounts. */
export function ClientPortalAccess({ clientId, clientName }: { clientId: string; clientName: string }) {
  const qc = useQueryClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [access, setAccess] = useState<{ slug: string; code: string } | null>(null);
  const [slugDraft, setSlugDraft] = useState("");

  const ensureAccess = useServerFn(ensureClientPortalAccess);
  const createLogin = useServerFn(createClientPortalLogin);
  const listLogins = useServerFn(listClientPortalLogins);
  const removeLogin = useServerFn(removeClientPortalLogin);
  const saveSlug = useServerFn(setClientPortalSlug);

  const logins = useQuery({
    queryKey: ["client-portal-logins", clientId],
    queryFn: () => listLogins({ data: { clientId } }),
  });

  const makeLink = useMutation({
    mutationFn: (rotateCode: boolean) => ensureAccess({ data: { clientId, rotateCode } }),
    onSuccess: (res) => {
      setAccess(res);
      setSlugDraft(res.slug);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const rename = useMutation({
    mutationFn: () => saveSlug({ data: { clientId, slug: slugDraft } }),
    onSuccess: (res) => {
      setAccess((a) => (a ? { ...a, slug: res.slug } : a));
      setSlugDraft(res.slug);
      toast.success("Short link updated");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const addLogin = useMutation({
    mutationFn: () => createLogin({ data: { clientId, email: email.trim(), password } }),
    onSuccess: () => {
      toast.success("Portal login created");
      setEmail("");
      setPassword("");
      qc.invalidateQueries({ queryKey: ["client-portal-logins", clientId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const drop = useMutation({
    mutationFn: (id: string) => removeLogin({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["client-portal-logins", clientId] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const share = (text: string) => {
    navigator.clipboard?.writeText(text);
    toast.success("Link copied");
  };

  return (
    <div className="rounded-lg border border-border bg-card p-5">
      <div className="font-cond text-xs uppercase tracking-[0.3em] text-brand">Client portal — {clientName}</div>
      <p className="mt-1 text-sm text-muted-foreground">
        Give this client access to their paid and unpaid invoices with the full ride breakdown.
      </p>

      <div className="mt-4">
        <div className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
          Shareable page + access code
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => makeLink.mutate(false)}
            className="rounded-md border border-border px-3 py-2 font-cond text-[11px] uppercase tracking-widest hover:border-brand hover:text-brand"
          >
            {makeLink.isPending ? "Working…" : "Get link & code"}
          </button>
          <button
            type="button"
            onClick={() => makeLink.mutate(true)}
            className="rounded-md border border-border px-3 py-2 font-cond text-[11px] uppercase tracking-widest hover:border-destructive hover:text-destructive"
          >
            New code (revoke old)
          </button>
        </div>

        {access && (
          <div className="mt-3 space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <input
                value={slugDraft}
                onChange={(e) => setSlugDraft(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "-"))}
                className="min-w-[12rem] flex-1 rounded-md border border-input bg-surface-2 px-3 py-2 text-sm"
              />
              <button
                type="button"
                onClick={() => share(`${SITE}/${access.slug}`)}
                className="rounded-md bg-brand px-3 py-2 font-cond text-[11px] uppercase tracking-widest text-brand-foreground"
              >
                Copy
              </button>
              {slugDraft.trim() !== access.slug && (
                <button
                  type="button"
                  disabled={rename.isPending}
                  onClick={() => rename.mutate()}
                  className="rounded-md border border-border px-3 py-2 font-cond text-[11px] uppercase tracking-widest hover:border-brand hover:text-brand disabled:opacity-50"
                >
                  {rename.isPending ? "Saving…" : "Save short link"}
                </button>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-2 rounded-md border border-brand/40 bg-surface-2 px-3 py-2">
              <span className="font-mono text-sm font-semibold text-brand">
                {SITE}/c/{access.code}
              </span>
              <button
                type="button"
                onClick={() => share(`${SITE}/c/${access.code}`)}
                className="rounded-md bg-brand px-3 py-1.5 font-cond text-[11px] uppercase tracking-widest text-brand-foreground"
              >
                Copy short link
              </button>
            </div>
            <p className="text-xs text-muted-foreground">
              This short link opens the client&apos;s portal directly — no code typing needed. Keep it private: anyone
              with the link can view the account.
            </p>
            <div className="flex flex-wrap items-center gap-2">
              <div className="rounded-md border border-border bg-surface-2 px-4 py-2 font-display text-xl tracking-[0.4em]">
                {access.code}
              </div>
              <button
                type="button"
                onClick={() =>
                  share(
                    `View your Blackwave invoices: ${SITE}/${access.slug}\nAccess code: ${access.code}`,
                  )
                }
                className="rounded-md border border-border px-3 py-2 font-cond text-[11px] uppercase tracking-widest hover:border-brand hover:text-brand"
              >
                Copy link + code
              </button>
            </div>
            <p className="text-xs text-muted-foreground">
              The client opens {SITE}/{access.slug} and enters this six-digit code — no password needed. Type a shorter
              name and press “Save short link” to make the link easy to text (e.g. {SITE}/adjaye).
            </p>
          </div>
        )}
      </div>

      <div className="mt-6">
        <div className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">Sign-in accounts</div>
        <div className="mt-2 space-y-1">
          {(logins.data ?? []).map((l) => (
            <div key={l.id} className="flex items-center justify-between gap-3 border-b border-border/60 py-1.5 text-sm">
              <span>{l.email}</span>
              <button
                type="button"
                onClick={() => drop.mutate(l.id)}
                className="font-cond text-[10px] uppercase tracking-widest text-destructive"
              >
                Remove
              </button>
            </div>
          ))}
          {(logins.data ?? []).length === 0 && (
            <p className="text-sm text-muted-foreground">No portal logins yet.</p>
          )}
        </div>

        <div className="mt-3 flex flex-wrap gap-2">
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="client@company.com"
            className="min-w-[14rem] flex-1 rounded-md border border-input bg-surface-2 px-3 py-2 text-sm"
          />
          <input
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Temporary password"
            className="min-w-[12rem] flex-1 rounded-md border border-input bg-surface-2 px-3 py-2 text-sm"
          />
          <button
            type="button"
            onClick={() => addLogin.mutate()}
            disabled={addLogin.isPending}
            className="rounded-md bg-brand px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-brand-foreground disabled:opacity-50"
          >
            {addLogin.isPending ? "Creating…" : "Create login"}
          </button>
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          They sign in at {SITE}/auth with this email and password.
        </p>
      </div>
    </div>
  );
}
