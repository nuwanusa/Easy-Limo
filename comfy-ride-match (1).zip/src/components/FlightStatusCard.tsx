import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getFlightStatus } from "@/lib/flight.functions";

const timeOnly = (iso: string | null) =>
  iso
    ? new Date(iso).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true })
    : "—";

/** Live arrival time / terminal / gate for the passenger's flight. */
export function FlightStatusCard({
  flightNumber,
  pickupAt,
}: {
  flightNumber: string;
  pickupAt: string | null;
}) {
  const fetchFlight = useServerFn(getFlightStatus);
  const date = pickupAt ? new Date(pickupAt).toISOString().slice(0, 10) : undefined;

  const flight = useQuery({
    queryKey: ["flight", flightNumber, date],
    staleTime: 120_000,
    refetchInterval: 180_000,
    retry: false,
    queryFn: () => fetchFlight({ data: { flightNumber, ...(date ? { date } : {}) } }),
  });

  return (
    <div className="mt-4 rounded-lg border border-brand/40 bg-brand/5 p-5">
      <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
        Flight {flightNumber}
      </div>
      {flight.isLoading ? (
        <div className="mt-1 font-cond text-sm text-muted-foreground">Checking the flight…</div>
      ) : flight.isError ? (
        <div className="mt-1 font-cond text-sm text-muted-foreground">
          Live flight information is unavailable right now.
        </div>
      ) : !flight.data ? (
        <div className="mt-1 font-cond text-sm text-muted-foreground">
          No live information found for this flight.
        </div>
      ) : (
        <>
          <div className="font-display text-4xl uppercase leading-none">
            {timeOnly(flight.data.arrivalEstimated)}
          </div>
          <div className="mt-1 font-cond text-[12px] text-muted-foreground">
            Lands {flight.data.arrivalAirport ?? ""}
            {flight.data.arrivalScheduled &&
            flight.data.arrivalScheduled !== flight.data.arrivalEstimated
              ? ` · scheduled ${timeOnly(flight.data.arrivalScheduled)}`
              : ""}
            {flight.data.arrivalDelayMinutes
              ? ` · ${flight.data.arrivalDelayMinutes} min late`
              : ""}
          </div>
          <div className="mt-2 grid grid-cols-3 gap-2">
            <Cell label="Status" value={flight.data.status?.replace(/_/g, " ") ?? null} />
            <Cell label="Terminal" value={flight.data.arrivalTerminal} />
            <Cell label="Gate" value={flight.data.arrivalGate} />
          </div>
          {(flight.data.arrivalBaggage || flight.data.airline) && (
            <div className="mt-2 font-cond text-[12px] text-muted-foreground">
              {flight.data.airline ?? ""}
              {flight.data.arrivalBaggage ? ` · baggage belt ${flight.data.arrivalBaggage}` : ""}
            </div>
          )}
        </>
      )}
    </div>
  );
}

function Cell({ label, value }: { label: string; value?: string | null }) {
  return (
    <div>
      <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
        {label}
      </div>
      <div className="font-cond text-[13px]">{value || "—"}</div>
    </div>
  );
}
