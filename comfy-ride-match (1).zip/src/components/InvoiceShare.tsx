import { useState } from "react";
import { toast } from "sonner";

const EXPORT_WIDTH = 1800;

/**
 * Renders the invoice into an off-screen clone at a fixed page width so the
 * saved file always looks like a proper document, whatever the screen size.
 */
async function renderInvoice(): Promise<HTMLCanvasElement> {
  const source = document.querySelector<HTMLElement>(".invoice-sheet");
  if (!source) throw new Error("Invoice not ready yet");

  const holder = document.createElement("div");
  holder.setAttribute("aria-hidden", "true");
  holder.style.cssText = `position:fixed;top:0;left:-100000px;width:${EXPORT_WIDTH}px;background:#ffffff;pointer-events:none;z-index:-1;`;
  const clone = source.cloneNode(true) as HTMLElement;
  clone.classList.add("invoice-export");
  holder.appendChild(clone);
  document.body.appendChild(holder);

  try {
    if (document.fonts?.ready) await document.fonts.ready;
    const { toCanvas } = await import("html-to-image");
    const height = Math.ceil(clone.scrollHeight);
    return await toCanvas(clone, {
      pixelRatio: 2,
      backgroundColor: "#ffffff",
      cacheBust: true,
      width: EXPORT_WIDTH,
      height,
      style: { width: `${EXPORT_WIDTH}px`, height: `${height}px`, margin: "0" },
    });
  } finally {
    holder.remove();
  }
}

async function invoiceBlob(): Promise<Blob> {
  const canvas = await renderInvoice();
  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, "image/jpeg", 0.95),
  );
  if (!blob) throw new Error("Could not render the invoice");
  return blob;
}

function download(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}


export function InvoiceShare({ number }: { number: string }) {
  const [busy, setBusy] = useState<string | null>(null);
  const base = `Billing-Statement-${number || "draft"}`;

  const run = async (kind: "jpeg" | "pdf" | "share") => {
    setBusy(kind);
    try {
      if (kind === "pdf") {
        const canvas = await renderInvoice();
        const { jsPDF } = await import("jspdf");
        // Portrait A4: the invoice is scaled to the page width and sliced into
        // clean page-height bands so nothing is cut mid-row.
        const pdf = new jsPDF({ unit: "pt", format: "a4", orientation: "portrait" });
        const margin = 28;
        const pageW = pdf.internal.pageSize.getWidth();
        const pageH = pdf.internal.pageSize.getHeight();
        const usableW = pageW - margin * 2;
        const usableH = pageH - margin * 2;
        const scale = usableW / canvas.width; // canvas px -> pt
        const sliceH = Math.floor(usableH / scale); // canvas px per page
        const pages = Math.max(1, Math.ceil(canvas.height / sliceH));

        for (let p = 0; p < pages; p++) {
          const y = p * sliceH;
          const h = Math.min(sliceH, canvas.height - y);
          const part = document.createElement("canvas");
          part.width = canvas.width;
          part.height = h;
          const ctx = part.getContext("2d");
          if (!ctx) throw new Error("Could not render the invoice");
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(0, 0, part.width, part.height);
          ctx.drawImage(canvas, 0, y, canvas.width, h, 0, 0, canvas.width, h);
          if (p > 0) pdf.addPage("a4", "portrait");
          pdf.addImage(
            part.toDataURL("image/jpeg", 0.95),
            "JPEG",
            margin,
            margin,
            usableW,
            h * scale,
            undefined,
            "FAST",
          );
        }
        pdf.save(`${base}.pdf`);
        return;
      }

      const blob = await invoiceBlob();
      if (kind === "jpeg") {
        download(blob, `${base}.jpg`);
      } else {

        const file = new File([blob], `${base}.jpg`, { type: "image/jpeg" });
        const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
        if (nav.canShare?.({ files: [file] })) {
          await navigator.share({ files: [file], title: base });
        } else {
          download(blob, `${base}.jpg`);
          toast.info("Saved the statement image — attach it to your email or message.");
        }
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Export failed");
    } finally {
      setBusy(null);
    }
  };

  const cls =
    "rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest hover:border-brand hover:text-brand disabled:opacity-60";

  return (
    <>
      <button onClick={() => run("jpeg")} disabled={!!busy} className={cls}>
        {busy === "jpeg" ? "Saving…" : "Save JPEG"}
      </button>
      <button onClick={() => run("pdf")} disabled={!!busy} className={cls}>
        {busy === "pdf" ? "Saving…" : "Save PDF"}
      </button>
      <button onClick={() => run("share")} disabled={!!busy} className={cls}>
        {busy === "share" ? "Preparing…" : "Share"}
      </button>
    </>
  );
}
