import { useCallback, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { EmbeddedCheckoutProvider, EmbeddedCheckout } from "@stripe/react-stripe-js";
import { toast } from "sonner";
import { getStripe, getStripeEnvironment, paymentsConfigured } from "@/lib/stripe";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";
import {
  listClientCards,
  listClientCardsStaff,
  listMyCards,
  removeClientCard,
  removeClientCardStaff,
  removeMyCard,
  startClientCardSetup,
  startClientCardSetupStaff,
  startMyCardSetup,
  type CardHolder,
  type SavedCard,
} from "@/lib/client-cards.functions";

type Auth = { token?: string | undefined; code?: string | undefined };

const emptyHolder = {
  name: "",
  email: "",
  phone: "",
  line1: "",
  line2: "",
  city: "",
  state: "",
  postal_code: "",
  country: "US",
};

const BRANDS: Record<string, string> = {
  visa: "Visa",
  mastercard: "MasterCard",
  amex: "American Express",
  discover: "Discover",
  diners: "Diners Club",
  jcb: "JCB",
  unionpay: "UnionPay",
};

const brandLabel = (b: string) => BRANDS[b] ?? "Card";

const input =
  "w-full rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:border-brand";

export function CardsOnFile({
  clientId,
  auth,
  staff,
  embedded = false,
  defaultOpen = false,
}: {
  clientId?: string | undefined;
  auth?: Auth | undefined;
  staff?: boolean | undefined;
  embedded?: boolean | undefined;
  defaultOpen?: boolean | undefined;
}) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(defaultOpen);
  const [holder, setHolder] = useState({ ...emptyHolder });
  const [confirmed, setConfirmed] = useState<CardHolder | null>(null);
  const [error, setError] = useState<string | null>(null);

  const portalGuest = Boolean(auth?.token || auth?.code);
  const key = ["client-cards", staff ? clientId : portalGuest ? (auth?.token ?? auth?.code) : "me"];

  const { data: cards = [], isLoading } = useQuery({
    queryKey: key,
    enabled: staff ? Boolean(clientId) : true,
    queryFn: async (): Promise<SavedCard[]> => {
      if (staff) return listClientCardsStaff({ data: { clientId: clientId as string } });
      if (portalGuest) return listClientCards({ data: { ...auth } });
      return listMyCards({ data: {} });
    },
  });

  const remove = useMutation({
    mutationFn: async (cardId: string) => {
      const environment = getStripeEnvironment();
      if (staff) return removeClientCardStaff({ data: { clientId: clientId as string, cardId, environment } });
      if (portalGuest) return removeClientCard({ data: { cardId, environment, ...auth } });
      return removeMyCard({ data: { cardId, environment } });
    },
    onSuccess: () => {
      toast.success("Card removed");
      qc.invalidateQueries({ queryKey: key });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Could not remove that card"),
  });

  const fetchClientSecret = useCallback(async (): Promise<string> => {
    const payload = {
      holder: confirmed as CardHolder,
      returnUrl: `${window.location.origin}/checkout/return?card=1&session_id={CHECKOUT_SESSION_ID}`,
      environment: getStripeEnvironment(),
    };
    const result = staff
      ? await startClientCardSetupStaff({ data: { ...payload, clientId: clientId as string } })
      : portalGuest
        ? await startClientCardSetup({ data: { ...payload, ...auth } })
        : await startMyCardSetup({ data: payload });
    if ("error" in result) throw new Error(result.error as string);
    if (!result.clientSecret) throw new Error("The secure card form could not be opened");
    return result.clientSecret;
  }, [confirmed, staff, clientId, portalGuest, auth]);

  const set = (k: keyof typeof emptyHolder) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setHolder((h) => ({ ...h, [k]: e.target.value }));

  return (
    <div className={embedded ? "space-y-3" : "rounded-lg border border-border bg-card p-4"}>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">Cards on file</div>
          {!embedded && (
            <p className="text-sm text-muted-foreground">
              Visa, MasterCard, Discover and American Express. The card number, expiry and security code are entered on a
              secure payment form and are never stored here.
            </p>
          )}
        </div>
        {paymentsConfigured() && (
          <button
            type="button"
            onClick={() => {
              setError(null);
              setConfirmed(null);
              setHolder({ ...emptyHolder });
              setOpen(!open);
            }}
            className="rounded-md bg-brand px-4 py-2 font-cond text-xs uppercase tracking-widest text-white transition hover:opacity-90"
          >
            {open ? "Cancel" : "Add card"}
          </button>
        )}
      </div>

      {!paymentsConfigured() && (
        <p className="mt-3 text-sm text-muted-foreground">
          Card payments are not switched on for this site yet, so cards cannot be saved.
        </p>
      )}

      {open && !confirmed && (
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <input className={input} placeholder="Name on card" value={holder.name} onChange={set("name")} />
          <input className={input} placeholder="Email address" value={holder.email} onChange={set("email")} />
          <input className={input} placeholder="Phone number" value={holder.phone} onChange={set("phone")} />
          <input className={input} placeholder="Country" value={holder.country} onChange={set("country")} />
          <input className={input} placeholder="Billing address" value={holder.line1} onChange={set("line1")} />
          <input className={input} placeholder="Apt / suite" value={holder.line2} onChange={set("line2")} />
          <input className={input} placeholder="City" value={holder.city} onChange={set("city")} />
          <input className={input} placeholder="State" value={holder.state} onChange={set("state")} />
          <input className={input} placeholder="ZIP code" value={holder.postal_code} onChange={set("postal_code")} />
          <div className="sm:col-span-2">
            <button
              type="button"
              onClick={() => {
                if (staff && !clientId) {
                  toast.error("Choose a client account first");
                  return;
                }
                if (holder.name.trim().length < 2) {
                  toast.error("Enter the name on the card");
                  return;
                }
                setConfirmed({ ...holder });
              }}
              className="rounded-md bg-brand px-4 py-2 font-cond text-xs uppercase tracking-widest text-white transition hover:opacity-90"
            >
              Continue to card details
            </button>
          </div>
        </div>
      )}

      {open && confirmed && (
        <div className="mt-4">
          <PaymentTestModeBanner />
          {error ? (
            <p className="mt-3 text-sm text-destructive">{error}</p>
          ) : (
            <div className="mt-3">
              <EmbeddedCheckoutProvider stripe={getStripe()} options={{ fetchClientSecret }}>
                <EmbeddedCheckout />
              </EmbeddedCheckoutProvider>
            </div>
          )}
        </div>
      )}

      <div className={embedded ? "space-y-2" : "mt-4 space-y-2"}>
        {isLoading ? (
          <p className="text-sm text-muted-foreground">Loading saved cards…</p>
        ) : cards.length === 0 ? (
          <p className="text-sm text-muted-foreground">No cards saved yet.</p>
        ) : (
          cards.map((c) => (
            <div
              key={c.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-border px-3 py-2"
            >
              <div className="text-sm">
                <div className="font-medium">
                  {brandLabel(c.brand)} •••• {c.last4}
                  <span className="ml-2 text-muted-foreground">
                    exp {String(c.exp_month).padStart(2, "0")}/{String(c.exp_year).slice(-2)}
                  </span>
                </div>
                <div className="text-muted-foreground">
                  {c.cardholder_name}
                  {c.cardholder_phone ? ` · ${c.cardholder_phone}` : ""}
                  {c.cardholder_email ? ` · ${c.cardholder_email}` : ""}
                </div>
                {(c.billing_line1 || c.billing_city) && (
                  <div className="text-muted-foreground">
                    {[c.billing_line1, c.billing_line2, c.billing_city, c.billing_state, c.billing_postal_code]
                      .filter(Boolean)
                      .join(", ")}
                  </div>
                )}
              </div>
              <button
                type="button"
                onClick={() => remove.mutate(c.id)}
                className="font-cond text-xs uppercase tracking-widest text-destructive"
              >
                Remove
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
