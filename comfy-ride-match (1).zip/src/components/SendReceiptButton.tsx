import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Copy, Mail, ReceiptText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getPaymentReceiptShareLink, resendPaymentReceipt } from "@/lib/manual-payment.functions";
import type { PaymentTarget } from "@/lib/payments.functions";

interface SendReceiptButtonProps {
  target: PaymentTarget;
  id: string;
  paid?: boolean;
}

export function SendReceiptButton({ target, id, paid }: SendReceiptButtonProps) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const send = useServerFn(resendPaymentReceipt);
  const getLink = useServerFn(getPaymentReceiptShareLink);

  const receiptLink = useQuery({
    queryKey: ["payment-receipt-share-link", target, id],
    queryFn: () => getLink({ data: { target, id } }),
    enabled: Boolean(paid && open),
    staleTime: 5 * 60_000,
  });

  const mutation = useMutation({
    mutationFn: async () => send({ data: { target, id, name: name.trim(), email: email.trim() } }),
    onSuccess: (res) => {
      if (res?.sent) {
        toast.success(`Payment receipt sent to ${email.trim()}`);
        setName("");
        setEmail("");
        setOpen(false);
      }
      else if (res?.reason === "no_client_email") toast.error("No client email on file");
      else toast.warning("The payment receipt could not be sent", { description: res?.reason });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (!paid) return null;

  const url = receiptLink.data?.url ?? "";

  const copyLink = async () => {
    if (!url) {
      toast.error(receiptLink.data?.reason === "no_client" ? "Add a client to create a receipt link" : "Receipt link is not ready yet");
      return;
    }
    try {
      await navigator.clipboard.writeText(url);
      toast.success("Payment receipt link copied");
    } catch {
      toast.error("Could not copy the receipt link");
    }
  };

  return (
    <div className="no-print w-full rounded-md border border-border bg-card p-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 font-cond text-[11px] uppercase tracking-widest text-foreground">
          <ReceiptText className="size-4 text-brand" />
          Share payment receipt
        </div>
        <div className="flex flex-wrap gap-2">
          <Button type="button" variant="outline" size="sm" onClick={() => setOpen((value) => !value)}>
            <Mail /> {open ? "Close" : "Share to email"}
          </Button>
          <Button type="button" variant="outline" size="sm" onClick={() => void copyLink()} disabled={receiptLink.isFetching}>
            <Copy /> {receiptLink.isFetching ? "Preparing…" : "Copy share link"}
          </Button>
        </div>
      </div>

      {open ? (
        <form
          className="mt-3 grid gap-2 border-t border-border pt-3 sm:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)_auto]"
          onSubmit={(event) => {
            event.preventDefault();
            mutation.mutate();
          }}
        >
          <input
            type="text"
            required
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="Recipient name"
            className="h-10 rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-brand"
          />
          <input
            type="email"
            required
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="Recipient email"
            className="h-10 rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-brand"
          />
          <Button type="submit" className="h-10" disabled={mutation.isPending}>
            <Mail /> {mutation.isPending ? "Sending…" : "Send receipt"}
          </Button>
          <div className="flex min-w-0 items-center gap-2 sm:col-span-3">
            <input
              aria-label="Payment receipt share link"
              readOnly
              value={receiptLink.isFetching ? "Preparing receipt link…" : url || "A client is required to create a receipt link"}
              className="h-9 min-w-0 flex-1 rounded-md border border-input bg-muted px-3 text-xs text-muted-foreground"
            />
            <Button type="button" variant="outline" size="sm" onClick={() => void copyLink()} disabled={!url}>
              <Copy /> Copy
            </Button>
          </div>
        </form>
      ) : null}
    </div>
  );
}
