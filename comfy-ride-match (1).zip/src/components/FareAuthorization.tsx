import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { authorizeFare, captureFareHold, getFareHold, releaseFareHold } from "@/lib/fare-auth.functions";
import { listClientCardsStaff } from "@/lib/client-cards.functions";
import { getStripeEnvironment, paymentsConfigured } from "@/lib/stripe";
import { money } from "@/lib/dispatch";

/**
 * Staff control for holding the fare on a client's saved card before the ride
 * and charging or releasing it afterwards.
 */
export function FareAuthorization({
  reservationId,
  clientId,
}: {
  reservationId: string;
  clientId: string | null;
}) {
  const queryClient = useQueryClient();
  const [cardId, setCardId] = useState("");
  const [amount, setAmount] = useState("");
  const [busy, setBusy] = useState(false);

  const { data: hold } = useQuery({
    queryKey: ["fare-hold", reservationId],
    queryFn: () => getFareHold({ data: { reservationId } }),
  });

  const { data: cards = [] } = useQuery({
    queryKey: ["client-cards", clientId],
    queryFn: () => listClientCardsStaff({ data: { clientId: clientId as string } }),
    enabled: Boolean(clientId),
  });

  const refresh = async () => {
    await queryClient.invalidateQueries({ queryKey: ["fare-hold", reservationId] });
    await queryClient.invalidateQueries({ queryKey: ["reservation", reservationId] });
  };

  const run = async (fn: () => Promise<{ error?: string } | any>, ok: string) => {
    setBusy(true);
    try {
      const res = await fn();
      if (res?.error) toast.error(res.error);
      else {
        toast.success(ok);
        setAmount("");
        await refresh();
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Something went wrong");
    } finally {
      setBusy(false);
    }
  };

  const suggested = hold?.estimate ?? 0;
  const typed = Number(amount);
  const active = hold?.status === "authorized";

  return (
    <div className="rounded-lg border border-border bg-card p-5">
      <div className="font-cond text-[10px] uppercase tracking-widest text-brand">Card hold</div>

      {!paymentsConfigured() ? (
        <p className="mt-2 font-cond text-[13px] text-muted-foreground">
          Card payments are not set up for this build yet.
        </p>
      ) : active ? (
        <div className="mt-3 space-y-3">
          <p className="font-cond text-[13px]">
            Holding <strong>{money(hold?.amount ?? 0)}</strong>
            {hold?.brand ? ` on the ${hold.brand} ending ${hold.last4}` : ""} since{" "}
            {hold?.authorizedAt
              ? new Date(hold.authorizedAt).toLocaleString("en-US", { timeZone: "America/New_York" })
              : "—"}
            . The money is reserved, not taken.
          </p>
          <input
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            inputMode="decimal"
            placeholder={`Amount to charge (default ${money(hold?.amount ?? 0)})`}
            className="h-9 w-full rounded-md border border-border bg-background px-3 font-cond text-[13px]"
          />
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              disabled={busy}
              onClick={() =>
                run(
                  () =>
                    captureFareHold({
                      data: {
                        reservationId,
                        ...(amount && typed > 0 ? { amount: typed } : {}),
                        environment: getStripeEnvironment(),
                      },
                    }),
                  "Payment taken",
                )
              }
              className="h-9 rounded-md bg-brand px-4 font-cond text-[11px] uppercase tracking-widest text-white disabled:opacity-50"
            >
              Charge the hold
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() =>
                run(
                  () => releaseFareHold({ data: { reservationId, environment: getStripeEnvironment() } }),
                  "Hold released",
                )
              }
              className="h-9 rounded-md border border-border px-4 font-cond text-[11px] uppercase tracking-widest disabled:opacity-50"
            >
              Release hold
            </button>
          </div>
          <p className="font-cond text-[11px] text-muted-foreground">
            A hold expires after 7 days. You can charge less than the hold, never more.
          </p>
        </div>
      ) : hold?.status === "captured" ? (
        <p className="mt-2 font-cond text-[13px]">
          Charged {money(hold.capturedAmount)}
          {hold.capturedAt
            ? ` on ${new Date(hold.capturedAt).toLocaleString("en-US", { timeZone: "America/New_York" })}`
            : ""}
          .
        </p>
      ) : !clientId ? (
        <p className="mt-2 font-cond text-[13px] text-muted-foreground">
          Add a client account to this ride to hold the fare on a card.
        </p>
      ) : cards.length === 0 ? (
        <p className="mt-2 font-cond text-[13px] text-muted-foreground">
          No card on file for this client yet — add one from the client profile.
        </p>
      ) : (
        <div className="mt-3 space-y-3">
          {hold?.status === "released" ? (
            <p className="font-cond text-[12px] text-muted-foreground">The previous hold was released.</p>
          ) : null}
          <select
            value={cardId}
            onChange={(e) => setCardId(e.target.value)}
            className="h-9 w-full rounded-md border border-border bg-background px-3 font-cond text-[13px]"
          >
            <option value="">Choose a card on file</option>
            {cards.map((c) => (
              <option key={c.id} value={c.id}>
                {c.brand} •••• {c.last4} · {c.cardholder_name}
              </option>
            ))}
          </select>
          <input
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            inputMode="decimal"
            placeholder={`Amount to hold (fare ${money(suggested)})`}
            className="h-9 w-full rounded-md border border-border bg-background px-3 font-cond text-[13px]"
          />
          <button
            type="button"
            disabled={busy || !cardId}
            onClick={() =>
              run(
                () =>
                  authorizeFare({
                    data: {
                      reservationId,
                      cardId,
                      ...(amount && typed > 0 ? { amount: typed } : {}),
                      environment: getStripeEnvironment(),
                    },
                  }),
                "Card authorized",
              )
            }
            className="h-9 rounded-md bg-brand px-4 font-cond text-[11px] uppercase tracking-widest text-white disabled:opacity-50"
          >
            Authorize fare
          </button>
          <p className="font-cond text-[11px] text-muted-foreground">
            Leave the amount blank to hold the current fare. Many operators add 15–20% for tolls and waiting time.
          </p>
        </div>
      )}
    </div>
  );
}
