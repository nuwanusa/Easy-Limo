import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Building2, Globe, Mail, MapPin, Phone, Printer, Save, Upload, Hash, Map as MapIcon } from "lucide-react";
import type { LucideIcon } from "lucide-react";

type CompanyProfileRow = {
  id: string;
  name: string;
  code: string;
  address_line1: string | null;
  address_line2: string | null;
  city: string | null;
  state: string | null;
  postal_code: string | null;
  billing_email: string | null;
  default_email: string | null;
  support_email: string | null;
  phone_primary: string | null;
  phone_secondary: string | null;
  fax: string | null;
  website: string | null;
  logo_url: string | null;
};

type FormState = Omit<CompanyProfileRow, "id" | "code">;

const EMPTY: FormState = {
  name: "",
  address_line1: "",
  address_line2: "",
  city: "",
  state: "",
  postal_code: "",
  billing_email: "",
  default_email: "",
  support_email: "",
  phone_primary: "",
  phone_secondary: "",
  fax: "",
  website: "",
  logo_url: "",
};

/** Shrinks a picked image to a small square-ish logo stored inline with the company. */
function readLogo(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read that image"));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("That file is not an image"));
      img.onload = () => {
        const max = 512;
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext("2d");
        if (!ctx) return reject(new Error("Could not process that image"));
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/png"));
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
  icon: Icon,
  required,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  placeholder?: string;
  icon: LucideIcon;
  required?: boolean;
}) {
  return (
    <label className="grid min-w-0 gap-1.5">
      <span className="text-sm font-medium text-dashboard-navy">
        {label}
        {required && <span className="text-dashboard-red"> *</span>}
      </span>
      <span className="flex h-10 overflow-hidden rounded-md border border-dashboard-line bg-card focus-within:ring-2 focus-within:ring-dashboard-blue/30">
        <span className="grid w-10 shrink-0 place-items-center border-r border-dashboard-line text-dashboard-muted">
          <Icon className="h-4 w-4" />
        </span>
        <input
          type={type}
          value={value}
          placeholder={placeholder}
          onChange={(e) => onChange(e.target.value)}
          className="min-w-0 flex-1 bg-transparent px-3 text-sm text-dashboard-navy outline-none placeholder:text-dashboard-muted/70"
        />
      </span>
    </label>
  );
}

export function CompanyProfile() {
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [form, setForm] = useState<FormState>(EMPTY);

  const profile = useQuery({
    queryKey: ["company-profile"],
    queryFn: async () => {
      const { data: sessionData } = await supabase.auth.getSession();
      const userId = sessionData.session?.user?.id;
      if (!userId) return null;
      const { data: membership } = await supabase
        .from("company_users")
        .select("company_id")
        .eq("user_id", userId)
        .maybeSingle();
      if (!membership) return null;
      const { data, error } = await supabase
        .from("companies")
        .select(
          "id, name, code, address_line1, address_line2, city, state, postal_code, billing_email, default_email, support_email, phone_primary, phone_secondary, fax, website, logo_url",
        )
        .eq("id", membership.company_id)
        .maybeSingle();
      if (error) throw error;
      return (data ?? null) as CompanyProfileRow | null;
    },
  });

  useEffect(() => {
    const row = profile.data;
    if (!row) return;
    setForm({
      name: row.name ?? "",
      address_line1: row.address_line1 ?? "",
      address_line2: row.address_line2 ?? "",
      city: row.city ?? "",
      state: row.state ?? "",
      postal_code: row.postal_code ?? "",
      billing_email: row.billing_email ?? "",
      default_email: row.default_email ?? "",
      support_email: row.support_email ?? "",
      phone_primary: row.phone_primary ?? "",
      phone_secondary: row.phone_secondary ?? "",
      fax: row.fax ?? "",
      website: row.website ?? "",
      logo_url: row.logo_url ?? "",
    });
  }, [profile.data]);

  const save = useMutation({
    mutationFn: async () => {
      const id = profile.data?.id;
      if (!id) throw new Error("No company found for this account");
      if (!form.name?.trim()) throw new Error("Company name is required");
      const { error } = await supabase
        .from("companies")
        .update({
          name: form.name.trim(),
          address_line1: form.address_line1 || null,
          address_line2: form.address_line2 || null,
          city: form.city || null,
          state: form.state || null,
          postal_code: form.postal_code || null,
          billing_email: form.billing_email || null,
          default_email: form.default_email || null,
          support_email: form.support_email || null,
          phone_primary: form.phone_primary || null,
          phone_secondary: form.phone_secondary || null,
          fax: form.fax || null,
          website: form.website || null,
          logo_url: form.logo_url || null,
        })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Company profile saved");
      qc.invalidateQueries({ queryKey: ["company-profile"] });
      qc.invalidateQueries({ queryKey: ["my-company"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const set = (key: keyof FormState) => (value: string) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  if (profile.isLoading) {
    return (
      <section className="plate rounded-lg border border-border p-5 text-sm text-muted-foreground">
        Loading company profile…
      </section>
    );
  }

  if (!profile.data) {
    return (
      <section className="plate rounded-lg border border-border p-5 text-sm text-muted-foreground">
        This account is not linked to a company yet.
      </section>
    );
  }

  return (
    <section className="rounded-xl border border-dashboard-line bg-card p-5 shadow-sm">
      <div className="flex items-start gap-4">
        <Building2 className="mt-1 h-8 w-8 text-dashboard-blue" />
        <div>
          <h2 className="font-display text-xl font-semibold text-dashboard-navy">Company Profile</h2>
          <p className="text-sm text-dashboard-muted">
            This information appears on invoices, quotes, and emails sent to your clients.
          </p>
        </div>
      </div>

      <form
        className="mt-5 grid gap-5 lg:grid-cols-[1.25fr_1fr_0.9fr]"
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate();
        }}
      >
        <div className="grid content-start gap-3">
          <Field label="Company Name" required icon={Building2} value={form.name} onChange={set("name")} />
          <Field label="Address Line 1" icon={MapPin} placeholder="e.g. 123 Main St" value={form.address_line1 ?? ""} onChange={set("address_line1")} />
          <Field label="Address Line 2" icon={MapPin} placeholder="Apt, Suite, etc. (optional)" value={form.address_line2 ?? ""} onChange={set("address_line2")} />
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-[1.2fr_1fr_1fr]">
            <Field label="City" icon={Building2} placeholder="City" value={form.city ?? ""} onChange={set("city")} />
            <Field label="State" icon={MapIcon} placeholder="State" value={form.state ?? ""} onChange={set("state")} />
            <Field label="ZIP" icon={Hash} placeholder="12345" value={form.postal_code ?? ""} onChange={set("postal_code")} />
          </div>
          <Field label="Website" icon={Globe} placeholder="https://www.yoursite.com" value={form.website ?? ""} onChange={set("website")} />
        </div>

        <div className="grid content-start gap-3">
          <Field label="Default Email" type="email" icon={Mail} value={form.default_email ?? ""} onChange={set("default_email")} />
          <Field label="Billing Email" type="email" icon={Mail} value={form.billing_email ?? ""} onChange={set("billing_email")} />
          <Field label="Customer Service Email" type="email" icon={Mail} value={form.support_email ?? ""} onChange={set("support_email")} />
          <Field label="Primary Phone" icon={Phone} value={form.phone_primary ?? ""} onChange={set("phone_primary")} />
          <Field label="Secondary Phone" icon={Phone} value={form.phone_secondary ?? ""} onChange={set("phone_secondary")} />
          <Field label="Fax" icon={Printer} value={form.fax ?? ""} onChange={set("fax")} />
        </div>

        <div className="grid content-start gap-3">
          <span className="text-sm font-medium text-dashboard-navy">Company Logo</span>
          <div className="grid justify-items-center gap-3 rounded-lg border border-dashed border-dashboard-line bg-dashboard-canvas p-5 text-center">
            <div className="grid h-28 w-28 place-items-center overflow-hidden rounded-xl bg-dashboard-sidebar p-2">
              {form.logo_url ? (
                <img src={form.logo_url} alt={`${form.name || "Company"} logo`} className="max-h-full max-w-full object-contain" />
              ) : (
                <span className="text-xs text-primary-foreground/70">No logo</span>
              )}
            </div>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={async (e) => {
                const file = e.target.files?.[0];
                e.target.value = "";
                if (!file) return;
                if (file.size > 5 * 1024 * 1024) {
                  toast.error("Please pick an image under 5 MB");
                  return;
                }
                try {
                  const dataUrl = await readLogo(file);
                  setForm((prev) => ({ ...prev, logo_url: dataUrl }));
                  toast.success("Logo ready — press Save to keep it");
                } catch (err) {
                  toast.error((err as Error).message);
                }
              }}
            />
            <div className="flex flex-wrap justify-center gap-2">
              <button type="button" onClick={() => fileRef.current?.click()} className="inline-flex items-center gap-2 rounded-md border border-dashboard-blue px-4 py-2 text-sm font-semibold text-dashboard-blue hover:bg-dashboard-ice">
                <Upload className="h-4 w-4" /> Upload Logo
              </button>
              {form.logo_url && (
                <button type="button" onClick={() => setForm((prev) => ({ ...prev, logo_url: "" }))} className="rounded-md border border-dashboard-line px-3 py-2 text-sm text-destructive">
                  Remove
                </button>
              )}
            </div>
            <p className="text-xs text-dashboard-muted">
              PNG or JPG, ideally a wide or square mark. Large images are resized automatically.
            </p>
          </div>
          <button type="submit" disabled={save.isPending} className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-dashboard-blue px-4 text-sm font-semibold text-primary-foreground disabled:opacity-60">
            <Save className="h-4 w-4" /> {save.isPending ? "Saving…" : "Save Company Profile"}
          </button>
        </div>
      </form>
    </section>
  );
}
