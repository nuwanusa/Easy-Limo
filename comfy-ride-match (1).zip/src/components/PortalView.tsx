import { useMemo, useState } from "react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import {
  forwardInvoiceByEmail,
  forwardMyInvoiceByEmail,
  changePortalCode,
  changeMyPortalCode,
  submitMyRideDispute,
  submitRideDispute,
} from "@/lib/client-portal.functions";
import { ClientPayPanel } from "@/components/ClientPayPanel";
import { PayByCardLink } from "@/components/PayByCardLink";
import type { PortalData, PortalRide } from "@/lib/client-portal.functions";
import { CardsOnFile } from "@/components/CardsOnFile";
import { RideReview } from "@/components/RideReview";
import { ClientRequestForm } from "@/components/ClientRequestForm";
import { ClientRideTracker } from "@/components/ClientRideTracker";
import { Button } from "@/components/ui/button";
import { CalendarDays, ChevronLeft, ChevronRight, FileText, UserRound } from "lucide-react";

const money = (v: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(v || 0);

const shortDate = (v: string | null | undefined) =>
  v
    ? new Date(/^\d{4}-\d{2}-\d{2}$/.test(v) ? `${v}T12:00:00Z` : v).toLocaleDateString("en-US", {
        month: "numeric",
        day: "numeric",
        year: "numeric",
        timeZone: "America/New_York",
      })
    : "";

const dayLabel = (v: string | null) =>
  v
    ? new Date(v).toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
        timeZone: "America/New_York",
      })
    : "—";

const clockTime = (v: string | null) =>
  v
    ? new Date(v).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZone: "America/New_York" })
    : "—";

const flatRate = (r: PortalRide) => (r.booking_type === "hourly" ? 0 : r.base_fare);
const hourlyCharge = (r: PortalRide) => (r.booking_type === "hourly" ? r.hourly_rate * Math.max(r.hours, 0) : 0);
const waitingCharge = (r: PortalRide) => (r.waiting_minutes / 60) * r.waiting_rate;
const stopCharge = (r: PortalRide) => r.stop_fee * r.stops.length;
const carSeatCharge = (r: PortalRide) => r.car_seat_count * r.car_seat_fee;
export const rideTotal = (r: PortalRide) =>
  (r.base_rate ?? 0) +
  flatRate(r) +
  hourlyCharge(r) +
  waitingCharge(r) +
  stopCharge(r) +
  carSeatCharge(r) +
  r.airport_fee +
  r.parking_fee +
  r.meet_greet_fee +
  r.tolls +
  r.gratuity;

function Line({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-border/60 py-1.5 text-sm">
      <span className="text-muted-foreground">
        {label}
        {hint ? <span className="ml-1 text-xs opacity-70">({hint})</span> : null}
      </span>
      <span className="font-medium text-foreground">{value}</span>
    </div>
  );
}

/** Rate row for the client's rates card: label with hint on its own line, price pinned right. */
function RateLine({ label, hint, value }: { label: string; hint?: string; value: string }) {
  return (
    <div className="grid grid-cols-[minmax(0,1fr)_auto] items-baseline gap-x-4 border-b border-border/60 py-2.5">
      <div className="min-w-0 break-words">
        <div className="text-sm font-medium text-foreground">{label}</div>
        {hint ? <div className="mt-0.5 font-cond text-[11px] uppercase tracking-wider text-muted-foreground">{hint}</div> : null}
      </div>
      <div className="shrink-0 text-sm font-semibold tabular-nums text-foreground">{value}</div>
    </div>
  );
}

export type PortalAuth = { token?: string; code?: string };

function DisputeCharge({ ride, auth }: { ride: PortalRide; auth?: PortalAuth | undefined }) {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [amount, setAmount] = useState("");
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  const sendGuest = useServerFn(submitRideDispute);
  const sendMine = useServerFn(submitMyRideDispute);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const payload = {
        reservationId: ride.id,
        message,
        amount: Number(amount) || 0,
        contactEmail: email.trim() || undefined,
      };
      if (auth?.token || auth?.code) {
        await sendGuest({ data: { ...payload, ...auth } });
      } else {
        await sendMine({ data: payload });
      }
      setSent(true);
      setOpen(false);
      setMessage("");
      setAmount("");
      toast.success("Your message was sent to Blackwave");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not send your message");
    } finally {
      setBusy(false);
    }
  };

  if (sent && !open) {
    return (
      <p className="mt-3 border-t border-border pt-3 font-cond text-[11px] uppercase tracking-widest text-emerald-600">
        Charge questioned — our office will reply by email
      </p>
    );
  }

  return (
    <div className="mt-3 border-t border-border pt-3">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="rounded-md border border-border px-3 py-2 font-cond text-[10px] uppercase tracking-widest text-muted-foreground hover:border-destructive hover:text-destructive"
      >
        {open ? "Cancel" : "Dispute a charge"}
      </button>

      {open && (
        <form onSubmit={submit} className="mt-3 space-y-2">
          <div className="flex flex-wrap gap-2">
            <input
              value={amount}
              onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))}
              placeholder="Amount in question (optional)"
              className="min-w-[12rem] flex-1 rounded-md border border-input bg-surface-2 px-3 py-2 text-sm"
            />
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Reply-to email (optional)"
              className="min-w-[12rem] flex-1 rounded-md border border-input bg-surface-2 px-3 py-2 text-sm"
            />
          </div>
          <textarea
            required
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={3}
            placeholder={`Tell us what looks wrong on ride ${ride.reference}…`}
            className="w-full rounded-md border border-input bg-surface-2 px-3 py-2 text-sm"
          />
          <button
            type="submit"
            disabled={busy}
            className="rounded-md bg-brand px-4 py-2 font-cond text-[10px] uppercase tracking-widest text-brand-foreground disabled:opacity-50"
          >
            {busy ? "Sending…" : "Send to Blackwave"}
          </button>
        </form>
      )}
    </div>
  );
}

function Detail({ label, value }: { label: string; value?: string | null }) {
  if (!value) return null;
  return (
    <div>
      <span className="text-muted-foreground">{label} — </span>
      {value}
    </div>
  );
}

function RideCard({ ride, auth }: { ride: PortalRide; auth?: PortalAuth | undefined }) {
  return (
    <div className="rounded-lg border border-border bg-background p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
            Ride {ride.reference} · {ride.status.replace(/_/g, " ")}
          </div>
          <div className="font-display text-lg uppercase leading-tight">
            {dayLabel(ride.pickup_at)} · {ride.passenger_name}
          </div>
        </div>
        <div className="text-right">
          <div className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">Ride total</div>
          <div className="text-xl font-semibold">{money(rideTotal(ride))}</div>
        </div>
      </div>

      <div className="mt-3 grid gap-4 md:grid-cols-2">
        <div>
          <div className="font-cond text-[11px] uppercase tracking-widest text-brand">Route & timing</div>
          <div className="mt-2 space-y-1 text-sm">
            <div>
              <span className="text-muted-foreground">Pickup {clockTime(ride.pickup_at)} — </span>
              {ride.pickup_address}
            </div>
            {ride.stops.map((s) => (
              <div key={`${ride.id}-${s.position}`}>
                <span className="text-muted-foreground">Stop {s.position} {s.stop_at ? clockTime(s.stop_at) : ""} — </span>
                {s.address}
                {s.note ? <span className="text-muted-foreground"> · {s.note}</span> : null}
              </div>
            ))}
            <div>
              <span className="text-muted-foreground">Drop-off {clockTime(ride.dropoff_at)} — </span>
              {ride.dropoff_address}
            </div>
            {ride.booking_type === "hourly" ? (
              <div className="pt-1 text-muted-foreground">{ride.hours} hr booked</div>
            ) : null}
          </div>

          <div className="mt-4">
            <div className="font-cond text-[11px] uppercase tracking-widest text-brand">
              Vehicle & passenger
            </div>
            <div className="mt-2 space-y-1 text-sm">
              <div>
                <span className="text-muted-foreground">Vehicle type — </span>
                {ride.vehicle_class}
              </div>
              <div>
                <span className="text-muted-foreground">Vehicle — </span>
                {[ride.vehicle_year, ride.vehicle_make, ride.vehicle_model, ride.vehicle_color]
                  .filter(Boolean)
                  .join(" ") || "To be assigned"}
                {ride.vehicle_plate ? ` · ${ride.vehicle_plate}` : ""}
              </div>
              <div>
                <span className="text-muted-foreground">Passenger — </span>
                {ride.passenger_name}
              </div>
              {ride.extra_passengers
                .filter((p) => p?.name)
                .map((p, i) => (
                  <div key={`${ride.id}-xp-${i}`}>
                    <span className="text-muted-foreground">Passenger {i + 2} — </span>
                    {p.name}
                    {p.phone ? ` · ${p.phone}` : ""}
                  </div>
                ))}
            </div>
          </div>

          {(ride.airport_name || ride.flight_number || ride.airline) && (
            <div className="mt-4">
              <div className="font-cond text-[11px] uppercase tracking-widest text-brand">
                Airport & flight ({ride.flight_direction === "departure" ? "airport drop-off" : "airport pickup"})
              </div>
              <div className="mt-2 space-y-1 text-sm">
                <Detail label="Airport" value={ride.airport_name} />
                <Detail label="Airline" value={ride.airline} />
                {ride.flight_direction !== "departure" && (
                  <Detail label="Flight #" value={ride.flight_number} />
                )}
                <Detail label="Terminal / level" value={ride.terminal_level} />
                {ride.flight_direction !== "departure" && (
                  <Detail label="Door #" value={ride.door_number} />
                )}
              </div>
            </div>
          )}
        </div>

        <div>
          <div className="font-cond text-[11px] uppercase tracking-widest text-brand">Charges</div>
          <div className="mt-2">
            <Line label="Base rate" value={money(ride.base_rate ?? 0)} />
            {ride.booking_type === "hourly" ? (
              <Line
                label="Hourly rate"
                hint={`${ride.hours} hr @ ${money(ride.hourly_rate)}/hr`}
                value={money(hourlyCharge(ride))}
              />
            ) : (
              <Line label="Flat fare" value={money(flatRate(ride))} />
            )}
            <Line
              label="Waiting time"
              hint={`${Math.round(ride.waiting_minutes)} min @ ${money(ride.waiting_rate)}/hr`}
              value={money(waitingCharge(ride))}
            />
            {ride.stops.length > 0 && (
              <Line label="Extra stops" hint={`${ride.stops.length}`} value={money(stopCharge(ride))} />
            )}
            {ride.car_seat_count > 0 && (
              <Line
                label="Car seats"
                hint={`${ride.car_seat_count} @ ${money(ride.car_seat_fee)}`}
                value={money(carSeatCharge(ride))}
              />
            )}
            <Line label="Airport fee" value={money(ride.airport_fee)} />
            <Line label="Parking" value={money(ride.parking_fee)} />
            <Line label="Meet & greet" value={money(ride.meet_greet_fee)} />
            <Line label="Tolls" value={money(ride.tolls)} />
            <Line label="Gratuity" value={money(ride.gratuity)} />
          </div>
        </div>
      </div>

      <DisputeCharge ride={ride} auth={auth} />
      <div className="mt-3 border-t border-border pt-3">
        <RideReview reservationId={ride.id} reference={ride.reference} auth={auth} />
      </div>
    </div>
  );
}

function ShareInvoice({ title, amount, paid }: { title: string; amount: number; paid: boolean }) {
  const link = typeof window === "undefined" ? "" : window.location.href;
  const text = `${title} — ${paid ? "Paid" : "Amount due"} ${money(amount)}\nView it here: ${link}`;

  const btn =
    "flex h-9 items-center rounded-md border border-border px-4 font-cond text-[10px] uppercase tracking-widest text-muted-foreground hover:border-brand hover:text-brand";

  return (
    <>
      <button
        type="button"
        className={btn}
        onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank", "noopener")}
      >
        WhatsApp
      </button>
      <a
        className={btn}
        href={`mailto:?subject=${encodeURIComponent(title)}&body=${encodeURIComponent(text)}`}
      >
        Email
      </a>
      <button
        type="button"
        className={btn}
        onClick={async () => {
          try {
            await navigator.clipboard.writeText(link);
            toast.success("Link copied");
          } catch {
            toast.error("Could not copy the link");
          }
        }}
      >
        Copy link
      </button>
    </>
  );
}

function EmailInvoice({
  payTarget,
  auth,
}: {
  payTarget: { target: "invoice" | "reservation"; id: string };
  auth?: PortalAuth | undefined;
}) {
  const [open, setOpen] = useState(false);
  const [to, setTo] = useState("");
  const [busy, setBusy] = useState(false);

  const sendGuest = useServerFn(forwardInvoiceByEmail);
  const sendMine = useServerFn(forwardMyInvoiceByEmail);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const payload = { target: payTarget.target, id: payTarget.id, to: to.trim() };
      const res =
        auth?.token || auth?.code
          ? await sendGuest({ data: { ...payload, ...auth } })
          : await sendMine({ data: payload });
      if (res?.sent) {
        toast.success(`Billing statement sent to ${to.trim()}`);
        setTo("");
        setOpen(false);
      } else {
        toast.error("That address could not be emailed");
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not send the invoice");
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex h-9 items-center rounded-md border border-border px-4 font-cond text-[10px] uppercase tracking-widest text-muted-foreground hover:border-brand hover:text-brand"
      >
        {open ? "Cancel" : "Send to email"}
      </button>

      {open && (
        <form onSubmit={submit} className="flex w-full flex-wrap items-center gap-2">
          <input
            type="email"
            required
            value={to}
            onChange={(e) => setTo(e.target.value)}
            placeholder="Send this statement to (email address)"
            className="h-9 min-w-[14rem] flex-1 rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-brand"
          />
          <button
            type="submit"
            disabled={busy}
            className="flex h-9 items-center rounded-md bg-brand px-4 font-cond text-[10px] uppercase tracking-widest text-brand-foreground disabled:opacity-50"
          >
            {busy ? "Sending…" : "Send statement"}
          </button>
        </form>
      )}
    </>
  );
}

function Group({
  title,
  subtitle,
  paid,
  rides,
  discount = 0,
  payments = 0,
  payTarget,
  auth,
}: {
  title: string;
  subtitle: string;
  paid: boolean;
  rides: PortalRide[];
  discount?: number;
  payments?: number;
  payTarget: { target: "invoice" | "reservation"; id: string };
  auth?: PortalAuth | undefined;
}) {
  const [open, setOpen] = useState(false);
  const [payOpen, setPayOpen] = useState(false);

  const subtotal = rides.reduce((s, r) => s + rideTotal(r), 0);
  const due = Math.max(subtotal - discount - payments, 0);

  return (
    <div className="overflow-hidden rounded-lg border border-portal-line bg-card">
      <div className="portal-invoice-header border-b-4 border-[#4d9bff] bg-[#0b3a75] px-5 py-4 text-white">
        <div className="font-display text-xl uppercase leading-tight text-white">{title}</div>
        <div className="font-cond text-[11px] uppercase tracking-widest text-blue-100">{subtitle}</div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span
            className={`flex h-9 items-center rounded-full border px-4 font-cond text-[10px] uppercase tracking-widest ${
              paid ? "border-emerald-300/60 text-white" : "border-white/40 text-white"
            }`}
          >
            {paid ? "Paid" : "Unpaid"}
          </span>
          <span className="flex h-9 items-center text-lg font-semibold text-white">{money(paid ? subtotal - discount : due)}</span>
          <div className="ml-auto flex flex-wrap items-center gap-2">
            <ShareInvoice title={title} amount={paid ? subtotal - discount : due} paid={paid} />
            <EmailInvoice payTarget={payTarget} auth={auth} />
            {!paid && due > 0 && (
              <button
                type="button"
                onClick={() => setPayOpen((v) => !v)}
                className="flex h-9 items-center rounded-md bg-white px-4 font-cond text-[10px] uppercase tracking-widest transition hover:bg-blue-50"
                style={{ color: "#0b3a75" }}
              >
                {payOpen ? "Close" : "Pay now"}
              </button>
            )}
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              className="flex h-9 items-center rounded-md border border-white/50 px-4 font-cond text-[10px] uppercase tracking-widest text-white hover:bg-white/10"
            >
              {open ? "Hide" : "Details"}
            </button>
          </div>
        </div>

      </div>
      <div className="px-5 py-4">
        {!paid && due > 0 && (
          <div className="mt-3">
            <PayByCardLink target={payTarget.target} id={payTarget.id} amount={due} />
          </div>
        )}

        {!paid && due > 0 && payOpen && (
          <div className="mt-4">
            <ClientPayPanel
              target={payTarget.target}
              id={payTarget.id}
              amount={due}
              label={`Pay ${money(due)} or part of it`}
            />
          </div>
        )}
      </div>


      {open && (
        <div className="space-y-4 border-t border-border px-5 py-5">
          {rides.map((r) => (
            <RideCard key={r.id} ride={r} auth={auth} />
          ))}

          <div className="ml-auto w-full max-w-sm rounded-lg border border-border bg-background p-4">
            <Line label="Subtotal" value={money(subtotal)} />
            {discount > 0 && <Line label="Discount" value={`- ${money(discount)}`} />}
            {payments > 0 && <Line label="Payments received" value={`- ${money(payments)}`} />}
            <div className="mt-2 flex items-baseline justify-between">
              <span className="font-cond text-xs uppercase tracking-widest text-muted-foreground">
                {paid ? "Total paid" : "Amount due"}
              </span>
              <span className="text-2xl font-semibold">{money(paid ? subtotal - discount : due)}</span>
            </div>
          </div>

          {!paid && due > 0 && (
            <div className="flex justify-end">
              <ClientPayPanel target={payTarget.target} id={payTarget.id} amount={due} />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/** Read-only view of the rates saved for this client. */
function RateCard({ data }: { data: PortalData }) {
  const [open, setOpen] = useState(false);
  const rates = data.rates ?? [];
  const zones = data.zoneRates ?? [];
  if (rates.length === 0 && zones.length === 0) return null;

  return (
    <div className="mt-6 rounded-xl border border-border bg-card">
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
        <div>
          <div className="font-display text-xl uppercase leading-tight">Your rates</div>
          <div className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
            Every price on file for your account
          </div>
        </div>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="flex h-9 items-center rounded-md border border-brand px-4 font-cond text-[10px] uppercase tracking-widest text-brand hover:bg-brand/10"
        >
          {open ? "Hide" : "View rates"}
        </button>
      </div>

      {open && (
        <div className="space-y-6 border-t border-border px-5 py-5">
          <div>
            <div className="font-cond text-[11px] uppercase tracking-widest text-brand">Service rates</div>
            <div className="mt-2">
              {rates.length === 0 ? (
                <p className="text-sm text-muted-foreground">No service rates on file.</p>
              ) : (
                rates.map((r) => (
                  <RateLine
                    key={r.id}
                    label={r.label}
                    hint={[
                      r.vehicle_class,
                      r.rate_type === "hourly" ? "per hour" : r.rate_type,
                      r.rate_type === "hourly" && r.minimum_hours > 0 ? `${r.minimum_hours} hr min` : null,
                    ]
                      .filter(Boolean)
                      .join(" · ")}
                    value={money(r.amount)}
                  />
                ))
              )}
            </div>
          </div>

          <div>
            <div className="font-cond text-[11px] uppercase tracking-widest text-brand">Point-to-point & airport</div>
            <div className="mt-2">
              {zones.length === 0 ? (
                <p className="text-sm text-muted-foreground">No route prices on file.</p>
              ) : (
                zones.map((z) => (
                  <RateLine
                    key={z.id}
                    label={`${z.from_label} → ${z.to_label}`}
                    hint={[z.vehicle_class, z.client_specific ? "your rate" : "standard"].filter(Boolean).join(" · ")}
                    value={money(z.amount)}
                  />
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/** Client-facing list of every invoice with the full ride breakdown behind it. */
export function PortalView({ data, auth }: { data: PortalData; auth?: PortalAuth | undefined }) {
  const [filter, setFilter] = useState<"all" | "unpaid" | "paid">("all");
  const [query, setQuery] = useState("");
  const [panel, setPanel] = useState<"profile" | "invoices" | "reservations">("reservations");
  const [collapsed, setCollapsed] = useState(false);

  const groups = useMemo(() => {
    const byInvoice = new Map<string, PortalRide[]>();
    const singles: PortalRide[] = [];
    for (const r of data.rides) {
      if (r.invoice_id) {
        const list = byInvoice.get(r.invoice_id) ?? [];
        list.push(r);
        byInvoice.set(r.invoice_id, list);
      } else if (r.invoice_number) {
        singles.push(r);
      }
    }

    type Item = {
      key: string;
      title: string;
      subtitle: string;
      paid: boolean;
      rides: PortalRide[];
      discount: number;
      payments: number;
      payTarget: { target: "invoice" | "reservation"; id: string };
      sortAt: string;
    };

    const items: Item[] = data.invoices.map((inv) => {
      const rides = (byInvoice.get(inv.id) ?? []).sort((a, b) => a.pickup_at.localeCompare(b.pickup_at));
      return {
        key: inv.id,
        title: `Statement ${inv.invoice_number}`,
        subtitle: [
          inv.period_start || inv.period_end
            ? `${shortDate(inv.period_start) === shortDate(inv.period_end) ? shortDate(inv.period_start) : `${shortDate(inv.period_start)} – ${shortDate(inv.period_end)}`}`
            : `Issued ${dayLabel(inv.issued_at)}`,
          `${rides.length} ride${rides.length === 1 ? "" : "s"}`,
          inv.paid_at ? `Paid ${dayLabel(inv.paid_at)}` : (data.client.terms ?? "Due on receipt"),
        ].join(" · "),
        paid: Boolean(inv.paid_at),
        rides,
        discount: inv.discount,
        payments: inv.payments,
        payTarget: { target: "invoice" as const, id: inv.id },
        sortAt: inv.issued_at ?? rides[0]?.pickup_at ?? "",
      };
    });

    for (const r of singles) {
      items.push({
        key: r.id,
        title: `Statement ${r.invoice_number}`,
        subtitle: [
          dayLabel(r.pickup_at),
          "1 ride",
          r.invoice_paid_at ? `Paid ${dayLabel(r.invoice_paid_at)}` : "Due on receipt",
        ].join(" · "),
        paid: Boolean(r.invoice_paid_at),
        rides: [r],
        discount: 0,
        payments: 0,
        payTarget: { target: "reservation" as const, id: r.id },
        sortAt: r.invoice_issued_at ?? r.pickup_at,
      });
    }

    return items.sort((a, b) => (b.sortAt ?? "").localeCompare(a.sortAt ?? ""));
  }, [data]);

  const q = query.trim().toLowerCase();
  const matches = (g: (typeof groups)[number]) => {
    if (!q) return true;
    const haystack = [
      g.title,
      g.subtitle,
      ...g.rides.flatMap((r) => [
        r.reference,
        r.passenger_name,
        r.pickup_address,
        r.dropoff_address,
        r.invoice_number ?? "",
        r.vehicle_class,
        dayLabel(r.pickup_at),
        ...r.stops.map((s) => s.address),
      ]),
    ]
      .join(" ")
      .toLowerCase();
    return haystack.includes(q);
  };

  const visible = groups
    .filter((g) => (filter === "all" ? true : filter === "paid" ? g.paid : !g.paid))
    .filter(matches);
  const outstanding = groups
    .filter((g) => !g.paid)
    .reduce((s, g) => s + Math.max(g.rides.reduce((x, r) => x + rideTotal(r), 0) - g.discount - g.payments, 0), 0);

  const tabs = [
    { id: "profile" as const, label: "Profile", icon: UserRound },
    { id: "invoices" as const, label: "Statements", icon: FileText },
    { id: "reservations" as const, label: "Book a ride", icon: CalendarDays },
  ];

  return (
    <div className="flex min-h-[calc(100vh-65px)] flex-col bg-portal-mist font-portal-body lg:h-[calc(100vh-65px)] lg:min-h-[640px] lg:flex-row lg:overflow-hidden">
      <aside
        className={`portal-sidebar relative z-[600] shrink-0 border-b border-border bg-background shadow-portal transition-[width] duration-300 lg:h-full lg:border-b-0 lg:border-r ${collapsed ? "lg:w-20" : "lg:w-[430px]"}`}
      >
        <div className="border-b border-border px-5 py-5">
          <div className={`flex items-center justify-between gap-3 ${collapsed ? "lg:justify-center" : ""}`}>
            <div className={collapsed ? "hidden" : ""}>
              <div className="text-[10px] font-bold uppercase tracking-widest text-portal-teal">Client portal</div>
              <h1 className="mt-1 font-portal-display text-2xl font-bold leading-tight text-foreground">{data.client.name}</h1>
              <p className="mt-1 text-xs text-muted-foreground">Account {data.client.account_number}</p>
            </div>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="shrink-0 gap-1.5 font-cond text-[10px] font-bold uppercase tracking-widest text-muted-foreground hover:text-foreground"
              onClick={() => setCollapsed((value) => !value)}
              title={collapsed ? "Expand panel" : "Minimize panel"}
              aria-label={collapsed ? "Open account panel" : "Minimize account panel"}
            >
              {collapsed ? <ChevronRight className="size-4" /> : <ChevronLeft className="size-4" />}
              <span className={collapsed ? "sr-only" : ""}>Minimize</span>
            </Button>
          </div>

          {!collapsed && (
            <div className="mt-5 grid grid-cols-2 gap-3">
              <div className="border-l-2 border-portal-teal pl-3">
                <div className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground">Outstanding</div>
                <div className="font-portal-display text-xl font-bold text-foreground">{money(outstanding)}</div>
              </div>
              <div className="border-l-2 border-portal-blue pl-3">
                <div className="text-[9px] font-bold uppercase tracking-widest text-muted-foreground">Terms</div>
                <div className="mt-1 text-sm font-semibold text-foreground">{data.client.terms}</div>
              </div>
            </div>
          )}
        </div>

        <nav className={`grid grid-cols-3 border-b border-border ${collapsed ? "lg:grid-cols-1" : ""}`} aria-label="Client account sections">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <Button
                key={tab.id}
                type="button"
                variant="ghost"
                onClick={() => {
                  setPanel(tab.id);
                  setCollapsed(false);
                }}
                className={`h-14 rounded-none border-b-2 px-2 text-[10px] font-bold uppercase tracking-wider ${
                  panel === tab.id
                    ? "border-portal-teal bg-muted text-portal-teal"
                    : "border-transparent text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                aria-label={tab.label}
              >
                <Icon className="size-4" />
                <span className={collapsed ? "hidden" : ""}>{tab.label}</span>
              </Button>
            );
          })}
        </nav>

        {!collapsed && (
          <div className="portal-sidebar-scroll max-h-[56vh] overflow-y-auto p-5 lg:max-h-none lg:h-[calc(100%-213px)]">
            {panel === "profile" && (
              <section className="space-y-4">
                <div className="text-[10px] font-bold uppercase tracking-widest text-portal-teal">Profile information</div>
                <div className="grid gap-3 border border-border bg-card p-4">
            {[
              { l: "Client name", v: data.client.name },
              {
                l: "Address",
                v: [data.client.address_line1, data.client.address_line2].filter(Boolean).join(", ") || "—",
              },
              { l: "Contact number", v: data.client.phone || "—" },
              { l: "Bill to", v: data.client.billing_contact_email || data.client.email || "—" },
            ].map((f) => (
              <div key={f.l} className="rounded-lg border border-border bg-background px-3 py-2">
                <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">{f.l}</div>
                <div className="font-cond text-sm break-words">{f.v}</div>
              </div>
            ))}
                </div>
                <ChangeAccessCode auth={auth} />
                <CardsOnFile auth={auth} />
                <RateCard data={data} />
              </section>
            )}

            {panel === "invoices" && (
              <section>
          <div className="text-[10px] font-bold uppercase tracking-widest text-portal-teal">Statements</div>
          <div className="mt-4 grid grid-cols-3 gap-2">
            {(["all", "unpaid", "paid"] as const).map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => setFilter(f)}
                className={`flex h-11 w-full items-center justify-center rounded-md border px-2 font-cond text-[11px] uppercase tracking-widest transition ${
                  filter === f ? "border-brand bg-brand/10 text-brand" : "border-border text-muted-foreground hover:border-brand"
                }`}
              >
                {f === "all" ? "All statements" : f}
              </button>
            ))}
          </div>
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search statement #, passenger, ride, address, date"
            className="mt-2 h-11 w-full rounded-md border border-border bg-background px-3 text-sm outline-none transition placeholder:text-muted-foreground focus:border-brand"
          />
          {q && (
            <p className="mt-2 font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
              {visible.length} match{visible.length === 1 ? "" : "es"} for “{query.trim()}”
            </p>
          )}

          <div className="mt-4 space-y-4">
            {visible.length === 0 ? (
              <p className="rounded-xl border border-border bg-card px-5 py-8 text-center text-sm text-muted-foreground">
                No invoices to show yet.
              </p>
            ) : (
              visible.map((g) => (
                <Group
                  key={g.key}
                  title={g.title}
                  subtitle={g.subtitle}
                  paid={g.paid}
                  rides={g.rides}
                  discount={g.discount}
                  payments={g.payments}
                  payTarget={g.payTarget}
                  auth={auth}
                />
              ))
            )}
          </div>
              </section>
            )}

            {panel === "reservations" && (
              <section className="space-y-4">
                <div className="text-[10px] font-bold uppercase tracking-widest text-portal-teal">Request a reservation</div>
                <ClientRequestForm auth={auth} />
              </section>
            )}
          </div>
        )}
      </aside>

      <ClientRideTracker auth={auth} />
    </div>
  );
}

/** Lets the client pick a new six-digit access code for their portal. */
function ChangeAccessCode({ auth }: { auth?: PortalAuth | undefined }) {
  const [open, setOpen] = useState(false);
  const [next, setNext] = useState("");
  const [busy, setBusy] = useState(false);
  const changeGuest = useServerFn(changePortalCode);
  const changeMine = useServerFn(changeMyPortalCode);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const payload = { newCode: next.trim() };
      if (auth?.token || auth?.code) await changeGuest({ data: { ...payload, ...auth } });
      else await changeMine({ data: payload });
      toast.success("Your access code was changed");
      setNext("");
      setOpen(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not change the code");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mt-4 rounded-xl border border-border bg-card px-5 py-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">Access code</div>
          <p className="text-sm text-muted-foreground">Pick your own six-digit code for opening this page.</p>
        </div>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="flex h-9 items-center rounded-md border border-border px-4 font-cond text-[10px] uppercase tracking-widest text-muted-foreground hover:border-brand hover:text-brand"
        >
          {open ? "Cancel" : "Change code"}
        </button>
      </div>

      {open && (
        <form onSubmit={submit} className="mt-3 flex flex-wrap items-center gap-2">
          <input
            inputMode="numeric"
            pattern="\d{6}"
            maxLength={6}
            required
            value={next}
            onChange={(e) => setNext(e.target.value.replace(/\D/g, "").slice(0, 6))}
            placeholder="New six-digit code"
            className="h-9 min-w-[12rem] flex-1 rounded-md border border-input bg-background px-3 text-sm tracking-[0.3em] outline-none focus:border-brand"
          />
          <button
            type="submit"
            disabled={busy || next.length !== 6}
            className="flex h-9 items-center rounded-md bg-brand px-4 font-cond text-[10px] uppercase tracking-widest text-brand-foreground disabled:opacity-50"
          >
            {busy ? "Saving…" : "Save code"}
          </button>
        </form>
      )}
    </div>
  );
}
