import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Link } from "@tanstack/react-router";
import { clockTime, dayLabel, statusLabel, type Driver, type Reservation } from "@/lib/dispatch";
import { isActiveStatus } from "@/lib/trip-status";
import { getEta } from "@/lib/eta.functions";
import { supabase } from "@/integrations/supabase/client";
import { DriverInfoShare } from "@/components/DriverInfoShare";
import { RideEmailShare } from "@/components/RideEmailShare";
import { TrackLinkShare } from "@/components/TrackLinkShare";

/** Live board of rides a chauffeur is currently working. */
export function ActiveRides({
  reservations,
  drivers,
}: {
  reservations: Reservation[];
  drivers: Driver[];
}) {
  const qc = useQueryClient();
  const removeRide = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("reservations").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["reservations"] });
      toast.success("Ride deleted");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const rides = reservations
    .filter((r) => isActiveStatus(r.status))
    .sort((a, b) => a.pickup_at.localeCompare(b.pickup_at));

  const rideIds = rides.map((r) => r.id).sort();
  const driverIds = [...new Set(rides.map((r) => r.driver_id).filter((id): id is string => Boolean(id)))].sort();
  // Actual moment the chauffeur reported standing at the pickup point.
  const { data: arrivals = {} } = useQuery({
    queryKey: ["active-ride-arrivals", rideIds.join(",")],
    enabled: rideIds.length > 0,
    refetchInterval: 60_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("reservation_status_events")
        .select("reservation_id, status, occurred_at")
        .in("reservation_id", rideIds)
        .eq("status", "on_location")
        .order("occurred_at", { ascending: true });
      if (error) throw error;
      const map: Record<string, string> = {};
      for (const e of data ?? []) if (!map[e.reservation_id]) map[e.reservation_id] = e.occurred_at;
      return map;
    },
  });


  // Freshest GPS breadcrumb per ride — far more current than the driver row.
  const { data: pings = {} } = useQuery({
    queryKey: ["active-ride-pings", rideIds.join(",")],
    enabled: rideIds.length > 0,
    refetchInterval: 20_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ride_track_points")
        .select("reservation_id, lat, lng, recorded_at")
        .in("reservation_id", rideIds)
        .order("recorded_at", { ascending: false })
        .limit(400);
      if (error) throw error;
      const map: Record<string, { lat: number; lng: number; at: string }> = {};
      for (const p of data ?? [])
        if (!map[p.reservation_id])
          map[p.reservation_id] = { lat: Number(p.lat), lng: Number(p.lng), at: p.recorded_at };
      return map;
    },
  });

  // Refresh driver coordinates independently from the reservation list. Some
  // active rides have no breadcrumb rows, while the driver's phone is still
  // updating the live position stored on their profile.
  const { data: liveDrivers = {} } = useQuery({
    queryKey: ["active-ride-driver-locations", driverIds.join(",")],
    enabled: driverIds.length > 0,
    refetchInterval: 10_000,
    staleTime: 0,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("drivers")
        .select("id, last_lat, last_lng, last_seen_at")
        .in("id", driverIds);
      if (error) throw error;
      const map: Record<string, { lat: number; lng: number; at: string | null }> = {};
      for (const driver of data ?? []) {
        if (driver.last_lat == null || driver.last_lng == null) continue;
        map[driver.id] = {
          lat: Number(driver.last_lat),
          lng: Number(driver.last_lng),
          at: driver.last_seen_at,
        };
      }
      return map;
    },
  });

  return (
    <section className="mx-6 mb-8 rounded-lg border border-border bg-card">
      <header className="flex items-center justify-between border-b border-border px-4 py-3">
        <h2 className="font-display text-lg">Active rides</h2>
        <span className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
          {rides.length} on the road
        </span>
      </header>

      {rides.length === 0 ? (
        <p className="px-4 py-6 text-center font-cond text-sm text-muted-foreground">
          No rides are in progress right now.
        </p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px]">
            <thead>
              <tr className="border-b border-border font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                <th className="px-4 py-3 text-left">Driver</th>
                <th className="px-4 py-3 text-left">Passenger</th>
                <th className="px-4 py-3 text-left">Pickup location</th>
                <th className="px-4 py-3 text-left">Pickup time</th>
                <th className="px-4 py-3 text-left">Status</th>
                <th className="px-4 py-3 text-left">Arrived at pickup</th>
                <th className="px-4 py-3 text-right">ETA to pickup</th>
                <th className="px-4 py-3 text-left">Share</th>
                <th className="px-4 py-3 text-right">Delete</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border font-cond text-sm">
              {rides.map((r) => {
                const driver = drivers.find((d) => d.id === r.driver_id);
                const now = Date.now();
                const ping = pings[r.id];
                const pingFresh = Boolean(ping && now - new Date(ping.at).getTime() < 90_000);
                const liveDriver = r.driver_id ? liveDrivers[r.driver_id] : undefined;
                const liveDriverFresh = Boolean(
                  liveDriver?.at && now - new Date(liveDriver.at).getTime() < 90_000,
                );
                const loadedDriverFresh = Boolean(
                  driver?.last_seen_at && now - new Date(driver.last_seen_at).getTime() < 90_000,
                );
                const lat = pingFresh
                  ? ping?.lat ?? null
                  : liveDriverFresh
                    ? liveDriver?.lat ?? null
                    : loadedDriverFresh
                      ? driver?.last_lat ?? null
                      : null;
                const lng = pingFresh
                  ? ping?.lng ?? null
                  : liveDriverFresh
                    ? liveDriver?.lng ?? null
                    : loadedDriverFresh
                      ? driver?.last_lng ?? null
                      : null;
                const hasStoredLocation = Boolean(
                  ping || liveDriver || (driver?.last_lat != null && driver?.last_lng != null),
                );
                return (
                  <tr key={r.id}>
                    <td className="px-4 py-3">{(driver?.full_name ?? "—").split(" ")[0]}</td>
                    <td className="px-4 py-3">
                      <Link to="/rides/$id" params={{ id: r.id }} className="text-brand hover:underline">
                        {r.passenger_name}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{r.pickup_address}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-muted-foreground">
                      {dayLabel(r.pickup_at)} · {clockTime(r.pickup_at)}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{statusLabel(r.status)}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-muted-foreground">
                      {arrivals[r.id] ? clockTime(arrivals[r.id]!) : "—"}
                    </td>

                    <td className="whitespace-nowrap px-4 py-3 text-right">
                      <PickupEtaCell
                        rideId={r.id}
                        destination={r.pickup_address}
                        lat={lat}
                        lng={lng}
                        locationStale={hasStoredLocation && (lat == null || lng == null)}
                        done={r.status !== "en_route"}
                      />
                    </td>
                    <td className="px-4 py-3">
                      <DriverInfoShare
                        driverId={r.driver_id}
                        vehicleId={r.vehicle_id}
                        passenger={r.passenger_name}
                        pickupAt={r.pickup_at}
                        reference={r.reference}
                        reservationId={r.id}
                        label="Share driver & vehicle"
                      />
                      <RideEmailShare reservationId={r.id} />
                      <TrackLinkShare
                        reservationId={r.id}
                        token={(r as any).track_token ?? null}
                        reference={r.reference}
                      />
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        type="button"
                        disabled={removeRide.isPending}
                        onClick={() => {
                          if ((r as any).invoice_id || (r as any).invoice_number) {
                            toast.error("This ride is on an invoice and cannot be deleted.");
                            return;
                          }
                          if (confirm(`Delete active ride ${r.reference}?`)) {
                            removeRide.mutate(r.id);
                          }
                        }}
                        className="font-cond text-[11px] uppercase tracking-widest text-destructive hover:underline disabled:opacity-50"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}

function PickupEtaCell({
  rideId,
  destination,
  lat,
  lng,
  locationStale,
  done,
}: {
  rideId: string;
  destination: string;
  lat: number | null;
  lng: number | null;
  locationStale: boolean;
  done: boolean;
}) {
  const eta = useServerFn(getEta);
  const enabled = !done && lat != null && lng != null;
  const { data, isFetching } = useQuery({
    queryKey: ["active-ride-eta", rideId, lat, lng],
    enabled,
    refetchInterval: 20_000,
    staleTime: 0,
    queryFn: () => {
      if (lat == null || lng == null) throw new Error("Live location is unavailable.");
      return eta({ data: { lat, lng, destination } });
    },
  });

  if (done) return <span className="text-muted-foreground">At pickup</span>;
  if (!enabled) {
    return (
      <span className="text-muted-foreground">
        {locationStale ? "Waiting for current location" : "No live location"}
      </span>
    );
  }
  if (isFetching && !data) return <span className="text-muted-foreground">…</span>;
  if (!data) return <span className="text-muted-foreground">—</span>;
  if (data.minutes <= 2) return <span className="text-brand">Arriving now</span>;
  return (
    <span className="text-brand">
      {new Date(data.arrivalIso).toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      })}
      <span className="ml-1 text-[11px] text-muted-foreground">({data.minutes} min)</span>
    </span>
  );
}
