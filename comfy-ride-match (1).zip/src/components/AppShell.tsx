import { useEffect } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useSession, initials } from "@/lib/auth";
import { useDriverAccount } from "@/lib/driver";
import { LayoutGrid, CalendarDays, FileText, Users, Car, IdCard, MapPin, Calculator, ShieldCheck, Wallet, Star, Handshake, Mail, Search, Settings, LogOut } from "lucide-react";
import { useRole } from "@/lib/roles";
import { useIsPlatformOwner } from "@/lib/company";
import { useCompany } from "@/lib/company";
import { useClientAccount } from "@/lib/client-portal";
import { BrandLogo } from "@/components/BrandLogo";
import { MessengerPopup } from "@/components/MessengerPopup";

const NAV = [
  { to: "/dashboard", label: "Home", icon: LayoutGrid },
  { to: "/reservations", label: "Reservations", icon: CalendarDays },
  { to: "/invoices", label: "Statements", icon: FileText },
  { to: "/accounting", label: "Accounting", icon: Calculator },
  { to: "/clients", label: "Clients", icon: Users },
  { to: "/fleet", label: "Fleet", icon: Car },
  { to: "/drivers", label: "Drivers", icon: IdCard },
  { to: "/pay", label: "Pay", icon: Wallet },
  { to: "/map", label: "Live Map", icon: MapPin },
  { to: "/inbox", label: "Inbox", icon: Mail },
  { to: "/quotes", label: "Quotes", icon: FileText },
  { to: "/reviews", label: "Reviews", icon: Star },
  { to: "/affiliates", label: "Affiliates", icon: Handshake },
  { to: "/billing", label: "Billing", icon: Wallet },
  { to: "/admin", label: "Admin", icon: ShieldCheck },
] as const;

const BOTTOM = NAV.filter((n) => ["/fleet", "/clients", "/drivers", "/quotes", "/reviews", "/affiliates", "/billing"].includes(n.to));

// Top tab bar: Home, Reservations, Accounting and Live Map.
const TOP = NAV.filter((n) => ["/dashboard", "/reservations", "/accounting", "/map"].includes(n.to));




export function AppShell({ children }: { children: React.ReactNode }) {
  const { session, loading, user } = useSession();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { data: driver, isLoading: driverLoading } = useDriverAccount();
  const { data: clientAccount, isLoading: clientLoading } = useClientAccount();
  const { isAdmin, isStaff, loading: roleLoading } = useRole();
  const { isPlatformOwner } = useIsPlatformOwner();
  const { company } = useCompany();

  useEffect(() => {
    if (!loading && !session) navigate({ to: "/auth" });
  }, [loading, session, navigate]);

  useEffect(() => {
    if (session && !roleLoading && !isStaff && driver) navigate({ to: "/driver" });
  }, [session, roleLoading, isStaff, driver, navigate]);

  useEffect(() => {
    if (session && !roleLoading && !isStaff && clientAccount) navigate({ to: "/portal" });
  }, [session, roleLoading, isStaff, clientAccount, navigate]);

  if (
    loading ||
    !session ||
    (roleLoading && session) ||
    (!isStaff && ((driverLoading && session) || driver || (clientLoading && session) || clientAccount))
  ) {
    return (
      <div className="cine flex min-h-screen items-center justify-center">
        <span className="font-cond text-xs uppercase tracking-[0.4em] text-muted-foreground">
          Loading board
        </span>
      </div>
    );
  }

  const name =
    (user?.user_metadata?.["full_name"] as string | undefined) ?? user?.email?.split("@")[0] ?? "Operator";
  const firstName = name.split(" ")[0] ?? name;

  if (["/dashboard", "/reservations", "/accounting", "/clients", "/pay", "/map", "/admin", "/billing", "/drivers"].includes(pathname)) {
    return (
      <div className="min-h-screen bg-dashboard-canvas font-admin-body text-foreground lg:grid lg:grid-cols-[228px_minmax(0,1fr)]">
        <aside className="hidden min-h-screen bg-dashboard-sidebar text-primary-foreground lg:sticky lg:top-0 lg:flex lg:h-screen lg:flex-col">
          <Link to="/dashboard" className="flex min-h-28 items-center justify-center border-b border-primary-foreground/10 px-6">
            <BrandLogo className="h-20 w-40 bg-transparent object-contain" />
          </Link>
          <nav className="flex-1 space-y-1 px-3 py-5">
            {NAV.filter((item) => isAdmin || !["/accounting", "/admin"].includes(item.to)).map((item) => {
              const active = pathname === item.to;
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`flex items-center gap-3 rounded-md px-4 py-3 text-sm font-medium transition-colors ${active ? "bg-dashboard-blue text-primary-foreground" : "text-primary-foreground/76 hover:bg-primary-foreground/8 hover:text-primary-foreground"}`}
                >
                  <Icon className="size-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <div className="border-t border-primary-foreground/10 p-4">
            <p className="text-center text-xs leading-relaxed text-primary-foreground/60">Luxury Transportation<br />in New York &amp; Beyond</p>
          </div>
        </aside>

        <div className="min-w-0">
          <header className="sticky top-0 z-40 border-b border-dashboard-line bg-background/95 backdrop-blur">
            <div className="flex h-14 items-center gap-3 px-3 sm:px-5">
              <Link to="/dashboard" className="lg:hidden"><BrandLogo className="size-9" /></Link>
              <div className="relative hidden max-w-xl flex-1 sm:block">
                <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <input readOnly aria-label="Search" placeholder="Search reservations, clients, flights, or invoices…" className="h-9 w-full rounded-md border border-dashboard-line bg-dashboard-canvas pl-9 pr-3 text-xs outline-none" />
              </div>
              <Link to="/reservations" search={{ new: "1" }} className="ml-auto inline-flex h-9 items-center gap-2 rounded-md bg-dashboard-sidebar px-4 text-xs font-semibold text-primary-foreground hover:bg-dashboard-blue">
                <CalendarDays className="size-4" /> <span className="hidden sm:inline">New reservation</span>
              </Link>
              {isAdmin && <Link to="/admin" aria-label="Settings" className="grid size-9 place-items-center text-dashboard-muted hover:text-dashboard-blue"><Settings className="size-4" /></Link>}
              <div className="grid size-8 place-items-center rounded-full bg-dashboard-soft font-semibold text-dashboard-navy">{initials(name)}</div>
              <div className="hidden min-w-0 sm:block">
                <p className="max-w-36 truncate text-xs font-semibold text-dashboard-navy">{name}</p>
                <p className="text-[9px] text-dashboard-muted">Blackwave Dispatch</p>
              </div>
              <button
                aria-label="Sign out"
                onClick={async () => {
                  await queryClient.cancelQueries();
                  queryClient.clear();
                  await supabase.auth.signOut();
                  navigate({ to: "/auth", replace: true });
                }}
                className="grid size-9 place-items-center text-dashboard-muted hover:text-destructive"
              ><LogOut className="size-4" /></button>
            </div>
            <nav className="flex overflow-x-auto border-t border-dashboard-line px-2 lg:hidden">
              {TOP.filter((item) => isAdmin || item.to !== "/accounting").map((item) => (
                <Link key={item.to} to={item.to} className={`shrink-0 border-b-2 px-4 py-2 text-xs font-semibold ${pathname === item.to ? "border-dashboard-blue text-dashboard-blue" : "border-transparent text-dashboard-muted"}`}>{item.label}</Link>
              ))}
            </nav>
          </header>
          <main>{children}</main>
          <MessengerPopup mode="admin" companyId={company?.companyId} />
        </div>
      </div>
    );
  }

  return (
    <div className="cine flex min-h-screen flex-col text-foreground">
      <header className="sticky top-0 z-40 border-b border-border bg-nav">
        <div className="flex items-center gap-3 px-4 py-3 sm:px-6">
          <Link to="/dashboard" className="shrink-0">
            <BrandLogo className="size-10" />
          </Link>
          <div className="min-w-0 flex-1">
            <div className="truncate font-display text-lg uppercase leading-none tracking-wide">
              Hi, {firstName}!
            </div>
            <div className="font-cond text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
              Blackwave Dispatch
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-3">
            {isPlatformOwner && (
              <Link
                to="/platform"
                className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground transition-colors hover:text-brand"
              >
                Platform
              </Link>
            )}
            {isAdmin && (
              <Link
                to="/admin"
                className="hidden font-cond text-[10px] uppercase tracking-widest text-muted-foreground transition-colors hover:text-brand sm:inline"
              >
                Accounts
              </Link>
            )}
            <button
              onClick={async () => {
                await queryClient.cancelQueries();
                queryClient.clear();
                await supabase.auth.signOut();
                navigate({ to: "/auth", replace: true });
              }}
              className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground transition-colors hover:text-brand"
            >
              Sign out
            </button>
            <div className="grid size-9 place-items-center rounded-full bg-surface-2 font-cond text-sm uppercase">
              {initials(name)}
            </div>
          </div>
        </div>

        <nav className="grid w-full auto-cols-fr grid-flow-col items-stretch gap-1 px-1 sm:gap-3 sm:px-4">
          {TOP.filter((item) => isAdmin || item.to !== "/accounting").map((item) => {
            const active = pathname === item.to || (item.to !== "/dashboard" && pathname.startsWith(item.to));
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`min-w-0 truncate border-b-2 px-1 py-3 text-center font-cond text-[11px] uppercase leading-tight tracking-normal transition-colors sm:px-2 sm:text-[17px] sm:tracking-wide ${
                  active
                    ? "border-brand text-brand"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>


      </header>

      <main className="flex-1 pb-24">{children}</main>
      <MessengerPopup mode="admin" companyId={company?.companyId} />

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-nav">
        <div className="flex items-center px-2 py-2">
          {BOTTOM.filter((item) => isAdmin || item.to !== "/admin").map((item) => {
            const active = pathname === item.to || (item.to !== "/dashboard" && pathname.startsWith(item.to));
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                aria-label={item.label}
                className={`grid flex-1 place-items-center gap-1 px-1 py-1 ${
                  active ? "text-brand" : "text-muted-foreground"
                }`}
              >
                <Icon className="size-6" />
                <span className="font-cond text-[9px] uppercase tracking-widest">{item.label}</span>
              </Link>
            );
          })}
        </div>

      </nav>
    </div>
  );
}

export function PageHeading({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="border-b border-border px-6 py-6">
      <div className="font-cond text-xs uppercase tracking-[0.4em] text-brand">{eyebrow}</div>
      <h1 className="font-display text-5xl uppercase leading-[0.9]">{title}</h1>
    </div>
  );
}

export function StatusChip({ status }: { status: string }) {
  const tone =
    status === "en_route"
      ? "border-brand/60 bg-brand/10 text-brand"
      : status === "unassigned"
        ? "border-destructive/50 text-destructive"
        : status === "completed"
          ? "border-border text-muted-foreground"
          : "border-border text-foreground";
  return (
    <span
      className={`inline-block rounded-full border px-3 py-1 font-cond text-[10px] uppercase tracking-widest ${tone}`}
    >
      {status.replace(/_/g, " ")}
    </span>
  );
}
