import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getEta } from "@/lib/eta.functions";
import { clockTime } from "@/lib/dispatch";

type Coords = { lat: number; lng: number };

export type EtaLeg = {
  id: string;
  label: string;
  /** Omit to use the chauffeur's live location as the origin. */
  origin?: string;
  destination: string;
};

/** Build the selectable ETA legs for a trip: live location, and each leg of the itinerary. */
export function buildEtaLegs(
  pickup: string,
  stops: Array<{ address: string }>,
  dropoff: string,
): EtaLeg[] {
  const legs: EtaLeg[] = [{ id: "live-pickup", label: "My location → Pickup", destination: pickup }];
  const points = [
    { label: "Pickup", address: pickup },
    ...stops.map((s, i) => ({ label: `Stop ${i + 1}`, address: s.address })),
    { label: "Drop-off", address: dropoff },
  ].filter((p) => !!p.address);

  if (stops.length > 0) {
    legs.push({
      id: "live-next",
      label: `My location → ${points[1]!.label}`,
      destination: points[1]!.address,
    });
  }
  legs.push({ id: "live-dropoff", label: "My location → Drop-off", destination: dropoff });

  for (let i = 0; i < points.length - 1; i += 1) {
    const from = points[i]!;
    const to = points[i + 1]!;
    legs.push({
      id: `leg-${i}`,
      label: `${from.label} → ${to.label}`,
      origin: from.address,
      destination: to.address,
    });
  }
  if (stops.length > 0) {
    legs.push({
      id: "pickup-dropoff",
      label: "Pickup → Drop-off",
      origin: pickup,
      destination: dropoff,
    });
  }
  return legs;
}

/** Chauffeur-selectable ETA: live location or any leg of the itinerary. */
export function TripEta({
  pickup,
  stops,
  dropoff,
}: {
  pickup: string;
  stops: Array<{ address: string }>;
  dropoff: string;
}) {
  const fetchEta = useServerFn(getEta);
  const legs = useMemo(() => buildEtaLegs(pickup, stops, dropoff), [pickup, stops, dropoff]);
  const [legId, setLegId] = useState(legs[0]!.id);
  const leg = legs.find((l) => l.id === legId) ?? legs[0]!;
  const [coords, setCoords] = useState<Coords | null>(null);
  const [geoError, setGeoError] = useState<string | null>(null);
  // ETA only loads when the chauffeur asks for it.
  const [requested, setRequested] = useState(false);
  const needsLocation = !leg.origin;

  useEffect(() => {
    if (!requested || !needsLocation) return;
    if (!("geolocation" in navigator)) {
      setGeoError("Location is not available on this device.");
      return;
    }
    const watch = navigator.geolocation.watchPosition(
      (pos) => {
        setGeoError(null);
        setCoords({
          lat: Math.round(pos.coords.latitude * 1e5) / 1e5,
          lng: Math.round(pos.coords.longitude * 1e5) / 1e5,
        });
      },
      () => setGeoError("Turn on location to see your ETA."),
      { enableHighAccuracy: true, maximumAge: 30_000, timeout: 15_000 },
    );
    return () => navigator.geolocation.clearWatch(watch);
  }, [requested, needsLocation]);

  const eta = useQuery({
    queryKey: ["eta", leg.id, leg.origin ?? null, leg.destination, coords?.lat, coords?.lng],
    enabled: requested && !!leg.destination && (!needsLocation || !!coords),
    staleTime: 60_000,
    refetchInterval: 60_000,
    queryFn: () =>
      fetchEta({
        data: needsLocation
          ? { lat: coords!.lat, lng: coords!.lng, destination: leg.destination }
          : { origin: leg.origin!, destination: leg.destination },
      }),
  });

  return (
    <div className="mt-4 rounded-lg border border-brand/40 bg-brand/5 p-5">
      <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
        Drive time
      </div>
      <select
        value={legId}
        onChange={(e) => setLegId(e.target.value)}
        className="mt-2 w-full rounded-md border border-border bg-background px-3 py-2 font-cond text-sm"
        aria-label="Choose which ETA to see"
      >
        {legs.map((l) => (
          <option key={l.id} value={l.id}>
            {l.label}
          </option>
        ))}
      </select>

      {!requested ? (
        <button
          type="button"
          onClick={() => setRequested(true)}
          className="mt-3 w-full rounded-md border border-brand/60 py-2 font-cond text-[11px] uppercase tracking-widest text-brand"
        >
          Get ETA
        </button>
      ) : needsLocation && geoError ? (
        <div className="mt-3 font-cond text-sm text-muted-foreground">{geoError}</div>
      ) : eta.isError ? (
        <div className="mt-3 font-cond text-sm text-muted-foreground">
          Could not calculate this ETA right now.
        </div>
      ) : !eta.data ? (
        <div className="mt-3 font-cond text-sm text-muted-foreground">Calculating…</div>
      ) : (
        <>
          <div className="mt-3 font-display text-4xl uppercase leading-none">
            {eta.data.minutes} min
          </div>
          <div className="mt-1 font-cond text-[12px] text-muted-foreground">
            {eta.data.miles} mi
            {needsLocation ? ` · arriving about ${clockTime(eta.data.arrivalIso)}` : ""}
          </div>
        </>
      )}
      <div className="mt-2 font-cond text-[12px] text-muted-foreground">
        {leg.origin ? `${leg.origin} → ${leg.destination}` : leg.destination}
      </div>
    </div>
  );
}
