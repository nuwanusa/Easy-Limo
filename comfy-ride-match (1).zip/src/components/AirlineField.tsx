import { useMemo, useRef, useState } from "react";
import { searchAirlines } from "@/lib/airline-catalog";

export function AirlineField({
  label = "Airline",
  value,
  onChange,
  placeholder = "Search airline",
}: {
  label?: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  const [open, setOpen] = useState(false);
  const blurTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const matches = useMemo(() => searchAirlines(value), [value]);

  return (
    <div className="relative">
      <div className="mb-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
        {label}
      </div>
      <input
        type="text"
        value={value}
        placeholder={placeholder}
        autoComplete="off"
        onChange={(e) => {
          onChange(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onBlur={() => {
          blurTimer.current = setTimeout(() => setOpen(false), 120);
        }}
        className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground outline-none placeholder:text-muted-foreground focus:border-brand/60"
      />
      {open && matches.length > 0 && (
        <ul className="absolute z-[60] mt-1 max-h-64 w-full overflow-auto rounded-md border border-input bg-surface shadow-lg">
          {matches.map((a) => (
            <li key={`${a.iata}-${a.name}`}>
              <button
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  if (blurTimer.current) clearTimeout(blurTimer.current);
                  onChange(a.name);
                  setOpen(false);
                }}
                className="flex w-full items-center justify-between gap-3 px-3 py-2 text-left font-cond text-sm text-foreground hover:bg-muted"
              >
                <span>{a.name}</span>
                <span className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
                  {a.iata}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
