import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { getAddressSuggestions } from "@/lib/places.functions";

type Suggestion = { text: string; placeId: string };

export function AddressAutocomplete({
  value,
  onChange,
  placeholder,
  required,
  className,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string | undefined;
  required?: boolean | undefined;
  className?: string | undefined;
}) {
  const lookup = useServerFn(getAddressSuggestions);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [failed, setFailed] = useState(false);
  const [open, setOpen] = useState(false);
  const boxRef = useRef<HTMLDivElement | null>(null);
  const queryRef = useRef("");

  useEffect(() => {
    const onDocClick = (e: MouseEvent) => {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, []);

  useEffect(() => {
    const input = queryRef.current;
    if (input.trim().length < 2) {
      setSuggestions([]);
      return;
    }
    let cancelled = false;
    const timer = setTimeout(async () => {
      try {
        const raw = await lookup({ data: { query: input } });
        if (cancelled) return;
        setFailed(false);
        setSuggestions(raw);
      } catch (err) {
        console.error("Address suggestions failed", err);
        if (!cancelled) {
          setSuggestions([]);
          setFailed(true);
        }
      }
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [value]);

  queryRef.current = value;

  return (
    <div ref={boxRef} className="relative z-30">
      <input
        value={value}
        required={required}
        placeholder={placeholder}
        autoComplete="off"
        onChange={(e) => {
          onChange(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        className={
          className ??
          "w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground outline-none placeholder:text-muted-foreground focus:border-brand/60"
        }
      />
      {failed && value.trim().length >= 2 && (
        <p className="mt-1 font-cond text-[11px] text-muted-foreground">
          Address suggestions aren&apos;t available on this address right now — you can still type the
          address manually.
        </p>
      )}
      {open && suggestions.length > 0 && (
        <ul className="absolute z-[70] mt-1 max-h-64 w-full overflow-auto rounded-md border border-border bg-popover shadow-xl">
          {suggestions.map((s) => (
            <li key={s.placeId + s.text}>
              <button
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => {
                  onChange(s.text);
                  setSuggestions([]);
                  setOpen(false);
                }}
                className="block w-full px-3 py-2 text-left font-cond text-sm text-foreground hover:bg-surface"
              >
                {s.text}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export function AddressField({
  label,
  value,
  onChange,
  required,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
  placeholder?: string;
}) {
  return (
    <div>
      <div className="mb-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <AddressAutocomplete value={value} onChange={onChange} required={required} placeholder={placeholder} />
    </div>
  );
}
