import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { sendRideDetailsEmail } from "@/lib/ride-share.functions";

/**
 * Small expandable "Send to email" control that emails the full trip
 * details for one reservation to any address.
 */
export function RideEmailShare({ reservationId, boxed }: { reservationId: string; boxed?: boolean }) {
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const send = useServerFn(sendRideDetailsEmail);

  const mutation = useMutation({
    mutationFn: (vars: { to: string; name: string }) =>
      send({ data: { reservationId, to: vars.to, name: vars.name } }),
    onSuccess: (result) => {
      if (result.sent) {
        toast.success(`Trip details sent to ${email}`);
        setEmail("");
        setName("");
        setOpen(false);
      } else {
        toast.error(`Not sent: ${result.reason ?? "unknown reason"}`);
      }
    },
    onError: (err) =>
      toast.error(err instanceof Error ? err.message : "Could not send the email"),
  });

  if (boxed) {
    return (
      <div className="mt-3 rounded-md border border-border/60 bg-muted/20 p-3">
        <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
          Send to email
        </div>
        <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-[1fr_1.4fr_auto]">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Name"
            className="rounded-md border border-border bg-transparent px-3 py-2 font-cond text-[12px] text-foreground"
          />
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="name@email.com"
            className="rounded-md border border-border bg-transparent px-3 py-2 font-cond text-[12px] text-foreground"
            onKeyDown={(e) => {
              if (e.key === "Enter" && email.includes("@"))
                mutation.mutate({ to: email.trim(), name: name.trim() });
            }}
          />
          <button
            type="button"
            disabled={mutation.isPending || !email.includes("@")}
            onClick={() => mutation.mutate({ to: email.trim(), name: name.trim() })}
            className="rounded-md bg-brand px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-brand-foreground disabled:opacity-50"
          >
            {mutation.isPending ? "Sending…" : "Send"}
          </button>
        </div>
      </div>
    );
  }

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="mt-1 block font-cond text-[10px] uppercase tracking-widest text-brand hover:underline"
      >
        Send to email
      </button>
    );
  }

  return (
    <div className="mt-1 flex items-center gap-1">
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Name"
        className="w-24 rounded-md border border-border bg-transparent px-2 py-1 font-cond text-[11px] text-foreground"
      />
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="name@email.com"
        className="w-36 rounded-md border border-border bg-transparent px-2 py-1 font-cond text-[11px] text-foreground"
        onKeyDown={(e) => {
          if (e.key === "Enter" && email.includes("@")) mutation.mutate({ to: email.trim(), name: name.trim() });
        }}
      />
      <button
        type="button"
        disabled={mutation.isPending || !email.includes("@")}
        onClick={() => mutation.mutate({ to: email.trim(), name: name.trim() })}
        className="rounded-md bg-brand px-2 py-1 font-cond text-[10px] uppercase tracking-widest text-brand-foreground disabled:opacity-50"
      >
        {mutation.isPending ? "…" : "Send"}
      </button>
      <button
        type="button"
        onClick={() => setOpen(false)}
        className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground hover:text-foreground"
      >
        ✕
      </button>
    </div>
  );
}
