import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { getShortPayPath, type PaymentTarget } from "@/lib/payments.functions";

/**
 * Share row for a card-payment link: copy an email-ready message,
 * copy the plain link, or open WhatsApp with a prefilled message.
 * Uses the short /pay/<code> link when it is available.
 */
export function PaymentShare({
  target,
  id,
  reference,
  dark,
}: {
  target: PaymentTarget;
  id: string;
  reference?: string | null | undefined;
  dark?: boolean;
}) {
  const fetchShort = useServerFn(getShortPayPath);
  const short = useQuery({
    queryKey: ["pay-short-link", target, id],
    queryFn: () => fetchShort({ data: { target, id } }),
    staleTime: 5 * 60_000,
  });
  const path =
    short.data && !("error" in short.data) ? short.data.path : `/paycard/${target}/${id}`;

  const url = () => `${window.location.origin}${path}`;

  const message = () =>
    [
      "Blackwave Transportation — pay securely by credit or debit card.",
      reference ? `Reference: ${reference}` : "",
      url(),
      "Questions? info@rideblackwave.com · (917) 325-3211",
    ]
      .filter(Boolean)
      .join("\n");

  const emailText = () =>
    [
      "You can pay your Blackwave Transportation balance securely by credit or debit card:",
      "",
      url(),
      reference ? `Reference: ${reference}` : "",
      "Questions? info@rideblackwave.com · (917) 325-3211",
    ]
      .filter(Boolean)
      .join("\n");

  const copy = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success(`${label} copied`, { description: label === "Link" ? url() : undefined });
    } catch {
      toast.error(`Could not copy the ${label.toLowerCase()}`);
    }
  };

  const whatsapp = () => {
    const wa = `https://wa.me/?text=${encodeURIComponent(message())}`;
    window.open(wa, "_blank", "noopener");
  };

  const btn = dark
    ? "rounded-md border border-white/20 px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-white/80 transition hover:border-white/50 hover:text-white"
    : "rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-muted-foreground transition hover:border-brand hover:text-brand";

  return (
    <div>
      <div className={`font-cond text-[10px] uppercase tracking-widest ${dark ? "text-white/50" : "text-muted-foreground"}`}>
        Share this payment
      </div>
      <div className="mt-2 flex flex-wrap gap-2">
        <button type="button" onClick={() => copy(emailText(), "Email")} className={btn}>
          Copy email
        </button>
        <button type="button" onClick={() => copy(url(), "Link")} className={btn}>
          Copy link
        </button>
        <button type="button" onClick={whatsapp} className={btn}>
          Share WhatsApp
        </button>
      </div>
      <p className={`mt-2 text-xs ${dark ? "text-white/40" : "text-muted-foreground"}`}>
        Copy email places a ready-to-send message with the payment link on your clipboard.
      </p>
    </div>
  );
}
