import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getEta } from "@/lib/eta.functions";
import { clockTime } from "@/lib/dispatch";

type Coords = { lat: number; lng: number };

/** Live drive-time ETA from the chauffeur's phone to the next address. */
export function PickupEta({ destination, label = "Pickup" }: { destination: string; label?: string }) {
  const fetchEta = useServerFn(getEta);
  const [coords, setCoords] = useState<Coords | null>(null);
  const [geoError, setGeoError] = useState<string | null>(null);

  useEffect(() => {
    if (!("geolocation" in navigator)) {
      setGeoError("Location is not available on this device.");
      return;
    }
    const watch = navigator.geolocation.watchPosition(
      (pos) =>
        setCoords({
          lat: Math.round(pos.coords.latitude * 1e5) / 1e5,
          lng: Math.round(pos.coords.longitude * 1e5) / 1e5,
        }),
      () => setGeoError("Turn on location to see your ETA."),
      { enableHighAccuracy: true, maximumAge: 30_000, timeout: 15_000 },
    );
    return () => navigator.geolocation.clearWatch(watch);
  }, []);

  const eta = useQuery({
    queryKey: ["eta", destination, coords?.lat, coords?.lng],
    enabled: !!coords && !!destination,
    staleTime: 60_000,
    refetchInterval: 60_000,
    queryFn: () => fetchEta({ data: { lat: coords!.lat, lng: coords!.lng, destination } }),
  });

  return (
    <div className="mt-4 rounded-lg border border-brand/40 bg-brand/5 p-5">
      <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
        ETA to {label.toLowerCase()}
      </div>
      {geoError ? (
        <div className="mt-1 font-cond text-sm text-muted-foreground">{geoError}</div>
      ) : eta.isError ? (
        <div className="mt-1 font-cond text-sm text-muted-foreground">
          Could not calculate the ETA right now.
        </div>
      ) : !eta.data ? (
        <div className="mt-1 font-cond text-sm text-muted-foreground">Calculating…</div>
      ) : (
        <>
          <div className="font-display text-4xl uppercase leading-none">{eta.data.minutes} min</div>
          <div className="mt-1 font-cond text-[12px] text-muted-foreground">
            {eta.data.miles} mi · arriving about {clockTime(eta.data.arrivalIso)}
          </div>
        </>
      )}
      <div className="mt-2 font-cond text-[12px] text-muted-foreground">{destination}</div>
    </div>
  );
}
