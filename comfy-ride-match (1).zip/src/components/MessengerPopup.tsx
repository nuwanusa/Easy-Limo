import { useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { MessageCircle, Send } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

type MessengerMode = "admin" | "driver" | "client";
type Thread = {
  id: string;
  company_id: string;
  party_type: "client" | "driver";
  client_id: string | null;
  driver_id: string | null;
  last_message_at: string;
  admin_read_at: string | null;
  participant_read_at: string | null;
  participantName: string;
};
type Message = {
  id: string;
  thread_id: string;
  sender_user_id: string;
  sender_type: "admin" | "client" | "driver";
  body: string;
  created_at: string;
};

export function MessengerPopup({
  mode,
  companyId,
  driverId,
  clientId,
}: {
  mode: MessengerMode;
  companyId: string | undefined;
  driverId?: string | undefined;
  clientId?: string | undefined;
}) {
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [activeThreadId, setActiveThreadId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  const threadsQuery = useQuery({
    queryKey: ["message-threads", mode, companyId, driverId, clientId],
    enabled: Boolean(companyId),
    refetchInterval: 15_000,
    queryFn: async (): Promise<Thread[]> => {
      let request = supabase
        .from("message_threads")
        .select("id, company_id, party_type, client_id, driver_id, last_message_at, admin_read_at, participant_read_at")
        .eq("company_id", companyId ?? "")
        .order("last_message_at", { ascending: false });
      if (mode === "driver") request = request.eq("driver_id", driverId ?? "");
      if (mode === "client") request = request.eq("client_id", clientId ?? "");
      const { data, error } = await request;
      if (error) throw error;

      const rows = data ?? [];
      const clientIds = rows.map((row) => row.client_id).filter((id): id is string => Boolean(id));
      const driverIds = rows.map((row) => row.driver_id).filter((id): id is string => Boolean(id));
      const [clientsResult, driversResult] = await Promise.all([
        clientIds.length ? supabase.from("clients").select("id, name").in("id", clientIds) : Promise.resolve({ data: [], error: null }),
        driverIds.length ? supabase.from("drivers").select("id, full_name").in("id", driverIds) : Promise.resolve({ data: [], error: null }),
      ]);
      if (clientsResult.error) throw clientsResult.error;
      if (driversResult.error) throw driversResult.error;
      const clientNames = new Map((clientsResult.data ?? []).map((item) => [item.id, item.name]));
      const driverNames = new Map((driversResult.data ?? []).map((item) => [item.id, item.full_name]));
      return rows.map((row) => ({
        ...row,
        party_type: row.party_type as "client" | "driver",
        participantName:
          row.party_type === "client"
            ? clientNames.get(row.client_id ?? "") ?? "Client"
            : driverNames.get(row.driver_id ?? "") ?? "Chauffeur",
      }));
    },
  });

  const threads = threadsQuery.data ?? [];
  const activeThread = threads.find((thread) => thread.id === activeThreadId) ?? threads[0] ?? null;
  const unreadCount = threads.filter((thread) => {
    const readAt = mode === "admin" ? thread.admin_read_at : thread.participant_read_at;
    return !readAt || new Date(thread.last_message_at).getTime() > new Date(readAt).getTime();
  }).length;

  const messagesQuery = useQuery({
    queryKey: ["messages", activeThread?.id],
    enabled: Boolean(activeThread?.id),
    refetchInterval: 10_000,
    queryFn: async (): Promise<Message[]> => {
      const { data, error } = await supabase
        .from("messages")
        .select("id, thread_id, sender_user_id, sender_type, body, created_at")
        .eq("thread_id", activeThread?.id ?? "")
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as Message[];
    },
  });

  useEffect(() => {
    const channel = supabase
      .channel(`messenger-${mode}-${companyId ?? "none"}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["message-threads"] });
        void queryClient.invalidateQueries({ queryKey: ["messages"] });
      })
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [companyId, mode, queryClient]);

  useEffect(() => {
    if (!open || !activeThread) return;
    const readUpdate = mode === "admin"
      ? { admin_read_at: new Date().toISOString() }
      : { participant_read_at: new Date().toISOString() };
    void supabase
      .from("message_threads")
      .update(readUpdate)
      .eq("id", activeThread.id)
      .then(() => queryClient.invalidateQueries({ queryKey: ["message-threads"] }));
  }, [activeThread?.id, mode, open, queryClient]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messagesQuery.data?.length, open]);

  const createThread = async () => {
    if (!companyId || mode === "admin") return null;
    const payload = {
      company_id: companyId,
      party_type: mode,
      client_id: mode === "client" ? clientId ?? null : null,
      driver_id: mode === "driver" ? driverId ?? null : null,
    };
    const { data, error } = await supabase.from("message_threads").insert(payload).select("id").single();
    if (error) {
      const existing = await supabase
        .from("message_threads")
        .select("id")
        .eq(mode === "client" ? "client_id" : "driver_id", mode === "client" ? clientId ?? "" : driverId ?? "")
        .maybeSingle();
      if (existing.error) throw existing.error;
      return existing.data?.id ?? null;
    }
    return data.id;
  };

  const send = useMutation({
    mutationFn: async () => {
      const body = draft.trim();
      if (!body) return;
      const threadId = activeThread?.id ?? (await createThread());
      if (!threadId) throw new Error("No conversation is available yet.");
      const { data: sessionData } = await supabase.auth.getSession();
      const userId = sessionData.session?.user.id;
      if (!userId) throw new Error("Please sign in again to send a message.");
      const { error } = await supabase.from("messages").insert({
        thread_id: threadId,
        sender_user_id: userId,
        sender_type: mode,
        body,
      });
      if (error) throw error;
      setActiveThreadId(threadId);
      setDraft("");
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["message-threads"] });
      await queryClient.invalidateQueries({ queryKey: ["messages"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const messages = messagesQuery.data ?? [];
  const title = mode === "admin" ? activeThread?.participantName ?? "Messages" : "Message dispatch";
  const emptyText = mode === "admin" ? "No client or chauffeur messages yet." : "Send a message to your dispatch team.";
  const orderedThreads = useMemo(() => threads, [threads]);

  if (!companyId || (mode === "driver" && !driverId) || (mode === "client" && !clientId)) return null;

  return (
    <>
      <Button
        type="button"
        size="icon"
        aria-label="Open messages"
        title="Messages"
        onClick={() => setOpen((value) => !value)}
        className="fixed bottom-24 right-4 z-[720] size-12 rounded-full bg-dashboard-navy text-primary-foreground shadow-lg hover:bg-dashboard-blue sm:right-6"
      >
        <MessageCircle className="size-5" />
        {unreadCount > 0 && (
          <span className="absolute -right-1 -top-1 grid min-w-5 place-items-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">
            {Math.min(unreadCount, 9)}
          </span>
        )}
      </Button>

      {open && (
        <section className="fixed bottom-40 right-4 z-[710] flex h-[min(620px,calc(100vh-180px))] w-[min(760px,calc(100vw-32px))] overflow-hidden rounded-lg border border-border bg-background shadow-2xl sm:right-6">
          {mode === "admin" && (
            <aside className="w-56 shrink-0 border-r border-border bg-dashboard-ice/55">
              <div className="border-b border-border px-4 py-3">
                <p className="text-[10px] font-bold uppercase text-dashboard-steel">Inbox</p>
                <h2 className="font-admin-display text-lg font-semibold text-dashboard-navy">Conversations</h2>
              </div>
              <ScrollArea className="h-[calc(100%-61px)]">
                {orderedThreads.map((thread) => {
                  const unread = !thread.admin_read_at || new Date(thread.last_message_at) > new Date(thread.admin_read_at);
                  return (
                    <Button
                      key={thread.id}
                      type="button"
                      variant="ghost"
                      onClick={() => setActiveThreadId(thread.id)}
                      className={cn(
                        "h-auto w-full justify-start rounded-none border-b border-border px-4 py-3 text-left",
                        activeThread?.id === thread.id && "bg-background",
                      )}
                    >
                      <span className="min-w-0">
                        <span className="block truncate text-sm font-semibold">{thread.participantName}</span>
                        <span className="block text-[10px] uppercase text-muted-foreground">{thread.party_type}</span>
                      </span>
                      {unread && <span className="ml-auto size-2 rounded-full bg-dashboard-blue" />}
                    </Button>
                  );
                })}
              </ScrollArea>
            </aside>
          )}

          <div className="flex min-w-0 flex-1 flex-col">
            <header className="border-b border-border px-4 py-3">
              <p className="text-[10px] font-bold uppercase text-dashboard-steel">Private conversation</p>
              <h2 className="truncate font-admin-display text-lg font-semibold text-dashboard-navy">{title}</h2>
            </header>
            <ScrollArea className="flex-1 px-4 py-3">
              {messages.length === 0 ? (
                <div className="grid h-56 place-items-center text-center text-sm text-muted-foreground">{emptyText}</div>
              ) : (
                <div className="space-y-3">
                  {messages.map((message) => {
                    const mine = message.sender_type === mode || (mode === "admin" && message.sender_type === "admin");
                    return (
                      <div key={message.id} className={cn("flex", mine ? "justify-end" : "justify-start")}>
                        <div className={cn("max-w-[82%] rounded-lg px-3 py-2", mine ? "bg-dashboard-navy text-primary-foreground" : "bg-muted text-foreground")}>
                          <p className="whitespace-pre-wrap break-words text-sm">{message.body}</p>
                          <p className={cn("mt-1 text-[9px]", mine ? "text-dashboard-ice/70" : "text-muted-foreground")}>
                            {new Date(message.created_at).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                  <div ref={endRef} />
                </div>
              )}
            </ScrollArea>
            {(mode !== "admin" || activeThread) && (
              <form
                className="border-t border-border p-3"
                onSubmit={(event) => {
                  event.preventDefault();
                  send.mutate();
                }}
              >
                <div className="flex items-end gap-2">
                  <Textarea
                    value={draft}
                    maxLength={2000}
                    rows={2}
                    onChange={(event) => setDraft(event.target.value)}
                    placeholder="Write a message"
                    className="max-h-28 min-h-16 resize-none"
                  />
                  <Button type="submit" size="icon" disabled={!draft.trim() || send.isPending} aria-label="Send message">
                    <Send className="size-4" />
                  </Button>
                </div>
              </form>
            )}
          </div>
        </section>
      )}
    </>
  );
}