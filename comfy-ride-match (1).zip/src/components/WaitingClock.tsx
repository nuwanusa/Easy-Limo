import { useEffect, useState } from "react";
import { WAITING_GRACE_MINUTES } from "@/lib/waiting-time";

/**
 * Live waiting-time clock for the chauffeur trip page.
 *
 * Waiting time is free for the first 15 minutes after the chauffeur arrives.
 * The clock ticks live while the passenger has not boarded yet and freezes
 * on the recorded total once the trip moves past "Passenger on board".
 */

// The clock only runs while the chauffeur is standing at the pickup location.
// Going back to "On my way" means they are not waiting there, so it stops.
const STATUSES_BEFORE_BOARDING = ["on_location"];

const fmt = (totalSeconds: number) => {
  const s = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const mm = String(m).padStart(2, "0");
  const ss = String(sec).padStart(2, "0");
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
};

export function WaitingClock({
  arrivedAt,
  status,
  waitingMinutes,
  airport,
}: {
  arrivedAt: string | null | undefined;
  status: string;
  waitingMinutes: number | null | undefined;
  airport: boolean;
}) {
  const [now, setNow] = useState(() => Date.now());

  const live = STATUSES_BEFORE_BOARDING.includes(status);

  useEffect(() => {
    if (!live) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [live]);

  if (airport) return null;

  if (!arrivedAt) return null;
  const graceEnd = new Date(arrivedAt).getTime() + WAITING_GRACE_MINUTES * 60_000;
  if (!Number.isFinite(graceEnd)) return null;

  // Passenger on board (or later): show the recorded total, frozen.
  if (!live) {
    if (status === "completed" || status === "cancelled") return null;
    if (waitingMinutes == null || waitingMinutes <= 0) return null;
    return (
      <div className="mt-4 rounded-lg border border-border bg-card p-5">
        <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
          Waiting time
        </div>
        <div className="mt-1 font-display text-3xl uppercase leading-none tabular-nums">
          {fmt(waitingMinutes * 60)}
        </div>
        <div className="mt-1 font-cond text-[11px] text-muted-foreground">
          First 15 minutes after arriving at the pickup location are free — this is the billable waiting time sent
          to dispatch.
        </div>
      </div>
    );
  }

  // Still waiting for the passenger: live ticking clock.
  const graceRemaining = (graceEnd - now) / 1000;
  const freeWait = graceRemaining > 0;

  return (
    <div
      className={`mt-4 rounded-lg border p-5 ${
        freeWait ? "border-border bg-card" : "border-warning/40 bg-warning/10"
      }`}
    >
      <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
        {freeWait ? "Free wait remaining" : "Waiting time"}
      </div>
      <div
        className={`mt-1 font-display text-4xl leading-none tabular-nums ${
          freeWait ? "text-foreground" : "text-warning"
        }`}
      >
        {freeWait ? fmt(graceRemaining) : fmt((now - graceEnd) / 1000)}
      </div>
      <div className="mt-1 font-cond text-[11px] text-muted-foreground">
        {freeWait
          ? `No charge for the first ${WAITING_GRACE_MINUTES} minutes after arriving at the pickup location.`
          : "Counting past the free 15-minute grace — reported to dispatch when the passenger is on board."}
      </div>
    </div>
  );
}
