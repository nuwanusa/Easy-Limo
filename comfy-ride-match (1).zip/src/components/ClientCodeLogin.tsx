import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useNavigate } from "@tanstack/react-router";
import { Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";
import loginBg from "@/assets/login-bg.jpg";
import { supabase } from "@/integrations/supabase/client";
import { getPortalByCode } from "@/lib/client-portal.functions";
import type { PortalData } from "@/lib/client-portal.functions";
import { PortalView } from "@/components/PortalView";
import { BrandLogo } from "@/components/BrandLogo";
import { Button } from "@/components/ui/button";
import { resolveLanding } from "@/lib/post-login";

/** Client access with the six-digit code from their invoice link, or email + password. */
export function ClientCodeLogin({ onSwitchToStaff }: { onSwitchToStaff: () => void }) {
  const fetchByCode = useServerFn(getPortalByCode);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [method, setMethod] = useState<"code" | "password">("code");
  const [code, setCode] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [data, setData] = useState<PortalData | null>(null);

  const open = useMutation({
    mutationFn: () => fetchByCode({ data: { code: code.trim() } }),
    onSuccess: (res) => setData(res),
    onError: (e: Error) => toast.error(e.message),
  });

  const signIn = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });
      if (error) throw error;
    },
    onSuccess: async () => {
      queryClient.clear();
      navigate({ to: await resolveLanding() });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (data) {
    return (
      <div className="cine min-h-screen text-foreground">
        <header className="border-b border-border bg-nav">
          <div className="flex w-full items-center justify-between gap-3 px-4 py-3 sm:px-6">
            <a href="https://rideblackwave.com" className="flex flex-1 items-center gap-3">
              <BrandLogo className="size-10" />
              <span className="block">
                <span className="block font-display text-lg uppercase leading-none">Client portal</span>
                <span className="block font-cond text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
                  Blackwave Transportation LLC
                </span>
              </span>
            </a>
            <Button
              type="button"
              variant="ghost"
              onClick={() => {
                setData(null);
                setCode("");
              }}
              className="font-work text-[10px] uppercase tracking-widest text-muted-foreground hover:text-brand"
            >
              Close
            </Button>
          </div>
        </header>
        <PortalView data={data} auth={{ code: code.trim() }} />
      </div>
    );
  }

  return (
    <div
      className="relative flex min-h-screen flex-col items-center justify-center bg-background bg-cover bg-center px-6 py-12"
      style={{ backgroundImage: `url(${loginBg})` }}
    >
      <div className="absolute inset-0 bg-foreground/40 backdrop-blur-[2px]" />
      <div className="relative w-full max-w-[440px] rounded-[2.5rem] border border-card/40 bg-card/95 p-6 shadow-2xl backdrop-blur-xl sm:p-10">
        <div className="text-center">
          <BrandLogo className="mx-auto mb-5 h-24 w-24 rounded-2xl shadow-xl" />
          <h1 className="font-editorial text-3xl leading-none text-foreground">
            Client Portal
          </h1>
          <div className="mt-3 font-work text-[11px] uppercase tracking-[0.22em] text-foreground">
            Blackwave Transportation LLC
          </div>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-1.5 rounded-2xl bg-surface-2 p-1.5">
          <Button
            type="button"
            variant="ghost"
            onClick={onSwitchToStaff}
            className="h-11 rounded-xl px-2 font-work text-[11px] uppercase tracking-[0.12em] text-muted-foreground hover:bg-brand/10 hover:text-brand"
          >
            Staff / Admin
          </Button>
          <Button
            type="button"
            className="h-11 rounded-xl bg-brand px-2 font-work text-[11px] uppercase tracking-[0.12em] text-brand-foreground shadow-md hover:bg-brand/90"
          >
            Client
          </Button>
        </div>

        <div className="mt-5 grid grid-cols-2 border-b border-border">
          {(
            [
              { key: "code", label: "Access code" },
              { key: "password", label: "Email & password" },
            ] as const
          ).map((t) => (
            <Button
              key={t.key}
              type="button"
              variant="ghost"
              onClick={() => setMethod(t.key)}
              className={`h-12 rounded-none border-b-2 px-2 font-work text-[10px] uppercase tracking-[0.12em] transition-colors ${
                method === t.key
                  ? "border-brand text-brand"
                  : "border-transparent text-muted-foreground hover:bg-brand/5 hover:text-brand"
              }`}
            >
              {t.label}
            </Button>
          ))}
        </div>

        {method === "code" ? (
          <>
            <p className="mx-auto mt-6 max-w-xs text-center font-work text-sm leading-relaxed text-muted-foreground">
              Enter your six-digit access code to securely continue to your client portal.
            </p>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                open.mutate();
              }}
              className="mt-7 space-y-5"
            >
              <input
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={6}
                autoFocus
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                placeholder="1 2 3 4 5 6"
                aria-label="Six-digit access code"
                className="h-16 w-full rounded-2xl border-2 border-input bg-surface px-4 text-center font-work text-2xl tracking-[0.45em] text-foreground outline-none transition focus:border-brand focus:ring-4 focus:ring-brand/10"
              />
              <Button
                type="submit"
                disabled={open.isPending || code.length !== 6}
                className="h-14 w-full rounded-2xl bg-brand font-work text-sm uppercase tracking-[0.18em] text-brand-foreground shadow-lg hover:bg-brand/90 disabled:opacity-60"
              >
                {open.isPending ? "Opening…" : "Continue to portal"}
              </Button>
            </form>
          </>
        ) : (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              signIn.mutate();
            }}
            className="mt-7 space-y-4"
          >
            <label className="relative block">
              <input
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder=" "
                className="peer h-16 w-full rounded-2xl border-2 border-input bg-surface px-4 pt-5 font-work text-base text-foreground outline-none transition focus:border-brand focus:ring-4 focus:ring-brand/10"
              />
              <span className="pointer-events-none absolute left-4 top-2 font-work text-[10px] uppercase tracking-[0.15em] text-muted-foreground transition-all peer-placeholder-shown:top-5 peer-placeholder-shown:text-sm peer-placeholder-shown:normal-case peer-placeholder-shown:tracking-normal peer-focus:top-2 peer-focus:text-[10px] peer-focus:uppercase peer-focus:tracking-[0.15em] peer-focus:text-brand">Email address</span>
            </label>
            <label className="relative block">
              <input
                type={showPassword ? "text" : "password"}
                required
                minLength={6}
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder=" "
                className="peer h-16 w-full rounded-2xl border-2 border-input bg-surface px-4 pt-5 pr-12 font-work text-base text-foreground outline-none transition focus:border-brand focus:ring-4 focus:ring-brand/10"
              />
              <span className="pointer-events-none absolute left-4 top-2 font-work text-[10px] uppercase tracking-[0.15em] text-muted-foreground transition-all peer-placeholder-shown:top-5 peer-placeholder-shown:text-sm peer-placeholder-shown:normal-case peer-placeholder-shown:tracking-normal peer-focus:top-2 peer-focus:text-[10px] peer-focus:uppercase peer-focus:tracking-[0.15em] peer-focus:text-brand">Password</span>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                aria-label={showPassword ? "Hide password" : "Show password"}
                onClick={() => setShowPassword((value) => !value)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-brand"
              >
                {showPassword ? <EyeOff /> : <Eye />}
              </Button>
            </label>
            <Button
              type="submit"
              disabled={signIn.isPending}
              className="h-14 w-full rounded-2xl bg-brand font-work text-sm uppercase tracking-[0.18em] text-brand-foreground shadow-lg hover:bg-brand/90 disabled:opacity-60"
            >
              {signIn.isPending ? "Signing in…" : "Continue to portal"}
            </Button>
          </form>
        )}

        <p className="mt-6 text-center font-work text-xs leading-relaxed text-muted-foreground">
          Need help signing in? Contact Blackwave Transportation at info@rideblackwave.com.
        </p>
      </div>
    </div>
  );
}
