import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useSession } from "@/lib/auth";
import { BrandLogo } from "@/components/BrandLogo";

export const COMPANY = {
  name: "Blackwave Transportation LLC",
  phone: "(917) 325-3211",
  phoneHref: "tel:+19173253211",
  email: "info@rideblackwave.com",
  address: "52 Meredith Avenue, Staten Island, NY 10314",
  site: "www.rideblackwave.com",
};

const LINKS = [
  { to: "/", label: "Home" },
  { to: "/our-fleet", label: "Fleet" },
  { to: "/services", label: "Services" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

function Mark() {
  return <BrandLogo className="h-10 w-10 rounded-sm" />;
}

function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { session } = useSession();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed left-0 right-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "border-b border-border bg-background/85 backdrop-blur-xl" : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5 lg:px-10">
        <Link to="/" className="group flex items-center gap-3">
          <Mark />
          <div className="leading-tight">
            <div className="font-display text-xl tracking-wide">Blackwave Transportation</div>
            <div className="font-mono text-[0.6rem] uppercase tracking-[0.3em] text-muted-foreground">
              Private Chauffeur
            </div>
          </div>
        </Link>

        <nav className="hidden items-center gap-10 md:flex">
          {LINKS.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-gold"
              activeProps={{ className: "text-gold" }}
              activeOptions={{ exact: l.to === "/" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-6 md:flex">
          <Link
            to={session ? "/dashboard" : "/auth"}
            className="font-mono text-xs uppercase tracking-[0.2em] text-muted-foreground transition-colors hover:text-gold"
          >
            {session ? "Dashboard" : "Log In"}
          </Link>
          <Link
            to="/contact"
            className="border border-gold px-5 py-2.5 font-mono text-xs uppercase tracking-[0.2em] text-gold transition-all hover:bg-gold hover:text-primary-foreground"
          >
            Reserve
          </Link>
        </div>

        <button aria-label="Menu" onClick={() => setOpen((o) => !o)} className="text-foreground md:hidden">
          <div className="space-y-1.5">
            <span className={`block h-px w-7 bg-current transition ${open ? "translate-y-2 rotate-45" : ""}`} />
            <span className={`block h-px w-7 bg-current transition ${open ? "opacity-0" : ""}`} />
            <span className={`block h-px w-7 bg-current transition ${open ? "-translate-y-2 -rotate-45" : ""}`} />
          </div>
        </button>
      </div>

      {open && (
        <div className="border-t border-border bg-background/95 backdrop-blur-xl md:hidden">
          <nav className="flex flex-col gap-5 px-6 py-6">
            {LINKS.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className="font-mono text-xs uppercase tracking-[0.25em] text-muted-foreground hover:text-gold"
                activeProps={{ className: "text-gold" }}
                activeOptions={{ exact: l.to === "/" }}
              >
                {l.label}
              </Link>
            ))}
            <Link
              to={session ? "/dashboard" : "/auth"}
              onClick={() => setOpen(false)}
              className="font-mono text-xs uppercase tracking-[0.25em] text-muted-foreground hover:text-gold"
            >
              {session ? "Dashboard" : "Log In"}
            </Link>
            <a
              href={COMPANY.phoneHref}
              className="font-mono text-xs uppercase tracking-[0.25em] text-muted-foreground hover:text-gold"
            >
              {COMPANY.phone}
            </a>
            <Link
              to="/contact"
              onClick={() => setOpen(false)}
              className="mt-2 inline-block border border-gold px-5 py-3 text-center font-mono text-xs uppercase tracking-[0.2em] text-gold"
            >
              Reserve
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}

function SiteFooter() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="mx-auto max-w-7xl px-6 py-20 lg:px-10">
        <div className="grid gap-12 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-3">
              <Mark />
              <div className="font-display text-2xl">Blackwave Transportation</div>
            </div>
            <p className="mt-6 max-w-md text-sm leading-relaxed text-muted-foreground">
              A private chauffeur service for executives, dignitaries, and discerning travelers across
              the Northeast corridor.
            </p>
            <p className="eyebrow mt-8">Available 24 / 7 / 365</p>
          </div>

          <div>
            <p className="eyebrow mb-5">Navigate</p>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li><Link to="/our-fleet" className="hover:text-gold">Fleet</Link></li>
              <li><Link to="/services" className="hover:text-gold">Services</Link></li>
              <li><Link to="/about" className="hover:text-gold">About</Link></li>
              <li><Link to="/contact" className="hover:text-gold">Contact</Link></li>
              <li><Link to="/auth" className="hover:text-gold">Client & staff login</Link></li>
            </ul>
          </div>

          <div>
            <p className="eyebrow mb-5">Concierge</p>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li>
                <a href={COMPANY.phoneHref} className="hover:text-gold">{COMPANY.phone}</a>
              </li>
              <li>
                <a href={`mailto:${COMPANY.email}`} className="hover:text-gold">{COMPANY.email}</a>
              </li>
              <li>{COMPANY.address}</li>
            </ul>
          </div>
        </div>

        <div className="hairline mt-16" />
        <div className="mt-8 flex flex-col items-start justify-between gap-4 text-xs text-muted-foreground md:flex-row md:items-center">
          <p>© {new Date().getFullYear()} {COMPANY.name}. All rights reserved.</p>
          <p className="font-mono uppercase tracking-[0.25em]">Discretion · Precision · Distinction</p>
        </div>
      </div>
    </footer>
  );
}

export function SiteLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="luxe flex min-h-screen flex-col bg-background text-foreground">
      <SiteHeader />
      <main className="min-h-screen flex-1">{children}</main>
      <SiteFooter />
    </div>
  );
}

export function PageHeader({ kicker, title, blurb }: { kicker: string; title: string; blurb?: string }) {
  return (
    <section className="pb-16 pt-40 lg:pt-48">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <p className="eyebrow mb-6">{kicker}</p>
        <h1 className="max-w-4xl font-display text-5xl leading-[1.05] md:text-7xl">{title}</h1>
        {blurb && <p className="mt-8 max-w-2xl text-lg leading-relaxed text-muted-foreground">{blurb}</p>}
      </div>
    </section>
  );
}
