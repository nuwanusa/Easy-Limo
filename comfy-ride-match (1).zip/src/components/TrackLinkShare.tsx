import { useState } from "react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { sendTrackLinkEmail } from "@/lib/ride-track.functions";

const LINK_BASE = "https://rideblackwave.com";

/**
 * Creates (or reuses) the passenger tracking link for a reservation and gives
 * staff quick ways to hand it over: copy, text, WhatsApp, email app, or a
 * direct send-to-email box.
 */
export function TrackLinkShare({
  reservationId,
  token,
  reference,
  onCreated,
}: {
  reservationId: string;
  token?: string | null | undefined;
  reference?: string | null | undefined;
  onCreated?: (() => void) | undefined;
}) {
  // Long legacy tokens get replaced with a short code so every link is easy to text.
  const [url, setUrl] = useState<string | null>(
    token && token.length <= 16 ? `${LINK_BASE}/t/${token}` : null,
  );
  const [busy, setBusy] = useState(false);
  const [to, setTo] = useState("");
  const [name, setName] = useState("");
  const [sending, setSending] = useState(false);
  const sendEmail = useServerFn(sendTrackLinkEmail);

  const ensure = async () => {
    if (url) return url;
    setBusy(true);
    try {
      let t = token && token.length <= 16 ? token : null;
      if (!t) {
        // Short, unambiguous code (no 0/o/1/l) — keeps links easy to text.
        const alphabet = "abcdefghjkmnpqrstuvwxyz23456789";
        const bytes = crypto.getRandomValues(new Uint8Array(8));
        t = Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
        const { error } = await supabase
          .from("reservations")
          .update({ track_token: t })
          .eq("id", reservationId);
        if (error) throw error;
        onCreated?.();
      }
      const next = `${LINK_BASE}/t/${t}`;
      setUrl(next);
      return next;
    } finally {
      setBusy(false);
    }
  };

  const message = (link: string) =>
    [
      "Blackwave Transportation — track your vehicle live.",
      reference ? `Reservation: ${reference}` : "",
      link,
    ]
      .filter(Boolean)
      .join("\n");

  const act = async (kind: "copy" | "sms" | "whatsapp" | "email") => {
    const tab = kind === "whatsapp" ? window.open("", "_blank", "noopener") : null;
    try {
      const link = await ensure();
      const body = message(link);
      if (kind === "copy") {
        await navigator.clipboard.writeText(link);
        toast.success("Tracking link copied", { description: link });
        return;
      }
      if (kind === "whatsapp") {
        const wa = `https://wa.me/?text=${encodeURIComponent(body)}`;
        if (tab && !tab.closed) tab.location.href = wa;
        else window.location.href = wa;
        return;
      }
      if (kind === "sms") {
        window.location.href = `sms:?&body=${encodeURIComponent(body)}`;
        return;
      }
      window.location.href = `mailto:?subject=${encodeURIComponent(
        "Track your Blackwave vehicle",
      )}&body=${encodeURIComponent(body)}`;
    } catch (e) {
      tab?.close();
      toast.error(e instanceof Error ? e.message : "Could not create the tracking link");
    }
  };

  const submit = async () => {
    if (!to.includes("@")) {
      toast.error("Enter a valid email address");
      return;
    }
    setSending(true);
    try {
      const link = await ensure();
      await sendEmail({ data: { reservationId, to: to.trim(), name: name.trim(), url: link } });
      toast.success(`Tracking link sent to ${to.trim()}`);
      setTo("");
      setName("");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not send the tracking link");
    } finally {
      setSending(false);
    }
  };

  const btn =
    "rounded border border-border px-3 py-1.5 font-cond text-[10px] uppercase tracking-widest hover:border-brand hover:text-brand disabled:opacity-50";

  return (
    <div className="mt-3 rounded-lg border border-border bg-card p-4">
      <div className="font-cond text-[11px] uppercase tracking-widest text-brand">
        Passenger tracking link
      </div>
      <p className="mt-1 font-cond text-xs text-muted-foreground">
        Share a live map so the passenger can follow the vehicle and arrival time.
      </p>

      {url && (
        <div className="mt-2 break-all rounded border border-border bg-background px-2 py-1 font-cond text-xs">
          {url}
        </div>
      )}

      <div className="mt-2 flex flex-wrap gap-2">
        <button disabled={busy} onClick={() => act("copy")} className={btn}>
          Copy link
        </button>
        <button disabled={busy} onClick={() => act("sms")} className={btn}>
          Text
        </button>
        <button disabled={busy} onClick={() => act("whatsapp")} className={btn}>
          WhatsApp
        </button>
        <button disabled={busy} onClick={() => act("email")} className={btn}>
          Email app
        </button>
      </div>

      <div className="mt-3 grid gap-2 sm:grid-cols-[1fr_1.4fr_auto]">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Name (optional)"
          className="h-9 rounded border border-border bg-background px-2 font-cond text-sm"
        />
        <input
          value={to}
          onChange={(e) => setTo(e.target.value)}
          type="email"
          placeholder="passenger@email.com"
          className="h-9 rounded border border-border bg-background px-2 font-cond text-sm"
        />
        <button disabled={sending || busy} onClick={submit} className={`${btn} h-9`}>
          {sending ? "Sending…" : "Send"}
        </button>
      </div>
    </div>
  );
}
