import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { money, VEHICLE_CLASSES, zoneRatesQuery } from "@/lib/dispatch";

export const ZONE_TYPES = ["city", "state", "borough", "region", "airport"] as const;

const emptyZone = {
  from_label: "",
  from_type: "city",
  to_label: "",
  to_type: "city",
  vehicle_class: "sedan",
  amount: "0",
  notes: "",
};

export function PriceMap({ clientId, clientName }: { clientId: string; clientName: string }) {
  const qc = useQueryClient();
  const { data: zones = [] } = useQuery(zoneRatesQuery);
  const [form, setForm] = useState(emptyZone);

  const rows = zones.filter((z) => z.client_id === clientId);

  const save = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("zone_rates").insert({
        client_id: clientId,
        from_label: form.from_label,
        from_type: form.from_type,
        to_label: form.to_label,
        to_type: form.to_type,
        vehicle_class: form.vehicle_class,
        amount: Number(form.amount),
        notes: form.notes || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["zone_rates"] });
      setForm(emptyZone);
      toast.success("Route price added");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("zone_rates").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["zone_rates"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const swap = () =>
    setForm({
      ...form,
      from_label: form.to_label,
      from_type: form.to_type,
      to_label: form.from_label,
      to_type: form.from_type,
    });

  return (
    <div className="mt-8 border-t border-border pt-5">
      <div className="font-cond text-[11px] uppercase tracking-[0.3em] text-brand">
        Price map — point A to point B · {clientName}
      </div>
      <p className="mt-1 font-cond text-xs text-muted-foreground">
        Set a fare between two places. Each place can be a city, state, borough, region or airport.
      </p>

      <div className="mt-4 divide-y divide-border">
        {rows.map((z) => (
          <div key={z.id} className="flex flex-wrap items-center gap-3 py-2 font-cond text-sm">
            <span className="min-w-56">
              {z.from_label} <span className="text-muted-foreground">({z.from_type})</span> →{" "}
              {z.to_label} <span className="text-muted-foreground">({z.to_type})</span>
            </span>
            <span className="text-muted-foreground">{z.vehicle_class}</span>
            <span>{money(Number(z.amount))}</span>
            {z.notes && <span className="text-muted-foreground">{z.notes}</span>}
            <button
              onClick={() => remove.mutate(z.id)}
              className="ml-auto rounded-md border border-destructive/50 px-3 py-1 font-cond text-[10px] uppercase tracking-widest text-destructive"
            >
              Remove
            </button>
          </div>
        ))}
        {rows.length === 0 && (
          <div className="py-2 font-cond text-sm text-muted-foreground">No route prices saved yet.</div>
        )}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate();
        }}
        className="mt-4 grid gap-3 md:grid-cols-6"
      >
        <ZoneField
          label="Point A"
          value={form.from_label}
          type={form.from_type}
          onValue={(v) => setForm({ ...form, from_label: v })}
          onType={(v) => setForm({ ...form, from_type: v })}
          placeholder="Manhattan"
        />
        <ZoneField
          label="Point B"
          value={form.to_label}
          type={form.to_type}
          onValue={(v) => setForm({ ...form, to_label: v })}
          onType={(v) => setForm({ ...form, to_type: v })}
          placeholder="JFK Airport"
        />
        <div>
          <div className="mb-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">Vehicle</div>
          <select
            value={form.vehicle_class}
            onChange={(e) => setForm({ ...form, vehicle_class: e.target.value })}
            className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
          >
            {VEHICLE_CLASSES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
        <div>
          <div className="mb-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">Fare</div>
          <input
            type="number"
            value={form.amount}
            onChange={(e) => setForm({ ...form, amount: e.target.value })}
            className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
          />
        </div>
        <div>
          <div className="mb-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">Notes</div>
          <input
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
            placeholder="Optional"
            className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground placeholder:text-muted-foreground"
          />
        </div>
        <div className="flex flex-col justify-end gap-2">
          <div className="flex gap-2">
            <button
              type="button"
              onClick={swap}
              className="rounded-md border border-border px-3 py-2 font-cond text-[10px] uppercase tracking-widest text-muted-foreground"
            >
              Swap
            </button>
            <button
              type="submit"
              disabled={save.isPending}
              className="flex-1 rounded-md bg-brand px-4 py-2 font-cond text-[10px] uppercase tracking-[0.3em] text-brand-foreground disabled:opacity-60"
            >
              Add route
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}

function ZoneField({
  label,
  value,
  type,
  onValue,
  onType,
  placeholder,
}: {
  label: string;
  value: string;
  type: string;
  onValue: (v: string) => void;
  onType: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <div>
      <div className="mb-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <input
        value={value}
        required
        placeholder={placeholder}
        onChange={(e) => onValue(e.target.value)}
        className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground placeholder:text-muted-foreground focus:border-brand/60"
      />
      <select
        value={type}
        onChange={(e) => onType(e.target.value)}
        className="mt-1 w-full rounded-md border border-input bg-surface px-3 py-1.5 font-cond text-[11px] uppercase tracking-widest text-muted-foreground"
      >
        {ZONE_TYPES.map((t) => (
          <option key={t} value={t}>
            {t}
          </option>
        ))}
      </select>
    </div>
  );
}
