import { useState } from "react";
import { toast } from "sonner";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  listMyReservationRequests,
  submitMyReservationRequest,
  submitReservationRequest,
} from "@/lib/reservation-requests.functions";
import { AddressAutocomplete } from "@/components/AddressAutocomplete";
import type { PortalAuth } from "@/components/PortalView";
import { Button } from "@/components/ui/button";

const VEHICLES = ["Sedan", "SUV", "Sprinter", "Stretch limo", "Mini bus"];

const label =
  "mb-1.5 flex min-h-8 items-end font-cond text-[10px] uppercase tracking-widest text-muted-foreground";
const input =
  "h-11 w-full rounded-md border border-input bg-background px-3 font-cond text-sm text-foreground outline-none focus:border-brand/60";

const dayTime = (v: string) =>
  new Date(v).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    timeZone: "America/New_York",
  });

/** Lets a client ask for a new reservation; staff approve it before it is booked. */
export function ClientRequestForm({ auth }: { auth?: PortalAuth | undefined }) {
  const qc = useQueryClient();
  const guest = Boolean(auth?.token || auth?.code);
  const submitGuest = useServerFn(submitReservationRequest);
  const submitMine = useServerFn(submitMyReservationRequest);
  const listMine = useServerFn(listMyReservationRequests);

  const [open] = useState(true);
  const [hourly, setHourly] = useState(false);
  const [form, setForm] = useState({
    pickup_at: "",
    pickup_address: "",
    dropoff_address: "",
    vehicle_class: "Sedan",
    hours: "3",
    passenger_count: "1",
    luggage_count: "0",
    passenger_name: "",
    contact_phone: "",
    contact_email: "",
    notes: "",
  });
  const set = (k: keyof typeof form, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const requests = useQuery({
    queryKey: ["my-reservation-requests", auth?.token ?? "", auth?.code ?? ""],
    queryFn: () => listMine({ data: { token: auth?.token, code: auth?.code } }),
    staleTime: 30_000,
  });

  const send = useMutation({
    mutationFn: async () => {
      const payload = {
        pickup_at: form.pickup_at,
        pickup_address: form.pickup_address,
        dropoff_address: form.dropoff_address,
        vehicle_class: form.vehicle_class,
        booking_type: (hourly ? "hourly" : "point_to_point") as "hourly" | "point_to_point",
        hours: Number(form.hours) || 0,
        passenger_count: Number(form.passenger_count) || 1,
        luggage_count: Number(form.luggage_count) || 0,
        passenger_name: form.passenger_name,
        contact_phone: form.contact_phone,
        contact_email: form.contact_email,
        notes: form.notes,
        ...(guest ? { token: auth?.token, code: auth?.code } : {}),
      };
      return guest ? submitGuest({ data: payload }) : submitMine({ data: payload });
    },
    onSuccess: () => {
      toast.success("Request sent — we'll confirm by email once it's approved");
      setForm((f) => ({ ...f, pickup_at: "", pickup_address: "", dropoff_address: "", notes: "" }));
      void qc.invalidateQueries({ queryKey: ["my-reservation-requests"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const list = requests.data ?? [];

  return (
    <div className="mt-6 rounded-xl border border-border bg-card p-5">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
        <div className="min-w-0">
          <div className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
            Request a reservation
          </div>
          <p className="font-cond text-sm text-muted-foreground">
            Send your trip details — we confirm by email once approved.
          </p>
        </div>
      </div>


      {open && (
        <form
          className="mt-5 grid grid-cols-6 gap-x-3 gap-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            send.mutate();
          }}
        >
          <div className="col-span-6 grid grid-cols-2 gap-2">
            {[
              { k: false, t: "Point to point" },
              { k: true, t: "Hourly" },
            ].map((o) => (
              <Button
                key={o.t}
                type="button"
                variant="outline"
                onClick={() => setHourly(o.k)}
                className={`h-11 min-w-0 px-2 font-cond text-[11px] uppercase tracking-widest ${
                  hourly === o.k ? "border-brand bg-brand/10 text-brand" : "border-border text-muted-foreground"
                }`}
              >
                {o.t}
              </Button>
            ))}
          </div>

          <div className="col-span-6 sm:col-span-2">
            <div className={label}>Pickup date &amp; time</div>
            <input
              type="datetime-local"
              required
              value={form.pickup_at}
              onChange={(e) => set("pickup_at", e.target.value)}
              className={input}
            />
          </div>
          <div className="col-span-6 sm:col-span-4">
            <div className={label}>Pickup location</div>
            <AddressAutocomplete
              value={form.pickup_address}
              onChange={(v) => set("pickup_address", v)}
              required
              placeholder="Address, airport or hotel"
            />
          </div>

          <div className="col-span-6 sm:col-span-4">
            <div className={label}>{hourly ? "First stop / direction" : "Drop-off location"}</div>
            <AddressAutocomplete
              value={form.dropoff_address}
              onChange={(v) => set("dropoff_address", v)}
              required={!hourly}
              placeholder="Address"
            />
          </div>
          <div className="col-span-6 sm:col-span-2">
            <div className={label}>Vehicle type</div>
            <select
              value={form.vehicle_class}
              onChange={(e) => set("vehicle_class", e.target.value)}
              className={input}
            >
              {VEHICLES.map((v) => (
                <option key={v}>{v}</option>
              ))}
            </select>
          </div>

          {hourly && (
            <div className="col-span-6 sm:col-span-2">
              <div className={label}>Number of hours</div>
              <input
                type="number"
                min="1"
                step="0.5"
                value={form.hours}
                onChange={(e) => set("hours", e.target.value)}
                className={input}
              />
            </div>
          )}
          <div className="col-span-3 sm:col-span-2">
            <div className={label}>Passengers</div>
            <input
              type="number"
              min="1"
              value={form.passenger_count}
              onChange={(e) => set("passenger_count", e.target.value)}
              className={input}
            />
          </div>
          <div className="col-span-3 sm:col-span-2">
            <div className={label}>Luggage</div>
            <input
              type="number"
              min="0"
              value={form.luggage_count}
              onChange={(e) => set("luggage_count", e.target.value)}
              className={input}
            />
          </div>

          <div className="col-span-6 sm:col-span-2">
            <div className={label}>Passenger name</div>
            <input
              value={form.passenger_name}
              onChange={(e) => set("passenger_name", e.target.value)}
              className={input}
            />
          </div>
          <div className="col-span-6 sm:col-span-3">
            <div className={label}>Contact phone</div>
            <input
              value={form.contact_phone}
              onChange={(e) => set("contact_phone", e.target.value)}
              className={input}
            />
          </div>
          <div className="col-span-6 sm:col-span-3">
            <div className={label}>Contact email</div>
            <input
              type="email"
              value={form.contact_email}
              onChange={(e) => set("contact_email", e.target.value)}
              className={input}
            />
          </div>

          <div className="col-span-6">
            <div className={label}>Notes</div>
            <textarea
              rows={2}
              value={form.notes}
              onChange={(e) => set("notes", e.target.value)}
              className={`${input} h-24 resize-y py-3`}
            />
          </div>

          <div className="col-span-6">
            <Button
              type="submit"
              disabled={send.isPending}
              className="h-11 w-full bg-brand px-5 font-cond text-[11px] uppercase tracking-widest text-brand-foreground hover:bg-brand/90 sm:w-auto"
            >
              {send.isPending ? "Sending…" : "Send request"}
            </Button>
          </div>
        </form>
      )}

      {list.length > 0 && (
        <div className="mt-5 grid gap-2">
          {list.slice(0, 6).map((r) => (
            <div
              key={r.id}
              className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border bg-background px-4 py-3"
            >
              <div className="font-cond text-sm">
                <span className="text-muted-foreground">{dayTime(r.pickup_at)}</span> · {r.pickup_address}
                {r.dropoff_address ? ` → ${r.dropoff_address}` : ""}
              </div>
              <span
                className={`rounded-full px-3 py-1 font-cond text-[10px] uppercase tracking-widest ${
                  r.status === "approved"
                    ? "bg-emerald-500/15 text-emerald-500"
                    : r.status === "declined"
                      ? "bg-destructive/15 text-destructive"
                      : "bg-muted text-muted-foreground"
                }`}
              >
                {r.status}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
