import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { clockTime, dayLabel } from "@/lib/dispatch";

type TripEvent = {
  id: string;
  reservation_id: string;
  status: string;
  occurred_at: string;
};

type Receipt = {
  id: string;
  reservation_id: string;
  kind: string;
  file_path: string;
  amount: number;
  created_at: string;
};

const RECEIPT_KINDS = [
  { id: "parking", label: "Parking receipt" },
  { id: "airport", label: "Airport fee receipt" },
  { id: "toll", label: "Toll receipt" },
  { id: "other", label: "Other receipt" },
] as const;

/** Human label for a recorded trip milestone. */
const eventLabel = (status: string) => {
  const stop = /^at_stop_(\d+)$/.exec(status);
  if (stop) return `Arrived at stop ${stop[1]}`;
  if (status === "en_route") return "Started — en route to pickup";
  if (status === "on_location") return "Arrived at pickup location";
  if (status === "passenger_on_board") return "Passenger on board";
  if (status === "completed") return "Passenger dropped off";
  return status.replace(/_/g, " ");
};

export function RideSummary({
  reservationId,
  initialNote,
}: {
  reservationId: string;
  initialNote: string | null;
}) {
  const qc = useQueryClient();
  const [note, setNote] = useState(initialNote ?? "");
  const [kind, setKind] = useState<string>("parking");
  const [amount, setAmount] = useState("");
  const [file, setFile] = useState<File | null>(null);

  useEffect(() => {
    setNote(initialNote ?? "");
  }, [initialNote]);

  const { data: events = [] } = useQuery({
    queryKey: ["trip-events", reservationId],
    queryFn: async (): Promise<TripEvent[]> => {
      const { data, error } = await supabase
        .from("reservation_status_events")
        .select("*")
        .eq("reservation_id", reservationId)
        .order("occurred_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as TripEvent[];
    },
  });

  const { data: receipts = [] } = useQuery({
    queryKey: ["trip-receipts", reservationId],
    queryFn: async (): Promise<Receipt[]> => {
      const { data, error } = await supabase
        .from("reservation_receipts")
        .select("*")
        .eq("reservation_id", reservationId)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as Receipt[];
    },
  });

  const saveNote = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("reservations")
        .update({ driver_note: note })
        .eq("id", reservationId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Note sent to dispatch");
      qc.invalidateQueries({ queryKey: ["driver-trips"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const upload = useMutation({
    mutationFn: async () => {
      if (!file) throw new Error("Choose a photo or PDF first");
      const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const path = `${reservationId}/${Date.now()}-${safe}`;
      const { error: upErr } = await supabase.storage
        .from("ride-receipts")
        .upload(path, file, { contentType: file.type || "application/octet-stream" });
      if (upErr) throw upErr;
      const { error } = await supabase.from("reservation_receipts").insert({
        reservation_id: reservationId,
        kind,
        file_path: path,
        amount: amount ? Number(amount) : 0,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setFile(null);
      setAmount("");
      toast.success("Receipt attached");
      qc.invalidateQueries({ queryKey: ["trip-receipts", reservationId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const openReceipt = async (path: string) => {
    const { data, error } = await supabase.storage
      .from("ride-receipts")
      .createSignedUrl(path, 3600);
    if (error || !data?.signedUrl) {
      toast.error(error?.message ?? "Could not open receipt");
      return;
    }
    window.open(data.signedUrl, "_blank", "noopener");
  };

  return (
    <div className="mt-4 space-y-4">
      <div className="rounded-lg border border-brand/40 bg-brand/5 p-5">
        <div className="font-cond text-[10px] uppercase tracking-widest text-brand">
          Ride summary
        </div>
        {events.length === 0 ? (
          <p className="mt-2 font-cond text-[13px] text-muted-foreground">
            No timings were recorded for this trip.
          </p>
        ) : (
          <div className="mt-3 space-y-2">
            {events.map((e) => (
              <div key={e.id} className="flex items-baseline justify-between gap-3">
                <span className="font-cond text-[13px]">{eventLabel(e.status)}</span>
                <span className="font-cond text-[13px] text-muted-foreground">
                  {clockTime(e.occurred_at)}
                </span>
              </div>
            ))}
            <div className="pt-1 font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
              {dayLabel(events[0]!.occurred_at)}
            </div>
          </div>
        )}
      </div>

      <div className="rounded-lg border border-border bg-card p-5">
        <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
          Note to dispatch
        </div>
        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          rows={4}
          placeholder="Anything dispatch should know about this ride…"
          className="mt-2 w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm outline-none placeholder:text-muted-foreground focus:border-brand/60"
        />
        <button
          onClick={() => saveNote.mutate()}
          disabled={saveNote.isPending}
          className="mt-2 w-full rounded-md bg-brand py-2.5 font-cond text-[11px] uppercase tracking-widest text-brand-foreground disabled:opacity-60"
        >
          {saveNote.isPending ? "Sending…" : "Send note to dispatch"}
        </button>
      </div>

      <div className="rounded-lg border border-border bg-card p-5">
        <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
          Attach a receipt
        </div>
        <div className="mt-2 grid gap-2">
          <select
            value={kind}
            onChange={(e) => setKind(e.target.value)}
            className="rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm outline-none focus:border-brand/60"
          >
            {RECEIPT_KINDS.map((k) => (
              <option key={k.id} value={k.id}>
                {k.label}
              </option>
            ))}
          </select>
          <input
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            inputMode="decimal"
            placeholder="Amount (optional)"
            className="rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm outline-none placeholder:text-muted-foreground focus:border-brand/60"
          />
          <input
            type="file"
            accept="image/*,application/pdf"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            className="rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm"
          />
          <button
            onClick={() => upload.mutate()}
            disabled={upload.isPending || !file}
            className="rounded-md border border-brand py-2.5 font-cond text-[11px] uppercase tracking-widest text-brand disabled:opacity-40"
          >
            {upload.isPending ? "Uploading…" : "Attach receipt"}
          </button>
        </div>

        {receipts.length > 0 && (
          <div className="mt-4 space-y-2">
            {receipts.map((r) => (
              <button
                key={r.id}
                onClick={() => openReceipt(r.file_path)}
                className="flex w-full items-baseline justify-between gap-3 rounded-md border border-border px-3 py-2 text-left"
              >
                <span className="font-cond text-[13px]">
                  {RECEIPT_KINDS.find((k) => k.id === r.kind)?.label ?? r.kind}
                </span>
                <span className="font-cond text-[12px] text-brand">
                  {Number(r.amount) > 0 ? `$${Number(r.amount).toFixed(2)} · ` : ""}View
                </span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
