import { useEffect, useMemo, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getCompletedRideRoute, getEstimatedRideRoute } from "@/lib/ride-report.functions";

export function CompletedRideRouteMap({ reservationId }: { reservationId: string }) {
  const mapElementRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const routeLayerRef = useRef<any>(null);

  // The driven route covers the passenger's trip only — from the chauffeur's
  // "Passenger on board" tap until drop-off — with GPS dropouts filled with
  // the real road so the line follows streets. Server-side so it can use
  // Google Routes for the gap filling.
  const loadRoute = useServerFn(getCompletedRideRoute);
  const { data: routePoints = [], isLoading } = useQuery({
    queryKey: ["completed-ride-route", reservationId],
    queryFn: () => loadRoute({ data: { reservation_id: reservationId } }),
    staleTime: 60 * 60 * 1000,
  });

  const loadEstimatedRoute = useServerFn(getEstimatedRideRoute);
  const { data: estimatedPoints = [], isLoading: isEstimateLoading } = useQuery({
    queryKey: ["estimated-ride-route", reservationId],
    queryFn: () => loadEstimatedRoute({ data: { reservation_id: reservationId } }),
    enabled: !isLoading && routePoints.length < 2,
    staleTime: 60 * 60 * 1000,
  });
  const isEstimated = routePoints.length < 2 && estimatedPoints.length >= 2;
  const points = routePoints.length >= 2 ? routePoints : estimatedPoints;

  const routeKey = useMemo(
    () => points.map((point) => `${point.lat},${point.lng}`).join("|"),
    [points],
  );

  useEffect(() => {
    if (points.length < 2) return;
    let cancelled = false;

    void (async () => {
      const L = (await import("leaflet")).default;
      await import("leaflet/dist/leaflet.css");
      if (cancelled || !mapElementRef.current) return;

      const route: [number, number][] = points.map((point) => [Number(point.lat), Number(point.lng)]);
      const firstPoint = route[0];
      const lastPoint = route[route.length - 1];
      if (!firstPoint || !lastPoint) return;
      if (!mapRef.current) {
        mapRef.current = L.map(mapElementRef.current, {
          scrollWheelZoom: false,
        });
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          maxZoom: 19,
          attribution: "© OpenStreetMap",
        }).addTo(mapRef.current);
      }

      routeLayerRef.current?.remove();
      routeLayerRef.current = L.layerGroup().addTo(mapRef.current);
      L.polyline(route, {
        color: "var(--color-brand)",
        weight: 5,
        opacity: 0.9,
      }).addTo(routeLayerRef.current);
      L.circleMarker(firstPoint, {
        radius: 7,
        color: "var(--color-card)",
        weight: 2,
        fillColor: "var(--color-emerald-600)",
        fillOpacity: 1,
      })
        .bindTooltip("Passenger on board")
        .addTo(routeLayerRef.current);
      L.circleMarker(lastPoint, {
        radius: 7,
        color: "var(--color-card)",
        weight: 2,
        fillColor: "var(--color-destructive)",
        fillOpacity: 1,
      })
        .bindTooltip("Passenger dropped off")
        .addTo(routeLayerRef.current);
      mapRef.current.fitBounds(route, { padding: [28, 28], maxZoom: 16 });
      window.setTimeout(() => mapRef.current?.invalidateSize(), 100);
    })().catch(() => undefined);

    return () => {
      cancelled = true;
    };
  }, [points, routeKey]);

  if (isLoading || (routePoints.length < 2 && isEstimateLoading)) {
    return <div className="h-72 animate-pulse rounded-md bg-muted/40" />;
  }

  if (points.length < 2) {
    return (
      <div className="flex h-40 items-center justify-center rounded-md border border-dashed border-border bg-muted/20 px-5 text-center font-cond text-sm text-muted-foreground">
        A route map is not available for this ride.
      </div>
    );
  }

  return (
    <div>
      <div ref={mapElementRef} className="h-80 w-full overflow-hidden rounded-md border border-border sm:h-96" />
      {isEstimated ? (
        <p className="mt-2 font-cond text-[11px] text-muted-foreground">
          Estimated from the booked pickup, stops, and drop-off because driver GPS was not recorded.
        </p>
      ) : null}
      <div className="mt-2 flex items-center gap-5 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
        <span className="flex items-center gap-2">
          <span className="size-2.5 rounded-full bg-emerald-600" /> Passenger on board
        </span>
        <span className="flex items-center gap-2">
          <span className="size-2.5 rounded-full bg-destructive" /> Dropped off
        </span>
      </div>
    </div>
  );
}
