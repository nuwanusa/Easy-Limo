import { Link, useRouterState } from "@tanstack/react-router";

const TABS = [
  { to: "/accounting", label: "Accounting" },
  { to: "/invoices", label: "Statements" },
  { to: "/pay", label: "Pay" },
] as const;

export function MoneyTabs() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <div className="grid auto-cols-fr grid-flow-col border-b border-border px-2 sm:px-4">
      {TABS.map((tab) => {
        const active = pathname.startsWith(tab.to);
        return (
          <Link
            key={tab.to}
            to={tab.to}
            className={`border-b-2 px-2 py-2.5 text-center font-cond text-[11px] uppercase tracking-widest transition-colors ${
              active ? "border-brand text-brand" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab.label}
          </Link>
        );
      })}
    </div>
  );
}
