import { useCallback, useState } from "react";
import { EmbeddedCheckoutProvider, EmbeddedCheckout } from "@stripe/react-stripe-js";
import { getStripe, getStripeEnvironment, paymentsConfigured } from "@/lib/stripe";
import { createPaymentCheckout, type PaymentTarget } from "@/lib/payments.functions";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";
import { PaymentShare } from "@/components/PaymentShare";

const MANUAL_METHODS = [
  { key: "zelle", name: "Zelle", detail: "9173253211", note: "Send to this number and include the invoice number." },
  { key: "venmo", name: "Venmo", detail: "@nuwanusa", note: "Include the invoice number in the note." },
  { key: "cashapp", name: "Cash App", detail: "$blackwavelimo", note: "Include the invoice number in the note." },
  { key: "ach", name: "ACH — Chase Bank", detail: "Account # 507675562 · Routing # 021000021", note: "Bank transfer to CHASE BANK. Include the invoice number." },
] as const;

/** Payment options shown to a client: card checkout plus manual transfer details. */
export function ClientPayPanel({
  target,
  id,
  amount,
  label,
}: {
  target: PaymentTarget;
  id: string;
  amount: number;
  label?: string | undefined;
}) {
  const [open, setOpen] = useState(false);
  const [method, setMethod] = useState<string | null>(null);
  const [partial, setPartial] = useState(false);
  const [entered, setEntered] = useState("");
  const [charge, setCharge] = useState<number | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const fetchClientSecret = useCallback(async (): Promise<string> => {
    const result = await createPaymentCheckout({
      data: {
        target,
        id,
        returnUrl: `${window.location.origin}/checkout/return?session_id={CHECKOUT_SESSION_ID}`,
        environment: getStripeEnvironment(),
        ...(charge != null ? { amount: charge } : {}),
      },
    });
    if ("error" in result) throw new Error(result.error);
    if (!result.clientSecret) throw new Error("Checkout could not be started");
    return result.clientSecret;
  }, [target, id, charge]);

  if (amount <= 0) return null;
  const selected = MANUAL_METHODS.find((m) => m.key === method);
  const allowPartial = target === "invoice";

  const startCard = () => {
    if (!partial) {
      setNotice(null);
      setCharge(amount);
      return;
    }
    const value = Number(entered);
    if (!Number.isFinite(value) || value < 0.5) {
      setNotice("Enter an amount of at least $0.50.");
      return;
    }
    if (value > amount) {
      setNotice(`That is more than the balance of $${amount.toFixed(2)}.`);
      return;
    }
    setNotice(null);
    setCharge(Number(value.toFixed(2)));
  };

  return (
    <div>
      <button
        type="button"
        onClick={() => {
          setOpen((v) => !v);
          setMethod(null);
          setCharge(null);
          setNotice(null);
        }}
        className="rounded-md bg-brand px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-brand-foreground transition hover:opacity-90"
      >
        {open ? "Close" : (label ?? `Pay $${amount.toFixed(2)}`)}
      </button>


      {open && (
        <div className="mt-4 rounded-lg border border-border bg-card p-5">
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setMethod("card")}
              className={`rounded-md border px-4 py-2 font-cond text-[11px] uppercase tracking-widest transition ${
                method === "card" ? "border-brand bg-brand/10 text-brand" : "border-border hover:border-brand"
              }`}
            >
              Credit card
            </button>
            {MANUAL_METHODS.map((m) => (
              <button
                key={m.key}
                type="button"
                onClick={() => setMethod(m.key)}
                className={`rounded-md border px-4 py-2 font-cond text-[11px] uppercase tracking-widest transition ${
                  method === m.key ? "border-brand bg-brand/10 text-brand" : "border-border hover:border-brand"
                }`}
              >
                {m.name}
              </button>
            ))}
          </div>

          {selected && (
            <div className="mt-4 rounded-md border border-border bg-background p-4">
              <div className="font-cond text-xs uppercase tracking-widest text-muted-foreground">{selected.name}</div>
              <div className="mt-1 text-lg font-semibold text-foreground">{selected.detail}</div>
              <p className="mt-1 text-sm text-muted-foreground">{selected.note}</p>
              <p className="mt-2 text-xs text-muted-foreground">
                Once we receive the transfer the invoice is marked paid and a receipt is emailed to you.
              </p>
            </div>
          )}

          {method === "card" && (
            <div className="mt-4">
              {!paymentsConfigured() ? (
                <p className="text-sm text-destructive">Card payments are not available right now.</p>
              ) : charge == null ? (
                <div className="rounded-md border border-border bg-background p-4">
                  <div className="font-cond text-xs uppercase tracking-widest text-muted-foreground">
                    How much would you like to pay?
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setPartial(false);
                        setNotice(null);
                      }}
                      className={`rounded-md border px-4 py-2 font-cond text-[11px] uppercase tracking-widest transition ${
                        !partial ? "border-brand bg-brand/10 text-brand" : "border-border hover:border-brand"
                      }`}
                    >
                      Full balance ${amount.toFixed(2)}
                    </button>
                    {allowPartial && (
                      <button
                        type="button"
                        onClick={() => {
                          setPartial(true);
                          setNotice(null);
                        }}
                        className={`rounded-md border px-4 py-2 font-cond text-[11px] uppercase tracking-widest transition ${
                          partial ? "border-brand bg-brand/10 text-brand" : "border-border hover:border-brand"
                        }`}
                      >
                        Part payment
                      </button>
                    )}
                  </div>

                  {partial && (
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      <span className="text-sm text-muted-foreground">$</span>
                      <input
                        inputMode="decimal"
                        value={entered}
                        onChange={(e) => setEntered(e.target.value)}
                        placeholder={amount.toFixed(2)}
                        className="w-36 rounded-md border border-border bg-background px-3 py-2 text-sm outline-none focus:border-brand"
                      />
                      <span className="text-xs text-muted-foreground">
                        Balance ${amount.toFixed(2)} — the rest stays open on this invoice.
                      </span>
                    </div>
                  )}

                  {notice && <p className="mt-2 text-sm text-destructive">{notice}</p>}

                  <button
                    type="button"
                    onClick={startCard}
                    className="mt-4 rounded-md bg-brand px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-brand-foreground transition hover:opacity-90"
                  >
                    Continue to card
                  </button>
                </div>
              ) : (
                <>
                  <PaymentTestModeBanner />
                  <div className="mt-2 flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      Paying ${(charge * 1.03).toFixed(2)} (${charge.toFixed(2)} + 3% card fee)
                    </span>
                    <button
                      type="button"
                      onClick={() => setCharge(null)}
                      className="font-cond text-[11px] uppercase tracking-widest text-brand"
                    >
                      Change amount
                    </button>
                  </div>
                  <div className="mt-3">
                    <EmbeddedCheckoutProvider key={charge} stripe={getStripe()} options={{ fetchClientSecret }}>
                      <EmbeddedCheckout />
                    </EmbeddedCheckoutProvider>
                  </div>
                </>
              )}
            </div>
          )}

          <div className="mt-5 border-t border-border pt-4">
            <PaymentShare target={target} id={id} />
          </div>
        </div>
      )}
    </div>
  );
}
