import { useCallback, useState } from "react";
import { EmbeddedCheckoutProvider, EmbeddedCheckout } from "@stripe/react-stripe-js";
import { getStripe, getStripeEnvironment, paymentsConfigured } from "@/lib/stripe";
import { createPaymentCheckout, type PaymentTarget } from "@/lib/payments.functions";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";
import { PaymentShare } from "@/components/PaymentShare";

interface PayNowButtonProps {
  target: PaymentTarget;
  id: string;
  amount: number;
  paid?: boolean;
  label?: string;
}

export function PayNowButton({ target, id, amount, paid, label }: PayNowButtonProps) {
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchClientSecret = useCallback(async (): Promise<string> => {
    const result = await createPaymentCheckout({
      data: {
        target,
        id,
        returnUrl: `${window.location.origin}/checkout/return?session_id={CHECKOUT_SESSION_ID}`,
        environment: getStripeEnvironment(),
      },
    });
    if ("error" in result) throw new Error(result.error);
    if (!result.clientSecret) throw new Error("Checkout could not be started");
    return result.clientSecret;
  }, [target, id]);

  if (paid || amount <= 0 || !paymentsConfigured()) return null;

  return (
    <div className="no-print">
      {!open ? (
        <button
          type="button"
          onClick={() => {
            setError(null);
            setOpen(true);
          }}
          className="rounded-md bg-brand px-4 py-2 font-cond text-xs uppercase tracking-widest text-white transition hover:opacity-90"
        >
          {label ?? "Pay by card"}
        </button>
      ) : (
        <div className="mt-4 rounded-lg border border-border bg-card p-4">
          <div className="mb-3 flex items-center justify-between">
            <span className="font-cond text-xs uppercase tracking-widest text-muted-foreground">
              Card payment
            </span>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="font-cond text-xs uppercase tracking-widest text-muted-foreground hover:text-brand"
            >
              Cancel
            </button>
          </div>
          <PaymentTestModeBanner />
          {error ? (
            <p className="mt-3 text-sm text-destructive">{error}</p>
          ) : (
            <div id="checkout" className="mt-3">
              <EmbeddedCheckoutProvider stripe={getStripe()} options={{ fetchClientSecret }}>
                <EmbeddedCheckout />
              </EmbeddedCheckoutProvider>
            </div>
          )}
          <div className="mt-5 border-t border-border pt-4">
            <PaymentShare target={target} id={id} />
          </div>
        </div>
      )}
    </div>
  );
}
