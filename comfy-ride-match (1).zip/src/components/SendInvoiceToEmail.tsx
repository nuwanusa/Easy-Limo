import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { staffForwardInvoiceByEmail } from "@/lib/invoice-notify.functions";

/** Staff control: emails this invoice to any address they type in. */
export function SendInvoiceToEmail({ invoiceId }: { invoiceId: string }) {
  const [open, setOpen] = useState(false);
  const [to, setTo] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const send = useServerFn(staffForwardInvoiceByEmail);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const res: any = await send({ data: { invoiceId, to: to.trim(), ...(name.trim() ? { name: name.trim() } : {}) } });
      if (res?.sent) {
        toast.success(`Billing statement sent to ${to.trim()}`);
        setTo("");
        setName("");
        setOpen(false);
      } else {
        toast.error("That address could not be emailed");
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not send the invoice");
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="no-print rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest hover:border-brand hover:text-brand"
      >
        {open ? "Cancel" : "Send to email"}
      </button>

      {open && (
        <form onSubmit={submit} className="no-print flex w-full flex-wrap items-center gap-2">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Recipient name"
            className="h-10 w-44 rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-brand"
          />
          <input
            type="email"
            required
            value={to}
            onChange={(e) => setTo(e.target.value)}
            placeholder="Send this statement to (email address)"
            className="h-10 min-w-[14rem] flex-1 rounded-md border border-input bg-background px-3 text-sm outline-none focus:border-brand"
          />
          <button
            type="submit"
            disabled={busy}
            className="h-10 rounded-md bg-brand px-4 font-cond text-[11px] uppercase tracking-widest text-brand-foreground disabled:opacity-50"
          >
            {busy ? "Sending…" : "Send statement"}
          </button>
        </form>
      )}
    </>
  );
}
