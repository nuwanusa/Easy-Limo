import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { listCompanyPlans, listPlans, setCompanyPlan } from "@/lib/subscriptions.functions";

/** Platform-owner controls: plan and wake-up call add-on for one company. */
export function CompanyPlanControl({ companyId }: { companyId: string }) {
  const qc = useQueryClient();
  const plansFn = useServerFn(listPlans);
  const subsFn = useServerFn(listCompanyPlans);
  const saveFn = useServerFn(setCompanyPlan);

  const plans = useQuery({ queryKey: ["plans"], queryFn: () => plansFn() });
  const subs = useQuery({ queryKey: ["company-plans"], queryFn: () => subsFn() });
  const sub = (subs.data ?? []).find((s) => s.companyId === companyId);

  const save = useMutation({
    mutationFn: (input: { planCode?: string; wakeUpEnabled?: boolean }) =>
      saveFn({
        data: {
          companyId,
          planCode: input.planCode ?? sub?.planCode ?? "starter",
          ...(typeof input.wakeUpEnabled === "boolean"
            ? { wakeUpEnabled: input.wakeUpEnabled }
            : {}),
        },
      }),
    onSuccess: () => {
      toast.success("Subscription updated");
      qc.invalidateQueries({ queryKey: ["company-plans"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="mt-3 flex flex-wrap items-center gap-3 rounded-lg border border-border/70 px-3 py-2">
      <span className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
        Plan
      </span>
      <select
        value={sub?.planCode ?? "starter"}
        onChange={(e) => save.mutate({ planCode: e.target.value })}
        className="rounded-md border border-border bg-background px-2 py-1 text-sm"
      >
        {(plans.data ?? []).map((p) => (
          <option key={p.code} value={p.code}>
            {p.name} — ${(p.priceCents / 100).toFixed(0)}/mo
          </option>
        ))}
      </select>
      <label className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={Boolean(sub?.wakeUpEnabled)}
          onChange={(e) => save.mutate({ wakeUpEnabled: e.target.checked })}
        />
        Wake-up calls
        {sub ? (
          <span className="text-muted-foreground">
            (${(sub.wakeUpMonthlyCents / 100).toFixed(0)}/mo + $
            {(sub.wakeUpPerCallCents / 100).toFixed(2)} per call)
          </span>
        ) : null}
      </label>
    </div>
  );
}
