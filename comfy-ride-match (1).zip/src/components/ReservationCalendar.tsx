import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { clockTime, type Reservation } from "@/lib/dispatch";

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

const keyOf = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

export function ReservationCalendar({ reservations }: { reservations: Reservation[] }) {
  const today = new Date();
  const [cursor, setCursor] = useState(new Date(today.getFullYear(), today.getMonth(), 1));

  const byDay = useMemo(() => {
    const map = new Map<string, Reservation[]>();
    reservations.forEach((r) => {
      const d = new Date(r.pickup_at);
      if (Number.isNaN(d.getTime())) return;
      const k = keyOf(d);
      const list = map.get(k) ?? [];
      list.push(r);
      map.set(k, list);
    });
    map.forEach((list) => list.sort((a, b) => a.pickup_at.localeCompare(b.pickup_at)));
    return map;
  }, [reservations]);

  const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
  const daysInMonth = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();
  const lead = first.getDay();
  const cells: (Date | null)[] = [
    ...Array.from({ length: lead }, () => null),
    ...Array.from({ length: daysInMonth }, (_, i) => new Date(cursor.getFullYear(), cursor.getMonth(), i + 1)),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  const shift = (n: number) => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + n, 1));

  return (
    <section className="overflow-hidden rounded-md border border-dashboard-line bg-card shadow-sm">
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-b border-dashboard-line px-4 py-3 sm:flex sm:justify-between">
        <h2 className="truncate font-admin-display text-lg font-bold text-dashboard-navy">
          {cursor.toLocaleDateString(undefined, { month: "long", year: "numeric" })}
        </h2>
        <div className="flex shrink-0 items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            aria-label="Previous month"
            onClick={() => shift(-1)}
          >
            <ChevronLeft />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCursor(new Date(today.getFullYear(), today.getMonth(), 1))}
          >
            Today
          </Button>
          <Button
            variant="outline"
            size="icon"
            aria-label="Next month"
            onClick={() => shift(1)}
          >
            <ChevronRight />
          </Button>
        </div>
      </header>

      <div className="grid min-w-[760px] grid-cols-7 border-b border-dashboard-line text-[9px] font-bold uppercase text-dashboard-muted">
        {WEEKDAYS.map((d) => (
          <div key={d} className="px-2 py-2 text-center">
            {d}
          </div>
        ))}
      </div>

      <div className="grid min-w-[760px] grid-cols-7">
        {cells.map((d, i) => {
          const list = d ? (byDay.get(keyOf(d)) ?? []) : [];
          const isToday = !!d && keyOf(d) === keyOf(today);
          return (
            <div
              key={i}
              className={`min-h-[108px] border-b border-r border-dashboard-line p-1.5 last:border-r-0 ${
                d ? "" : "bg-dashboard-canvas"
              } ${isToday ? "bg-dashboard-ice ring-1 ring-inset ring-dashboard-blue" : ""}`}
            >
              {d && (
                <>
                  <div
                    className={`mb-1 font-cond text-[11px] ${
                      isToday
                        ? "inline-flex h-5 w-5 items-center justify-center rounded-full bg-brand font-bold text-brand-foreground"
                        : "text-muted-foreground"
                    }`}
                  >
                    {d.getDate()}
                  </div>

                  <div className="space-y-1">
                    {list.slice(0, 3).map((r) => (
                      <Link
                        key={r.id}
                        to="/reservations"
                        search={{ edit: r.id }}
                        className="block truncate rounded-sm bg-dashboard-ice px-1.5 py-1 text-[10px] font-semibold leading-tight text-dashboard-blue hover:bg-dashboard-soft"
                        title={`${clockTime(r.pickup_at)} · ${r.passenger_name}`}
                      >
                        {clockTime(r.pickup_at)} {r.passenger_name}
                      </Link>
                    ))}
                    {list.length > 3 && (
                      <div className="px-1.5 text-[10px] text-muted-foreground">+{list.length - 3} more</div>
                    )}
                  </div>
                </>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}
