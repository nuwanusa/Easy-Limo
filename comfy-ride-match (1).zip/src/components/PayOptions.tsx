import { useCallback, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { recordManualPayment } from "@/lib/manual-payment.functions";
import { EmbeddedCheckoutProvider, EmbeddedCheckout } from "@stripe/react-stripe-js";
import { getStripe, getStripeEnvironment, paymentsConfigured } from "@/lib/stripe";
import { createPaymentCheckout, type PaymentTarget } from "@/lib/payments.functions";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";
import { PaymentShare } from "@/components/PaymentShare";

interface PayOptionsProps {
  target: PaymentTarget;
  id: string;
  amount: number;
  paid?: boolean;
  label?: string;
}

const MANUAL_METHODS = [
  { key: "zelle", name: "Zelle", detail: "9173253211", note: "Send to this number and include the invoice number." },
  { key: "venmo", name: "Venmo", detail: "@nuwanusa", note: "Include the invoice number in the note." },
  { key: "cashapp", name: "Cash App", detail: "$blackwavelimo", note: "Include the invoice number in the note." },
  { key: "ach", name: "ACH — Chase Bank", detail: "Account # 507675562 · Routing # 021000021", note: "Bank transfer to CHASE BANK. Include the invoice number." },
] as const;

export function PayOptions({ target, id, amount, paid, label }: PayOptionsProps) {
  const [open, setOpen] = useState(false);
  const [method, setMethod] = useState<string | null>(null);
  const [error] = useState<string | null>(null);
  const qc = useQueryClient();
  const recordPayment = useServerFn(recordManualPayment);

  const markPaid = useMutation({
    mutationFn: async (methodName: string) =>
      recordPayment({ data: { target, id, method: methodName, amount } }),
    onSuccess: (res) => {
      qc.invalidateQueries({ queryKey: ["reservations"] });
      qc.invalidateQueries({ queryKey: ["invoices"] });
      setOpen(false);
      setMethod(null);
      if (res?.sent) toast.success("Marked paid in full — receipt emailed to the client");
      else if (res?.reason === "no_client_email") toast.success("Marked paid in full (no client email on file)");
      else toast.warning("Marked paid in full, but the receipt email failed", { description: res?.reason });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const fetchClientSecret = useCallback(async (): Promise<string> => {
    const result = await createPaymentCheckout({
      data: {
        target,
        id,
        returnUrl: `${window.location.origin}/checkout/return?session_id={CHECKOUT_SESSION_ID}`,
        environment: getStripeEnvironment(),
      },
    });
    if ("error" in result) throw new Error(result.error);
    if (!result.clientSecret) throw new Error("Checkout could not be started");
    return result.clientSecret;
  }, [target, id]);

  if (paid || amount <= 0) return null;

  const cardReady = paymentsConfigured();
  const selected = MANUAL_METHODS.find((m) => m.key === method);

  return (
    <div className="no-print">
      <button
        type="button"
        onClick={() => {
          setOpen((v) => !v);
          setMethod(null);
        }}
        className="rounded-md bg-brand px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-brand-foreground transition hover:opacity-90"
      >
        {open ? "Close pay" : (label ?? "Pay")}
      </button>

      {open && (
        <div className="mt-4 w-full rounded-lg border border-border bg-card p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="font-cond text-xs uppercase tracking-widest text-muted-foreground">
              Choose a payment method
            </span>
            <span className="font-cond text-sm text-foreground">
              Amount due ${amount.toFixed(2)}
            </span>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {MANUAL_METHODS.map((m) => (
              <button
                key={m.key}
                type="button"
                onClick={() => setMethod(m.key)}
                className={`rounded-md border px-4 py-2 font-cond text-[11px] uppercase tracking-widest transition ${
                  method === m.key
                    ? "border-brand bg-brand/10 text-brand"
                    : "border-border text-foreground hover:border-brand hover:text-brand"
                }`}
              >
                {m.name}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setMethod("card")}
              className={`rounded-md border px-4 py-2 font-cond text-[11px] uppercase tracking-widest transition ${
                method === "card"
                  ? "border-brand bg-brand/10 text-brand"
                  : "border-border text-foreground hover:border-brand hover:text-brand"
              }`}
            >
              Credit card
            </button>
          </div>

          {selected && (
            <div className="mt-4 rounded-md border border-border bg-background p-4">
              <div className="font-cond text-xs uppercase tracking-widest text-muted-foreground">
                {selected.name}
              </div>
              <div className="mt-1 text-lg font-semibold text-foreground">{selected.detail}</div>
              <p className="mt-1 text-sm text-muted-foreground">{selected.note}</p>
              <button
                type="button"
                onClick={() => markPaid.mutate(selected.name)}
                disabled={markPaid.isPending}
                className="mt-3 rounded-md bg-brand px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-brand-foreground transition hover:opacity-90 disabled:opacity-50"
              >
                {markPaid.isPending ? "Recording…" : `Payment received via ${selected.name} — mark paid in full`}
              </button>
              <p className="mt-2 text-xs text-muted-foreground">
                Marks this {target === "invoice" ? "invoice" : "ride"} paid in full and emails the client a thank-you
                receipt.
              </p>
            </div>
          )}

          {method === "card" && (
            <div className="mt-4">
              {!cardReady ? (
                <p className="text-sm text-destructive">
                  Card payments are not set up for this site yet.
                </p>
              ) : (
                <>
                  <p className="mb-2 text-xs text-muted-foreground">
                    A 3% card processing fee is added to card payments.
                  </p>
                  <PaymentTestModeBanner />
                  {error ? (
                    <p className="mt-3 text-sm text-destructive">{error}</p>
                  ) : (
                    <div id="checkout" className="mt-3">
                      <EmbeddedCheckoutProvider stripe={getStripe()} options={{ fetchClientSecret }}>
                        <EmbeddedCheckout />
                      </EmbeddedCheckoutProvider>
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          <div className="mt-5 border-t border-border pt-4">
            <PaymentShare target={target} id={id} />
          </div>
        </div>
      )}
    </div>
  );
}
