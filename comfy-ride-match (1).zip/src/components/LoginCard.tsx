import { Eye, EyeOff, Check } from "lucide-react";
import loginBg from "@/assets/login-bg.jpg";
import { BrandLogo } from "@/components/BrandLogo";


export function LoginCard({
  kicker,
  email,
  setEmail,
  password,
  setPassword,
  show,
  setShow,
  remember,
  setRemember,
  busy,
  submit,
  extraTop,
  footer,
  cta = "Login",
}: {
  kicker: string;
  email: string;
  setEmail: (v: string) => void;
  password: string;
  setPassword: (v: string) => void;
  show: boolean;
  setShow: (v: boolean) => void;
  remember: boolean;
  setRemember: (v: boolean) => void;
  busy: boolean;
  submit: (e: React.FormEvent) => void;
  extraTop?: React.ReactNode;
  footer?: React.ReactNode;
  cta?: string;
}) {
  return (
    
    <div
      className="relative flex min-h-screen flex-col items-center justify-center bg-background bg-cover bg-center px-6 py-12"
      style={{ backgroundImage: `url(${loginBg})` }}
    >
      <div className="absolute inset-0 bg-foreground/25" />
      <div className="relative w-full max-w-sm rounded-2xl border border-border bg-card p-6 shadow-2xl">


        <div className="text-center">
          <BrandLogo className="mx-auto mb-4 h-24 w-24" />
          <div className="mt-2 font-cond text-sm uppercase tracking-[0.2em] text-foreground">
            Blackwave Transportation LLC
          </div>
          <div className="mt-1 font-cond text-[11px] uppercase tracking-[0.4em] text-muted-foreground">
            {kicker}
          </div>
        </div>

        <form onSubmit={submit} className="mt-12 space-y-6">
          {extraTop}
          <label className="block">
            <span className="font-cond text-xs uppercase tracking-[0.15em] text-foreground">Email</span>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              required
              className="mt-2 w-full rounded-xl border border-input bg-surface-2 px-4 py-4 font-cond text-base text-foreground outline-none focus:border-brand"
            />
          </label>

          <label className="block">
            <span className="font-cond text-xs uppercase tracking-[0.15em] text-foreground">Password</span>
            <div className="relative mt-2">
              <input
                type={show ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                required
                minLength={6}
                className="w-full rounded-xl border border-input bg-surface-2 px-4 py-4 pr-12 font-cond text-base text-foreground outline-none focus:border-brand"
              />
              <button
                type="button"
                aria-label={show ? "Hide password" : "Show password"}
                onClick={() => setShow(!show)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
              >
                {show ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </label>

          <button
            type="button"
            onClick={() => setRemember(!remember)}
            className="flex items-center gap-3"
          >
            <span
              className={`grid size-6 place-items-center rounded-md border-2 ${
                remember ? "border-brand text-brand" : "border-border text-transparent"
              }`}
            >
              <Check size={16} strokeWidth={3} />
            </span>
            <span className="font-cond text-sm text-foreground">Remember my log-in details</span>
          </button>

          <button
            type="submit"
            disabled={busy}
            className="mt-4 w-full rounded-xl bg-brand py-4 font-display text-lg uppercase tracking-[0.2em] text-brand-foreground disabled:opacity-60"
          >
            {busy ? "Signing in…" : cta}
          </button>
        </form>

        <div className="mt-8">{footer}</div>
      </div>
    </div>
  );
}
