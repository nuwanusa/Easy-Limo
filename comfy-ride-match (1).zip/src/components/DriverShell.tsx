import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { LayoutGrid, Search, DollarSign, Grid2x2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSession, initials } from "@/lib/auth";
import type { Driver } from "@/lib/dispatch";
import { MessengerPopup } from "@/components/MessengerPopup";

const DUTY_KEY = "blackwave.on-duty";

export function DriverShell({
  driver,
  loading,
  children,
}: {
  driver: Driver | null;
  loading: boolean;
  children: React.ReactNode;
}) {
  const { session, loading: authLoading } = useSession();
  const navigate = useNavigate();
  const [onDuty, setOnDuty] = useState(true);
  const [locNote, setLocNote] = useState<string | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem(DUTY_KEY);
    if (stored !== null) setOnDuty(stored === "1");
  }, []);

  // Keep dispatch's live map in sync: online flag + last known position.
  useEffect(() => {
    if (!driver) return;
    let lastWrite = 0;
    const push = async (lat?: number, lng?: number, capturedAt = Date.now()) => {
      const now = Date.now();
      const hasCoordinates = lat != null && lng != null;
      if (hasCoordinates && Math.abs(now - capturedAt) > 30_000) {
        setLocNote("Waiting for a current GPS reading from your phone.");
        return;
      }
      if (lat != null && lng != null) {
        if (now - lastWrite < 10_000) return;
      }
      lastWrite = now;
      const patch: Record<string, unknown> = {
        is_online: onDuty,
      };
      // last_seen_at is the timestamp for the coordinate pair. Never refresh
      // it when GPS failed, or an old point would appear current to passengers.
      if (hasCoordinates) {
        patch['last_lat'] = lat;
        patch['last_lng'] = lng;
        patch['last_seen_at'] = new Date(capturedAt).toISOString();
      }
      const { error } = await supabase
        .from("drivers")
        .update(patch as never)
        .eq("id", driver.id);
      if (error) setLocNote("Couldn't update your status. Check your connection.");
       else if (hasCoordinates) setLocNote(null);
    };
    if (!onDuty) {
      void push();
      setLocNote(null);
      return;
    }
    const report = () => {
      if (!navigator.geolocation) {
        setLocNote("This device can't share location, so dispatch can't see you on the map.");
        void push();
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => void push(pos.coords.latitude, pos.coords.longitude, pos.timestamp),
        (err) => {
          setLocNote(
            err.code === err.PERMISSION_DENIED
              ? "Location is blocked. Allow location for this site so dispatch can see you on the map."
              : "Couldn't get your location yet — dispatch can't see you on the map.",
          );
          void push();
        },
        { enableHighAccuracy: true, maximumAge: 5_000, timeout: 15_000 },
      );
    };
    report();
    const watch = navigator.geolocation
      ? navigator.geolocation.watchPosition(
          (pos) => void push(pos.coords.latitude, pos.coords.longitude, pos.timestamp),
          () => undefined,
          { enableHighAccuracy: true, maximumAge: 5_000, timeout: 15_000 },
        )
      : null;
    const timer = setInterval(() => {
      report();
    }, 15_000);
    const refreshWhenVisible = () => {
      if (document.visibilityState === "visible") report();
    };
    document.addEventListener("visibilitychange", refreshWhenVisible);
    window.addEventListener("focus", report);
    return () => {
      clearInterval(timer);
      if (watch != null) navigator.geolocation.clearWatch(watch);
      document.removeEventListener("visibilitychange", refreshWhenVisible);
      window.removeEventListener("focus", report);
    };
  }, [driver, onDuty]);


  useEffect(() => {
    if (!authLoading && !session) navigate({ to: "/auth" });
  }, [authLoading, session, navigate]);

  const firstName = (driver?.full_name ?? "").split(" ")[0] ?? "";
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  const h = now?.getHours();
  const greeting = h == null ? "Welcome" : h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";
  const stamp = now
    ? `${now.toLocaleDateString(undefined, {
        weekday: "short",
        month: "short",
        day: "numeric",
      })} · ${now.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}`
    : "";

  return (
    <div className="cine flex min-h-screen flex-col text-foreground">
      <header className="sticky top-0 z-40 flex items-center gap-3 border-b border-border bg-nav px-4 py-3">
        <div className="grid size-10 shrink-0 place-items-center rounded-full bg-surface-2 font-cond text-sm uppercase">
          {initials(driver?.full_name)}
        </div>
        <div className="min-w-0 flex-1">
          <div className="truncate font-display text-sm uppercase leading-none tracking-wide">
            {greeting}
            {firstName ? `, ${firstName}` : ""}
          </div>
          <div className="mt-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
            {stamp}
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <span className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
            {onDuty ? "On duty" : "Off duty"}
          </span>
          <button
            role="switch"
            aria-checked={onDuty}
            aria-label="Toggle duty status"
            onClick={() => {
              const next = !onDuty;
              setOnDuty(next);
              localStorage.setItem(DUTY_KEY, next ? "1" : "0");
            }}
            className={`relative h-6 w-11 rounded-full border transition-colors ${
              onDuty ? "border-brand bg-brand/25" : "border-border bg-surface-2"
            }`}
          >
            <span
              className={`absolute top-0.5 size-5 rounded-full transition-all ${
                onDuty ? "left-[22px] bg-brand" : "left-0.5 bg-muted-foreground"
              }`}
            />
          </button>
        </div>
      </header>

      {onDuty && locNote && (
        <div className="mx-auto w-full max-w-[1800px] px-4 pt-3">
          <div className="rounded-md border border-border bg-card px-3 py-2 font-cond text-xs text-muted-foreground">
            {locNote}
          </div>
        </div>
      )}



      <main className="mx-auto w-full max-w-[1800px] flex-1 px-4 pb-24">
        {loading || authLoading ? (
          <div className="py-16 text-center font-cond text-xs uppercase tracking-[0.4em] text-muted-foreground">
            Loading trips
          </div>
        ) : !driver ? (
          <div className="mt-10 rounded-lg border border-border bg-card p-6 text-center">
            <div className="font-display text-2xl uppercase">Not on the roster</div>
            <p className="mt-2 font-cond text-sm text-muted-foreground">
              This account isn't linked to a driver record yet. Ask dispatch to add your email
              address to the driver roster, then sign out and back in.
            </p>
            <Link
              to="/dashboard"
              className="mt-5 inline-block rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest hover:border-brand/60 hover:text-brand"
            >
              Go to dispatch
            </Link>
          </div>
        ) : (
          children
        )}
      </main>
      <MessengerPopup mode="driver" companyId={driver?.company_id} driverId={driver?.id} />

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-nav">
        <div className="mx-auto flex w-full max-w-[1800px] items-center justify-around px-2 py-2">
          <Link
            to="/driver"
            className="grid place-items-center gap-1 px-4 py-1 text-brand"
            aria-label="Trips"
          >
            <LayoutGrid className="size-6" />
            <span className="font-cond text-[9px] uppercase tracking-widest">Trips</span>
          </Link>
          <button
            onClick={() => {
              const el = document.getElementById("driver-search");
              el?.scrollIntoView({ behavior: "smooth", block: "center" });
              (el as HTMLInputElement | null)?.focus();
            }}
            className="grid place-items-center gap-1 px-4 py-1 text-muted-foreground hover:text-brand"
            aria-label="Search trips"
          >
            <Search className="size-6" />
            <span className="font-cond text-[9px] uppercase tracking-widest">Search</span>
          </button>
          <Link
            to="/driver/pay"
            className="grid place-items-center gap-1 px-4 py-1 text-muted-foreground hover:text-brand"
            aria-label="Pay"
          >
            <DollarSign className="size-6" />
            <span className="font-cond text-[9px] uppercase tracking-widest">Pay</span>
          </Link>

          <button
            onClick={async () => {
              await supabase.auth.signOut();
              navigate({ to: "/auth" });
            }}
            className="grid place-items-center gap-1 px-4 py-1 text-muted-foreground hover:text-brand"
            aria-label="Sign out"
          >
            <Grid2x2 className="size-6" />
            <span className="font-cond text-[9px] uppercase tracking-widest">Sign out</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
