import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { sendChauffeurDetails } from "@/lib/chauffeur-details.functions";

/**
 * Shares the assigned chauffeur and vehicle details with the passenger or the
 * booking client: name, phone, vehicle make/model/colour and licence plate.
 */
export function DriverInfoShare({
  driverId,
  vehicleId,
  passenger,
  pickupAt,
  reference,
  reservationId,
  label,
}: {
  driverId?: string | null | undefined;
  vehicleId?: string | null | undefined;
  passenger?: string | null | undefined;
  pickupAt?: string | null | undefined;
  reference?: string | null | undefined;
  reservationId?: string | null | undefined;
  label?: string;
}) {
  const [open, setOpen] = useState(false);
  const [sendTo, setSendTo] = useState("");
  const sendFn = useServerFn(sendChauffeurDetails);
  const sendMutation = useMutation({
    mutationFn: () => sendFn({ data: { reservationId: reservationId!, to: sendTo } }),
    onSuccess: (res) => {
      if (res && "sent" in res && res.sent === false)
        toast.error("That address is unsubscribed from our emails");
      else {
        toast.success(`Chauffeur details sent to ${sendTo}`);
        setSendTo("");
      }
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const { data } = useQuery({
    enabled: !!driverId && open,
    queryKey: ["driver-info-share", driverId, vehicleId],
    queryFn: async () => {
      const d = await supabase
        .from("drivers")
        .select("full_name, phone, default_vehicle_id")
        .eq("id", driverId!)
        .maybeSingle();
      // Rides often have no vehicle of their own — fall back to the chauffeur's default vehicle.
      const useVehicleId = vehicleId ?? d.data?.default_vehicle_id ?? null;
      const v = useVehicleId
        ? await supabase
            .from("vehicles")
            .select("name, make, model, color, plate")
            .eq("id", useVehicleId)
            .maybeSingle()
        : { data: null };
      return { driver: d.data, vehicle: (v as { data: unknown }).data as
        | { name: string | null; make: string | null; model: string | null; color: string | null; plate: string | null }
        | null };
    },
  });


  if (!driverId) return null;

  const buildMessage = () => {
    const d = data?.driver;
    const v = data?.vehicle;
    const vehicleLine =
      [v?.color, v?.make, v?.model].filter(Boolean).join(" ") || v?.name || "";
    return [
      "Blackwave Transportation — your chauffeur details",
      reference ? `Reservation: ${reference}` : "",
      passenger ? `Passenger: ${passenger}` : "",
      pickupAt ? `Pickup: ${new Date(pickupAt).toLocaleString()}` : "",
      d?.full_name ? `Chauffeur: ${d.full_name}` : "",
      d?.phone ? `Phone: ${d.phone}` : "",
      vehicleLine ? `Vehicle: ${vehicleLine}` : "",
      v?.plate ? `Licence plate: ${v.plate}` : "",
    ]
      .filter(Boolean)
      .join("\n");
  };

  const act = async (kind: "copy" | "whatsapp" | "sms" | "email") => {
    // Claim the tab while the click gesture is live so popup blockers allow it.
    const tab = kind === "whatsapp" ? window.open("", "_blank", "noopener") : null;
    try {
      const body = buildMessage();
      if (kind === "copy") {
        await navigator.clipboard.writeText(body);
        toast.success("Chauffeur details copied");
        return;
      }
      if (kind === "whatsapp") {
        const wa = `https://wa.me/?text=${encodeURIComponent(body)}`;
        if (tab && !tab.closed) tab.location.href = wa;
        else if (navigator.share) await navigator.share({ text: body });
        else window.location.href = wa;
        return;
      }
      if (kind === "sms") {
        window.location.href = `sms:?&body=${encodeURIComponent(body)}`;
        return;
      }
      window.location.href = `mailto:?subject=${encodeURIComponent(
        "Your Blackwave chauffeur details",
      )}&body=${encodeURIComponent(body)}`;
    } catch (e) {
      tab?.close();
      toast.error(e instanceof Error ? e.message : "Could not share the details");
    }
  };

  const btn =
    "rounded border border-border px-2 py-1 font-cond text-[10px] uppercase tracking-widest hover:border-brand hover:text-brand disabled:opacity-50";

  return (
    <div className="mt-1">
      <button
        onClick={() => setOpen((v) => !v)}
        className="block font-cond text-[10px] uppercase tracking-widest text-brand hover:underline"
      >
        {label ?? "Share driver info"}
      </button>
      {open && (
        <div className="mt-1 grid gap-1">
          {data && (
            <div className="rounded border border-border bg-muted/40 px-2 py-1.5 text-xs">
              <div className="font-medium">
                {data.driver?.full_name ?? "No chauffeur assigned"}
                {data.driver?.phone ? (
                  <span className="text-muted-foreground"> · {data.driver.phone}</span>
                ) : null}
              </div>
              {data.vehicle && (
                <div className="text-muted-foreground">
                  {[
                    [data.vehicle.color, data.vehicle.make, data.vehicle.model]
                      .filter(Boolean)
                      .join(" ") || data.vehicle.name,
                    data.vehicle.plate ? `Plate ${data.vehicle.plate}` : "",
                  ]
                    .filter(Boolean)
                    .join(" · ")}
                </div>
              )}
            </div>
          )}
          <div className="flex flex-wrap gap-1">
            <button disabled={!data} onClick={() => act("copy")} className={btn}>
              Copy
            </button>
            <button disabled={!data} onClick={() => act("whatsapp")} className={btn}>
              WhatsApp
            </button>
            <button disabled={!data} onClick={() => act("sms")} className={btn}>
              Text
            </button>
            <button disabled={!data} onClick={() => act("email")} className={btn}>
              Email
            </button>
          </div>
          {reservationId && (
            <form
              className="flex flex-wrap items-center gap-1"
              onSubmit={(e) => {
                e.preventDefault();
                sendMutation.mutate();
              }}
            >
              <input
                type="email"
                required
                value={sendTo}
                onChange={(e) => setSendTo(e.target.value)}
                placeholder="Send to email"
                className="w-44 rounded border border-border bg-background px-2 py-1 text-xs"
              />
              <button type="submit" disabled={sendMutation.isPending} className={btn}>
                {sendMutation.isPending ? "Sending…" : "Send"}
              </button>
            </form>
          )}
        </div>
      )}
    </div>
  );
}
