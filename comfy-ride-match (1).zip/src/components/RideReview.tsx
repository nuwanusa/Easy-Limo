import { useState } from "react";
import { toast } from "sonner";
import { useServerFn } from "@tanstack/react-start";
import { submitRideReview, submitMyRideReview, REVIEW_TAGS } from "@/lib/client-portal.functions";

export type ReviewAuth = { token?: string; code?: string };

export function RideReview({
  reservationId,
  reference,
  auth,
}: {
  reservationId: string;
  reference: string;
  auth?: ReviewAuth | undefined;
}) {
  const [open, setOpen] = useState(false);
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [tags, setTags] = useState<string[]>([]);
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  const sendGuest = useServerFn(submitRideReview);
  const sendMine = useServerFn(submitMyRideReview);

  const toggleTag = (t: string) =>
    setTags((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (rating < 1) {
      toast.error("Choose 1 to 5 stars");
      return;
    }
    setBusy(true);
    try {
      const payload = { reservationId, rating, tags, comment };
      if (auth?.token || auth?.code) {
        await sendGuest({ data: { ...payload, ...auth } });
      } else {
        await sendMine({ data: payload });
      }
      setSent(true);
      setOpen(false);
      toast.success("Thank you for your review");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save your review");
    } finally {
      setBusy(false);
    }
  };

  if (sent && !open) {
    return (
      <span className="font-cond text-[11px] uppercase tracking-widest text-emerald-600">
        Review submitted — thank you
      </span>
    );
  }

  return (
    <div className="w-full">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="rounded-md border border-border px-3 py-2 font-cond text-[10px] uppercase tracking-widest text-muted-foreground hover:border-brand hover:text-brand"
      >
        {open ? "Cancel" : "Review this ride"}
      </button>

      {open && (
        <form onSubmit={submit} className="mt-3 space-y-3">
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((n) => (
              <button
                key={n}
                type="button"
                aria-label={`${n} star${n > 1 ? "s" : ""}`}
                onClick={() => setRating(n)}
                onMouseEnter={() => setHover(n)}
                onMouseLeave={() => setHover(0)}
                className={`text-2xl leading-none ${
                  n <= (hover || rating) ? "text-amber-500" : "text-muted-foreground/40"
                }`}
              >
                ★
              </button>
            ))}
            <span className="ml-2 text-sm text-muted-foreground">{rating ? `${rating} / 5` : "Rate this ride"}</span>
          </div>

          <div className="flex flex-wrap gap-2">
            {REVIEW_TAGS.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => toggleTag(t)}
                className={`rounded-full border px-3 py-1 text-xs ${
                  tags.includes(t)
                    ? "border-brand bg-brand text-brand-foreground"
                    : "border-border text-muted-foreground hover:border-brand"
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            rows={3}
            placeholder={`Tell us about ride ${reference}…`}
            className="w-full rounded-md border border-input bg-surface-2 px-3 py-2 text-sm"
          />

          <button
            type="submit"
            disabled={busy}
            className="rounded-md bg-brand px-4 py-2 font-cond text-[10px] uppercase tracking-widest text-brand-foreground disabled:opacity-50"
          >
            {busy ? "Sending…" : "Submit review"}
          </button>
        </form>
      )}
    </div>
  );
}
