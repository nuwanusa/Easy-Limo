import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const SERVICE_LABELS: Record<string, string> = {
  airport: "Airport transfer",
  transfer: "Point to point",
  hourly: "Hourly / as-directed",
  corporate: "Corporate account",
  event: "Wedding or event",
};

const money = (v: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(v);

const when = (iso: string | null) =>
  iso
    ? new Date(iso).toLocaleString("en-US", {
        weekday: "short",
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit",
        timeZone: "America/New_York",
      })
    : undefined;

const day = (d: string | null) =>
  d ? new Date(`${d}T12:00:00Z`).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : undefined;

async function assertStaff(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .in("role", ["admin", "dispatcher"])
    .limit(1);
  if (!data || data.length === 0) throw new Error("Only staff can send quotes");
  return supabaseAdmin;
}

/** Staff: prices a website quote request and emails it to the person who asked. */
export const sendQuoteToClient = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { id: string; amount: number; message?: string | undefined; validUntil?: string | undefined }) => {
    if (!/^[0-9a-fA-F-]{36}$/.test(data?.id ?? "")) throw new Error("Missing request");
    const amount = Number(data.amount);
    if (!Number.isFinite(amount) || amount <= 0) throw new Error("Enter a quote amount");
    return {
      ...data,
      amount,
      message: (data.message ?? "").trim().slice(0, 1500),
      validUntil: data.validUntil?.trim() || undefined,
    };
  })
  .handler(async ({ data, context }) => {
    const supabaseAdmin = await assertStaff((context as any).userId);

    const { data: q, error } = await supabaseAdmin
      .from("quote_requests")
      .select("*")
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw error;
    if (!q) throw new Error("That quote request no longer exists");
    if (!q.email) throw new Error("This request has no email address");

    const stops = Array.isArray(q.stops)
      ? (q.stops as any[]).map((s) => (typeof s === "string" ? s : String(s?.address ?? ""))).filter(Boolean)
      : [];

    const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");
    const result = await sendTemplateEmail("client-quote", q.email as string, {
      idempotencyKey: `quote-${q.id}-${Date.now()}`,
      replyTo: "info@rideblackwave.com",
      templateData: {
        name: q.full_name,
        amount: money(data.amount),
        validUntil: day(data.validUntil ?? null),
        message: data.message || undefined,
        serviceType: SERVICE_LABELS[q.service_type as string] ?? q.service_type,
        pickupAt: when(q.pickup_at as string | null),
        pickupAddress: q.pickup_address ?? undefined,
        stops,
        dropoffAddress: q.dropoff_address ?? undefined,
        passengers: q.passenger_count ? String(q.passenger_count) : undefined,
        luggage: q.luggage_count ? String(q.luggage_count) : undefined,
        vehicle: q.vehicle_class ?? undefined,
        roundTrip: Boolean(q.round_trip),
        notes: q.notes ?? undefined,
      },
    });

    if (!result.sent) {
      return { sent: false as const, reason: "This person has unsubscribed from our emails" };
    }

    const { error: upErr } = await supabaseAdmin
      .from("quote_requests")
      .update({
        quote_amount: data.amount,
        quote_message: data.message || null,
        quote_valid_until: data.validUntil ?? null,
        quote_sent_at: new Date().toISOString(),
        status: "quoted",
      })
      .eq("id", q.id);
    if (upErr) throw upErr;

    return { sent: true as const, to: q.email as string };
  });
