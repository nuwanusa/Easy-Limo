/**
 * Toll estimation for a finished ride.
 *
 * Google Routes returns the toll prices for the driven route (pickup -> stops ->
 * drop-off). We only fill the reservation's toll amount when staff have not
 * entered one, so a manual figure or a toll receipt always wins.
 */

const GATEWAY_URL = "https://connector-gateway.lovable.dev/google_maps";

type Money = { currencyCode?: string; units?: string | number; nanos?: number };

const moneyToNumber = (m: Money) => Number(m.units ?? 0) + Number(m.nanos ?? 0) / 1e9;

/** Asks Google Routes what the tolls cost along this itinerary (USD). */
export async function estimateTolls(
  origin: string,
  destination: string,
  stops: string[] = [],
): Promise<number | null> {
  const lovableKey = process.env["LOVABLE_API_KEY"];
  const mapsKey = process.env["GOOGLE_MAPS_API_KEY"];
  if (!lovableKey || !mapsKey || !origin || !destination) return null;

  const response = await fetch(`${GATEWAY_URL}/routes/directions/v2:computeRoutes`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${lovableKey}`,
      "X-Connection-Api-Key": mapsKey,
      "Content-Type": "application/json",
      "X-Goog-FieldMask": "routes.travelAdvisory.tollInfo,routes.distanceMeters",
    },
    body: JSON.stringify({
      origin: { address: origin },
      destination: { address: destination },
      intermediates: stops.filter(Boolean).slice(0, 8).map((address) => ({ address })),
      travelMode: "DRIVE",
      routingPreference: "TRAFFIC_UNAWARE",
      extraComputations: ["TOLLS"],
      routeModifiers: { avoidTolls: false, vehicleInfo: { emissionType: "GASOLINE" } },
    }),
  }).catch(() => null);

  if (!response || !response.ok) return null;

  const json = (await response.json().catch(() => null)) as {
    routes?: Array<{ travelAdvisory?: { tollInfo?: { estimatedPrice?: Money[] } } }>;
  } | null;

  const prices = json?.routes?.[0]?.travelAdvisory?.tollInfo?.estimatedPrice;
  if (!prices?.length) return 0;

  const usd = prices.find((p) => (p.currencyCode ?? "USD") === "USD") ?? prices[0]!;
  return Math.round(moneyToNumber(usd) * 100) / 100;
}

/**
 * Computes tolls for a completed ride and saves them on the reservation so
 * dispatch sees the amount without asking the chauffeur.
 */
export async function recordRideTolls(reservationId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const { data: r } = await supabaseAdmin
    .from("reservations")
    .select("id, tolls, pickup_address, dropoff_address")
    .eq("id", reservationId)
    .maybeSingle();
  if (!r || Number(r.tolls ?? 0) > 0 || !r.dropoff_address) return null;

  const { data: stops } = await supabaseAdmin
    .from("reservation_stops")
    .select("address, position")
    .eq("reservation_id", r.id)
    .order("position", { ascending: true });

  const amount = await estimateTolls(
    r.pickup_address,
    r.dropoff_address,
    (stops ?? []).map((s) => s.address as string),
  );
  if (amount === null || amount <= 0) return null;

  await supabaseAdmin.from("reservations").update({ tolls: amount }).eq("id", r.id);
  return amount;
}
