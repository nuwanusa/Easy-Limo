import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const DISPATCH_EMAIL = "info@rideblackwave.com";

const money = (v: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(v);

const dayLabel = (d: Date) =>
  d.toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
    timeZone: "America/New_York",
  });

async function notify(
  audience: "client" | "dispatch",
  to: string,
  data: Record<string, unknown>,
  key: string,
) {
  const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");
  return sendTemplateEmail("payment-receipt", to, {
    templateData: { audience, ...data },
    idempotencyKey: key,
  });
}

/**
 * Records a payment taken outside the card checkout (Zelle, Venmo, Cash App,
 * ACH): marks the invoice/ride paid in full and emails the client a receipt.
 */
export const recordManualPayment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { target: "invoice" | "reservation"; id: string; method: string; amount: number }) => {
    if (data.target !== "invoice" && data.target !== "reservation") throw new Error("Invalid target");
    if (!/^[0-9a-fA-F-]{36}$/.test(data.id)) throw new Error("Invalid id");
    if (!data.method || data.method.length > 40) throw new Error("Invalid payment method");
    return data;
  })
  .handler(async ({ data, context }) => {
    const supabase = context.supabase;
    const paidAt = new Date();
    const amount = Number(data.amount) || 0;

    let reference = "";
    let clientName: string | undefined;
    let email: string | undefined;
    let description = "";

    if (data.target === "invoice") {
      const { data: invoice, error } = await supabase
        .from("invoices")
        .select("*")
        .eq("id", data.id)
        .maybeSingle();
      if (error) throw error;
      if (!invoice) throw new Error("Invoice not found");

      await supabase
        .from("invoices")
        .update({
          paid_at: paidAt.toISOString(),
          payments: Number(invoice.payments ?? 0) + amount,
        })
        .eq("id", data.id);

      await supabase
        .from("reservations")
        .update({ invoice_paid_at: paidAt.toISOString() })
        .eq("invoice_id", data.id);

      reference = invoice.invoice_number;
      if (invoice.client_id) {
        const { data: client } = await supabase
          .from("clients")
          .select("name, email, notify_payment")
          .eq("id", invoice.client_id)
          .maybeSingle();
        clientName = client?.name ?? undefined;
        email = client?.email ?? undefined;
        if (client && (client as any).notify_payment === false) email = undefined;
      }
      description = `Invoice ${reference}${clientName ? ` — ${clientName}` : ""}`;
    } else {
      const { data: ride, error } = await supabase
        .from("reservations")
        .select("*")
        .eq("id", data.id)
        .maybeSingle();
      if (error) throw error;
      if (!ride) throw new Error("Reservation not found");

      await supabase
        .from("reservations")
        .update({ invoice_paid_at: paidAt.toISOString() })
        .eq("id", data.id);

      reference = ride.reference;
      clientName = ride.passenger_name ?? undefined;
      email = ride.passenger_email ?? undefined;
      if (ride.client_id) {
        const { data: client } = await supabase
          .from("clients")
          .select("email, notify_payment")
          .eq("id", ride.client_id)
          .maybeSingle();
        if (!email) email = client?.email ?? undefined;
        if (client && (client as any).notify_payment === false) email = undefined;
      }
      description = `Ride ${reference}${clientName ? ` — ${clientName}` : ""}`;
    }

    const { buildPaymentInvoiceDetails } = await import("@/lib/payment-receipt-data");
    const details = await buildPaymentInvoiceDetails(supabase, data.target, data.id, amount);

    const payload = {
      ...(details ?? {}),
      clientName,
      reference,
      description,
      amount: money(amount),
      paidOn: dayLabel(paidAt),
      method: data.method,
    };

    const stamp = Date.now();
    let sent = false;
    let reason: string | undefined;

    if (email) {
      try {
        const res = await notify("client", email, payload, `manual-${data.id}-client-${stamp}`);
        sent = res.sent;
        if (!res.sent) reason = res.reason ?? "send_failed";
      } catch (e) {
        reason = e instanceof Error ? e.message : "send_failed";
      }
    } else {
      reason = "no_client_email";
    }

    try {
      await notify("dispatch", DISPATCH_EMAIL, payload, `manual-${data.id}-dispatch-${stamp}`);
    } catch (e) {
      console.error("dispatch receipt failed", e);
    }

    return { sent, reason, paidAt: paidAt.toISOString() };
  });

/**
 * Manually (re)sends the payment confirmation receipt for an already paid
 * invoice or ride, without changing any payment data.
 */
export const resendPaymentReceipt = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { target: "invoice" | "reservation"; id: string; email?: string; name?: string }) => {
    if (data.target !== "invoice" && data.target !== "reservation") throw new Error("Invalid target");
    if (!/^[0-9a-fA-F-]{36}$/.test(data.id)) throw new Error("Invalid id");
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) throw new Error("Invalid email address");
    if (data.name && data.name.trim().length > 120) throw new Error("Recipient name is too long");
    return data;
  })
  .handler(async ({ data, context }) => {
    const supabase = context.supabase;

    let reference = "";
    let clientName: string | undefined;
    let email: string | undefined = data.email?.trim() || undefined;
    let description = "";
    let paidAt = new Date();
    let amount = 0;

    if (data.target === "invoice") {
      const { data: invoice, error } = await supabase
        .from("invoices")
        .select("*")
        .eq("id", data.id)
        .maybeSingle();
      if (error) throw error;
      if (!invoice) throw new Error("Invoice not found");
      reference = invoice.invoice_number;
      amount = Number(invoice.payments ?? 0) || 0;
      if (invoice.paid_at) paidAt = new Date(invoice.paid_at);
      if (invoice.client_id) {
        const { data: client } = await supabase
          .from("clients")
          .select("name, email")
          .eq("id", invoice.client_id)
          .maybeSingle();
        clientName = client?.name ?? undefined;
        email = email ?? client?.email ?? undefined;
      }
      description = `Invoice ${reference}${clientName ? ` — ${clientName}` : ""}`;
    } else {
      const { data: ride, error } = await supabase
        .from("reservations")
        .select("*")
        .eq("id", data.id)
        .maybeSingle();
      if (error) throw error;
      if (!ride) throw new Error("Reservation not found");
      reference = ride.reference;
      clientName = ride.passenger_name ?? undefined;
      email = email ?? ride.passenger_email ?? undefined;
      if (ride.invoice_paid_at) paidAt = new Date(ride.invoice_paid_at);
      if (!email && ride.client_id) {
        const { data: client } = await supabase
          .from("clients")
          .select("email")
          .eq("id", ride.client_id)
          .maybeSingle();
        email = client?.email ?? undefined;
      }
      description = `Ride ${reference}${clientName ? ` — ${clientName}` : ""}`;
    }

    const { buildPaymentInvoiceDetails } = await import("@/lib/payment-receipt-data");
    const details = await buildPaymentInvoiceDetails(supabase, data.target, data.id, amount);

    if (!email) return { sent: false, reason: "no_client_email" as const };

    const payload = {
      ...(details ?? {}),
      clientName: data.name?.trim() || clientName,
      reference,
      description,
      amount: details?.totalPaid ?? money(amount),
      paidOn: dayLabel(paidAt),
    };

    const stamp = Date.now();
    const res = await notify("client", email, payload, `resend-${data.id}-client-${stamp}`);
    return { sent: res.sent, reason: res.sent ? undefined : res.reason };
  });

const randomToken = () =>
  Array.from(crypto.getRandomValues(new Uint8Array(18)))
    .map((b) => "abcdefghijkmnpqrstuvwxyz23456789"[b % 32])
    .join("");

/** Returns the private public-facing billing statement URL used as a receipt link. */
export const getPaymentReceiptShareLink = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { target: "invoice" | "reservation"; id: string }) => {
    if (data.target !== "invoice" && data.target !== "reservation") throw new Error("Invalid target");
    if (!/^[0-9a-fA-F-]{36}$/.test(data.id)) throw new Error("Invalid id");
    return data;
  })
  .handler(async ({ data, context }) => {
    const supabase = context.supabase;
    const table = data.target === "invoice" ? "invoices" : "reservations";
    const { data: document, error } = await supabase
      .from(table)
      .select("client_id")
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw error;
    if (!document) throw new Error("Billing statement not found");
    if (!document.client_id) return { url: null, reason: "no_client" as const };

    const { data: client, error: clientError } = await supabase
      .from("clients")
      .select("id, portal_token")
      .eq("id", document.client_id)
      .maybeSingle();
    if (clientError) throw clientError;
    if (!client) return { url: null, reason: "no_client" as const };

    let token = client.portal_token ?? "";
    if (!token) {
      token = randomToken();
      const { error: updateError } = await supabase
        .from("clients")
        .update({ portal_token: token })
        .eq("id", client.id);
      if (updateError) throw updateError;
    }

    return { url: `https://rideblackwave.com/i/${token}/${data.id}`, reason: null };
  });
