import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { fareTotal } from "@/lib/dispatch";

export type AffiliatePortalRide = {
  id: string;
  reference: string;
  pickup_at: string;
  pickup_address: string;
  dropoff_address: string;
  dropoff_at: string | null;
  vehicle_class: string;
  booking_type: string;
  hours: number;
  passenger_name: string;
  passenger_phone: string | null;
  passenger_count: number;
  luggage_count: number;
  airport_name: string | null;
  airline: string | null;
  flight_number: string | null;
  notes: string | null;
  status: string;
  affiliate_status: string | null;
  affiliate_payout: number;
  affiliate_driver_name: string | null;
  affiliate_driver_phone: string | null;
  affiliate_vehicle: string | null;
  affiliate_notes: string | null;
};

export type AffiliatePortalData = {
  affiliate: {
    id: string;
    name: string;
    kind: string;
    contact_name: string | null;
    email: string | null;
    phone: string | null;
    default_percent: number;
    referral_percent: number;
  };
  rides: AffiliatePortalRide[];
  statements: {
    id: string;
    statement_number: string;
    period_start: string | null;
    period_end: string | null;
    total: number;
    status: string;
    sent_at: string | null;
    paid_at: string | null;
  }[];
  earnings: {
    id: string;
    kind: string;
    amount: number;
    created_at: string;
    statement_id: string | null;
    reference: string | null;
  }[];
};

const n = (v: unknown) => Number(v ?? 0) || 0;
const code6 = (v: string | undefined) => {
  if (!/^\d{6}$/.test(v ?? "")) throw new Error("Enter the six-digit partner code");
  return v as string;
};

async function affiliateByCode(code: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("affiliates")
    .select("*")
    .eq("portal_code", code)
    .maybeSingle();
  if (!data || data.status !== "active") throw new Error("That partner code is not valid");
  return { supabaseAdmin, affiliate: data as any };
}

/** Partner portal: everything one affiliate company can see with their code. */
export const getAffiliatePortal = createServerFn({ method: "POST" })
  .inputValidator((data: { code: string }) => ({ code: code6(data?.code) }))
  .handler(async ({ data }): Promise<AffiliatePortalData> => {
    const { supabaseAdmin, affiliate } = await affiliateByCode(data.code);

    const [{ data: rides = [] }, { data: statements = [] }, { data: earnings = [] }] = await Promise.all([
      supabaseAdmin
        .from("reservations")
        .select(
          "id, reference, pickup_at, pickup_address, dropoff_address, dropoff_at, vehicle_class, booking_type, hours, passenger_name, passenger_phone, passenger_count, luggage_count, airport_name, airline, flight_number, notes, status, affiliate_status, affiliate_payout, affiliate_driver_name, affiliate_driver_phone, affiliate_vehicle, affiliate_notes",
        )
        .eq("affiliate_id", affiliate.id)
        .order("pickup_at", { ascending: false })
        .limit(200),
      supabaseAdmin
        .from("affiliate_statements")
        .select("id, statement_number, period_start, period_end, total, status, sent_at, paid_at")
        .eq("affiliate_id", affiliate.id)
        .order("created_at", { ascending: false }),
      supabaseAdmin
        .from("affiliate_earnings")
        .select("id, kind, amount, created_at, statement_id, reservation_id")
        .eq("affiliate_id", affiliate.id)
        .order("created_at", { ascending: false })
        .limit(300),
    ]);

    const refById = new Map<string, string>();
    for (const r of (rides ?? []) as any[]) refById.set(r.id, r.reference);

    return {
      affiliate: {
        id: affiliate.id,
        name: affiliate.name,
        kind: affiliate.kind,
        contact_name: affiliate.contact_name,
        email: affiliate.email,
        phone: affiliate.phone,
        default_percent: n(affiliate.default_percent),
        referral_percent: n(affiliate.referral_percent),
      },
      rides: ((rides ?? []) as any[]).map((r) => ({
        ...r,
        hours: n(r.hours),
        affiliate_payout: n(r.affiliate_payout),
      })) as AffiliatePortalRide[],
      statements: ((statements ?? []) as any[]).map((s) => ({ ...s, total: n(s.total) })),
      earnings: ((earnings ?? []) as any[]).map((e) => ({
        id: e.id,
        kind: e.kind,
        amount: n(e.amount),
        created_at: e.created_at,
        statement_id: e.statement_id,
        reference: e.reservation_id ? (refById.get(e.reservation_id) ?? null) : null,
      })),
    };
  });

/** Partner portal: accept or decline a farmed-out ride. */
export const affiliateRespondToRide = createServerFn({ method: "POST" })
  .inputValidator((data: { code: string; reservationId: string; action: "accept" | "decline" }) => {
    if (!/^[0-9a-fA-F-]{36}$/.test(data?.reservationId ?? "")) throw new Error("Missing ride");
    if (data.action !== "accept" && data.action !== "decline") throw new Error("Unknown action");
    return { code: code6(data.code), reservationId: data.reservationId, action: data.action };
  })
  .handler(async ({ data }) => {
    const { supabaseAdmin, affiliate } = await affiliateByCode(data.code);
    const { data: updated, error } = await supabaseAdmin
      .from("reservations")
      .update({ affiliate_status: data.action === "accept" ? "accepted" : "declined" })
      .eq("id", data.reservationId)
      .eq("affiliate_id", affiliate.id)
      .select("id");
    if (error) throw error;
    if (!updated?.length) throw new Error("That ride is not assigned to you");
    return { ok: true as const };
  });

/** Partner portal: submit the chauffeur and vehicle covering a farmed-out ride. */
export const affiliateSubmitDriver = createServerFn({ method: "POST" })
  .inputValidator(
    (data: {
      code: string;
      reservationId: string;
      driverName: string;
      driverPhone: string;
      vehicle: string;
      notes?: string;
    }) => {
      if (!/^[0-9a-fA-F-]{36}$/.test(data?.reservationId ?? "")) throw new Error("Missing ride");
      if (!data.driverName?.trim()) throw new Error("Enter the chauffeur name");
      return { ...data, code: code6(data.code) };
    },
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin, affiliate } = await affiliateByCode(data.code);
    const { data: updated, error } = await supabaseAdmin
      .from("reservations")
      .update({
        affiliate_driver_name: data.driverName.trim(),
        affiliate_driver_phone: data.driverPhone?.trim() || null,
        affiliate_vehicle: data.vehicle?.trim() || null,
        affiliate_notes: data.notes?.trim() || null,
        affiliate_status: "accepted",
      })
      .eq("id", data.reservationId)
      .eq("affiliate_id", affiliate.id)
      .select("id");
    if (error) throw error;
    if (!updated?.length) throw new Error("That ride is not assigned to you");
    return { ok: true as const };
  });

async function assertStaff(context: any) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", context.userId)
    .in("role", ["admin", "dispatcher"])
    .limit(1);
  if (!data?.length) throw new Error("Only staff can manage affiliates");
  return supabaseAdmin;
}

/** Staff: assigns a ride to a partner operator and records what they are owed. */
export const assignRideToAffiliate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (data: { reservationId: string; affiliateId: string | null; payout?: number | undefined; percent?: number | undefined }) => {
      if (!/^[0-9a-fA-F-]{36}$/.test(data?.reservationId ?? "")) throw new Error("Missing ride");
      return data;
    },
  )
  .handler(async ({ data, context }) => {
    const db = await assertStaff(context);

    if (!data.affiliateId) {
      await db
        .from("reservations")
        .update({ affiliate_id: null, affiliate_payout: 0, affiliate_percent: 0, affiliate_status: null })
        .eq("id", data.reservationId);
      await db.from("affiliate_earnings").delete().eq("reservation_id", data.reservationId).eq("kind", "farm_out");
      return { ok: true as const };
    }

    const { data: ride } = await db.from("reservations").select("*").eq("id", data.reservationId).maybeSingle();
    if (!ride) throw new Error("That ride no longer exists");
    const { data: affiliate } = await db
      .from("affiliates")
      .select("*")
      .eq("id", data.affiliateId)
      .maybeSingle();
    if (!affiliate) throw new Error("Partner not found");

    const { count } = await db
      .from("reservation_stops")
      .select("id", { count: "exact", head: true })
      .eq("reservation_id", ride.id);

    const total = fareTotal(ride as any, count ?? 0);
    const percent = data.percent ?? n((affiliate as any).default_percent);
    const payout = data.payout && data.payout > 0 ? data.payout : Math.round(total * percent) / 100;

    const { error } = await db
      .from("reservations")
      .update({
        affiliate_id: affiliate.id,
        affiliate_payout: payout,
        affiliate_percent: percent,
        affiliate_status: (ride as any).affiliate_id === affiliate.id ? (ride as any).affiliate_status : "offered",
      })
      .eq("id", ride.id);
    if (error) throw error;

    await db.from("affiliate_earnings").delete().eq("reservation_id", ride.id).eq("kind", "farm_out");
    await db.from("affiliate_earnings").insert({
      company_id: (ride as any).company_id,
      affiliate_id: affiliate.id,
      reservation_id: ride.id,
      kind: "farm_out",
      amount: payout,
    });

    return { ok: true as const, payout };
  });

/** Staff: creates referral commission records for completed rides of clients a partner referred. */
export const syncReferralCommissions = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { affiliateId: string; from: string; to: string }) => data)
  .handler(async ({ data, context }) => {
    const db = await assertStaff(context);
    const { data: affiliate } = await db.from("affiliates").select("*").eq("id", data.affiliateId).maybeSingle();
    if (!affiliate) throw new Error("Partner not found");

    const { data: clients = [] } = await db
      .from("clients")
      .select("id, referral_percent")
      .eq("referred_by_affiliate_id", affiliate.id);
    if (!clients?.length) return { created: 0 };

    const clientIds = (clients as any[]).map((c) => c.id);
    const { data: rides = [] } = await db
      .from("reservations")
      .select("*")
      .in("client_id", clientIds)
      .eq("status", "completed")
      .gte("pickup_at", new Date(`${data.from}T00:00:00`).toISOString())
      .lte("pickup_at", new Date(`${data.to}T23:59:59`).toISOString());

    let created = 0;
    for (const ride of (rides ?? []) as any[]) {
      const { data: existing } = await db
        .from("affiliate_earnings")
        .select("id")
        .eq("reservation_id", ride.id)
        .eq("kind", "referral")
        .maybeSingle();
      if (existing) continue;
      const client = (clients as any[]).find((c) => c.id === ride.client_id);
      const percent = n(client?.referral_percent) || n((affiliate as any).referral_percent);
      if (!percent) continue;
      const amount = Math.round(fareTotal(ride, 0) * percent) / 100;
      if (amount <= 0) continue;
      await db.from("affiliate_earnings").insert({
        company_id: ride.company_id,
        affiliate_id: affiliate.id,
        reservation_id: ride.id,
        kind: "referral",
        amount,
      });
      created += 1;
    }
    return { created };
  });

/** Staff: rolls every unbilled amount in a period into one statement. */
export const createAffiliateStatement = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { affiliateId: string; from: string; to: string }) => {
    if (!data.from || !data.to) throw new Error("Pick a billing period");
    return data;
  })
  .handler(async ({ data, context }) => {
    const db = await assertStaff(context);
    const { data: affiliate } = await db.from("affiliates").select("*").eq("id", data.affiliateId).maybeSingle();
    if (!affiliate) throw new Error("Partner not found");

    const { data: earnings = [] } = await db
      .from("affiliate_earnings")
      .select("id, amount, created_at, reservation_id")
      .eq("affiliate_id", affiliate.id)
      .is("statement_id", null);

    const rideIds = ((earnings ?? []) as any[]).map((e) => e.reservation_id).filter(Boolean);
    const pickupById = new Map<string, string>();
    if (rideIds.length) {
      const { data: rides = [] } = await db.from("reservations").select("id, pickup_at").in("id", rideIds);
      for (const r of (rides ?? []) as any[]) pickupById.set(r.id, r.pickup_at);
    }

    const fromMs = new Date(`${data.from}T00:00:00`).getTime();
    const toMs = new Date(`${data.to}T23:59:59`).getTime();
    const inPeriod = ((earnings ?? []) as any[]).filter((e) => {
      const when = new Date(pickupById.get(e.reservation_id) ?? e.created_at).getTime();
      return when >= fromMs && when <= toMs;
    });
    if (!inPeriod.length) throw new Error("No unbilled amounts in that period");

    const total = inPeriod.reduce((sum, e) => sum + n(e.amount), 0);
    const number = `AF-${new Date().getFullYear()}${String(Date.now()).slice(-5)}`;

    const { data: statement, error } = await db
      .from("affiliate_statements")
      .insert({
        company_id: (affiliate as any).company_id,
        affiliate_id: affiliate.id,
        statement_number: number,
        period_start: data.from,
        period_end: data.to,
        total,
      })
      .select("*")
      .single();
    if (error) throw error;

    await db
      .from("affiliate_earnings")
      .update({ statement_id: statement.id })
      .in(
        "id",
        inPeriod.map((e) => e.id),
      );

    return { id: statement.id as string, number, total };
  });

/** Staff: emails a statement to the partner. */
export const sendAffiliateStatement = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { statementId: string; email?: string }) => data)
  .handler(async ({ data, context }) => {
    const db = await assertStaff(context);
    const { data: statement } = await db
      .from("affiliate_statements")
      .select("*")
      .eq("id", data.statementId)
      .maybeSingle();
    if (!statement) throw new Error("Statement not found");
    const { data: affiliate } = await db
      .from("affiliates")
      .select("*")
      .eq("id", (statement as any).affiliate_id)
      .maybeSingle();
    const to = data.email?.trim() || (affiliate as any)?.email;
    if (!to) throw new Error("This partner has no email address");

    const { data: earnings = [] } = await db
      .from("affiliate_earnings")
      .select("amount, kind, reservation_id")
      .eq("statement_id", statement.id);

    const rideIds = ((earnings ?? []) as any[]).map((e) => e.reservation_id).filter(Boolean);
    const rideById = new Map<string, any>();
    if (rideIds.length) {
      const { data: rides = [] } = await db
        .from("reservations")
        .select("id, reference, pickup_at, pickup_address, dropoff_address")
        .in("id", rideIds);
      for (const r of (rides ?? []) as any[]) rideById.set(r.id, r);
    }

    const money = (v: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(v);
    const day = (v: string | null) =>
      v ? new Date(v).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric", timeZone: "America/New_York" }) : "";

    const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");
    const result = await sendTemplateEmail("affiliate-statement", to, {
      idempotencyKey: `affiliate-statement-${statement.id}-${Date.now()}`,
      replyTo: "info@rideblackwave.com",
      templateData: {
        partnerName: (affiliate as any)?.name ?? "Partner",
        statementNumber: (statement as any).statement_number,
        period:
          (statement as any).period_start && (statement as any).period_end
            ? `${day((statement as any).period_start)} to ${day((statement as any).period_end)}`
            : "",
        total: money(n((statement as any).total)),
        lines: ((earnings ?? []) as any[]).map((e) => {
          const ride = rideById.get(e.reservation_id);
          return {
            reference: ride?.reference ?? (e.kind === "referral" ? "Referral" : "Adjustment"),
            date: day(ride?.pickup_at ?? null),
            route: ride ? `${ride.pickup_address} → ${ride.dropoff_address}` : "",
            kind: e.kind === "referral" ? "Referral commission" : "Farm-out payout",
            amount: money(n(e.amount)),
          };
        }),
      },
    });

    if (!result.sent) return { sent: false as const, reason: "This address has unsubscribed from our emails" };

    await db
      .from("affiliate_statements")
      .update({ sent_at: new Date().toISOString(), status: "sent" })
      .eq("id", statement.id);

    return { sent: true as const, to };
  });

/** Staff: marks a statement paid. */
export const markAffiliateStatementPaid = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { statementId: string }) => data)
  .handler(async ({ data, context }) => {
    const db = await assertStaff(context);
    const { error } = await db
      .from("affiliate_statements")
      .update({ paid_at: new Date().toISOString(), status: "paid" })
      .eq("id", data.statementId);
    if (error) throw error;
    return { ok: true as const };
  });
