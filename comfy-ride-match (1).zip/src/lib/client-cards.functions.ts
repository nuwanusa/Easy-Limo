import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { type StripeEnv, createStripeClient, getStripeErrorMessage } from "@/lib/stripe.server";

export type SavedCard = {
  id: string;
  brand: string;
  last4: string;
  exp_month: number;
  exp_year: number;
  cardholder_name: string;
  cardholder_email: string | null;
  cardholder_phone: string | null;
  billing_line1: string | null;
  billing_line2: string | null;
  billing_city: string | null;
  billing_state: string | null;
  billing_postal_code: string | null;
  billing_country: string | null;
  created_at: string;
};

export type CardHolder = {
  name: string;
  email?: string | undefined;
  phone?: string | undefined;
  line1?: string | undefined;
  line2?: string | undefined;
  city?: string | undefined;
  state?: string | undefined;
  postal_code?: string | undefined;
  country?: string | undefined;
};

const uuid = /^[0-9a-fA-F-]{36}$/;

const cleanHolder = (h: CardHolder): CardHolder => {
  const name = (h?.name ?? "").trim();
  if (name.length < 2) throw new Error("Enter the name on the card");
  const s = (v?: string) => {
    const t = (v ?? "").trim();
    return t ? t.slice(0, 200) : undefined;
  };
  return {
    name: name.slice(0, 200),
    email: s(h.email),
    phone: s(h.phone),
    line1: s(h.line1),
    line2: s(h.line2),
    city: s(h.city),
    state: s(h.state),
    postal_code: s(h.postal_code),
    country: s(h.country) ?? "US",
  };
};

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

async function assertStaff(context: any) {
  const supabaseAdmin = await admin();
  const { data } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", context.userId)
    .in("role", ["admin", "dispatcher"])
    .limit(1);
  if (!data || data.length === 0) throw new Error("Only staff can manage saved cards");
  return supabaseAdmin;
}

/** Resolves the client behind a portal link, six-digit code, or signed-in client session. */
async function resolveClient(input: { token?: string | undefined; code?: string | undefined }, context?: any) {
  const supabaseAdmin = await admin();
  if (input.token && /^[A-Za-z0-9_-]{10,80}$/.test(input.token)) {
    const { data } = await supabaseAdmin.from("clients").select("id").eq("portal_token", input.token).maybeSingle();
    if (data?.id) return data.id as string;
  }
  if (input.code && /^\d{6}$/.test(input.code)) {
    const { data } = await supabaseAdmin.from("clients").select("id").eq("portal_code", input.code).maybeSingle();
    if (data?.id) return data.id as string;
  }
  if (context?.userId) {
    const { data } = await supabaseAdmin
      .from("client_users")
      .select("client_id")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (data?.client_id) return data.client_id as string;
  }
  throw new Error("Your session expired — reopen your portal link");
}

async function listCards(clientId: string): Promise<SavedCard[]> {
  const supabaseAdmin = await admin();
  const { data = [] } = await supabaseAdmin
    .from("client_cards")
    .select(
      "id, brand, last4, exp_month, exp_year, cardholder_name, cardholder_email, cardholder_phone, billing_line1, billing_line2, billing_city, billing_state, billing_postal_code, billing_country, created_at",
    )
    .eq("client_id", clientId)
    .order("created_at", { ascending: false });
  return (data ?? []) as SavedCard[];
}

/** Opens a secure card form; the card number and security code go straight to the processor. */
async function startSetup(clientId: string, holder: CardHolder, returnUrl: string, environment: StripeEnv) {
  const supabaseAdmin = await admin();
  const { data: existing } = await supabaseAdmin
    .from("client_cards")
    .select("stripe_customer_id")
    .eq("client_id", clientId)
    .limit(1)
    .maybeSingle();

  const stripe = createStripeClient(environment);
  let customerId = (existing?.stripe_customer_id as string | undefined) ?? "";
  const address = {
    line1: holder.line1 ?? null,
    line2: holder.line2 ?? null,
    city: holder.city ?? null,
    state: holder.state ?? null,
    postal_code: holder.postal_code ?? null,
    country: holder.country ?? "US",
  };

  if (!customerId) {
    const created = await stripe.customers.create({
      name: holder.name,
      ...(holder.email ? { email: holder.email } : {}),
      ...(holder.phone ? { phone: holder.phone } : {}),
      address: address as any,
      metadata: { clientId },
    });
    customerId = created.id;
  }

  const session = await stripe.checkout.sessions.create({
    mode: "setup",
    ui_mode: "embedded_page",
    customer: customerId,
    return_url: returnUrl,
    metadata: {
      kind: "client_card",
      clientId,
      holder: JSON.stringify(holder).slice(0, 480),
    },
  });

  return { clientSecret: session.client_secret ?? "" };
}

const validateStart = (data: {
  clientId?: string | undefined;
  token?: string | undefined;
  code?: string | undefined;
  holder: CardHolder;
  returnUrl: string;
  environment: StripeEnv;
}) => {
  if (!data.returnUrl?.startsWith("http")) throw new Error("Invalid return address");
  return { ...data, holder: cleanHolder(data.holder) };
};

/** Staff: save a card on file from a client profile. */
export const startClientCardSetupStaff = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(validateStart)
  .handler(async ({ data, context }) => {
    try {
      await assertStaff(context);
      if (!data.clientId || !uuid.test(data.clientId)) throw new Error("Pick a client first");
      return await startSetup(data.clientId, data.holder, data.returnUrl, data.environment);
    } catch (error) {
      return { error: getStripeErrorMessage(error) };
    }
  });

/** Client portal: save a card on file from a link or six-digit code. */
export const startClientCardSetup = createServerFn({ method: "POST" })
  .inputValidator(validateStart)
  .handler(async ({ data }) => {
    try {
      const clientId = await resolveClient(data);
      return await startSetup(clientId, data.holder, data.returnUrl, data.environment);
    } catch (error) {
      return { error: getStripeErrorMessage(error) };
    }
  });

/** Signed-in client portal: save a card on file. */
export const startMyCardSetup = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(validateStart)
  .handler(async ({ data, context }) => {
    try {
      const clientId = await resolveClient(data, context);
      return await startSetup(clientId, data.holder, data.returnUrl, data.environment);
    } catch (error) {
      return { error: getStripeErrorMessage(error) };
    }
  });

/** Stores the card summary once the secure form finishes. */
export const finishClientCardSetup = createServerFn({ method: "POST" })
  .inputValidator((data: { sessionId: string; environment: StripeEnv }) => {
    if (!/^[a-zA-Z0-9_-]+$/.test(data?.sessionId ?? "")) throw new Error("Invalid session id");
    return data;
  })
  .handler(async ({ data }) => {
    try {
      const stripe = createStripeClient(data.environment);
      const session = await stripe.checkout.sessions.retrieve(data.sessionId, { expand: ["setup_intent"] });
      if (session.metadata?.["kind"] !== "client_card") return { error: "That form was not a card on file" };
      const clientId = session.metadata?.["clientId"] ?? "";
      if (!uuid.test(clientId)) return { error: "Card could not be linked to a client" };

      const setupIntent = session.setup_intent as any;
      const pmId = typeof setupIntent === "string" ? null : (setupIntent?.payment_method ?? null);
      if (!pmId) return { error: "The card was not saved — please try again" };
      const paymentMethodId = typeof pmId === "string" ? pmId : pmId.id;
      const pm = await stripe.paymentMethods.retrieve(paymentMethodId);

      let holder: CardHolder = { name: "" };
      try {
        holder = JSON.parse(session.metadata?.["holder"] ?? "{}");
      } catch {
        holder = { name: pm.billing_details?.name ?? "" };
      }

      const supabaseAdmin = await admin();
      const { error } = await supabaseAdmin.from("client_cards").upsert(
        {
          client_id: clientId,
          stripe_customer_id: typeof session.customer === "string" ? session.customer : (session.customer as any)?.id,
          stripe_payment_method_id: paymentMethodId,
          brand: pm.card?.brand ?? "card",
          last4: pm.card?.last4 ?? "",
          exp_month: pm.card?.exp_month ?? 0,
          exp_year: pm.card?.exp_year ?? 0,
          cardholder_name: holder.name || (pm.billing_details?.name ?? ""),
          cardholder_email: holder.email ?? null,
          cardholder_phone: holder.phone ?? null,
          billing_line1: holder.line1 ?? null,
          billing_line2: holder.line2 ?? null,
          billing_city: holder.city ?? null,
          billing_state: holder.state ?? null,
          billing_postal_code: holder.postal_code ?? null,
          billing_country: holder.country ?? "US",
        },
        { onConflict: "client_id,stripe_payment_method_id" },
      );
      if (error) throw error;
      return { ok: true, brand: pm.card?.brand ?? "card", last4: pm.card?.last4 ?? "" };
    } catch (error) {
      return { error: getStripeErrorMessage(error) };
    }
  });

/** Staff: cards saved for a client. */
export const listClientCardsStaff = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { clientId: string }) => data)
  .handler(async ({ data, context }): Promise<SavedCard[]> => {
    await assertStaff(context);
    if (!uuid.test(data.clientId)) return [];
    return listCards(data.clientId);
  });

/** Client portal: cards saved on the account, from a link or code. */
export const listClientCards = createServerFn({ method: "POST" })
  .inputValidator((data: { token?: string | undefined; code?: string | undefined }) => data)
  .handler(async ({ data }): Promise<SavedCard[]> => {
    const clientId = await resolveClient(data);
    return listCards(clientId);
  });

/** Signed-in client portal: cards saved on the account. */
export const listMyCards = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { token?: string | undefined; code?: string | undefined }) => data)
  .handler(async ({ data, context }): Promise<SavedCard[]> => {
    const clientId = await resolveClient(data, context);
    return listCards(clientId);
  });

async function detach(clientId: string, cardId: string, environment: StripeEnv) {
  const supabaseAdmin = await admin();
  const { data: row } = await supabaseAdmin
    .from("client_cards")
    .select("id, client_id, stripe_payment_method_id")
    .eq("id", cardId)
    .maybeSingle();
  if (!row || row.client_id !== clientId) throw new Error("That card is not on your account");
  try {
    const stripe = createStripeClient(environment);
    await stripe.paymentMethods.detach(row.stripe_payment_method_id as string);
  } catch {
    // already detached at the processor — still remove our copy
  }
  await supabaseAdmin.from("client_cards").delete().eq("id", cardId);
  return { ok: true };
}

/** Staff: remove a saved card. */
export const removeClientCardStaff = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { clientId: string; cardId: string; environment: StripeEnv }) => data)
  .handler(async ({ data, context }) => {
    await assertStaff(context);
    return detach(data.clientId, data.cardId, data.environment);
  });

/** Client portal: remove a saved card from a link or code. */
export const removeClientCard = createServerFn({ method: "POST" })
  .inputValidator(
    (data: { cardId: string; environment: StripeEnv; token?: string | undefined; code?: string | undefined }) => data,
  )
  .handler(async ({ data }) => {
    const clientId = await resolveClient(data);
    return detach(clientId, data.cardId, data.environment);
  });

/** Signed-in client portal: remove a saved card. */
export const removeMyCard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (data: { cardId: string; environment: StripeEnv; token?: string | undefined; code?: string | undefined }) => data,
  )
  .handler(async ({ data, context }) => {
    const clientId = await resolveClient(data, context);
    return detach(clientId, data.cardId, data.environment);
  });
