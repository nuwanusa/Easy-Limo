import { createServerFn } from "@tanstack/react-start";
import { type StripeEnv, createStripeClient, getStripeErrorMessage } from "@/lib/stripe.server";

export type PaymentTarget = "invoice" | "reservation";

/** Card payments carry a 3% processing fee. */
export const CARD_FEE_RATE = 0.03;
export const cardFee = (amount: number) => Math.round(amount * CARD_FEE_RATE * 100) / 100;

type CheckoutResult = { clientSecret: string } | { error: string };

const num = (v: unknown) => Number(v ?? 0) || 0;

const billableHours = (r: any) => Math.max(num(r.hours), num(r.minimum_hours));
const flatRate = (r: any) => (r.booking_type === "hourly" ? 0 : num(r.base_fare));
const hourlyCharge = (r: any) => (r.booking_type === "hourly" ? num(r.hourly_rate) * billableHours(r) : 0);
const waitingCharge = (r: any) => (num(r.waiting_minutes) / 60) * num(r.waiting_rate);

const rideTotal = (r: any, stopCount: number) =>
  num(r.base_rate) +
  flatRate(r) +
  hourlyCharge(r) +
  waitingCharge(r) +
  num(r.airport_fee) +
  num(r.meet_greet_fee) +
  num(r.parking_fee) +
  num(r.tolls) +
  num(r.gratuity) +
  num(r.stop_fee) * stopCount;

async function stopCount(supabase: any, reservationIds: string[]) {
  const counts = new Map<string, number>();
  if (!reservationIds.length) return counts;
  const { data } = await supabase
    .from("reservation_stops")
    .select("reservation_id")
    .in("reservation_id", reservationIds);
  for (const row of data ?? []) {
    counts.set(row.reservation_id, (counts.get(row.reservation_id) ?? 0) + 1);
  }
  return counts;
}

/**
 * Amounts are always recomputed on the server from stored rides — the browser
 * never gets to name a price.
 */
async function resolveAmount(target: PaymentTarget, id: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  if (target === "invoice") {
    const { data: invoice } = await supabaseAdmin.from("invoices").select("*").eq("id", id).maybeSingle();
    if (!invoice) throw new Error("Invoice not found");
    if (invoice.paid_at) throw new Error("This invoice is already paid");

    const { data: rides = [] } = await supabaseAdmin
      .from("reservations")
      .select("*")
      .eq("invoice_id", id);
    const counts = await stopCount(supabaseAdmin, (rides ?? []).map((r: any) => r.id));
    const subtotal = (rides ?? []).reduce((s: number, r: any) => s + rideTotal(r, counts.get(r.id) ?? 0), 0);
    const due = subtotal - num(invoice.discount) - num(invoice.payments);

    let email: string | undefined = (rides ?? [])
      .map((ride: any) => typeof ride.billing_contact_email === "string" ? ride.billing_contact_email.trim() : "")
      .find(Boolean) || undefined;
    let name = "Client";
    if (invoice.client_id) {
      const { data: client } = await supabaseAdmin
        .from("clients")
        .select("name, email, billing_contact_email")
        .eq("id", invoice.client_id)
        .maybeSingle();
      email = email ?? client?.billing_contact_email ?? client?.email ?? undefined;
      name = client?.name ?? name;
    }

    return {
      amount: due,
      subtotal,
      discount: num(invoice.discount),
      credited: num(invoice.payments),
      label: `Invoice ${invoice.invoice_number} — ${name}`,
      email,
    };

  }

  const { data: ride } = await supabaseAdmin.from("reservations").select("*").eq("id", id).maybeSingle();
  if (!ride) throw new Error("Reservation not found");
  if (ride.invoice_paid_at) throw new Error("This ride is already paid");

  const counts = await stopCount(supabaseAdmin, [ride.id]);
  let email: string | undefined = ride.billing_contact_email ?? ride.passenger_email ?? undefined;
  if (!email && ride.client_id) {
    const { data: client } = await supabaseAdmin
      .from("clients")
      .select("email, billing_contact_email")
      .eq("id", ride.client_id)
      .maybeSingle();
    email = client?.billing_contact_email ?? client?.email ?? undefined;
  }

  const rideAmount = rideTotal(ride, counts.get(ride.id) ?? 0);
  return {
    amount: rideAmount,
    subtotal: rideAmount,
    discount: 0,
    credited: 0,
    label: `Ride ${ride.reference} — ${ride.passenger_name ?? "Passenger"}`,
    email,
  };

}

export const createPaymentCheckout = createServerFn({ method: "POST" })
  .inputValidator(
    (data: {
      target: PaymentTarget;
      id: string;
      returnUrl: string;
      environment: StripeEnv;
      amount?: number | undefined;
      tip?: number | undefined;
    }) => {
      if (data.target !== "invoice" && data.target !== "reservation") throw new Error("Invalid target");
      if (!/^[0-9a-fA-F-]{36}$/.test(data.id)) throw new Error("Invalid id");
      if (data.amount != null && (!Number.isFinite(data.amount) || data.amount <= 0)) {
        throw new Error("Enter a valid amount");
      }
      if (data.tip != null && (!Number.isFinite(data.tip) || data.tip < 0)) {
        throw new Error("Enter a valid gratuity");
      }
      return data;
    },
  )
  .handler(async ({ data }): Promise<CheckoutResult> => {
    try {
      const { amount: due, label: baseLabel, email } = await resolveAmount(data.target, data.id);
      const dueCents = Math.round(due * 100);
      if (dueCents < 50) return { error: "Nothing left to pay on this " + data.target };

      // A partial amount is only honoured for invoices, and never above the balance.
      const requestedCents =
        data.target === "invoice" && data.amount != null ? Math.round(data.amount * 100) : dueCents;
      const amountInCents = Math.min(Math.max(requestedCents, 0), dueCents);
      if (amountInCents < 50) return { error: "The minimum payment is $0.50" };

      const partial = amountInCents < dueCents;
      const label = partial ? `${baseLabel} (part payment)` : baseLabel;

      // Card payments carry a 3% processing fee on top of the balance.
      // The fee is charged on the balance only, never on a gratuity.
      const feeCents = Math.round(amountInCents * CARD_FEE_RATE);
      const tipCents = data.tip != null ? Math.max(Math.round(data.tip * 100), 0) : 0;


      const stripe = createStripeClient(data.environment);
      const session = await stripe.checkout.sessions.create({
        line_items: [
          {
            price_data: {
              currency: "usd",
              product_data: { name: label },
              unit_amount: amountInCents,
            },
            quantity: 1,
          },
          ...(feeCents > 0
            ? [
                {
                  price_data: {
                    currency: "usd" as const,
                    product_data: { name: "Credit card processing fee (3%)" },
                    unit_amount: feeCents,
                  },
                  quantity: 1,
                },
              ]
            : []),
          ...(tipCents > 0
            ? [
                {
                  price_data: {
                    currency: "usd" as const,
                    product_data: { name: "Gratuity" },
                    unit_amount: tipCents,
                  },
                  quantity: 1,
                },
              ]
            : []),
        ],
        mode: "payment",
        ui_mode: "embedded_page",
        return_url: data.returnUrl,
        payment_intent_data: { description: label },
        ...(email && { customer_email: email }),
        metadata: {
          target: data.target,
          targetId: data.id,
          dueCents: String(dueCents),
          paidCents: String(amountInCents),
          feeCents: String(feeCents),
          tipCents: String(tipCents),
        },
      });

      return { clientSecret: session.client_secret ?? "" };
    } catch (error) {
      return { error: getStripeErrorMessage(error) };
    }
  });

/** Current balance for an invoice or ride, so the client can pay part of it. */
export const getAmountDue = createServerFn({ method: "POST" })
  .inputValidator((data: { target: PaymentTarget; id: string }) => {
    if (data.target !== "invoice" && data.target !== "reservation") throw new Error("Invalid target");
    if (!/^[0-9a-fA-F-]{36}$/.test(data.id)) throw new Error("Invalid id");
    return data;
  })
  .handler(async ({ data }) => {
    try {
      const { amount } = await resolveAmount(data.target, data.id);
      return { due: Math.max(amount, 0) };
    } catch (error) {
      return { error: error instanceof Error ? error.message : "Could not read the balance" };
    }
  });

type PaySummary =
  | {
      number: string;
      name: string;
      amount: number;
      paid: boolean;
      subtotal: number;
      discount: number;
      credited: number;
      details?: PayDetails;
    }
  | { error: string };

type PayRide = {
  reference: string;
  pickupAt: string | null;
  dropoffAt: string | null;
  pickup: string | null;
  dropoff: string | null;
  items: Array<{ label: string; value: string }>;
};
type PayDetails = {
  company: string | null;
  address: string | null;
  billingContact: string | null;
  billingEmail: string | null;
  billingPhone: string | null;
  rides: PayRide[];
};

const RIDE_COLS =
  "reference, pickup_at, dropoff_at, pickup_address, dropoff_address, booking_type, base_rate, base_fare, hourly_rate, hours, minimum_hours, airport_fee, tolls, parking_fee, meet_greet_fee, stop_fee, waiting_minutes, waiting_rate, car_seat_count, car_seat_fee, gratuity, billing_contact_name, billing_contact_email, billing_contact_phone, client_id";

const money = (n: number) => `$${n.toFixed(2)}`;
function rideItems(r: any) {
  const n = (k: string) => Number(r[k] ?? 0) || 0;
  const items: Array<{ label: string; value: string }> = [];
  const hourly = r.booking_type === "hourly";
  if (n("base_rate") > 0) items.push({ label: "Base rate", value: money(n("base_rate")) });
  if (!hourly && n("base_fare") > 0) items.push({ label: "Flat rate", value: money(n("base_fare")) });
  if (hourly && n("hourly_rate") > 0) items.push({ label: "Hourly rate", value: `${money(n("hourly_rate"))}/hr` });
  if (hourly && n("hours") > 0) {
    const billed = Math.max(n("hours"), n("minimum_hours"));
    items.push({ label: "Total hours", value: `${billed} hr` });
  }
  const extra: Array<[string, number]> = [
    ["Stops", n("stop_fee")],
    ["Waiting time", n("waiting_minutes") > 0 ? (n("waiting_minutes") / 60) * n("waiting_rate") : 0],
    ["Airport fee", n("airport_fee")],
    ["Meet & greet", n("meet_greet_fee")],
    ["Parking", n("parking_fee")],
    ["Tolls", n("tolls")],
    ["Car seats", n("car_seat_count") * n("car_seat_fee")],
    ["Gratuity", n("gratuity")],
  ];
  for (const [label, v] of extra) if (v > 0) items.push({ label, value: money(v) });
  return items;
}

async function loadPayDetails(admin: any, clientId: string | null, rides: any[]): Promise<PayDetails> {
  let client: any = null;
  const cid = clientId ?? rides[0]?.client_id ?? null;
  if (cid) {
    const { data } = await admin
      .from("clients")
      .select("name, address_line1, address_line2, contact_name, billing_contact_email, billing_contact_phone, email, phone")
      .eq("id", cid)
      .maybeSingle();
    client = data;
  }
  const first: any = rides[0] ?? {};
  const address = [client?.address_line1, client?.address_line2].filter(Boolean).join(", ") || null;
  return {
    company: client?.name ?? null,
    address,
    billingContact: first.billing_contact_name || client?.contact_name || null,
    billingEmail: first.billing_contact_email || client?.billing_contact_email || null,
    billingPhone: first.billing_contact_phone || client?.billing_contact_phone || null,
    rides: rides.map((r) => ({
      reference: r.reference,
      pickupAt: r.pickup_at ?? null,
      dropoffAt: r.dropoff_at ?? null,
      pickup: r.pickup_address ?? null,
      dropoff: r.dropoff_address ?? null,
      items: rideItems(r),
    })),
  };
}


/** Public summary used by the card payment page: number, who it is for, and the balance. */
export const getPaySummary = createServerFn({ method: "POST" })
  .inputValidator((data: { target: PaymentTarget; id: string }) => {
    if (data.target !== "invoice" && data.target !== "reservation") throw new Error("Invalid target");
    if (!/^[0-9a-fA-F-]{36}$/.test(data.id)) throw new Error("Invalid id");
    return data;
  })
  .handler(async ({ data }): Promise<PaySummary> => {
    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

      if (data.target === "invoice") {
        const { data: invoice } = await supabaseAdmin
          .from("invoices")
          .select("id, invoice_number, paid_at, client_id")
          .eq("id", data.id)
          .maybeSingle();
        if (!invoice) return { error: "This invoice could not be found" };

        let name = "";
        if (invoice.client_id) {
          const { data: client } = await supabaseAdmin
            .from("clients")
            .select("name")
            .eq("id", invoice.client_id)
            .maybeSingle();
          name = client?.name ?? "";
        }
        const number = invoice.invoice_number ?? "Invoice";
        if (invoice.paid_at)
          return { number, name, amount: 0, paid: true, subtotal: 0, discount: 0, credited: 0 };

        const { amount, subtotal, discount, credited } = await resolveAmount("invoice", data.id);
        const { data: rides } = await supabaseAdmin
          .from("reservations")
          .select(RIDE_COLS)
          .eq("invoice_id", data.id)
          .order("pickup_at", { ascending: true });
        const details = await loadPayDetails(supabaseAdmin, invoice.client_id, (rides ?? []) as any[]);
        return { number, name, amount: Math.max(amount, 0), paid: false, subtotal, discount, credited, details };

      }

      const { data: ride } = await supabaseAdmin
        .from("reservations")
        .select("id, reference, invoice_number, invoice_paid_at, passenger_name")
        .eq("id", data.id)
        .maybeSingle();
      if (!ride) return { error: "This ride could not be found" };

      const number = ride.invoice_number ?? `INV-${ride.reference}`;
      const name = ride.passenger_name ?? "";
      if (ride.invoice_paid_at)
        return { number, name, amount: 0, paid: true, subtotal: 0, discount: 0, credited: 0 };

      const { amount, subtotal, discount, credited } = await resolveAmount("reservation", data.id);
      const { data: full } = await supabaseAdmin.from("reservations").select(RIDE_COLS).eq("id", data.id).maybeSingle();
      const details = await loadPayDetails(supabaseAdmin, null, full ? [full as any] : []);
      return { number, name, amount: Math.max(amount, 0), paid: false, subtotal, discount, credited, details };

    } catch (error) {
      return { error: error instanceof Error ? error.message : "Could not read this balance" };
    }
  });


/** Read a finished checkout session so the return page can confirm the result. */
export const getCheckoutResult = createServerFn({ method: "POST" })
  .inputValidator((data: { sessionId: string; environment: StripeEnv }) => {
    if (!/^[a-zA-Z0-9_-]+$/.test(data.sessionId)) throw new Error("Invalid session id");
    return data;
  })
  .handler(async ({ data }) => {
    try {
      const stripe = createStripeClient(data.environment);
      const session = await stripe.checkout.sessions.retrieve(data.sessionId);
      return {
        status: session.status ?? null,
        paymentStatus: session.payment_status ?? null,
        amountTotal: (session.amount_total ?? 0) / 100,
        target: (session.metadata?.["target"] ?? null) as PaymentTarget | null,
        targetId: session.metadata?.["targetId"] ?? null,
      };
    } catch (error) {
      return { error: getStripeErrorMessage(error) };
    }
  });

// ---- Short payment links (rideblackwave.com/pay/<code>) ----

/** Creates (once) and returns the short path for a card payment page. Public: the payment page itself is public. */
export const getShortPayPath = createServerFn({ method: "POST" })
  .inputValidator((data: { target: PaymentTarget; id: string }) => data)
  .handler(async ({ data }) => {
    if (data.target !== "invoice" && data.target !== "reservation") {
      return { error: "Invalid payment target" } as const;
    }
    if (!/^[0-9a-fA-F-]{10,}$/.test(data.id)) {
      return { error: "Invalid payment reference" } as const;
    }
    try {
      const { ensurePaymentLinkCode } = await import("@/lib/payment-links.server");
      const code = await ensurePaymentLinkCode(data.target, data.id);
      return { path: `/p/${code}` } as const;
    } catch {
      return { error: "Could not create a short payment link" } as const;
    }
  });

/** Resolves a short /pay/<code> link back to its payment target. */
export const resolveShortPayCode = createServerFn({ method: "GET" })
  .inputValidator((data: { code: string }) => data)
  .handler(async ({ data }) => {
    const { resolvePaymentLinkCode } = await import("@/lib/payment-links.server");
    return resolvePaymentLinkCode(data.code);
  });
