import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const GATEWAY_URL = "https://connector-gateway.lovable.dev/google_maps";

const input = z.object({
  query: z.string().min(2).max(200),
});

export type PlaceSuggestion = { text: string; placeId: string };

/** Address suggestions served through the server-side Google Maps key. */
export const getAddressSuggestions = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => input.parse(data))
  .handler(async ({ data }): Promise<PlaceSuggestion[]> => {
    const lovableKey = process.env["LOVABLE_API_KEY"];
    const mapsKey = process.env["GOOGLE_MAPS_API_KEY"];
    if (!lovableKey || !mapsKey) throw new Error("Maps service is not configured.");

    const headers = {
      Authorization: `Bearer ${lovableKey}`,
      "X-Connection-Api-Key": mapsKey,
      "Content-Type": "application/json",
    };

    // Places API (New) autocomplete
    const res = await fetch(`${GATEWAY_URL}/places/v1/places:autocomplete`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        input: data.query,
        includedRegionCodes: ["us"],
      }),
    });

    if (res.ok) {
      const json = (await res.json()) as {
        suggestions?: Array<{
          placePrediction?: { placeId?: string; text?: { text?: string } };
        }>;
      };
      const out = (json.suggestions ?? [])
        .map((s) => ({
          text: s.placePrediction?.text?.text ?? "",
          placeId: s.placePrediction?.placeId ?? "",
        }))
        .filter((s) => s.text);
      if (out.length > 0) return out;
      return [];
    }

    // Fallback: legacy Places autocomplete
    const legacy = await fetch(
      `${GATEWAY_URL}/maps/api/place/autocomplete/json?input=${encodeURIComponent(
        data.query,
      )}&components=country:us`,
      { headers },
    );
    if (!legacy.ok) {
      const body = await legacy.text();
      throw new Error(`Address lookup failed [${legacy.status}]: ${body.slice(0, 300)}`);
    }
    const legacyJson = (await legacy.json()) as {
      status?: string;
      predictions?: Array<{ description?: string; place_id?: string }>;
    };
    if (legacyJson.status && legacyJson.status !== "OK" && legacyJson.status !== "ZERO_RESULTS") {
      throw new Error(`Address lookup failed: ${legacyJson.status}`);
    }
    return (legacyJson.predictions ?? [])
      .map((p) => ({ text: p.description ?? "", placeId: p.place_id ?? "" }))
      .filter((p) => p.text);
  });
