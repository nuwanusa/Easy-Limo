import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/** True when the signed-in account belongs to a client company (portal user). */
export function useClientAccount() {
  return useQuery({
    queryKey: ["my-client-account"],
    queryFn: async () => {
      const { data: sessionData } = await supabase.auth.getSession();
      const userId = sessionData.session?.user?.id;
      if (!userId) return null;
      const { data } = await supabase
        .from("client_users")
        .select("client_id")
        .eq("user_id", userId)
        .maybeSingle();
      return data ?? null;
    },
    staleTime: 60_000,
  });
}
