import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type Input = { reservationId: string; to: string };

/** Emails the assigned chauffeur and vehicle details for one ride to any address. */
export const sendChauffeurDetails = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: Input) => {
    const reservationId = input.reservationId?.trim();
    const to = input.to?.trim().toLowerCase();
    if (!reservationId) throw new Error("Reservation is required");
    if (!to || !to.includes("@")) throw new Error("Enter a valid email address");
    return { reservationId, to };
  })
  .handler(async ({ data, context }) => {
    const { data: ride, error } = await context.supabase
      .from("reservations")
      .select(
        "id, reference, passenger_name, pickup_at, pickup_address, driver_id, vehicle_id, drivers(full_name, phone), vehicles(name, make, model, color, plate)",
      )
      .eq("id", data.reservationId)
      .maybeSingle();
    if (error) throw error;
    if (!ride) throw new Error("Reservation not found");

    const driver = (ride as { drivers: { full_name: string; phone: string | null } | null })
      .drivers;
    if (!driver) throw new Error("No chauffeur is assigned to this ride yet");
    type Veh = {
      name: string | null;
      make: string | null;
      model: string | null;
      color: string | null;
      plate: string | null;
    };
    let vehicle = (ride as { vehicles: Veh | null }).vehicles;
    if (!vehicle) {
      // Rides often have no vehicle of their own — use the chauffeur's default vehicle.
      const { data: drv } = await context.supabase
        .from("drivers")
        .select("default_vehicle_id")
        .eq("id", (ride as { driver_id: string }).driver_id)
        .maybeSingle();
      if (drv?.default_vehicle_id) {
        const { data: v } = await context.supabase
          .from("vehicles")
          .select("name, make, model, color, plate")
          .eq("id", drv.default_vehicle_id)
          .maybeSingle();
        vehicle = (v as Veh | null) ?? null;
      }
    }

    const vehicleLine =
      [vehicle?.color, vehicle?.make, vehicle?.model].filter(Boolean).join(" ") ||
      vehicle?.name ||
      "";


    const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");
    const result = await sendTemplateEmail("chauffeur-details", data.to, {
      idempotencyKey: `chauffeur-details-${ride.id}-${data.to}-${Date.now()}`,
      templateData: {
        reference: ride.reference ?? "",
        passengerName: ride.passenger_name ?? "",
        pickupAt: ride.pickup_at
          ? new Date(ride.pickup_at).toLocaleString("en-US", {
              weekday: "long",
              month: "long",
              day: "numeric",
              year: "numeric",
              hour: "numeric",
              minute: "2-digit",
              hour12: true,
            })
          : "",
        pickupAddress: ride.pickup_address ?? "",
        driverName: driver.full_name ?? "",
        driverPhone: driver.phone ?? "",
        vehicle: vehicleLine,
        vehiclePlate: vehicle?.plate ?? "",
      },
    });

    return result;
  });
