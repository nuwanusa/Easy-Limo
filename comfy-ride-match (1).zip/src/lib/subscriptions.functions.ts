import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type PlanRow = {
  code: string;
  name: string;
  priceCents: number;
  features: string[];
  sort: number;
};

export type CompanyBilling = {
  companyId: string;
  companyName: string;
  plan: PlanRow | null;
  status: string;
  trialEndsAt: string | null;
  wakeUpEnabled: boolean;
  wakeUpMonthlyCents: number;
  wakeUpPerCallCents: number;
  monthCalls: number;
  monthCallCents: number;
  monthTotalCents: number;
  recent: {
    id: string;
    reference: string;
    driver: string;
    status: string;
    attempts: number;
    createdAt: string;
    chargeCents: number;
  }[];
};

async function adminClient() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

async function myCompanyId(supabaseAdmin: any, userId: string) {
  const { data } = await supabaseAdmin
    .from("company_users")
    .select("company_id")
    .eq("user_id", userId)
    .maybeSingle();
  return (data?.company_id as string | undefined) ?? null;
}

async function isPlatformOwner(supabaseAdmin: any, userId: string) {
  const { data } = await supabaseAdmin
    .from("platform_owners")
    .select("user_id")
    .eq("user_id", userId)
    .maybeSingle();
  return Boolean(data);
}

function toPlan(row: any): PlanRow {
  return {
    code: row.code as string,
    name: row.name as string,
    priceCents: Number(row.price_cents ?? 0),
    features: Array.isArray(row.features) ? (row.features as string[]) : [],
    sort: Number(row.sort ?? 0),
  };
}

export const listPlans = createServerFn({ method: "GET" }).handler(async () => {
  const supabaseAdmin = await adminClient();
  const { data } = await supabaseAdmin
    .from("subscription_plans")
    .select("*")
    .order("sort", { ascending: true });
  return (data ?? []).map(toPlan);
});

/** Billing summary for the signed-in staff member's own company. */
export const getCompanyBilling = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<CompanyBilling | null> => {
    const supabaseAdmin = await adminClient();
    const companyId = await myCompanyId(supabaseAdmin, context.userId);
    if (!companyId) return null;

    const { data: company } = await supabaseAdmin
      .from("companies")
      .select("name")
      .eq("id", companyId)
      .maybeSingle();

    const { data: sub } = await supabaseAdmin
      .from("company_subscriptions")
      .select("*")
      .eq("company_id", companyId)
      .maybeSingle();

    let plan: PlanRow | null = null;
    if (sub?.plan_code) {
      const { data: planRow } = await supabaseAdmin
        .from("subscription_plans")
        .select("*")
        .eq("code", sub.plan_code)
        .maybeSingle();
      if (planRow) plan = toPlan(planRow);
    }

    const start = new Date();
    start.setUTCDate(1);
    start.setUTCHours(0, 0, 0, 0);

    const { data: calls } = await supabaseAdmin
      .from("wake_up_calls")
      .select("id, reservation_id, driver_id, status, attempts, charge_cents, created_at")
      .eq("company_id", companyId)
      .gte("created_at", start.toISOString())
      .order("created_at", { ascending: false })
      .limit(50);

    const rows = calls ?? [];
    const monthCallCents = rows.reduce((sum, r) => sum + Number(r.charge_cents ?? 0), 0);

    const rideIds = rows.slice(0, 10).map((r) => r.reservation_id);
    const driverIds = rows.slice(0, 10).map((r) => r.driver_id).filter(Boolean) as string[];
    const { data: rides } = rideIds.length
      ? await supabaseAdmin.from("reservations").select("id, reference").in("id", rideIds)
      : { data: [] as any[] };
    const { data: drivers } = driverIds.length
      ? await supabaseAdmin.from("drivers").select("id, full_name").in("id", driverIds)
      : { data: [] as any[] };
    const refById = new Map((rides ?? []).map((r: any) => [r.id, r.reference]));
    const nameById = new Map((drivers ?? []).map((d: any) => [d.id, d.full_name]));

    const monthlyCents =
      (plan?.priceCents ?? 0) + (sub?.wake_up_calls_enabled ? Number(sub.wake_up_monthly_cents ?? 0) : 0);

    return {
      companyId,
      companyName: (company?.name as string) ?? "",
      plan,
      status: (sub?.status as string) ?? "none",
      trialEndsAt: (sub?.trial_ends_at as string | null) ?? null,
      wakeUpEnabled: Boolean(sub?.wake_up_calls_enabled),
      wakeUpMonthlyCents: Number(sub?.wake_up_monthly_cents ?? 0),
      wakeUpPerCallCents: Number(sub?.wake_up_per_call_cents ?? 0),
      monthCalls: rows.length,
      monthCallCents,
      monthTotalCents: monthlyCents + monthCallCents,
      recent: rows.slice(0, 10).map((r) => ({
        id: r.id as string,
        reference: refById.get(r.reservation_id) ?? "",
        driver: nameById.get(r.driver_id) ?? "",
        status: r.status as string,
        attempts: Number(r.attempts ?? 0),
        createdAt: r.created_at as string,
        chargeCents: Number(r.charge_cents ?? 0),
      })),
    };
  });

/** A company admin switches the wake-up call add-on on or off. */
export const setWakeUpAddon = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { enabled: boolean }) => ({ enabled: Boolean(input.enabled) }))
  .handler(async ({ data, context }) => {
    const supabaseAdmin = await adminClient();
    const companyId = await myCompanyId(supabaseAdmin, context.userId);
    if (!companyId) throw new Error("No company found for this account");

    const { data: adminRole } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", context.userId)
      .eq("role", "admin")
      .maybeSingle();
    if (!adminRole && !(await isPlatformOwner(supabaseAdmin, context.userId)))
      throw new Error("Only a company admin can change the subscription");

    const { error } = await supabaseAdmin
      .from("company_subscriptions")
      .upsert(
        { company_id: companyId, plan_code: "starter", wake_up_calls_enabled: data.enabled },
        { onConflict: "company_id", ignoreDuplicates: false },
      );
    if (error) throw error;
    return { ok: true, enabled: data.enabled };
  });

type SetPlanInput = {
  companyId: string;
  planCode: string;
  status?: string;
  wakeUpEnabled?: boolean;
  wakeUpMonthlyCents?: number;
  wakeUpPerCallCents?: number;
};

/** Platform owner assigns a plan and add-on pricing to a company. */
export const setCompanyPlan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: SetPlanInput) => {
    if (!input.companyId) throw new Error("Company is required");
    if (!input.planCode) throw new Error("Plan is required");
    return input;
  })
  .handler(async ({ data, context }) => {
    const supabaseAdmin = await adminClient();
    if (!(await isPlatformOwner(supabaseAdmin, context.userId)))
      throw new Error("Only the platform owner can change company plans");

    const payload: Record<string, unknown> = {
      company_id: data.companyId,
      plan_code: data.planCode,
    };
    if (data.status) payload["status"] = data.status;
    if (typeof data.wakeUpEnabled === "boolean") payload["wake_up_calls_enabled"] = data.wakeUpEnabled;
    if (typeof data.wakeUpMonthlyCents === "number")
      payload["wake_up_monthly_cents"] = Math.max(0, Math.round(data.wakeUpMonthlyCents));
    if (typeof data.wakeUpPerCallCents === "number")
      payload["wake_up_per_call_cents"] = Math.max(0, Math.round(data.wakeUpPerCallCents));

    const { error } = await supabaseAdmin
      .from("company_subscriptions")
      .upsert(payload as never, { onConflict: "company_id", ignoreDuplicates: false });
    if (error) throw error;
    return { ok: true };
  });

/** Plans plus each company's current subscription, for the platform console. */
export const listCompanyPlans = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const supabaseAdmin = await adminClient();
    if (!(await isPlatformOwner(supabaseAdmin, context.userId)))
      throw new Error("Only the platform owner can view company plans");
    const { data } = await supabaseAdmin.from("company_subscriptions").select("*");
    return (data ?? []).map((row: any) => ({
      companyId: row.company_id as string,
      planCode: row.plan_code as string,
      status: row.status as string,
      wakeUpEnabled: Boolean(row.wake_up_calls_enabled),
      wakeUpMonthlyCents: Number(row.wake_up_monthly_cents ?? 0),
      wakeUpPerCallCents: Number(row.wake_up_per_call_cents ?? 0),
    }));
  });
