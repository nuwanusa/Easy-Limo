import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type AppRole = "admin" | "dispatcher" | "driver";

export function useRole() {
  const query = useQuery({
    queryKey: ["my-role"],
    queryFn: async (): Promise<AppRole[]> => {
      const { data: sessionData } = await supabase.auth.getSession();
      const userId = sessionData.session?.user?.id;
      if (!userId) return [];
      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userId);
      if (error) throw error;
      return (data ?? []).map((r) => r.role as AppRole);
    },
    staleTime: 60_000,
  });

  const roles = query.data ?? [];
  return {
    roles,
    isAdmin: roles.includes("admin"),
    isDispatcher: roles.includes("dispatcher"),
    isStaff: roles.includes("admin") || roles.includes("dispatcher"),
    loading: query.isLoading,
  };
}
