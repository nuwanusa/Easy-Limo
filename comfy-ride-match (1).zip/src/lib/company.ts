import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const COMPANY_CODE_KEY = "blackwave.company-code";

export function rememberedCompanyCode() {
  if (typeof window === "undefined") return "";
  return localStorage.getItem(COMPANY_CODE_KEY) ?? "";
}

export function rememberCompanyCode(code: string) {
  if (typeof window === "undefined") return;
  if (code) localStorage.setItem(COMPANY_CODE_KEY, code.trim().toUpperCase());
}

export type CompanyMembership = {
  companyId: string;
  name: string;
  code: string;
  status: string;
  mustChangePassword: boolean;
};

/** Reads the signed-in user's company membership (null when they belong to none). */
export async function fetchMembership(): Promise<CompanyMembership | null> {
  const { data: sessionData } = await supabase.auth.getSession();
  const userId = sessionData.session?.user?.id;
  if (!userId) return null;
  const { data } = await supabase
    .from("company_users")
    .select("company_id, must_change_password, companies(name, code, status)")
    .eq("user_id", userId)
    .maybeSingle();
  if (!data) return null;
  const company = (data as { companies: { name: string; code: string; status: string } | null })
    .companies;
  return {
    companyId: data.company_id as string,
    name: company?.name ?? "",
    code: company?.code ?? "",
    status: company?.status ?? "active",
    mustChangePassword: Boolean(data.must_change_password),
  };
}

/**
 * Confirms the signed-in account belongs to the company code typed at sign-in.
 * Signs the user out again when the code is wrong or the company is suspended.
 */
export async function verifyCompanyCode(code: string): Promise<void> {
  const typed = code.trim().toUpperCase();
  const membership = await fetchMembership();
  if (!membership) {
    // Platform owners and legacy accounts without a company keep working.
    const { data: sessionData } = await supabase.auth.getSession();
    const userId = sessionData.session?.user?.id;
    if (!userId) return;
    const { data: owner } = await supabase
      .from("platform_owners")
      .select("user_id")
      .eq("user_id", userId)
      .maybeSingle();
    if (owner) return;
    return;
  }
  if (membership.status !== "active") {
    await supabase.auth.signOut();
    throw new Error("This company account is suspended. Contact the platform administrator.");
  }
  if (typed && membership.code && typed !== membership.code) {
    await supabase.auth.signOut();
    throw new Error("That Company ID does not match this account.");
  }
  rememberCompanyCode(membership.code);
}

export function useCompany() {
  const query = useQuery({
    queryKey: ["my-company"],
    queryFn: fetchMembership,
    staleTime: 60_000,
  });
  return { company: query.data ?? null, loading: query.isLoading };
}

export function useIsPlatformOwner() {
  const query = useQuery({
    queryKey: ["platform-owner"],
    queryFn: async () => {
      const { data: sessionData } = await supabase.auth.getSession();
      const userId = sessionData.session?.user?.id;
      if (!userId) return false;
      const { data } = await supabase
        .from("platform_owners")
        .select("user_id")
        .eq("user_id", userId)
        .maybeSingle();
      return Boolean(data);
    },
    staleTime: 60_000,
  });
  return { isPlatformOwner: query.data ?? false, loading: query.isLoading };
}
