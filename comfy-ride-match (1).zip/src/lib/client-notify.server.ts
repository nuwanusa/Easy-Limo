/** Shared builder for the client-facing trip emails (server only). */

const part = (value: string | null | undefined, opts: Intl.DateTimeFormatOptions) => {
  if (!value) return undefined;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return undefined;
  return d.toLocaleString("en-US", { ...opts, timeZone: "America/New_York" });
};

const fmtDate = (v: string | null | undefined) =>
  part(v, { weekday: "long", month: "long", day: "numeric", year: "numeric" });
const fmtTime = (v: string | null | undefined) => part(v, { hour: "numeric", minute: "2-digit" });

export type ClientNoticeKind = "reservation" | "accepted" | "reminder";

const COPY: Record<ClientNoticeKind, { headline: string; intro: string; prefColumn: string }> = {
  reservation: {
    headline: "Reservation confirmed",
    intro: "your reservation is booked. Here are the trip details.",
    prefColumn: "notify_reservation",
  },
  accepted: {
    headline: "Your chauffeur is assigned",
    intro: "your chauffeur has accepted this ride. Here are the trip, chauffeur and vehicle details.",
    prefColumn: "notify_driver_accepted",
  },
  reminder: {
    headline: "Ride reminder — tomorrow",
    intro: "this is a friendly reminder about your ride scheduled within the next 24 hours.",
    prefColumn: "notify_ride_reminder",
  },
};

export type NoticeResult = { sent: boolean; reason?: string };

/**
 * Sends one client trip notice, honouring the client's email preferences.
 * `db` must be able to read reservations, clients, drivers, vehicles and stops.
 */
export async function sendClientTripNotice(
  db: any,
  reservationId: string,
  kind: ClientNoticeKind,
): Promise<NoticeResult> {
  const copy = COPY[kind];

  const { data: ride, error } = await db
    .from("reservations")
    .select("*")
    .eq("id", reservationId)
    .maybeSingle();
  if (error) throw error;
  if (!ride) return { sent: false, reason: "reservation_not_found" };

  let client: any = null;
  if (ride.client_id) {
    const { data } = await db.from("clients").select("*").eq("id", ride.client_id).maybeSingle();
    client = data;
  }

  if (client && client[copy.prefColumn] === false) return { sent: false, reason: "client_opted_out" };
  if (!client) return { sent: false, reason: "no_client_on_ride" };

  const recipient: string | undefined = client?.email || ride.passenger_email || undefined;
  if (!recipient) return { sent: false, reason: "no_client_email" };

  const { data: stops } = await db
    .from("reservation_stops")
    .select("address, position")
    .eq("reservation_id", ride.id)
    .order("position", { ascending: true });

  let driver: any = null;
  let vehicle: any = null;
  if (kind === "accepted" || kind === "reminder") {
    if (ride.driver_id) {
      const { data } = await db
        .from("drivers")
        .select("full_name, phone, default_vehicle_id")
        .eq("id", ride.driver_id)
        .maybeSingle();
      driver = data;
    }
    const vehicleId = ride.vehicle_id ?? driver?.default_vehicle_id ?? null;
    if (vehicleId) {
      const { data } = await db
        .from("vehicles")
        .select("name, vehicle_class, make, model, plate, color")
        .eq("id", vehicleId)
        .maybeSingle();
      vehicle = data;
    }
  }

  const vehicleLabel = vehicle
    ? [vehicle.make, vehicle.model, vehicle.name ? `(${vehicle.name})` : null].filter(Boolean).join(" ")
    : undefined;

  const templateData: Record<string, unknown> = {
    kind,
    headline: copy.headline,
    intro: copy.intro,
    clientName: client?.contact_name || client?.name || ride.passenger_name || undefined,
    clientPhone: client?.booking_contact_phone || client?.phone || undefined,
    reference: ride.reference,
    pickupDate: fmtDate(ride.pickup_at),
    pickupTime: fmtTime(ride.pickup_at),
    dropoffTime: fmtTime(ride.dropoff_at),
    pickupAddress: ride.pickup_address,
    dropoffAddress: ride.dropoff_address,
    stops: (stops ?? []).map((s: { address: string }) => s.address),
    passengerName: ride.passenger_name,
    passengerPhone: ride.passenger_phone ?? undefined,
    passengerCount: ride.passenger_count ? String(ride.passenger_count) : undefined,
    vehicleClass: vehicle?.vehicle_class ?? ride.vehicle_class,
    driverName: driver?.full_name ?? undefined,
    driverPhone: driver?.phone ?? undefined,
    vehicle: vehicleLabel,
    vehiclePlate: vehicle?.plate ?? undefined,
    vehicleColor: vehicle?.color ?? undefined,
    paymentMethod: ride.payment_method ?? undefined,
    airportName: ride.airport_name ?? undefined,
    airline: ride.airline ?? undefined,
    flightDirection:
      ride.flight_direction && ride.flight_direction !== "none"
        ? ride.flight_direction.charAt(0).toUpperCase() + ride.flight_direction.slice(1)
        : undefined,
    flightNumber: ride.flight_number ?? undefined,
    terminalLevel: ride.terminal_level ?? undefined,
    doorNumber: ride.door_number ?? undefined,
  };

  const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");
  try {
    const result = await sendTemplateEmail("client-trip-notice", recipient, {
      templateData,
      idempotencyKey: `client-${kind}-${ride.id}-${Date.now()}`,
    });
    return result?.sent ? { sent: true } : { sent: false, reason: result?.reason ?? "not_sent" };
  } catch (e) {
    return { sent: false, reason: e instanceof Error ? e.message : "send_failed" };
  }
}
