/**
 * Background GPS for the native Android app. Returns null in a normal browser,
 * so the website keeps using the regular location watcher.
 */
type Stop = () => void;

export async function startNativeBackgroundTracking(
  onFix: (lat: number, lng: number, at: number) => void,
): Promise<Stop | null> {
  if (typeof window === "undefined") return null;
  const { Capacitor, registerPlugin } = await import("@capacitor/core");
  if (!Capacitor.isNativePlatform()) return null;

  type BG = {
    addWatcher: (
      opts: Record<string, unknown>,
      cb: (loc?: { latitude: number; longitude: number; time?: number | null }, err?: { code?: string }) => void,
    ) => Promise<string>;
    removeWatcher: (o: { id: string }) => Promise<void>;
    openSettings: () => Promise<void>;
  };
  const BackgroundGeolocation = registerPlugin<BG>("BackgroundGeolocation");

  const id = await BackgroundGeolocation.addWatcher(
    {
      backgroundTitle: "Blackwave ride in progress",
      backgroundMessage: "Sharing your location for tolls and client tracking.",
      requestPermissions: true,
      stale: false,
      distanceFilter: 25,
    },
    (loc, err) => {
      if (err?.code === "NOT_AUTHORIZED") {
        if (window.confirm("Blackwave needs location access 'Allow all the time'. Open settings?")) {
          void BackgroundGeolocation.openSettings();
        }
        return;
      }
      if (loc) onFix(loc.latitude, loc.longitude, loc.time ?? Date.now());
    },
  );
  return () => void BackgroundGeolocation.removeWatcher({ id });
}
