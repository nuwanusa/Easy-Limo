/**
 * Automatic waiting time.
 *
 * On non-airport rides the chauffeur waits free of charge for the first
 * 15 minutes after arriving at the pickup location. Anything beyond that, up
 * to the moment the passenger is on board, is billable waiting time.
 */

export const WAITING_GRACE_MINUTES = 15;

/** Airport runs are excluded: they have their own meet & greet / parking rules. */
export const isAirportRide = (r: {
  airport_name?: string | null;
  flight_number?: string | null;
}) => Boolean((r.airport_name ?? "").trim() || (r.flight_number ?? "").trim());

/** Hourly (as-directed) jobs bill by the hour — no waiting time, no grace period. */
export const isHourlyRide = (r: { booking_type?: string | null }) =>
  (r.booking_type ?? "").trim() === "hourly";

/** Rides that never accrue automatic waiting time. */
export const waitingExempt = (r: {
  airport_name?: string | null;
  flight_number?: string | null;
  booking_type?: string | null;
}) => isAirportRide(r) || isHourlyRide(r);

/** Billable waiting minutes between arrival + grace and the on-board time. */
export const autoWaitingMinutes = (
  arrivedAt: string | Date | null | undefined,
  onBoardAt: string | Date | null | undefined,
  graceMinutes = WAITING_GRACE_MINUTES,
) => {
  if (!arrivedAt || !onBoardAt) return 0;
  const start = new Date(arrivedAt).getTime() + graceMinutes * 60_000;
  const end = new Date(onBoardAt).getTime();
  if (!Number.isFinite(start) || !Number.isFinite(end)) return 0;
  return Math.max(0, Math.round((end - start) / 60_000));
};

/** "1 h 05 m" style label for a minute count. */
export const waitingLabel = (minutes: number) => {
  const m = Math.max(0, Math.round(minutes));
  if (m < 60) return `${m} min`;
  return `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, "0")} min`;
};
