import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Passenger tracking link. The random token in the URL is the credential, so
 * the public handler looks the reservation up by token only and never returns
 * fare, client or billing information.
 */

export interface PublicTrackedRide {
  reference: string;
  status: string;
  pickup_at: string | null;
  pickup_address: string | null;
  dropoff_address: string | null;
  passenger_name: string | null;
  driver_name: string | null;
  driver_phone: string | null;
  vehicle: string | null;
  vehicle_plate: string | null;
  vehicle_color: string | null;
  lat: number | null;
  lng: number | null;
  last_seen_at: string | null;
  eta_minutes: number | null;
  eta_arrival: string | null;
  eta_destination: string | null;
}

const ETA_GATEWAY = "https://connector-gateway.lovable.dev/google_maps";
const LIVE_LOCATION_MAX_AGE_MS = 90_000;

const freshAt = (value: string | null | undefined) => {
  if (!value) return false;
  const timestamp = new Date(value).getTime();
  const diff = Date.now() - timestamp;
  return Number.isFinite(timestamp) && diff <= LIVE_LOCATION_MAX_AGE_MS && diff >= -60_000;
};

async function driveEta(lat: number, lng: number, destination: string | null) {
  const lovableKey = process.env["LOVABLE_API_KEY"];
  const mapsKey = process.env["GOOGLE_MAPS_API_KEY"];
  if (!lovableKey || !mapsKey || !destination?.trim()) return null;
  try {
    const response = await fetch(`${ETA_GATEWAY}/routes/directions/v2:computeRoutes`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${lovableKey}`,
        "X-Connection-Api-Key": mapsKey,
        "Content-Type": "application/json",
        "X-Goog-FieldMask": "routes.duration",
      },
      body: JSON.stringify({
        origin: { location: { latLng: { latitude: lat, longitude: lng } } },
        destination: { address: destination },
        travelMode: "DRIVE",
        routingPreference: "TRAFFIC_AWARE",
        regionCode: "US",
      }),
    });
    if (!response.ok) return null;
    const json = (await response.json()) as { routes?: Array<{ duration?: string }> };
    const duration = json.routes?.[0]?.duration;
    if (!duration) return null;
    const seconds = Number(String(duration).replace("s", ""));
    return {
      minutes: Math.max(1, Math.round(seconds / 60)),
      arrival: new Date(Date.now() + seconds * 1000).toISOString(),
      destination,
    };
  } catch {
    return null;
  }
}

/** Public: live vehicle position for one reservation, by tracking token. */
export const getTrackedRide = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => z.object({ token: z.string().min(8).max(80) }).parse(data))
  .handler(async ({ data }): Promise<PublicTrackedRide | null> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: r } = await supabaseAdmin
      .from("reservations")
      .select(
        "id, reference, status, pickup_at, pickup_address, dropoff_address, passenger_name, driver_id, vehicle_id",
      )
      .eq("track_token", data.token)
      .maybeSingle();
    if (!r) return null;

    let driver: any = null;
    if (r.driver_id) {
      const { data: d } = await supabaseAdmin
        .from("drivers")
        .select("full_name, phone, last_lat, last_lng, last_seen_at, default_vehicle_id")
        .eq("id", r.driver_id)
        .maybeSingle();
      driver = d;
    }

    const { data: ping } = await supabaseAdmin
      .from("ride_track_points")
      .select("lat, lng, recorded_at")
      .eq("reservation_id", r.id)
      .order("recorded_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    const vehicleId = r.vehicle_id ?? driver?.default_vehicle_id ?? null;
    let vehicle: any = null;
    if (vehicleId) {
      const { data: v } = await supabaseAdmin
        .from("vehicles")
        .select("make, model, name, plate, color")
        .eq("id", vehicleId)
        .maybeSingle();
      vehicle = v;
    }

    const pingFresh = freshAt(ping?.recorded_at);
    const driverFresh = freshAt(driver?.last_seen_at);
    const lat = pingFresh ? ping?.lat ?? null : driverFresh ? driver?.last_lat ?? null : null;
    const lng = pingFresh ? ping?.lng ?? null : driverFresh ? driver?.last_lng ?? null : null;
    const locationAt = pingFresh ? ping?.recorded_at ?? null : driverFresh ? driver?.last_seen_at ?? null : null;
    const onboard = r.status === "passenger_on_board";
    const eta =
      lat != null && lng != null
        ? await driveEta(Number(lat), Number(lng), onboard ? r.dropoff_address : r.pickup_address)
        : null;

    return {
      reference: r.reference,
      status: r.status,
      pickup_at: r.pickup_at,
      pickup_address: r.pickup_address,
      dropoff_address: r.dropoff_address,
      passenger_name: r.passenger_name,
      driver_name: driver?.full_name ?? null,
      driver_phone: driver?.phone ?? null,
      vehicle: vehicle ? [vehicle.make, vehicle.model].filter(Boolean).join(" ") || vehicle.name : null,
      vehicle_plate: vehicle?.plate ?? null,
      vehicle_color: vehicle?.color ?? null,
      lat: lat == null ? null : Number(lat),
      lng: lng == null ? null : Number(lng),
      last_seen_at: locationAt,
      eta_minutes: eta?.minutes ?? null,
      eta_arrival: eta?.arrival ?? null,
      eta_destination: eta?.destination ?? null,
    };
  });

/** Staff: emails the passenger tracking link. */
export const sendTrackLinkEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { reservationId: string; to: string; name?: string; url: string }) => {
    const reservationId = input.reservationId?.trim();
    const to = input.to?.trim().toLowerCase();
    const url = input.url?.trim();
    if (!reservationId) throw new Error("Reservation is required");
    if (!to || !to.includes("@")) throw new Error("Enter a valid email address");
    if (!url) throw new Error("Tracking link is required");
    return { reservationId, to, url, name: input.name?.trim() || null };
  })
  .handler(async ({ data, context }) => {
    const { data: r } = await context.supabase
      .from("reservations")
      .select("reference, pickup_at, pickup_address, dropoff_address, passenger_name")
      .eq("id", data.reservationId)
      .maybeSingle();

    const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");
    return sendTemplateEmail("ride-track-link", data.to, {
      idempotencyKey: `track-link-${data.reservationId}-${data.to}-${Date.now()}`,
      templateData: {
        greetingName: data.name,
        reference: r?.reference ?? null,
        passengerName: r?.passenger_name ?? null,
        pickupAt: r?.pickup_at
          ? new Date(r.pickup_at).toLocaleString("en-US", {
              weekday: "long",
              month: "long",
              day: "numeric",
              hour: "numeric",
              minute: "2-digit",
              hour12: true,
              timeZone: "America/New_York",
            })
          : null,
        pickupAddress: r?.pickup_address ?? null,
        dropoffAddress: r?.dropoff_address ?? null,
        trackUrl: data.url,
      },
    });
  });
