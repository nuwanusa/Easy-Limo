import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { autoWaitingMinutes, isAirportRide } from "@/lib/waiting-time";

/**
 * One-time chauffeur flow. These functions are reachable without a signed-in
 * account: the random link token in the URL is the credential, so every handler
 * looks the reservation up by token and never trusts an id from the caller.
 */

const tokenOnly = z.object({ token: z.string().min(20).max(80) });

const GUEST_STATUSES = ["confirmed", "en_route", "on_location", "passenger_on_board", "completed"] as const;

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

async function findReservation(token: string) {
  const db = await admin();
  const { data, error } = await db
    .from("reservations")
    .select("*")
    .eq("guest_link_token", token)
    .maybeSingle();
  if (error) throw error;
  return data;
}

/** Trip sheet shown at the top of the one-time driver page. */
export const getGuestTrip = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => tokenOnly.parse(data))
  .handler(async ({ data }) => {
    const db = await admin();
    const r = await findReservation(data.token);
    if (!r) return null;

    const { data: stops } = await db
      .from("reservation_stops")
      .select("id, position, address, note")
      .eq("reservation_id", r.id)
      .order("position", { ascending: true });

    let driver: {
      full_name: string;
      phone: string | null;
      payout_method: string | null;
      payout_handle: string | null;
      payout_bank_name: string | null;
      payout_routing_number: string | null;
      payout_account_number: string | null;
    } | null = null;
    if (r.driver_id) {
      const { data: d } = await db
        .from("drivers")
        .select("full_name, phone, payout_method, payout_handle, payout_bank_name, payout_routing_number, payout_account_number")
        .eq("id", r.driver_id)
        .maybeSingle();
      driver = d ?? null;
    }


    return {
      reference: r.reference,
      status: r.status,
      passenger_name: r.passenger_name,
      passenger_phone: r.passenger_phone,
      driver_contact_role: r.driver_contact_role ?? "passenger",
      booked_by_name: r.booked_by_name,
      booked_by_phone: r.booked_by_phone,
      billing_contact_name: r.billing_contact_name,
      billing_contact_phone: r.billing_contact_phone,
      passenger_count: r.passenger_count,
      pickup_address: r.pickup_address,
      pickup_at: r.pickup_at,
      dropoff_address: r.dropoff_address,
      dropoff_at: r.dropoff_at,
      notes: r.notes,
      driver_note: r.driver_note,

      airport_name: r.airport_name,
      airline: r.airline,
      flight_number: r.flight_number,
      flight_direction: r.flight_direction,
      terminal_level: r.terminal_level,
      door_number: r.door_number,
      stops: stops ?? [],
      submitted: !!r.driver_id,
      driver,
    };
  });

const submitInput = tokenOnly.extend({
  full_name: z.string().trim().min(2).max(120),
  phone: z.string().trim().min(7).max(40),
  make: z.string().trim().max(60).optional().default(""),
  model: z.string().trim().max(60).optional().default(""),
  plate: z.string().trim().min(2).max(20),
  color: z.string().trim().max(40).optional().default(""),
});

/** Saves the one-time chauffeur and their vehicle onto the reservation. */
export const submitGuestDriver = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => submitInput.parse(data))
  .handler(async ({ data }) => {
    const db = await admin();
    const r = await findReservation(data.token);
    if (!r) throw new Error("This link is no longer valid.");

    const plate = data.plate.toUpperCase();
    const vehicleName = [data.color, data.make, data.model].filter(Boolean).join(" ") || plate;

    let vehicleId: string | null = null;
    const { data: existingVehicle } = await db
      .from("vehicles")
      .select("id")
      .eq("plate", plate)
      .maybeSingle();
    if (existingVehicle) {
      vehicleId = existingVehicle.id as string;
      await db
        .from("vehicles")
        .update({
          name: vehicleName,
          make: data.make || null,
          model: data.model || null,
          color: data.color || null,
        })
        .eq("id", vehicleId);
    } else {
      const { data: created, error } = await db
        .from("vehicles")
        .insert({
          fleet_code: `GUEST-${plate}`,
          name: vehicleName,
          vehicle_class: r.vehicle_class,
          plate,
          make: data.make || null,
          model: data.model || null,
          color: data.color || null,
          capacity: r.passenger_count || 4,
          status: "active",
        })
        .select("id")
        .single();
      if (error) throw error;
      vehicleId = created.id as string;
    }

    let driverId = r.driver_id as string | null;
    if (driverId) {
      await db
        .from("drivers")
        .update({ full_name: data.full_name, phone: data.phone, default_vehicle_id: null })
        .eq("id", driverId);
    } else {
      const { data: created, error } = await db
        .from("drivers")
        .insert({
          full_name: data.full_name,
          phone: data.phone,
          status: "active",
          is_guest: true,
          is_active: true,
        })
        .select("id")
        .single();
      if (error) throw error;
      driverId = created.id as string;
    }

    const { error: upErr } = await db
      .from("reservations")
      .update({
        driver_id: driverId,
        vehicle_id: vehicleId,
        driver_confirmed_at: new Date().toISOString(),
      })
      .eq("id", r.id);
    if (upErr) throw upErr;

    return { ok: true };
  });

/** Moves the trip along the one-time chauffeur's status flow. */
export const setGuestStatus = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) =>
    tokenOnly.extend({ status: z.enum(GUEST_STATUSES) }).parse(data),
  )
  .handler(async ({ data }) => {
    const db = await admin();
    const r = await findReservation(data.token);
    if (!r?.driver_id) throw new Error("Submit your details first.");

    // Drivers can correct a status tapped by mistake: moving backwards simply
    // reverts the trip, and leaving "completed" clears the drop-off time.
    const patch: { status: string; dropoff_at?: string | null; waiting_minutes?: number } = {
      status: data.status,
    };
    if (data.status === "completed" && !r.dropoff_at) patch.dropoff_at = new Date().toISOString();
    if (data.status !== "completed" && r.status === "completed") patch.dropoff_at = null;

    // Non-airport rides bill waiting time automatically: everything past the
    // 15-minute grace after the chauffeur arrives until the passenger boards.
    if (data.status === "passenger_on_board" && !isAirportRide(r)) {
      const { data: arrived } = await db
        .from("reservation_status_events")
        .select("occurred_at")
        .eq("reservation_id", r.id)
        .eq("status", "on_location")
        .order("occurred_at", { ascending: true })
        .limit(1);
      patch.waiting_minutes = autoWaitingMinutes(arrived?.[0]?.occurred_at ?? null, new Date());
    }





    const { error } = await db.from("reservations").update(patch).eq("id", r.id);
    if (error) throw error;

    await db
      .from("reservation_status_events")
      .insert({ reservation_id: r.id, status: data.status, occurred_at: new Date().toISOString() });

    if (data.status === "completed" && r.status !== "completed") {
      await db
        .from("drivers")
        .update({ is_online: false, last_lat: null, last_lng: null })
        .eq("id", r.driver_id);
      // File the tolls for the route driven so dispatch gets them automatically.
      const { recordRideTolls } = await import("@/lib/tolls.server");
      await recordRideTolls(r.id).catch(() => null);
      // File the ride report with dispatch: milestone times, stop times, distance driven.
      const { recordRideReport } = await import("@/lib/ride-report.server");
      await recordRideReport(r.id).catch(() => null);
    }

    return { status: data.status };
  });

/** Saves the one-time chauffeur's message to dispatch. */
export const saveGuestNote = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) =>
    tokenOnly.extend({ note: z.string().trim().max(2000) }).parse(data),
  )
  .handler(async ({ data }) => {
    const db = await admin();
    const r = await findReservation(data.token);
    if (!r) throw new Error("This link is no longer valid.");
    const { error } = await db
      .from("reservations")
      .update({ driver_note: data.note })
      .eq("id", r.id);
    if (error) throw error;
    return { ok: true };
  });

/** Lists receipts already attached to this trip. */
export const listGuestReceipts = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => tokenOnly.parse(data))
  .handler(async ({ data }) => {
    const db = await admin();
    const r = await findReservation(data.token);
    if (!r) return [];
    const { data: rows } = await db
      .from("reservation_receipts")
      .select("id, kind, amount, created_at")
      .eq("reservation_id", r.id)
      .order("created_at", { ascending: true });
    return rows ?? [];
  });

/** Uploads a receipt photo/PDF sent from the one-time chauffeur's phone. */
export const uploadGuestReceipt = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) =>
    tokenOnly
      .extend({
        kind: z.enum(["parking", "toll", "airport", "other"]),
        amount: z.number().min(0).max(100000).optional().default(0),
        filename: z.string().trim().min(1).max(200),
        content_type: z.string().trim().max(120).optional().default("application/octet-stream"),
        // base64 payload, capped near 8 MB of binary
        file_base64: z.string().min(10).max(11_000_000),
      })
      .parse(data),
  )
  .handler(async ({ data }) => {
    const db = await admin();
    const r = await findReservation(data.token);
    if (!r) throw new Error("This link is no longer valid.");

    const bytes = Buffer.from(data.file_base64, "base64");
    const safe = data.filename.replace(/[^a-zA-Z0-9._-]/g, "_");
    const path = `${r.id}/${Date.now()}-${safe}`;

    const { error: upErr } = await db.storage
      .from("ride-receipts")
      .upload(path, bytes, { contentType: data.content_type || "application/octet-stream" });
    if (upErr) throw upErr;

    const { error } = await db.from("reservation_receipts").insert({
      reservation_id: r.id,
      kind: data.kind,
      file_path: path,
      amount: data.amount ?? 0,
    });
    if (error) throw error;
    return { ok: true };
  });

/** Saves how the one-time chauffeur wants to be paid. */
export const saveGuestPayout = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) =>
    tokenOnly
      .extend({
        method: z.enum(["zelle", "ach", "venmo", "cashapp"]),
        handle: z.string().trim().max(120).optional().default(""),
        bank_name: z.string().trim().max(120).optional().default(""),
        routing_number: z.string().trim().max(40).optional().default(""),
        account_number: z.string().trim().max(40).optional().default(""),
      })
      .parse(data),
  )
  .handler(async ({ data }) => {
    const db = await admin();
    const r = await findReservation(data.token);
    if (!r?.driver_id) throw new Error("Submit your details first.");

    if (data.method === "ach") {
      if (!data.bank_name || !/^\d{9}$/.test(data.routing_number)) {
        throw new Error("Enter your bank name and a 9-digit routing number.");
      }
      if (!/^\d{4,17}$/.test(data.account_number)) {
        throw new Error("Enter a valid bank account number.");
      }
    } else if (!data.handle) {
      throw new Error("Enter the name or handle for this payment method.");
    }

    const { error } = await db
      .from("drivers")
      .update({
        payout_method: data.method,
        payout_handle: data.method === "ach" ? null : data.handle,
        payout_bank_name: data.method === "ach" ? data.bank_name : null,
        payout_routing_number: data.method === "ach" ? data.routing_number : null,
        payout_account_number: data.method === "ach" ? data.account_number : null,
      })
      .eq("id", r.driver_id);
    if (error) throw error;
    return { ok: true };
  });

/** Publishes the one-time chauffeur's live position for the dispatch map. */


export const pingGuestLocation = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) =>
    tokenOnly
      .extend({ lat: z.number().min(-90).max(90), lng: z.number().min(-180).max(180) })
      .parse(data),
  )
  .handler(async ({ data }) => {
    const db = await admin();
    const r = await findReservation(data.token);
    if (!r?.driver_id) return { ok: false };
    if (r.status === "completed" || r.status === "cancelled") return { ok: false };

    await db
      .from("drivers")
      .update({
        is_online: true,
        last_lat: data.lat,
        last_lng: data.lng,
        last_seen_at: new Date().toISOString(),
      })
      .eq("id", r.driver_id);

    // Breadcrumb for the road actually driven, so tolls are charged for the
    // booths this chauffeur really passed.
    await db.from("ride_track_points").insert({
      reservation_id: r.id,
      driver_id: r.driver_id,
      lat: data.lat,
      lng: data.lng,
      recorded_at: new Date().toISOString(),
    });

    return { ok: true };
  });
