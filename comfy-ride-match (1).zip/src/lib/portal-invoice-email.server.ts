// Server-only: builds and sends a client-facing invoice email for the portal.

const money = (v: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(v || 0);

const num = (v: unknown) => Number(v ?? 0) || 0;

/** Main passenger plus any additional passenger names entered on the reservation. */
const passengerNames = (r: Ride) => {
  const main = (r.passenger_name ?? "").trim();
  const extras = Array.isArray(r.extra_passengers)
    ? (r.extra_passengers as any[])
        .map((p) => (typeof p?.name === "string" ? p.name.trim() : ""))
        .filter(Boolean)
    : [];
  const all = [main, ...extras].filter(Boolean);
  return all.length ? all.join(", ") : "—";
};

const dayLabel = (v: string | null | undefined) => {
  if (!v) return "—";
  const d = new Date(/^\d{4}-\d{2}-\d{2}$/.test(v) ? `${v}T12:00:00Z` : v);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric", timeZone: "America/New_York" });
};

const clockTime = (v: string | null | undefined) => {
  if (!v) return "—";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZone: "America/New_York" });
};

type Ride = any;

const shortDate = (v: string | null | undefined) => {
  if (!v) return "";
  const d = new Date(/^\d{4}-\d{2}-\d{2}$/.test(v) ? `${v}T12:00:00Z` : v);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleDateString("en-US", { month: "numeric", day: "numeric", year: "numeric", timeZone: "America/New_York" });
};

const billingPeriod = (rides: Ride[], start?: string | null, end?: string | null) => {
  const rideDates = rides
    .map((ride) => ride.pickup_at as string | null | undefined)
    .filter((value): value is string => Boolean(value))
    .sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
  const first = start ?? rideDates[0];
  const last = end ?? rideDates[rideDates.length - 1];
  if (!first && !last) return undefined;
  const firstLabel = shortDate(first);
  const lastLabel = shortDate(last);
  if (firstLabel === lastLabel) return firstLabel || undefined;
  return [firstLabel, lastLabel].filter(Boolean).join(" – ") || undefined;
};

const billableHours = (r: Ride) => Math.max(num(r.hours), num(r.minimum_hours));
const baseRate = (r: Ride) => num(r.base_rate);
const flatRate = (r: Ride) => (r.booking_type === "hourly" ? 0 : num(r.base_fare));
const hourlyCharge = (r: Ride) => (r.booking_type === "hourly" ? num(r.hourly_rate) * billableHours(r) : 0);
const waitingCharge = (r: Ride) => (num(r.waiting_minutes) / 60) * num(r.waiting_rate);
const carSeatCharge = (r: Ride) => num(r.car_seat_count) * num(r.car_seat_fee);
const otherCharges = (r: Ride, stops: number) =>
  num(r.tolls) +
  num(r.airport_fee) +
  num(r.parking_fee) +
  num(r.meet_greet_fee) +
  waitingCharge(r) +
  carSeatCharge(r) +
  num(r.gratuity) +
  num(r.stop_fee) * stops;
const rideTotal = (r: Ride, stops: number) =>
  baseRate(r) + flatRate(r) + hourlyCharge(r) + otherCharges(r, stops);

const tollNames = (r: Ride): { label: string; amount: number }[] => {
  const legs: any[] = Array.isArray(r.tolls_breakdown) ? r.tolls_breakdown : [];
  const out: { label: string; amount: number }[] = [];
  for (const leg of legs) {
    for (const t of leg?.tolls ?? []) {
      const amount = num(t?.amount);
      if (!amount) continue;
      out.push({ label: [t?.name ?? leg?.label ?? "Toll", t?.agency, t?.payment].filter(Boolean).join(" · "), amount });
    }
  }
  return out;
};

const otherBreakdown = (r: Ride, stops: number) => {
  const rows: { label: string; amount: string }[] = [];
  const push = (label: string, v: number) => {
    if (v > 0) rows.push({ label, amount: money(v) });
  };
  const named = tollNames(r);
  if (named.length && Math.abs(named.reduce((s, t) => s + t.amount, 0) - num(r.tolls)) < 0.02) {
    for (const t of named) rows.push({ label: `Toll — ${t.label}`, amount: money(t.amount) });
  } else {
    push("Tolls", num(r.tolls));
    for (const t of named) rows.push({ label: t.label, amount: money(t.amount) });
  }
  push("Airport fee", num(r.airport_fee));
  push("Parking", num(r.parking_fee));
  push("Meet & greet", num(r.meet_greet_fee));
  if (num(r.waiting_minutes) > 0)
    rows.push({
      label: `Waiting time (${num(r.waiting_minutes)} min @ ${money(num(r.waiting_rate))}/hr)`,
      amount: money(waitingCharge(r)),
    });
  push("Gratuity", num(r.gratuity));
  if (num(r.car_seat_count) > 0)
    push(`Car seats (${num(r.car_seat_count)})`, carSeatCharge(r));
  if (stops > 0) push(`Extra stops (${stops})`, num(r.stop_fee) * stops);
  return rows;
};

const chargeItems = (r: Ride, stops: number) => {
  const rows: { label: string; amount: string }[] = [];
  const push = (label: string, value: number) => {
    if (value > 0) rows.push({ label, amount: money(value) });
  };
  push("Base rate", baseRate(r));
  push("Flat rate", flatRate(r));
  if (hourlyCharge(r) > 0)
    push(
      `Other - ${money(num(r.hourly_rate))} / hour X ${billableHours(r)} hours = ${money(hourlyCharge(r))}`,
      hourlyCharge(r),
    );
  push("Tolls", num(r.tolls));
  push("Parking fee", num(r.parking_fee));
  push("Airport fee", num(r.airport_fee));
  push("Meet & greet", num(r.meet_greet_fee));
  if (waitingCharge(r) > 0)
    push(`Waiting time · ${num(r.waiting_minutes)} min`, waitingCharge(r));
  push("Gratuity", num(r.gratuity));
  if (stops > 0) push(`Extra stops · ${stops}`, num(r.stop_fee) * stops);
  if (carSeatCharge(r) > 0) push(`Car seats · ${num(r.car_seat_count)}`, carSeatCharge(r));
  return rows;
};

const tripRow = (r: Ride, counts: Map<string, string[]>) => {
  const stopAddrs = counts.get(r.id) ?? [];
  const stops = stopAddrs.length;
  const routeParts = [r.pickup_address ? `PU: ${r.pickup_address}` : "", ...stopAddrs, r.dropoff_address ? `DO: ${r.dropoff_address}` : ""].filter(Boolean);
  return {
    date: dayLabel(r.pickup_at),
    pickupTime: clockTime(r.pickup_at),
    dropoffTime: clockTime(r.dropoff_at),
    passenger: passengerNames(r),
    notesLine: `Notes: ${num(r.passenger_count) || 0} passenger${(num(r.passenger_count) || 0) === 1 ? "" : "s"} · ${num(r.luggage_count)} luggage`,
    route: routeParts.join(" → "),
    vehicle: r.vehicle_class ?? "—",
    baseRate: money(baseRate(r)),
    flatRate: r.booking_type === "hourly" ? undefined : money(flatRate(r)),
    flatDetail: undefined,
    others: r.booking_type === "hourly" ? money(otherCharges(r, stops) + hourlyCharge(r)) : money(otherCharges(r, stops)),
    othersDetail:
      r.booking_type === "hourly"
        ? [
            {
              label: `Other - ${money(num(r.hourly_rate))} / hour X ${billableHours(r)} hours = ${money(hourlyCharge(r))}`,
              amount: money(hourlyCharge(r)),
            },
            ...otherBreakdown(r, stops),
          ]
        : otherBreakdown(r, stops),
    distance: num(r.distance_miles) > 0 ? `${num(r.distance_miles)} mi` : "—",
    amount: money(rideTotal(r, stops)),
    charges: chargeItems(r, stops),
  };
};

async function stopCounts(admin: any, ids: string[]) {
  const map = new Map<string, string[]>();
  if (!ids.length) return map;
  const { data } = await admin
    .from("reservation_stops")
    .select("reservation_id, address, position")
    .in("reservation_id", ids)
    .order("position");
  for (const row of data ?? []) {
    const list = map.get(row.reservation_id) ?? [];
    if (row.address) list.push(row.address as string);
    map.set(row.reservation_id, list);
  }
  return map;
}

const sum = (rides: Ride[], fn: (r: Ride) => number) => rides.reduce((s, r) => s + fn(r), 0);

/**
 * Sends the invoice (or single-ride invoice) belonging to `clientId` to any
 * email address the client types into the portal.
 */
export async function emailInvoiceToAddress(opts: {
  clientId: string;
  target: "invoice" | "reservation";
  id: string;
  to: string;
  recipientName?: string;
}): Promise<{ sent: boolean; reason?: string }> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");

  const { data: client } = await supabaseAdmin
    .from("clients")
    .select("id, name, email, account_number, terms, address_line1, address_line2, billing_contact_email")
    .eq("id", opts.clientId)
    .maybeSingle();
  if (!client) throw new Error("Account not found");

  let rides: Ride[] = [];
  let invoiceNumber = "";
  let issuedOn = "";
  let createdOn = "";
  let period: string | undefined;
  let discount = 0;
  let payments = 0;
  let paidAt: string | null = null;
  let notes: string | undefined;

  if (opts.target === "invoice") {
    const { data: invoice } = await supabaseAdmin
      .from("invoices")
      .select("*")
      .eq("id", opts.id)
      .eq("client_id", opts.clientId)
      .maybeSingle();
    if (!invoice) throw new Error("That invoice is not on your account");
    const { data = [] } = await supabaseAdmin
      .from("reservations")
      .select("*")
      .eq("invoice_id", invoice.id)
      .order("pickup_at", { ascending: true });
    rides = data ?? [];
    invoiceNumber = invoice.invoice_number;
    issuedOn = dayLabel(invoice.issued_at ?? invoice.created_at);
    createdOn = dayLabel(invoice.created_at);
    period = billingPeriod(rides, invoice.period_start, invoice.period_end);
    discount = num(invoice.discount);
    payments = num(invoice.payments);
    paidAt = invoice.paid_at ?? null;
    notes = invoice.notes ?? undefined;
  } else {
    const { data: ride } = await supabaseAdmin
      .from("reservations")
      .select("*")
      .eq("id", opts.id)
      .eq("client_id", opts.clientId)
      .maybeSingle();
    if (!ride) throw new Error("That ride is not on your account");
    rides = [ride];
    invoiceNumber = ride.invoice_number ?? `INV-${ride.reference}`;
    issuedOn = dayLabel(ride.invoice_issued_at ?? ride.pickup_at);
    createdOn = dayLabel(ride.created_at ?? ride.pickup_at);
    period = billingPeriod(rides);
    paidAt = ride.invoice_paid_at ?? null;
  }

  const counts = await stopCounts(supabaseAdmin, rides.map((r) => r.id));
  const subtotal = rides.reduce((s, r) => s + rideTotal(r, (counts.get(r.id) ?? []).length), 0);
  const totalDue = Math.max(subtotal - discount - payments, 0);
  const stops = rides.reduce((s, r) => s + (counts.get(r.id) ?? []).length, 0);

  const lines = [
    { label: `Base rate (${rides.length} rides)`, amount: money(sum(rides, baseRate)) },
    { label: `Flat rate rides (${rides.filter((r) => r.booking_type !== "hourly").length})`, amount: money(sum(rides, flatRate)) },
    { label: `Hourly rides (${sum(rides, billableHours)} hr)`, amount: money(sum(rides, hourlyCharge)) },
    { label: `Waiting time (${Math.round(sum(rides, (r) => num(r.waiting_minutes)))} min)`, amount: money(sum(rides, waitingCharge)) },
  ];
  if (stops > 0) {
    lines.push({ label: `Extra stops (${stops})`, amount: money(sum(rides, (r) => num(r.stop_fee) * (counts.get(r.id) ?? []).length)) });
  }

  const otherFees = [
    { label: "Meet & greet", amount: money(sum(rides, (r) => num(r.meet_greet_fee))) },
    { label: "Airport fee", amount: money(sum(rides, (r) => num(r.airport_fee))) },
    { label: "Parking fee", amount: money(sum(rides, (r) => num(r.parking_fee))) },
    { label: "Tolls", amount: money(sum(rides, (r) => num(r.tolls))) },
    { label: "Gratuity", amount: money(sum(rides, (r) => num(r.gratuity))) },
  ];

  const result = await sendTemplateEmail("client-invoice", opts.to, {
    templateData: {
      clientName: client.name,
      contactName:
        opts.recipientName ||
        rides
          .map((r) => (typeof r.billing_contact_name === "string" ? r.billing_contact_name.trim() : ""))
          .find(Boolean) || undefined,
      addressLine1: client.address_line1 ?? undefined,
      addressLine2: client.address_line2 ?? undefined,
      clientEmail: client.email ?? undefined,
      accountNumber: client.account_number ?? undefined,
      invoiceNumber,
      issuedOn,
      createdOn,
      period,
      periodSubject: period,
      tripCount: String(rides.length),
      dueDate: paidAt ? `Paid ${dayLabel(paidAt)}` : (client.terms ?? "Due on receipt"),
      trips: rides.map((r) => tripRow(r, counts)),
      lines,
      otherFees,
      subtotal: money(subtotal),
      discount: money(discount),
      payments: money(payments),
      totalDue: money(paidAt ? 0 : totalDue),
      notes,
      invoiceUrl: await (async () => {
        const { data: c } = await supabaseAdmin
          .from("clients")
          .select("portal_token")
          .eq("id", opts.clientId)
          .maybeSingle();
        const token = (c?.portal_token as string | null) ?? "";
        return token ? `https://rideblackwave.com/i/${token}/${opts.id}` : undefined;
      })(),
      payUrl: paidAt
        ? undefined
        : await (await import("@/lib/payment-links.server")).publicPaymentUrl(opts.target, opts.id),
    },

    idempotencyKey: `portal-invoice-${opts.target}-${opts.id}-${opts.to}-${Date.now()}`,
    ...(client.email ? { replyTo: client.email } : {}),
  });

  return result.sent ? { sent: true } : { sent: false, reason: result.reason };
}
