import { supabase } from "@/integrations/supabase/client";

export type LandingPath = "/dashboard" | "/driver" | "/portal" | "/set-password";

/** Decides where a freshly signed-in account belongs: staff board, driver app, or client portal. */
export async function resolveLanding(): Promise<LandingPath> {
  const { data: sessionData } = await supabase.auth.getSession();
  const userId = sessionData.session?.user?.id;
  if (!userId) return "/dashboard";

  // A company admin signing in with a temporary password must pick a new one first.
  const { data: membership } = await supabase
    .from("company_users")
    .select("must_change_password")
    .eq("user_id", userId)
    .maybeSingle();
  if (membership?.must_change_password) return "/set-password";


  const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", userId);
  const list = (roles ?? []).map((r) => r.role as string);
  if (list.includes("admin") || list.includes("dispatcher")) return "/dashboard";
  if (list.includes("driver")) return "/driver";

  const { data: client } = await supabase
    .from("client_users")
    .select("client_id")
    .eq("user_id", userId)
    .maybeSingle();
  if (client?.client_id) return "/portal";

  const { data: driver } = await supabase.from("drivers").select("id").eq("user_id", userId).maybeSingle();
  if (driver?.id) return "/driver";

  return "/dashboard";
}
