/**
 * Automatic chauffeur wake-up calls.
 *
 * For early pickups (before 7 AM New York time) the chauffeur is phoned two
 * hours ahead. The call asks them to press 1 to confirm; when they don't, it
 * repeats every 10 minutes up to three times and is then flagged for dispatch.
 * Calls are only placed for companies whose subscription includes the add-on,
 * and each attempt is billed at the company's per-call price.
 */

const GATEWAY_URL = "https://connector-gateway.lovable.dev/twilio";
const MAX_ATTEMPTS = 3;
const RETRY_MINUTES = 10;
const LEAD_MINUTES = 120;
const EARLY_HOUR = 7;

export function siteUrl() {
  return process.env["PUBLIC_SITE_URL"] || "https://rideblackwave.com";
}

function nyHour(iso: string) {
  return Number(
    new Date(iso).toLocaleString("en-US", {
      hour: "numeric",
      hour12: false,
      timeZone: "America/New_York",
    }),
  );
}

function nyTime(iso: string) {
  return new Date(iso).toLocaleString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    timeZone: "America/New_York",
  });
}

function escapeXml(value: string) {
  return value.replace(/[<>&'"]/g, (c) =>
    ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;" })[c] as string,
  );
}

export function wakeUpTwiml(message: string, actionUrl: string) {
  return `<?xml version="1.0" encoding="UTF-8"?><Response><Gather numDigits="1" timeout="8" action="${escapeXml(actionUrl)}" method="POST"><Say voice="Polly.Joanna">${escapeXml(message)}</Say><Pause length="1"/><Say voice="Polly.Joanna">Press 1 to confirm you are awake.</Say></Gather><Say voice="Polly.Joanna">We did not hear a confirmation. We will call you again shortly.</Say></Response>`;
}

async function placeCall(to: string, twiml: string) {
  const lovableKey = process.env["LOVABLE_API_KEY"];
  const twilioKey = process.env["TWILIO_API_KEY"];
  const from = process.env["TWILIO_FROM_NUMBER"];
  if (!lovableKey || !twilioKey || !from)
    return { ok: false as const, error: "twilio_not_configured" };

  const response = await fetch(`${GATEWAY_URL}/Calls.json`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${lovableKey}`,
      "X-Connection-Api-Key": twilioKey,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams({ To: to, From: from, Twiml: twiml }),
  });
  const body = await response.text();
  if (!response.ok) {
    console.error(`wake-up call failed [${response.status}]: ${body}`);
    return { ok: false as const, error: `${response.status}: ${body.slice(0, 300)}` };
  }
  return { ok: true as const };
}

const digits = (phone: string) => {
  const clean = phone.replace(/[^\d+]/g, "");
  if (clean.startsWith("+")) return clean;
  const only = clean.replace(/\D/g, "");
  return only.length === 10 ? `+1${only}` : `+${only}`;
};

export async function runWakeUpCalls(supabaseAdmin: any) {
  const now = new Date();
  const horizon = new Date(now.getTime() + (LEAD_MINUTES + 5) * 60 * 1000);

  const { data: rides, error } = await supabaseAdmin
    .from("reservations")
    .select("id, reference, company_id, driver_id, pickup_at, pickup_address, passenger_name, status")
    .not("driver_id", "is", null)
    .neq("status", "cancelled")
    .gte("pickup_at", now.toISOString())
    .lte("pickup_at", horizon.toISOString())
    .limit(200);
  if (error) throw error;

  const early = (rides ?? []).filter((r: any) => nyHour(r.pickup_at) < EARLY_HOUR);
  if (!early.length) return { checked: 0, called: 0, escalated: 0 };

  const companyIds = Array.from(new Set(early.map((r: any) => r.company_id)));
  const { data: subs } = await supabaseAdmin
    .from("company_subscriptions")
    .select("company_id, status, wake_up_calls_enabled, wake_up_per_call_cents")
    .in("company_id", companyIds);
  const subById = new Map((subs ?? []).map((s: any) => [s.company_id, s]));

  let called = 0;
  let escalated = 0;

  for (const ride of early) {
    const sub: any = subById.get(ride.company_id);
    if (!sub?.wake_up_calls_enabled) continue;
    if (!["active", "trialing"].includes(sub.status)) continue;

    const dueAt = new Date(new Date(ride.pickup_at).getTime() - LEAD_MINUTES * 60 * 1000);
    if (now < dueAt) continue;

    const { data: existing } = await supabaseAdmin
      .from("wake_up_calls")
      .select("*")
      .eq("reservation_id", ride.id)
      .maybeSingle();

    if (existing?.status === "confirmed" || existing?.status === "escalated") continue;
    if (existing?.attempts >= MAX_ATTEMPTS) {
      await supabaseAdmin
        .from("wake_up_calls")
        .update({ status: "escalated" })
        .eq("id", existing.id);
      escalated += 1;
      continue;
    }
    if (
      existing?.last_attempt_at &&
      now.getTime() - new Date(existing.last_attempt_at).getTime() < RETRY_MINUTES * 60 * 1000
    )
      continue;

    const { data: driver } = await supabaseAdmin
      .from("drivers")
      .select("id, full_name, phone")
      .eq("id", ride.driver_id)
      .maybeSingle();
    if (!driver?.phone) continue;

    let row = existing;
    if (!row) {
      const { data: created } = await supabaseAdmin
        .from("wake_up_calls")
        .insert({
          company_id: ride.company_id,
          reservation_id: ride.id,
          driver_id: driver.id,
          phone: driver.phone,
          status: "calling",
        })
        .select("*")
        .maybeSingle();
      row = created;
    }
    if (!row) continue;

    const firstName = String(driver.full_name ?? "").split(" ")[0] || "there";
    const message = `Good morning ${firstName}. This is your Blackwave wake up call. Your pickup is at ${nyTime(ride.pickup_at)} from ${ride.pickup_address}. Passenger ${ride.passenger_name}.`;
    const action = `${siteUrl()}/api/public/wake-up-confirm?id=${row.id}`;
    const result = await placeCall(digits(driver.phone), wakeUpTwiml(message, action));

    const attempts = Number(row.attempts ?? 0) + 1;
    await supabaseAdmin
      .from("wake_up_calls")
      .update({
        attempts,
        last_attempt_at: new Date().toISOString(),
        status: result.ok ? (attempts >= MAX_ATTEMPTS ? "awaiting" : "calling") : "failed",
        last_error: result.ok ? null : result.error,
        charge_cents: result.ok
          ? Number(row.charge_cents ?? 0) + Number(sub.wake_up_per_call_cents ?? 0)
          : Number(row.charge_cents ?? 0),
      })
      .eq("id", row.id);

    if (result.ok) called += 1;
  }

  return { checked: early.length, called, escalated };
}

export async function confirmWakeUpCall(supabaseAdmin: any, id: string) {
  const { data } = await supabaseAdmin
    .from("wake_up_calls")
    .select("id")
    .eq("id", id)
    .maybeSingle();
  if (!data) return false;
  await supabaseAdmin
    .from("wake_up_calls")
    .update({ status: "confirmed", confirmed_at: new Date().toISOString() })
    .eq("id", id);
  return true;
}
