/**
 * Ride report for a finished trip.
 *
 * When a chauffeur (staff account or one-time link) marks the passenger
 * dropped off, we assemble the milestone times recorded during the trip
 * (arrival at pickup, passenger on board, each stop, drop-off), work out the
 * distance actually driven, save both on the reservation and email dispatch a
 * report.
 */

const GATEWAY_URL = "https://connector-gateway.lovable.dev/google_maps";

const fmtTime = (v: string | null | undefined) => {
  if (!v) return undefined;
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return undefined;
  return d.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    timeZone: "America/New_York",
  });
};

const fmtDate = (v: string | null | undefined) => {
  if (!v) return undefined;
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return undefined;
  return d.toLocaleString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
    timeZone: "America/New_York",
  });
};

type Money = { currencyCode?: string; units?: string | number; nanos?: number };

const moneyToNumber = (m: Money) => Number(m.units ?? 0) + Number(m.nanos ?? 0) / 1e9;

export interface TollCharge {
  name: string;
  agency: string;
  payment: string;
  amount: number | null;
}

export interface RouteReportLeg {
  label: string;
  distanceMiles: number;
  toll: number | null;
  tolls?: TollCharge[];
}

export interface RouteReport {
  miles: number;
  tollTotal: number | null;
  legs: RouteReportLeg[];
}

/**
 * Distance and tolls along pickup -> stops -> drop-off, per Google Routes.
 * Returns the total miles, the estimated toll total (USD) and a per-leg
 * breakdown so the report shows what each stretch cost.
 */
export async function computeRouteReport(
  origin: string,
  destination: string,
  stops: string[] = [],
  legLabels: string[] = [],
): Promise<RouteReport | null> {
  const lovableKey = process.env["LOVABLE_API_KEY"];
  const mapsKey = process.env["GOOGLE_MAPS_API_KEY"];
  if (!lovableKey || !mapsKey || !origin || !destination) return null;

  const response = await fetch(`${GATEWAY_URL}/routes/directions/v2:computeRoutes`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${lovableKey}`,
      "X-Connection-Api-Key": mapsKey,
      "Content-Type": "application/json",
      "X-Goog-FieldMask":
        "routes.distanceMeters,routes.travelAdvisory.tollInfo,routes.legs.distanceMeters,routes.legs.travelAdvisory.tollInfo,routes.legs.polyline.encodedPolyline",
    },
    body: JSON.stringify({
      origin: { address: origin },
      destination: { address: destination },
      intermediates: stops.filter(Boolean).slice(0, 8).map((address) => ({ address })),
      travelMode: "DRIVE",
      routingPreference: "TRAFFIC_UNAWARE",
      extraComputations: ["TOLLS"],
      routeModifiers: { avoidTolls: false, vehicleInfo: { emissionType: "GASOLINE" } },
    }),
  }).catch(() => null);

  if (!response || !response.ok) return null;
  const json = (await response.json().catch(() => null)) as {
    routes?: Array<{
      distanceMeters?: number;
      travelAdvisory?: { tollInfo?: { estimatedPrice?: Money[] } };
      legs?: Array<{
        distanceMeters?: number;
        travelAdvisory?: { tollInfo?: { estimatedPrice?: Money[] } };
        polyline?: { encodedPolyline?: string };
      }>;
    }>;
  } | null;
  const route = json?.routes?.[0];
  if (!route) return null;

  const pickUsd = (prices?: Money[]) => {
    if (!prices?.length) return null;
    const usd = prices.find((p) => (p.currencyCode ?? "USD") === "USD") ?? prices[0]!;
    return Math.round(moneyToNumber(usd) * 100) / 100;
  };

  const { facilitiesOnRoute } = await import("@/lib/toll-facilities");

  const meters = route.distanceMeters ?? 0;
  const legs: RouteReportLeg[] = (route.legs ?? []).map((leg, i) => {
    const toll = pickUsd(leg.travelAdvisory?.tollInfo?.estimatedPrice);
    let crossings = facilitiesOnRoute(leg.polyline?.encodedPolyline ?? "");
    // A planned polyline can pass near plazas the driver never used. Reconcile
    // the matches against Google's toll total for the leg: drop crossings until
    // the published rates fit inside that amount, then split proportionally to
    // each facility's published rate instead of evenly.
    if (toll !== null && crossings.length > 1) {
      const rateOf = (f: (typeof crossings)[number]) => f.rate ?? 0;
      while (crossings.length > 1) {
        const knownSum = crossings.reduce((s, c) => s + rateOf(c), 0);
        if (knownSum <= 0 || knownSum <= toll * 1.15) break;
        let drop = 0;
        for (let j = 1; j < crossings.length; j++) if (rateOf(crossings[j]!) > rateOf(crossings[drop]!)) drop = j;
        crossings = crossings.filter((_, j) => j !== drop);
      }
    }
    const rateSum = crossings.reduce((s, c) => s + (c.rate ?? 0), 0);
    const amountFor = (f: (typeof crossings)[number]) =>
      toll !== null && crossings.length > 0
        ? rateSum > 0
          ? Math.round(((toll * (f.rate ?? 0)) / rateSum) * 100) / 100
          : Math.round((toll / crossings.length) * 100) / 100
        : (f.rate ?? null);
    return {
      label: legLabels[i] ?? `Leg ${i + 1}`,
      distanceMiles: Math.round(((leg.distanceMeters ?? 0) / 1609.344) * 10) / 10,
      toll,
      tolls: crossings.map((f) => ({
        name: f.name,
        agency: f.agency,
        payment: f.payment,
        amount: amountFor(f),
      })),
    };
  });

  return {
    miles: Math.round((meters / 1609.344) * 10) / 10,
    tollTotal: pickUsd(route.travelAdvisory?.tollInfo?.estimatedPrice),
    legs,
  };
}

export interface TrailTollReport {
  miles: number;
  tollTotal: number;
  crossings: Array<{ name: string; agency: string; payment: string; amount: number | null; at: string }>;
}

/**
 * Tolls for the booths the chauffeur actually drove through, taken from the
 * GPS trail recorded during the trip. Returns null when no trail was recorded
 * (older rides, or location sharing switched off).
 */
export async function computeTrailReport(reservationId: string): Promise<TrailTollReport | null> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { crossingsFromTrail, trailMiles } = await import("@/lib/toll-facilities");

  const { data: points } = await supabaseAdmin
    .from("ride_track_points")
    .select("lat, lng, recorded_at")
    .eq("reservation_id", reservationId)
    .order("recorded_at", { ascending: true });

  const trail = (points ?? []) as Array<{ lat: number; lng: number; recorded_at: string }>;
  if (trail.length < 2) return null;

  const crossings = crossingsFromTrail(trail);

  // Where the GPS dropped out (tunnels, phone asleep), fill the gap with the
  // real road between the two fixes so tolls like the Hugh L. Carey Tunnel are
  // not missed and straight-line guesses do not invent crossings.
  const { trailGaps, decodePolyline } = await import("@/lib/toll-facilities");
  for (const [a, b] of trailGaps(trail).slice(0, 6)) {
    const encoded = await gapPolyline(a, b);
    if (!encoded) continue;
    const path = decodePolyline(encoded);
    const t0 = new Date(a.recorded_at).getTime();
    const t1 = new Date(b.recorded_at).getTime();
    const filled = path.map(([lat, lng], i) => ({
      lat,
      lng,
      recorded_at: new Date(t0 + ((t1 - t0) * i) / Math.max(1, path.length - 1)).toISOString(),
    }));
    crossings.push(...crossingsFromTrail(filled));
  }
  crossings.sort((x, y) => x.at.localeCompare(y.at));

  // Drop repeat hits of the same booth within 20 minutes (a GPS fix and a
  // filled gap can both touch it), and booths with no known charge.
  const lastSeen = new Map<string, number>();
  const unique = crossings.filter((c) => {
    if (c.amount === null) return false;
    const t = new Date(c.at).getTime();
    const prev = lastSeen.get(c.name);
    lastSeen.set(c.name, t);
    return prev === undefined || t - prev > 20 * 60 * 1000;
  });
  crossings.length = 0;
  crossings.push(...unique);

  const tollTotal = Math.round(crossings.reduce((sum, c) => sum + (c.amount ?? 0), 0) * 100) / 100;
  return { miles: trailMiles(trail), tollTotal, crossings };
}

/** Road polyline between two GPS fixes, per Google Routes. */
export async function gapPolyline(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
): Promise<string | null> {
  const lovableKey = process.env["LOVABLE_API_KEY"];
  const mapsKey = process.env["GOOGLE_MAPS_API_KEY"];
  if (!lovableKey || !mapsKey) return null;
  const res = await fetch(`${GATEWAY_URL}/routes/directions/v2:computeRoutes`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${lovableKey}`,
      "X-Connection-Api-Key": mapsKey,
      "Content-Type": "application/json",
      "X-Goog-FieldMask": "routes.polyline.encodedPolyline",
    },
    body: JSON.stringify({
      origin: { location: { latLng: { latitude: a.lat, longitude: a.lng } } },
      destination: { location: { latLng: { latitude: b.lat, longitude: b.lng } } },
      travelMode: "DRIVE",
      routingPreference: "TRAFFIC_UNAWARE",
    }),
  }).catch(() => null);
  if (!res || !res.ok) return null;
  const json = (await res.json().catch(() => null)) as {
    routes?: Array<{ polyline?: { encodedPolyline?: string } }>;
  } | null;
  return json?.routes?.[0]?.polyline?.encodedPolyline ?? null;
}

/** Miles driven along pickup -> stops -> drop-off, per Google Routes. */
export async function routeDistanceMiles(
  origin: string,
  destination: string,
  stops: string[] = [],
): Promise<number | null> {
  const report = await computeRouteReport(origin, destination, stops);
  return report && report.miles > 0 ? report.miles : null;
}

/**
 * Builds and files the ride report for a completed reservation:
 * saves stop arrival times and driven distance, then emails dispatch.
 */
export async function recordRideReport(reservationId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const { data: r } = await supabaseAdmin
    .from("reservations")
    .select("*")
    .eq("id", reservationId)
    .maybeSingle();
  if (!r) return null;

  const [{ data: stops }, { data: events }, { data: driver }] = await Promise.all([
    supabaseAdmin
      .from("reservation_stops")
      .select("id, address, position, stop_at")
      .eq("reservation_id", r.id)
      .order("position", { ascending: true }),
    supabaseAdmin
      .from("reservation_status_events")
      .select("status, occurred_at")
      .eq("reservation_id", r.id)
      .order("occurred_at", { ascending: true }),
    r.driver_id
      ? supabaseAdmin.from("drivers").select("full_name").eq("id", r.driver_id).maybeSingle()
      : Promise.resolve({ data: null as { full_name: string } | null }),
  ]);

  const rows = events ?? [];
  const first = (status: string) => rows.find((e) => e.status === status)?.occurred_at ?? null;
  const stopTime = (index: number) => first(`at_stop_${index + 1}`);

  const enRoute = first("en_route");
  const arrivedAtPickup = first("on_location");
  const onBoard = first("passenger_on_board");
  const droppedOff = first("completed") ?? r.dropoff_at;

  const stopList = stops ?? [];

  // Save any stop arrival times the chauffeur recorded but that are not yet on the stop rows.
  await Promise.all(
    stopList.map(async (s, i) => {
      const t = stopTime(i);
      if (!t || s.stop_at) return;
      await supabaseAdmin.from("reservation_stops").update({ stop_at: t }).eq("id", s.id);
    }),
  );

  // Distance and tolls for the route actually driven.
  const waypointLabels = [
    "Pickup",
    ...stopList.map((_, i) => `Stop ${i + 1}`),
    "Drop-off",
  ];
  const legLabels = waypointLabels.slice(0, -1).map((from, i) => `${from} → ${waypointLabels[i + 1]}`);

  let miles = Number(r.distance_miles ?? 0);
  let tollTotal = Number(r.tolls ?? 0);
  let tollLegs: Array<{ label: string; amount: string; items?: string[] }> = [];

  // Preferred source: the booths the chauffeur actually drove through.
  const trail = await computeTrailReport(r.id);

  if (trail && trail.crossings.length >= 0 && trail.miles > 0) {
    miles = trail.miles;
    tollTotal = trail.tollTotal;
    const legs = [
      {
        label: "Road actually driven",
        distanceMiles: trail.miles,
        toll: trail.tollTotal,
        tolls: trail.crossings,
      },
    ];
    await supabaseAdmin
      .from("reservations")
      .update({
        distance_miles: miles,
        tolls: tollTotal,
        tolls_breakdown: legs as unknown as never,
      })
      .eq("id", r.id);
    tollLegs = [
      {
        label: "Road actually driven",
        amount: `$${tollTotal.toFixed(2)} · ${miles} mi`,
        items: trail.crossings.map(
          (c) =>
            `${c.name} · ${c.payment} · ${c.amount !== null ? `$${c.amount.toFixed(2)}` : "rate pending"} · ${fmtTime(c.at) ?? ""}`,
        ),
      },
    ];
  } else if (r.pickup_address && r.dropoff_address) {
    const report = await computeRouteReport(
      r.pickup_address,
      r.dropoff_address,
      stopList.map((s) => s.address as string),
      legLabels,
    );
    if (report) {
      if (!(miles > 0) && report.miles > 0) {
        miles = report.miles;
        await supabaseAdmin.from("reservations").update({ distance_miles: miles }).eq("id", r.id);
      }
      // Only fill tolls when staff or the chauffeur have not entered an amount.
      if (!(tollTotal > 0) && report.tollTotal !== null && report.tollTotal > 0) {
        tollTotal = report.tollTotal;
        await supabaseAdmin.from("reservations").update({ tolls: tollTotal }).eq("id", r.id);
      }
      // Save the per-leg tolls breakdown so staff can see it on the ride page.
      await supabaseAdmin
        .from("reservations")
        .update({ tolls_breakdown: report.legs as unknown as never })
        .eq("id", r.id);
      tollLegs = report.legs.map((leg) => ({
        label: `${leg.label} (estimate — no GPS trail recorded)`,
        amount:
          leg.toll !== null && leg.toll > 0
            ? `$${leg.toll.toFixed(2)} · ${leg.distanceMiles} mi`
            : `No tolls · ${leg.distanceMiles} mi`,
        items: (leg.tolls ?? []).map((t) =>
          t.amount !== null && t.amount > 0
            ? `${t.name} · ${t.payment} · $${t.amount.toFixed(2)}`
            : `${t.name} · ${t.payment}`,
        ),
      }));
    }
  }

  const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");
  try {
    await sendTemplateEmail("ride-report", "info@rideblackwave.com", {
      templateData: {
        reference: r.reference,
        rideDate: fmtDate(r.pickup_at),
        driverName: driver?.full_name ?? null,
        passengerName: r.passenger_name,
        vehicle: r.vehicle_class,
        enRouteAt: fmtTime(enRoute),
        arrivedAtPickup: fmtTime(arrivedAtPickup),
        passengerOnBoard: fmtTime(onBoard) ?? fmtTime(r.pickup_at),
        droppedOff: fmtTime(droppedOff),
        legs: [
          { label: "Pickup", address: r.pickup_address, time: fmtTime(onBoard) },
          ...stopList.map((s, i) => ({
            label: `Stop ${i + 1}`,
            address: s.address as string,
            time: fmtTime(stopTime(i) ?? (s.stop_at as string | null)),
          })),
          { label: "Drop-off", address: r.dropoff_address, time: fmtTime(droppedOff) },
        ],
        distanceMiles: miles > 0 ? `${miles} mi` : undefined,
        tolls: tollTotal > 0 ? `$${tollTotal.toFixed(2)}` : undefined,
        tollLegs,
        driverNote: r.driver_note,
      },
      idempotencyKey: `ride-report-${r.id}-${Date.now()}`,
    });
  } catch (err) {
    console.error("ride report email failed", err);
  }

  return { miles, tollTotal, enRoute, arrivedAtPickup, onBoard, droppedOff };
}

/**
 * Recalculates distance and tolls for a reservation and saves the per-leg
 * breakdown — used by staff to backfill rides completed before the breakdown
 * was recorded. Sends no email.
 */
export async function refreshRideTolls(reservationId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  // Use the recorded GPS trail when there is one — those are the booths the
  // chauffeur really passed.
  const trail = await computeTrailReport(reservationId);
  if (trail && trail.miles > 0) {
    const legs = [
      {
        label: "Road actually driven",
        distanceMiles: trail.miles,
        toll: trail.tollTotal,
        tolls: trail.crossings,
      },
    ];
    await supabaseAdmin
      .from("reservations")
      .update({
        distance_miles: trail.miles,
        tolls: trail.tollTotal,
        tolls_breakdown: legs as unknown as never,
      })
      .eq("id", reservationId);
    return { miles: trail.miles, tollTotal: trail.tollTotal, legs };
  }

  const { data: r } = await supabaseAdmin
    .from("reservations")
    .select("id, pickup_address, dropoff_address")
    .eq("id", reservationId)
    .maybeSingle();
  if (!r?.pickup_address || !r.dropoff_address) return null;

  const { data: stops } = await supabaseAdmin
    .from("reservation_stops")
    .select("address, position")
    .eq("reservation_id", r.id)
    .order("position", { ascending: true });
  const stopList = stops ?? [];

  const waypointLabels = ["Pickup", ...stopList.map((_, i) => `Stop ${i + 1}`), "Drop-off"];
  const legLabels = waypointLabels.slice(0, -1).map((from, i) => `${from} → ${waypointLabels[i + 1]}`);

  const report = await computeRouteReport(
    r.pickup_address as string,
    r.dropoff_address as string,
    stopList.map((s) => s.address as string),
    legLabels,
  );
  if (!report) return null;

  await supabaseAdmin
    .from("reservations")
    .update({
      distance_miles: report.miles,
      tolls: report.tollTotal ?? 0,
      tolls_breakdown: report.legs as unknown as never,
    })
    .eq("id", r.id);

  return report;
}
