import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const part = (
  value: string | null | undefined,
  opts: Intl.DateTimeFormatOptions,
) => {
  if (!value) return undefined;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return undefined;
  return d.toLocaleString("en-US", { ...opts, timeZone: "America/New_York" });
};

const fmtDate = (v: string | null | undefined) =>
  part(v, { weekday: "long", month: "long", day: "numeric", year: "numeric" });
const fmtTime = (v: string | null | undefined) =>
  part(v, { hour: "numeric", minute: "2-digit" });

const fmt = (value: string | null | undefined) => {
  if (!value) return undefined;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return undefined;
  return d.toLocaleString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
    timeZone: "America/New_York",
  });
};

async function buildAndSend(
  supabase: any,
  reservationId: string,
  templateName: "driver-assignment" | "driver-confirmation"
) {
  const { data: reservation, error } = await supabase
    .from("reservations")
    .select("*")
    .eq("id", reservationId)
    .maybeSingle();
  if (error) throw error;
  if (!reservation) throw new Error("Reservation not found");
  if (!reservation.driver_id) return { sent: false, reason: "no_driver" as const };

  const { data: driver } = await supabase
    .from("drivers")
    .select("full_name, email, default_vehicle_id")
    .eq("id", reservation.driver_id)
    .maybeSingle();

  if (!driver?.email) return { sent: false, reason: "no_driver_email" as const };

  const { data: stops } = await supabase
    .from("reservation_stops")
    .select("address, position")
    .eq("reservation_id", reservation.id)
    .order("position", { ascending: true });

  // Use the ride's vehicle when one is set, otherwise fall back to the
  // chauffeur's default vehicle so the email still shows make/model/plate.
  const vehicleId = reservation.vehicle_id ?? driver.default_vehicle_id ?? null;
  const { data: vehicle } = vehicleId
    ? await supabase
        .from("vehicles")
        .select("name, vehicle_class, make, model, plate, color")
        .eq("id", vehicleId)
        .maybeSingle()
    : { data: null };

  const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");

  try {
    const result = await sendTemplateEmail(templateName, driver.email, {
      templateData: {
        driverName: driver.full_name?.split(" ")[0] ?? null,
        reference: reservation.reference,
        pickupAt: fmt(reservation.pickup_at),
        pickupDate: fmtDate(reservation.pickup_at),
        pickupTime: fmtTime(reservation.pickup_at),
        dropoffAt: fmt(reservation.dropoff_at),
        pickupAddress: reservation.pickup_address,
        dropoffAddress: reservation.dropoff_address,
        stops: (stops ?? []).map((s: { address: string }) => s.address),
        passengerName: reservation.passenger_name,
        passengerPhone: reservation.passenger_phone,
        passengerCount: reservation.passenger_count,
        vehicleClass: vehicle?.vehicle_class ?? reservation.vehicle_class,
        vehicleName: vehicle?.name ?? null,
        vehicleMake: vehicle?.make ?? null,
        vehicleModel: vehicle?.model ?? null,
        vehiclePlate: vehicle?.plate ?? null,
        vehicleColor: vehicle?.color ?? null,
        airportName: reservation.airport_name,
        flightNumber: reservation.flight_number,
        flightDirection: reservation.flight_number ? reservation.flight_direction : null,
        terminalLevel: reservation.terminal_level,
        doorNumber: reservation.door_number,
        notes: reservation.notes,
      },
      idempotencyKey: `${templateName}-${reservation.id}-${reservation.driver_id}-${Date.now()}`,
    });
    if (!result.sent) return { sent: false, reason: result.reason };
    return { sent: true as const, email: driver.email };
  } catch (err) {
    console.error(`${templateName} email failed`, err);
    return {
      sent: false,
      reason: err instanceof Error ? err.message : "send_failed",
    };
  }
}

/**
 * Emails the assigned driver a full trip briefing. Called after a dispatcher
 * assigns (or reassigns) a driver to a reservation.
 */
export const sendDriverAssignmentEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { reservationId: string }) => {
    if (!input?.reservationId) throw new Error("Reservation is required");
    return input;
  })
  .handler(async ({ data, context }) =>
    buildAndSend(context.supabase, data.reservationId, "driver-assignment")
  );

/**
 * Emails the driver a confirmation copy of the trip after they accept it in
 * the driver app.
 */
export const sendDriverConfirmationEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { reservationId: string }) => {
    if (!input?.reservationId) throw new Error("Reservation is required");
    return input;
  })
  .handler(async ({ data, context }) =>
    buildAndSend(context.supabase, data.reservationId, "driver-confirmation")
  );

