import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Called by the chauffeur app when a trip is marked dropped off: files the
 * ride report (milestone times, stop times and distance driven) with dispatch.
 */
export const submitRideReport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ reservation_id: z.string().uuid() }).parse(data))
  .handler(async ({ data }) => {
    const { recordRideReport } = await import("@/lib/ride-report.server");
    return (await recordRideReport(data.reservation_id)) ?? { miles: 0 };
  });

/**
 * Staff-only: recalculates distance and tolls for a ride and saves the
 * per-leg tolls breakdown (no email). Backfills rides completed earlier.
 */
export const recalculateRideTolls = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ reservation_id: z.string().uuid() }).parse(data))
  .handler(async ({ data }) => {
    const { refreshRideTolls } = await import("@/lib/ride-report.server");
    return await refreshRideTolls(data.reservation_id);
  });

/** Provides an estimated booked route when an older ride has no saved GPS trail. */
export const getEstimatedRideRoute = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ reservation_id: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    const { data: ride, error } = await context.supabase
      .from("reservations")
      .select("pickup_address, dropoff_address")
      .eq("id", data.reservation_id)
      .maybeSingle();
    if (error) throw error;
    if (!ride?.pickup_address || !ride.dropoff_address) return [];

    const { data: stops, error: stopsError } = await context.supabase
      .from("reservation_stops")
      .select("address, position")
      .eq("reservation_id", data.reservation_id)
      .order("position", { ascending: true });
    if (stopsError) throw stopsError;

    const lovableKey = process.env["LOVABLE_API_KEY"];
    const mapsKey = process.env["GOOGLE_MAPS_API_KEY"];
    if (!lovableKey || !mapsKey) return [];

    const response = await fetch(
      "https://connector-gateway.lovable.dev/google_maps/routes/directions/v2:computeRoutes",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${lovableKey}`,
          "X-Connection-Api-Key": mapsKey,
          "Content-Type": "application/json",
          "X-Goog-FieldMask": "routes.polyline.encodedPolyline",
        },
        body: JSON.stringify({
          origin: { address: ride.pickup_address },
          destination: { address: ride.dropoff_address },
          intermediates: (stops ?? []).slice(0, 8).map((stop) => ({ address: stop.address })),
          travelMode: "DRIVE",
          routingPreference: "TRAFFIC_UNAWARE",
        }),
      },
    );

    if (!response.ok) {
      const body = await response.text();
      console.error(`Google route request failed [${response.status}]: ${body}`);
      return [];
    }

    const result = (await response.json()) as {
      routes?: Array<{ polyline?: { encodedPolyline?: string } }>;
    };
    const encoded = result.routes?.[0]?.polyline?.encodedPolyline;
    if (!encoded) return [];
    const { decodePolyline } = await import("@/lib/toll-facilities");
    return decodePolyline(encoded).map(([lat, lng]) => ({ lat, lng }));
  });

/**
 * The driven route shown on a completed ride's map: GPS fixes from the
 * "Passenger on board" tap until "Passenger dropped off", with long GPS
 * dropouts (tunnels, phone asleep) filled with the real road between the two
 * surviving fixes so the line follows streets instead of cutting straight
 * across the map.
 */
export const getCompletedRideRoute = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ reservation_id: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    const { data: events, error: eventsError } = await context.supabase
      .from("reservation_status_events")
      .select("status, occurred_at")
      .eq("reservation_id", data.reservation_id)
      .in("status", ["passenger_on_board", "completed"])
      .order("occurred_at", { ascending: true });
    if (eventsError) throw eventsError;
    const rows = (events ?? []) as Array<{ status: string; occurred_at: string }>;
    const start = rows.find((e) => e.status === "passenger_on_board")?.occurred_at ?? null;
    const end = rows.find((e) => e.status === "completed")?.occurred_at ?? null;

    const { data: points, error: pointsError } = await context.supabase
      .from("ride_track_points")
      .select("lat, lng, recorded_at")
      .eq("reservation_id", data.reservation_id)
      .order("recorded_at", { ascending: true });
    if (pointsError) throw pointsError;
    const trail = (points ?? []) as Array<{ lat: number; lng: number; recorded_at: string }>;
    // Without a recorded "Passenger on board" tap we can't tell which GPS
    // belongs to the passenger's trip — use Google's estimated route instead.
    if (trail.length < 2 || !start) return [];

    // Keep only the passenger's trip: 1 minute before the on-board tap (clock
    // skew) to 2 minutes after the drop-off tap. Fall back to the full trail
    // when the window would leave too few points.
    const startMs = start ? new Date(start).getTime() - 60_000 : null;
    const endMs = end ? new Date(end).getTime() + 120_000 : null;
    let windowed = trail.filter((p) => {
      const t = new Date(p.recorded_at).getTime();
      if (startMs !== null && t < startMs) return false;
      if (endMs !== null && t > endMs) return false;
      return true;
    });
    if (windowed.length < 2) return [];

    const { trailGaps, decodePolyline } = await import("@/lib/toll-facilities");
    const gapStarts = new Set(trailGaps(windowed).map(([a]) => a.recorded_at));

    const route: Array<{ lat: number; lng: number }> = [];
    const { gapPolyline } = await import("@/lib/ride-report.server");
    for (let i = 0; i < windowed.length; i++) {
      const p = windowed[i]!;
      const next = windowed[i + 1];
      if (next && gapStarts.has(p.recorded_at)) {
        const encoded = await gapPolyline(p, next);
        if (encoded) {
          for (const [lat, lng] of decodePolyline(encoded)) route.push({ lat, lng });
          continue;
        }
      }
      route.push({ lat: p.lat, lng: p.lng });
    }
    return route;
  });
