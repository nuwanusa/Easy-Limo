import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { type StripeEnv, createStripeClient, getStripeErrorMessage } from "@/lib/stripe.server";

const uuid = /^[0-9a-fA-F-]{36}$/;
const num = (v: unknown) => Number(v ?? 0) || 0;

const billableHours = (r: any) => Math.max(num(r.hours), num(r.minimum_hours));
const rideTotal = (r: any, stops: number) =>
  num(r.base_rate) +
  (r.booking_type === "hourly" ? num(r.hourly_rate) * billableHours(r) : num(r.base_fare)) +
  (num(r.waiting_minutes) / 60) * num(r.waiting_rate) +
  num(r.airport_fee) +
  num(r.meet_greet_fee) +
  num(r.parking_fee) +
  num(r.tolls) +
  num(r.gratuity) +
  num(r.stop_fee) * stops;

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

async function assertStaff(context: any) {
  const supabaseAdmin = await admin();
  const { data } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", context.userId)
    .in("role", ["admin", "dispatcher"])
    .limit(1);
  if (!data || data.length === 0) throw new Error("Only staff can authorize a card");
  return supabaseAdmin;
}

async function loadRide(supabaseAdmin: any, reservationId: string) {
  const { data: ride } = await supabaseAdmin
    .from("reservations")
    .select("*")
    .eq("id", reservationId)
    .maybeSingle();
  if (!ride) throw new Error("Reservation not found");
  const { data: stops = [] } = await supabaseAdmin
    .from("reservation_stops")
    .select("id")
    .eq("reservation_id", reservationId);
  return { ride, estimate: rideTotal(ride, (stops ?? []).length) };
}

export type HoldState = {
  status: string | null;
  amount: number;
  capturedAmount: number;
  authorizedAt: string | null;
  capturedAt: string | null;
  brand: string | null;
  last4: string | null;
  estimate: number;
};

/** Current hold on a ride plus the fare the hold should cover. */
export const getFareHold = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { reservationId: string }) => {
    if (!uuid.test(data.reservationId)) throw new Error("Invalid reservation");
    return data;
  })
  .handler(async ({ data, context }): Promise<HoldState> => {
    const supabaseAdmin = await assertStaff(context);
    const { ride, estimate } = await loadRide(supabaseAdmin, data.reservationId);
    return {
      status: ride.auth_status ?? null,
      amount: num(ride.auth_amount),
      capturedAmount: num(ride.auth_captured_amount),
      authorizedAt: ride.authorized_at ?? null,
      capturedAt: ride.auth_captured_at ?? null,
      brand: ride.auth_card_brand ?? null,
      last4: ride.auth_card_last4 ?? null,
      estimate,
    };
  });

/**
 * Places a hold on a saved card. Money is reserved, not taken — capture or
 * release it once the ride is finished or cancelled.
 */
export const authorizeFare = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (data: { reservationId: string; cardId: string; amount?: number | undefined; environment: StripeEnv }) => {
      if (!uuid.test(data.reservationId)) throw new Error("Invalid reservation");
      if (!uuid.test(data.cardId)) throw new Error("Choose a card to authorize");
      if (data.amount != null && (!Number.isFinite(data.amount) || data.amount <= 0)) {
        throw new Error("Enter a valid amount to hold");
      }
      return data;
    },
  )
  .handler(async ({ data, context }) => {
    try {
      const supabaseAdmin = await assertStaff(context);
      const { ride, estimate } = await loadRide(supabaseAdmin, data.reservationId);
      if (ride.auth_status === "authorized") throw new Error("This ride already has an active hold");

      const amount = data.amount ?? estimate;
      const cents = Math.round(amount * 100);
      if (cents < 50) throw new Error("The minimum hold is $0.50");

      const { data: card } = await supabaseAdmin
        .from("client_cards")
        .select("id, client_id, stripe_customer_id, stripe_payment_method_id, brand, last4")
        .eq("id", data.cardId)
        .maybeSingle();
      if (!card) throw new Error("That card is no longer on file");
      if (ride.client_id && card.client_id !== ride.client_id) {
        throw new Error("That card belongs to a different client account");
      }

      const stripe = createStripeClient(data.environment);
      const intent = await stripe.paymentIntents.create({
        amount: cents,
        currency: "usd",
        customer: card.stripe_customer_id as string,
        payment_method: card.stripe_payment_method_id as string,
        capture_method: "manual",
        confirm: true,
        off_session: true,
        description: `Hold for ride ${ride.reference ?? ""}`.trim(),
        metadata: { reservationId: ride.id, reference: ride.reference ?? "" },
      });

      if (intent.status !== "requires_capture") {
        return { error: `The bank did not approve the hold (${intent.status.replace(/_/g, " ")})` };
      }

      await supabaseAdmin
        .from("reservations")
        .update({
          auth_payment_intent_id: intent.id,
          auth_amount: cents / 100,
          auth_status: "authorized",
          authorized_at: new Date().toISOString(),
          auth_captured_amount: 0,
          auth_captured_at: null,
          auth_card_brand: card.brand,
          auth_card_last4: card.last4,
        })
        .eq("id", ride.id);

      return { ok: true, amount: cents / 100, brand: card.brand, last4: card.last4 };
    } catch (error) {
      return { error: getStripeErrorMessage(error) };
    }
  });

/** Takes the money that was held — up to the held amount. */
export const captureFareHold = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { reservationId: string; amount?: number | undefined; environment: StripeEnv }) => {
    if (!uuid.test(data.reservationId)) throw new Error("Invalid reservation");
    if (data.amount != null && (!Number.isFinite(data.amount) || data.amount <= 0)) {
      throw new Error("Enter a valid amount to charge");
    }
    return data;
  })
  .handler(async ({ data, context }) => {
    try {
      const supabaseAdmin = await assertStaff(context);
      const { ride } = await loadRide(supabaseAdmin, data.reservationId);
      if (ride.auth_status !== "authorized" || !ride.auth_payment_intent_id) {
        throw new Error("There is no active hold on this ride");
      }
      const held = num(ride.auth_amount);
      const amount = data.amount ?? held;
      if (amount > held + 0.001) {
        throw new Error(`The hold is ${held.toFixed(2)} — charge the difference separately`);
      }
      const cents = Math.round(amount * 100);
      if (cents < 50) throw new Error("The minimum charge is $0.50");

      const stripe = createStripeClient(data.environment);
      const intent = await stripe.paymentIntents.capture(ride.auth_payment_intent_id as string, {
        amount_to_capture: cents,
      });
      if (intent.status !== "succeeded") {
        return { error: `The charge did not go through (${intent.status.replace(/_/g, " ")})` };
      }

      await supabaseAdmin
        .from("reservations")
        .update({
          auth_status: "captured",
          auth_captured_amount: cents / 100,
          auth_captured_at: new Date().toISOString(),
        })
        .eq("id", ride.id);

      return { ok: true, amount: cents / 100 };
    } catch (error) {
      return { error: getStripeErrorMessage(error) };
    }
  });

/** Gives the held money back to the client's card. */
export const releaseFareHold = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { reservationId: string; environment: StripeEnv }) => {
    if (!uuid.test(data.reservationId)) throw new Error("Invalid reservation");
    return data;
  })
  .handler(async ({ data, context }) => {
    try {
      const supabaseAdmin = await assertStaff(context);
      const { ride } = await loadRide(supabaseAdmin, data.reservationId);
      if (ride.auth_status !== "authorized" || !ride.auth_payment_intent_id) {
        throw new Error("There is no active hold on this ride");
      }
      const stripe = createStripeClient(data.environment);
      await stripe.paymentIntents.cancel(ride.auth_payment_intent_id as string);
      await supabaseAdmin
        .from("reservations")
        .update({ auth_status: "released", auth_captured_amount: 0, auth_captured_at: null })
        .eq("id", ride.id);
      return { ok: true };
    } catch (error) {
      return { error: getStripeErrorMessage(error) };
    }
  });
