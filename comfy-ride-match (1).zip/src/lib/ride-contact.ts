/**
 * Who the chauffeur should reach out to for a ride.
 * Staff pick this per reservation; chauffeur screens show that person's
 * name and phone with the Call / Text / WhatsApp buttons.
 */
export type DriverContactRole = "passenger" | "booking" | "billing";

export const DRIVER_CONTACT_OPTIONS: { value: DriverContactRole; label: string }[] = [
  { value: "passenger", label: "Passenger" },
  { value: "booking", label: "Booked by contact" },
  { value: "billing", label: "Billing contact" },
];

type ContactSource = {
  driver_contact_role?: string | null;
  passenger_name?: string | null;
  passenger_phone?: string | null;
  booked_by_name?: string | null;
  booked_by_phone?: string | null;
  billing_contact_name?: string | null;
  billing_contact_phone?: string | null;
};

export type RideContact = {
  role: DriverContactRole;
  label: string;
  name: string;
  phone: string;
};

/** Resolves the contact a chauffeur should call, falling back to the passenger. */
export function driverContact(ride: ContactSource): RideContact {
  const role = (ride.driver_contact_role as DriverContactRole) || "passenger";
  const passenger = {
    role: "passenger" as const,
    label: "Passenger",
    name: (ride.passenger_name ?? "").trim(),
    phone: (ride.passenger_phone ?? "").trim(),
  };
  if (role === "booking") {
    const phone = (ride.booked_by_phone ?? "").trim();
    if (phone)
      return {
        role,
        label: "Booked by",
        name: (ride.booked_by_name ?? "").trim(),
        phone,
      };
  }
  if (role === "billing") {
    const phone = (ride.billing_contact_phone ?? "").trim();
    if (phone)
      return {
        role,
        label: "Billing contact",
        name: (ride.billing_contact_name ?? "").trim(),
        phone,
      };
  }
  return passenger;
}
