import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const input = z.object({
  flightNumber: z.string().min(2).max(12),
  date: z.string().min(8).max(10).optional(),
});

type AviationStackFlight = {
  flight_status?: string | null;
  flight_date?: string | null;
  airline?: { name?: string | null } | null;
  flight?: { iata?: string | null; icao?: string | null } | null;
  departure?: {
    airport?: string | null;
    iata?: string | null;
    scheduled?: string | null;
    estimated?: string | null;
    actual?: string | null;
    delay?: number | null;
  } | null;
  arrival?: {
    airport?: string | null;
    iata?: string | null;
    terminal?: string | null;
    gate?: string | null;
    baggage?: string | null;
    scheduled?: string | null;
    estimated?: string | null;
    actual?: string | null;
    delay?: number | null;
  } | null;
};

type FlightStatusResult = {
  status: string | null;
  airline: string | null;
  flightNumber: string;
  departureAirport: string | null;
  departureScheduled: string | null;
  departureActual: string | null;
  arrivalAirport: string | null;
  arrivalTerminal: string | null;
  arrivalGate: string | null;
  arrivalBaggage: string | null;
  arrivalScheduled: string | null;
  arrivalEstimated: string | null;
  arrivalDelayMinutes: number | null;
  source: "aviationstack" | "aerodatabox";
};

type AeroDataBoxFlight = {
  status?: string | null;
  airline?: { name?: string | null } | null;
  number?: string | null;
  departure?: {
    airport?: { name?: string | null; iata?: string | null } | null;
    scheduledTime?: { local?: string | null; utc?: string | null } | null;
    revisedTime?: { local?: string | null; utc?: string | null } | null;
    runwayTime?: { local?: string | null; utc?: string | null } | null;
  } | null;
  arrival?: {
    airport?: { name?: string | null; iata?: string | null } | null;
    terminal?: string | null;
    gate?: string | null;
    baggageBelt?: string | null;
    scheduledTime?: { local?: string | null; utc?: string | null } | null;
    predictedTime?: { local?: string | null; utc?: string | null } | null;
    revisedTime?: { local?: string | null; utc?: string | null } | null;
    runwayTime?: { local?: string | null; utc?: string | null } | null;
  } | null;
};

/** AeroDataBox (RapidAPI) fallback — its free tier includes terminal/gate data. */
async function lookupAeroDataBox(
  flightIata: string,
  date: string | undefined,
  key: string,
): Promise<FlightStatusResult | null> {
  const path = date
    ? `https://aerodatabox.p.rapidapi.com/flights/number/${flightIata}/${date}`
    : `https://aerodatabox.p.rapidapi.com/flights/number/${flightIata}`;
  const res = await fetch(path, {
    headers: {
      "x-rapidapi-key": key,
      "x-rapidapi-host": "aerodatabox.p.rapidapi.com",
    },
  });
  if (res.status === 204 || res.status === 404) return null;
  if (!res.ok) throw new Error(`Flight lookup failed [${res.status}]`);

  const json = (await res.json()) as AeroDataBoxFlight[] | { message?: string };
  if (!Array.isArray(json)) return null;
  const f = json[0];
  if (!f) return null;

  const dep = f.departure ?? {};
  const arr = f.arrival ?? {};
  const t = (v?: { local?: string | null; utc?: string | null } | null) =>
    v?.local ?? v?.utc ?? null;

  return {
    status: f.status ?? null,
    airline: f.airline?.name ?? null,
    flightNumber: f.number ?? flightIata,
    departureAirport: dep.airport?.name ?? null,
    departureScheduled: t(dep.scheduledTime),
    departureActual: t(dep.runwayTime) ?? t(dep.revisedTime),
    arrivalAirport: arr.airport?.name ?? null,
    arrivalTerminal: arr.terminal ?? null,
    arrivalGate: arr.gate ?? null,
    arrivalBaggage: arr.baggageBelt ?? null,
    arrivalScheduled: t(arr.scheduledTime),
    arrivalEstimated:
      t(arr.runwayTime) ?? t(arr.predictedTime) ?? t(arr.revisedTime) ?? t(arr.scheduledTime),
    arrivalDelayMinutes: null,
    source: "aerodatabox",
  };
}

/** Live flight status (arrival time, terminal, gate) for a chauffeur's airport pickup. */
export const getFlightStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => input.parse(data))
  .handler(async ({ data }): Promise<FlightStatusResult | null> => {
    const key = process.env["AVIATIONSTACK_API_KEY"];
    const rapidKey = process.env["AERODATABOX_RAPIDAPI_KEY"];
    const flightIata0 = data.flightNumber.replace(/\s+/g, "").toUpperCase();

    // No primary key: try the fallback provider, otherwise degrade gracefully.
    if (!key) {
      if (!rapidKey) return null;
      return lookupAeroDataBox(flightIata0, data.date, rapidKey);
    }

    const flightIata = flightIata0;
    const url = new URL("https://api.aviationstack.com/v1/flights");
    url.searchParams.set("access_key", key);
    url.searchParams.set("flight_iata", flightIata);
    if (data.date) url.searchParams.set("flight_date", data.date);
    url.searchParams.set("limit", "5");

    // Fall back to AeroDataBox whenever the primary provider fails or has no data.
    const fallback = async () =>
      rapidKey ? lookupAeroDataBox(flightIata, data.date, rapidKey) : null;

    const res = await fetch(url.toString());
    if (!res.ok) {
      if (rapidKey) return fallback();
      throw new Error(`Flight lookup failed [${res.status}]`);
    }

    const json = (await res.json()) as {
      error?: { message?: string; info?: string };
      data?: AviationStackFlight[];
    };
    if (json.error) {
      if (rapidKey) return fallback();
      throw new Error(json.error.info ?? json.error.message ?? "Flight lookup failed.");
    }

    const flights = json.data ?? [];
    if (flights.length === 0) return fallback();

    // Prefer the requested day, otherwise the most recent record.
    const f = (data.date && flights.find((x) => x.flight_date === data.date)) || flights[0]!;
    const arrival = f.arrival ?? {};
    const departure = f.departure ?? {};

    return {
      status: f.flight_status ?? null,
      airline: f.airline?.name ?? null,
      flightNumber: f.flight?.iata ?? flightIata,
      departureAirport: departure.airport ?? null,
      departureScheduled: departure.scheduled ?? null,
      departureActual: departure.actual ?? departure.estimated ?? null,
      arrivalAirport: arrival.airport ?? null,
      arrivalTerminal: arrival.terminal ?? null,
      arrivalGate: arrival.gate ?? null,
      arrivalBaggage: arrival.baggage ?? null,
      arrivalScheduled: arrival.scheduled ?? null,
      arrivalEstimated: arrival.estimated ?? arrival.actual ?? arrival.scheduled ?? null,
      arrivalDelayMinutes: arrival.delay ?? null,
      source: "aviationstack" as const,
    };
  });
