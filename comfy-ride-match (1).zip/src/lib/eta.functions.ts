import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const GATEWAY_URL = "https://connector-gateway.lovable.dev/google_maps";

const input = z
  .object({
    lat: z.number().min(-90).max(90).optional(),
    lng: z.number().min(-180).max(180).optional(),
    origin: z.string().min(3).max(300).optional(),
    destination: z.string().min(3).max(300),
  })
  .refine((value) => Boolean(value.origin?.trim()) || (value.lat != null && value.lng != null), {
    message: "A current location or origin address is required.",
  });

/** Drive-time ETA from the chauffeur's current position to an address. */
export const getEta = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => input.parse(data))
  .handler(async ({ data }) => {
    const lovableKey = process.env["LOVABLE_API_KEY"];
    const mapsKey = process.env["GOOGLE_MAPS_API_KEY"];
    if (!lovableKey || !mapsKey) throw new Error("Maps service is not configured.");

    const origin = data.origin?.trim()
      ? { address: data.origin.trim() }
      : data.lat != null && data.lng != null
        ? { location: { latLng: { latitude: data.lat, longitude: data.lng } } }
        : null;
    if (!origin) throw new Error("A current location is required.");

    const response = await fetch(`${GATEWAY_URL}/routes/directions/v2:computeRoutes`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${lovableKey}`,
        "X-Connection-Api-Key": mapsKey,
        "Content-Type": "application/json",
        "X-Goog-FieldMask": "routes.duration,routes.distanceMeters",
      },
      body: JSON.stringify({
        origin,
        destination: { address: data.destination },
        travelMode: "DRIVE",
        routingPreference: "TRAFFIC_AWARE",
        regionCode: "US",
      }),
    });

    if (response.status === 403) {
      const details: Array<{ reason?: string }> =
        (await response.json().catch(() => null))?.error?.details ?? [];
      const reason = details.find((d) => d.reason)?.reason;
      if (reason === "API_KEY_HTTP_REFERRER_BLOCKED") {
        throw new Error(
          'Google Maps server key is referrer-restricted. In Google Cloud Console, set the server key\'s application restrictions to "None" or "IP addresses".',
        );
      }
      if (reason === "API_KEY_SERVICE_BLOCKED") {
        throw new Error(
          "Google Maps server key does not allow the Routes API. Add it to the server key's allowed-APIs list in Google Cloud Console.",
        );
      }
      throw new Error("Google Maps request was denied (403). Check the server key restrictions.");
    }

    if (!response.ok) {
      const body = await response.text();
      throw new Error(`Route request failed [${response.status}]: ${body}`);
    }

    const json = (await response.json()) as {
      routes?: Array<{ duration?: string; distanceMeters?: number }>;
    };
    const route = json.routes?.[0];
    if (!route?.duration) return null;

    const seconds = Number(String(route.duration).replace("s", ""));
    return {
      seconds,
      minutes: Math.max(1, Math.round(seconds / 60)),
      meters: route.distanceMeters ?? 0,
      miles: Math.round(((route.distanceMeters ?? 0) / 1609.34) * 10) / 10,
      arrivalIso: new Date(Date.now() + seconds * 1000).toISOString(),
    };
  });
