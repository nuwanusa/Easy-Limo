export type Airline = { name: string; iata: string };

/** Airlines commonly serving US airports (IATA code + marketing name). */
export const AIRLINES: Airline[] = [
  { name: "Aer Lingus", iata: "EI" },
  { name: "Aeromexico", iata: "AM" },
  { name: "Air Canada", iata: "AC" },
  { name: "Air China", iata: "CA" },
  { name: "Air Europa", iata: "UX" },
  { name: "Air France", iata: "AF" },
  { name: "Air India", iata: "AI" },
  { name: "Air New Zealand", iata: "NZ" },
  { name: "Air Serbia", iata: "JU" },
  { name: "Air Tahiti Nui", iata: "TN" },
  { name: "Alaska Airlines", iata: "AS" },
  { name: "Alitalia (ITA Airways)", iata: "AZ" },
  { name: "All Nippon Airways", iata: "NH" },
  { name: "Allegiant Air", iata: "G4" },
  { name: "American Airlines", iata: "AA" },
  { name: "Asiana Airlines", iata: "OZ" },
  { name: "Austrian Airlines", iata: "OS" },
  { name: "Avianca", iata: "AV" },
  { name: "Azul Brazilian Airlines", iata: "AD" },
  { name: "Bahamasair", iata: "UP" },
  { name: "Breeze Airways", iata: "MX" },
  { name: "British Airways", iata: "BA" },
  { name: "Brussels Airlines", iata: "SN" },
  { name: "Caribbean Airlines", iata: "BW" },
  { name: "Cathay Pacific", iata: "CX" },
  { name: "Cayman Airways", iata: "KX" },
  { name: "China Airlines", iata: "CI" },
  { name: "China Eastern", iata: "MU" },
  { name: "China Southern", iata: "CZ" },
  { name: "Condor", iata: "DE" },
  { name: "Copa Airlines", iata: "CM" },
  { name: "Delta Air Lines", iata: "DL" },
  { name: "EgyptAir", iata: "MS" },
  { name: "El Al", iata: "LY" },
  { name: "Emirates", iata: "EK" },
  { name: "Ethiopian Airlines", iata: "ET" },
  { name: "Etihad Airways", iata: "EY" },
  { name: "EVA Air", iata: "BR" },
  { name: "Finnair", iata: "AY" },
  { name: "Frontier Airlines", iata: "F9" },
  { name: "Hawaiian Airlines", iata: "HA" },
  { name: "Iberia", iata: "IB" },
  { name: "Icelandair", iata: "FI" },
  { name: "InterCaribbean Airways", iata: "JY" },
  { name: "ITA Airways", iata: "AZ" },
  { name: "Japan Airlines", iata: "JL" },
  { name: "JetBlue Airways", iata: "B6" },
  { name: "Kenya Airways", iata: "KQ" },
  { name: "KLM Royal Dutch Airlines", iata: "KL" },
  { name: "Korean Air", iata: "KE" },
  { name: "Kuwait Airways", iata: "KU" },
  { name: "LATAM Airlines", iata: "LA" },
  { name: "Level", iata: "LV" },
  { name: "LOT Polish Airlines", iata: "LO" },
  { name: "Lufthansa", iata: "LH" },
  { name: "Norse Atlantic Airways", iata: "N0" },
  { name: "Oman Air", iata: "WY" },
  { name: "Pakistan International Airlines", iata: "PK" },
  { name: "Philippine Airlines", iata: "PR" },
  { name: "Play", iata: "OG" },
  { name: "Porter Airlines", iata: "PD" },
  { name: "Qantas", iata: "QF" },
  { name: "Qatar Airways", iata: "QR" },
  { name: "Royal Air Maroc", iata: "AT" },
  { name: "Royal Jordanian", iata: "RJ" },
  { name: "Saudia", iata: "SV" },
  { name: "Scandinavian Airlines", iata: "SK" },
  { name: "Singapore Airlines", iata: "SQ" },
  { name: "South African Airways", iata: "SA" },
  { name: "Southwest Airlines", iata: "WN" },
  { name: "Spirit Airlines", iata: "NK" },
  { name: "Sun Country Airlines", iata: "SY" },
  { name: "Swiss International Air Lines", iata: "LX" },
  { name: "TAP Air Portugal", iata: "TP" },
  { name: "Thai Airways", iata: "TG" },
  { name: "Turkish Airlines", iata: "TK" },
  { name: "United Airlines", iata: "UA" },
  { name: "Virgin Atlantic", iata: "VS" },
  { name: "Volaris", iata: "Y4" },
  { name: "WestJet", iata: "WS" },
  { name: "Xiamen Air", iata: "MF" },
];

export function searchAirlines(query: string, limit = 8): Airline[] {
  const q = query.trim().toLowerCase();
  if (!q) return AIRLINES.slice(0, limit);
  const starts: Airline[] = [];
  const contains: Airline[] = [];
  for (const a of AIRLINES) {
    const name = a.name.toLowerCase();
    const code = a.iata.toLowerCase();
    if (name.startsWith(q) || code === q) starts.push(a);
    else if (name.includes(q) || code.startsWith(q)) contains.push(a);
    if (starts.length >= limit) break;
  }
  return [...starts, ...contains].slice(0, limit);
}
