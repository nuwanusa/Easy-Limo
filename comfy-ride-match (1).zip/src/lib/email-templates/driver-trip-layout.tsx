import * as React from 'react'
import {
  Body,
  Column,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Link,
  Preview,
  Row as EmailRow,
  Section,
  Text,
} from '@react-email/components'

export interface DriverTripProps {
  driverName?: string
  reference?: string
  pickupAt?: string
  pickupDate?: string
  pickupTime?: string
  dropoffAt?: string
  pickupAddress?: string
  dropoffAddress?: string
  stops?: string[]
  passengerName?: string
  passengerPhone?: string
  passengerCount?: number
  vehicleClass?: string
  vehicleName?: string
  vehicleMake?: string
  vehicleModel?: string
  vehiclePlate?: string
  vehicleColor?: string
  airportName?: string
  flightNumber?: string
  flightDirection?: string
  terminalLevel?: string
  doorNumber?: string
  notes?: string
}

const main = {
  backgroundColor: '#ffffff',
  fontFamily: 'Segoe UI, Helvetica, Arial, sans-serif',
  padding: '0',
}
const container = { padding: '0 0 32px', maxWidth: '1800px', width: '100%' }
const header = {
  background: 'linear-gradient(135deg, #0b1e3f 0%, #14357a 55%, #1d4ed8 100%)',
  backgroundColor: '#14357a',
  padding: '30px 36px 26px',
}
const brand = {
  color: '#ffffff',
  fontSize: '24px',
  letterSpacing: '4px',
  margin: '0',
  fontWeight: 'bold' as const,
  textTransform: 'uppercase' as const,
}
const brandSub = {
  color: '#a9c4ff',
  fontSize: '11px',
  letterSpacing: '3px',
  margin: '6px 0 0',
  textTransform: 'uppercase' as const,
}
const badge = {
  display: 'inline-block',
  backgroundColor: '#dbeafe',
  color: '#14357a',
  borderRadius: '999px',
  padding: '6px 16px',
  fontSize: '11px',
  letterSpacing: '2px',
  fontWeight: 'bold' as const,
  textTransform: 'uppercase' as const,
  margin: '16px 0 0',
}
const accentBar = { backgroundColor: '#60a5fa', height: '5px', lineHeight: '5px', fontSize: '1px' }
const inner = { padding: '26px 36px 0' }
const heading = { fontSize: '22px', color: '#0b1e3f', margin: '0 0 6px', fontWeight: 'bold' as const }
const sub = { fontSize: '14px', color: '#5b6474', margin: '0 0 6px', lineHeight: '22px' }
const colLeft = { width: '50%', verticalAlign: 'top' as const, padding: '0 12px 0 0' }
const colRight = { width: '50%', verticalAlign: 'top' as const, padding: '0 0 0 12px' }
const hero = {
  backgroundColor: '#f2f7ff',
  border: '1px solid #cddffb',
  borderLeft: '5px solid #1d4ed8',
  borderRadius: '10px',
  padding: '18px 22px',
  margin: '0 0 14px',
}
const heroLabel = {
  fontSize: '10px',
  letterSpacing: '2px',
  textTransform: 'uppercase' as const,
  color: '#2563eb',
  margin: '0 0 3px',
  fontWeight: 'bold' as const,
}
const heroValue = {
  fontSize: '19px',
  color: '#0b1e3f',
  margin: '0 0 12px',
  fontWeight: 'bold' as const,
}
const card = {
  backgroundColor: '#ffffff',
  border: '1px solid #dde6f5',
  borderRadius: '10px',
  padding: '4px 20px 14px',
  margin: '0 0 14px',
}
const sectionTitle = {
  fontSize: '11px',
  letterSpacing: '2px',
  textTransform: 'uppercase' as const,
  color: '#1d4ed8',
  margin: '0 0 8px',
  fontWeight: 'bold' as const,
}
const line = { fontSize: '14px', color: '#1a2233', margin: '0 0 7px', lineHeight: '20px' }
const label = { fontWeight: 'bold' as const, color: '#44506b' }
const hr = { borderColor: '#e5ecf8', margin: '18px 0' }
const noteBox = {
  backgroundColor: '#eff6ff',
  border: '1px solid #bfdbfe',
  borderLeft: '5px solid #2563eb',
  borderRadius: '10px',
  padding: '14px 18px',
}
const footer = {
  fontSize: '11px',
  color: '#8a93a5',
  textAlign: 'center' as const,
  margin: '22px 0 0',
  letterSpacing: '1px',
}

const Field = ({ name, value }: { name: string; value: string | number | null | undefined }) =>
  value === undefined || value === null || value === '' ? null : (
    <Text style={line}>
      <span style={label}>{name}: </span>
      {String(value)}
    </Text>
  )

export interface DriverTripLayoutProps extends DriverTripProps {
  badgeText: string
  title: string
  intro: React.ReactNode
  previewText: string
}

export const DriverTripEmail = ({
  badgeText,
  title,
  intro,
  previewText,
  reference,
  pickupAt,
  pickupDate,
  pickupTime,
  dropoffAt,
  pickupAddress,
  dropoffAddress,
  stops = [],
  passengerName,
  passengerPhone,
  passengerCount,
  vehicleClass,
  vehicleName,
  vehicleMake,
  vehicleModel,
  vehiclePlate,
  vehicleColor,
  airportName,
  flightNumber,
  flightDirection,
  terminalLevel,
  doorNumber,
  notes,
}: DriverTripLayoutProps) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>{previewText}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Text style={brand}>Blackwave</Text>
          <Text style={brandSub}>Transportation LLC</Text>
          <Text style={badge}>
            {badgeText}
            {reference ? ` · ${reference}` : ''}
          </Text>
        </Section>
        <Section style={accentBar}>&nbsp;</Section>

        <Section style={inner}>
          <Heading style={heading}>{title}</Heading>
          <Text style={sub}>{intro}</Text>

          <EmailRow>
            <Column style={colLeft}>
              <Text style={sectionTitle}>Pickup</Text>
              <Section style={hero}>
                <Text style={heroLabel}>Pickup date</Text>
                <Text style={heroValue}>{pickupDate ?? pickupAt ?? 'To be confirmed'}</Text>
                <Text style={heroLabel}>Pickup time</Text>
                <Text style={heroValue}>{pickupTime ?? '—'}</Text>
                <Text style={heroLabel}>Pickup location</Text>
                <Text style={{ ...heroValue, fontSize: '15px', margin: '0' }}>
                  {pickupAddress ?? '—'}
                </Text>
              </Section>

              <Text style={sectionTitle}>Client</Text>
              <Section style={card}>
                <Field name="Name" value={passengerName} />
                {passengerPhone ? (
                  <Text style={line}>
                    <span style={label}>Phone: </span>
                    <Link
                      href={`tel:${String(passengerPhone).replace(/[^+\d]/g, '')}`}
                      style={{ color: '#1d4ed8' }}
                    >
                      {passengerPhone}
                    </Link>
                  </Text>
                ) : null}
                <Field name="Passengers" value={passengerCount} />
              </Section>
            </Column>

            <Column style={colRight}>
              <Text style={sectionTitle}>Vehicle</Text>
              <Section style={card}>
                <Field name="Type" value={vehicleClass} />
                <Field name="Make" value={vehicleMake} />
                <Field name="Model" value={vehicleModel} />
                <Field name="Color" value={vehicleColor} />
                <Field name="Unit" value={vehicleName} />
                <Field name="License plate" value={vehiclePlate} />
              </Section>

              <Text style={sectionTitle}>Route</Text>
              <Section style={card}>
                <Field name="Pickup location" value={pickupAddress} />
                {stops.map((s, i) => (
                  <Field key={i} name={`Stop ${i + 1}`} value={s} />
                ))}
                <Field name="Drop-off location" value={dropoffAddress} />
                <Field name="Drop-off time" value={dropoffAt} />
              </Section>

              {airportName || flightNumber || terminalLevel || doorNumber ? (
                <>
                  <Text style={sectionTitle}>Airport Information</Text>
                  <Section style={card}>
                    <Field name="Airport name" value={airportName} />
                    <Field name="Terminal" value={terminalLevel} />
                    <Field name="Door #" value={doorNumber} />
                    <Field name="Level #" value={terminalLevel} />
                    <Field name="Flight #" value={flightNumber} />
                    <Field name="Direction" value={flightDirection} />
                  </Section>
                </>
              ) : null}
            </Column>
          </EmailRow>

          {notes ? (
            <>
              <Text style={sectionTitle}>Notes from dispatch</Text>
              <Section style={noteBox}>
                <Text style={{ ...line, margin: '0' }}>{notes}</Text>
              </Section>
            </>
          ) : null}

          <Hr style={hr} />
          <Text style={footer}>
            Blackwave Transportation LLC · info@rideblackwave.com · www.rideblackwave.com
          </Text>
        </Section>
      </Container>
    </Body>
  </Html>
)
