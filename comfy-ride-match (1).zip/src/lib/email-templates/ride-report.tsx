import * as React from 'react'
import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'
import type { TemplateEntry } from './registry'

export interface ReportLeg {
  label?: string
  address?: string
  time?: string
}

export interface TollLeg {
  label?: string
  amount?: string
  /** Named crossings on this section, e.g. "Queens-Midtown Tunnel · E-ZPass · $11.19". */
  items?: string[]
}

export interface RideReportProps {
  reference?: string
  rideDate?: string
  driverName?: string
  passengerName?: string
  vehicle?: string
  enRouteAt?: string
  arrivedAtPickup?: string
  passengerOnBoard?: string
  droppedOff?: string
  legs?: ReportLeg[]
  distanceMiles?: string
  tolls?: string
  tollLegs?: TollLeg[]
  driverNote?: string
}

const navy = '#0b1e3f'
const navyMid = '#14357a'
const blue = '#1d4ed8'
const iceBlue = '#eaf1ff'
const border = '#c9d8f5'
const slate = '#334155'

const main = {
  backgroundColor: '#ffffff',
  fontFamily: 'Segoe UI, Helvetica, Arial, sans-serif',
  padding: '0',
}
const container = { padding: '0 0 36px', maxWidth: '900px', width: '100%' }
const header = {
  background: `linear-gradient(135deg, ${navy} 0%, ${navyMid} 55%, ${blue} 100%)`,
  backgroundColor: navyMid,
  padding: '28px 32px 24px',
}
const brand = {
  color: '#ffffff',
  fontSize: '22px',
  letterSpacing: '4px',
  margin: '0',
  fontWeight: 'bold' as const,
}
const headline = { color: '#dbeafe', fontSize: '12px', letterSpacing: '3px', margin: '6px 0 0' }
const contactLine = { color: '#e2ecff', fontSize: '12px', lineHeight: '18px', margin: '2px 0 0' }
const section = { padding: '20px 32px 0' }
const cardStyle = {
  border: `1px solid ${border}`,
  backgroundColor: iceBlue,
  borderRadius: '10px',
  padding: '16px 18px',
  margin: '0 0 14px',
}
const label = {
  color: '#64748b',
  fontSize: '10px',
  letterSpacing: '2px',
  margin: '0',
  fontWeight: 'bold' as const,
}
const value = { color: navy, fontSize: '15px', margin: '2px 0 10px' }
const smallNote = { color: slate, fontSize: '13px', lineHeight: '20px', margin: '4px 0 0' }

const Row = ({ name, val }: { name: string; val?: string | undefined }) =>
  val ? (
    <>
      <Text style={label}>{name.toUpperCase()}</Text>
      <Text style={value}>{val}</Text>
    </>
  ) : null

export function RideReportEmail({
  reference,
  rideDate,
  driverName,
  passengerName,
  vehicle,
  enRouteAt,
  arrivedAtPickup,
  passengerOnBoard,
  droppedOff,
  legs = [],
  distanceMiles,
  tolls,
  tollLegs = [],
  driverNote,
}: RideReportProps) {
  return (
    <Html>
      <Head />
      <Preview>{`Ride report ${reference ?? ''} — ${passengerName ?? ''}`}</Preview>
      <Body style={main}>
        <Container style={container}>
          <Section style={header}>
            <Heading style={brand}>BLACKWAVE TRANSPORTATION</Heading>
            <Text style={headline}>RIDE REPORT</Text>
            <Text style={contactLine}>
              52 Meredith Avenue, Staten Island, NY 10314 · (917) 325-3211
            </Text>
            <Text style={contactLine}>info@rideblackwave.com · www.rideblackwave.com</Text>
          </Section>

          <Section style={section}>
            <div style={cardStyle}>
              <Row name="Reference" val={reference} />
              <Row name="Ride date" val={rideDate} />
              <Row name="Chauffeur" val={driverName} />
              <Row name="Passenger" val={passengerName} />
              <Row name="Vehicle" val={vehicle} />
            </div>

            <div style={cardStyle}>
              <Text style={label}>TIMELINE</Text>
              <Row name="En route to pickup" val={enRouteAt} />
              <Row name="Arrived at pickup" val={arrivedAtPickup} />
              <Row name="Passenger picked up" val={passengerOnBoard} />
              {legs.map((leg, i) => (
                <React.Fragment key={i}>
                  <Text style={label}>
                    {(leg.label ?? `STOP ${i + 1}`).toUpperCase()}
                    {leg.time ? ` · ${leg.time}` : ''}
                  </Text>
                  <Text style={value}>{leg.address}</Text>
                </React.Fragment>
              ))}
              <Row name="Passenger dropped off" val={droppedOff} />
            </div>

            <div style={cardStyle}>
              <Text style={label}>DISTANCE &amp; TOLLS</Text>
              <Row name="Distance driven (pickup to drop-off)" val={distanceMiles} />
              <Row name="Total tolls" val={tolls} />
              {tollLegs.length > 0 ? (
                <>
                  <Text style={label}>TOLLS BY ROUTE SECTION</Text>
                  {tollLegs.map((leg, i) => (
                    <React.Fragment key={i}>
                      <Text style={{ ...value, marginBottom: 0, fontWeight: 'bold' }}>
                        {leg.label}
                      </Text>
                      <Text style={{ ...value, margin: '0 0 4px' }}>{leg.amount}</Text>
                      {(leg.items ?? []).map((item, j) => (
                        <Text key={j} style={{ ...value, margin: '0 0 2px', color: slate }}>
                          {item}
                        </Text>
                      ))}
                      <Text style={{ ...value, margin: '0 0 10px' }}>&nbsp;</Text>
                    </React.Fragment>
                  ))}
                </>
              ) : null}
            </div>

            {driverNote ? (
              <div style={cardStyle}>
                <Text style={label}>CHAUFFEUR NOTE</Text>
                <Text style={smallNote}>{driverNote}</Text>
              </div>
            ) : null}
          </Section>
        </Container>
      </Body>
    </Html>
  )
}

export const template: TemplateEntry = {
  component: RideReportEmail,
  subject: (data) => `Ride report — ${data['reference'] ?? 'trip'} · ${data['passengerName'] ?? ''}`,
  displayName: 'Ride report',
  to: 'info@rideblackwave.com',
}

export default RideReportEmail
