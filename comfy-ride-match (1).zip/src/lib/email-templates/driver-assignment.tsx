import * as React from 'react'
import type { TemplateEntry } from './registry'
import { DriverTripEmail, type DriverTripProps } from './driver-trip-layout'

export type DriverAssignmentProps = DriverTripProps

const Email = (props: DriverAssignmentProps) => (
  <DriverTripEmail
    {...props}
    badgeText="New ride assigned"
    title="New ride assigned"
    previewText={`New ride assigned${props.pickupDate ? ` — pickup ${props.pickupDate}` : props.pickupAt ? ` — pickup ${props.pickupAt}` : ''}`}
    intro={`${props.driverName ? `Hi ${props.driverName}, ` : ''}a trip has been assigned to you${
      props.reference ? ` (confirmation ${props.reference})` : ''
    }. Please confirm it in the driver app.`}
  />
)

export const template = {
  component: Email,
  subject: (data: Record<string, any>) =>
    `New ride assigned${data['pickupDate'] ? ` — ${data['pickupDate']}` : data['pickupAt'] ? ` — ${data['pickupAt']}` : ''}`,
  displayName: 'Driver ride assignment',
  previewData: {
    driverName: 'Alex',
    reference: 'BW-1042',
    pickupDate: 'Friday, September 5, 2026',
    pickupTime: '4:30 PM',
    dropoffAt: 'Fri, Sep 5, 2026 at 5:45 PM',
    pickupAddress: '120 Park Ave, New York, NY',
    dropoffAddress: 'JFK International Airport',
    stops: ['300 Madison Ave, New York, NY'],
    passengerName: 'J. Rivera',
    passengerPhone: '(212) 555-0142',
    passengerCount: 2,
    vehicleClass: 'Executive Sedan',
    vehicleName: 'Unit 12',
    vehicleMake: 'Cadillac',
    vehicleModel: 'XTS',
    vehiclePlate: 'T123456C',
    vehicleColor: 'Black',
    airportName: 'John F. Kennedy International Airport',
    flightNumber: 'DL 402',
    flightDirection: 'departure',
    terminalLevel: 'Terminal 4',
    doorNumber: '3',
    notes: 'Passenger has two large suitcases.',
  },
} satisfies TemplateEntry
