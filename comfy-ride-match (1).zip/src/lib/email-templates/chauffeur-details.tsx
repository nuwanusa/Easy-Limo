import * as React from 'react'
import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'
import type { TemplateEntry } from './registry'

export interface ChauffeurDetailsProps {
  reference?: string
  passengerName?: string
  pickupAt?: string
  pickupAddress?: string
  driverName?: string
  driverPhone?: string
  vehicle?: string
  vehiclePlate?: string
}

const row = (label: string, value?: string) =>
  value ? (
    <table key={label} width="100%" cellPadding={0} cellSpacing={0} style={rowTable}>
      <tbody>
        <tr>
          <td style={labelCell}>{label}</td>
          <td style={valueCell}>{value}</td>
        </tr>
      </tbody>
    </table>
  ) : null

const Email = (props: ChauffeurDetailsProps) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>{`Your chauffeur${props.driverName ? ` — ${props.driverName}` : ''}`}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={heading}>Your chauffeur details</Heading>
        <Text style={intro}>
          Here are the chauffeur and vehicle details for your ride with Blackwave Transportation.
        </Text>
        <Section style={card}>
          {row('Chauffeur', props.driverName)}
          {row('Contact', props.driverPhone)}
          {row('Vehicle', props.vehicle)}
          {row('License plate', props.vehiclePlate)}
        </Section>
        <Section style={card}>
          {row('Reservation', props.reference)}
          {row('Passenger', props.passengerName)}
          {row('Pickup', props.pickupAt)}
          {row('Pickup location', props.pickupAddress)}
        </Section>
        <Text style={footer}>Blackwave Transportation LLC</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: (data: Record<string, any>) =>
    `Your chauffeur details${data['reference'] ? ` — ${data['reference']}` : ''}`,
  displayName: 'Chauffeur & vehicle details',
  previewData: {
    reference: 'BW-1042',
    passengerName: 'J. Rivera',
    pickupAt: 'Friday, September 5, 2026 at 4:30 PM',
    pickupAddress: '120 Park Ave, New York, NY',
    driverName: 'Alex Moreno',
    driverPhone: '(212) 555-0142',
    vehicle: 'Black Cadillac Escalade',
    vehiclePlate: 'T123456C',
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, Helvetica, sans-serif' }
const container = { padding: '24px', maxWidth: '600px' }
const heading = { fontSize: '22px', margin: '0 0 8px', color: '#0b1220' }
const intro = { fontSize: '14px', color: '#475569', margin: '0 0 16px' }
const card = {
  border: '1px solid #dbe4f0',
  backgroundColor: '#f4f8ff',
  borderRadius: '8px',
  padding: '12px 14px',
  marginBottom: '12px',
}
const rowTable = { marginBottom: '6px' }
const labelCell = {
  fontSize: '11px',
  textTransform: 'uppercase' as const,
  letterSpacing: '1px',
  color: '#64748b',
  width: '40%',
  verticalAlign: 'top' as const,
  padding: '3px 0',
}
const valueCell = {
  fontSize: '14px',
  color: '#0b1220',
  fontWeight: 'bold' as const,
  padding: '3px 0',
}
const footer = { fontSize: '12px', color: '#64748b', marginTop: '16px' }
