import * as React from 'react'
import type { TemplateEntry } from './registry'
import { DriverTripEmail, type DriverTripProps } from './driver-trip-layout'

export type DriverConfirmationProps = DriverTripProps

const Email = (props: DriverConfirmationProps) => (
  <DriverTripEmail
    {...props}
    badgeText="Ride confirmed"
    title="Your trip is confirmed"
    previewText={`Ride confirmed${props.pickupDate ? ` — ${props.pickupDate}` : props.pickupAt ? ` — ${props.pickupAt}` : ''}`}
    intro={`${props.driverName ? `Thanks ${props.driverName}, ` : ''}you have confirmed this trip${
      props.reference ? ` (confirmation ${props.reference})` : ''
    }. Here are your final details.`}
  />
)

export const template = {
  component: Email,
  subject: (data: Record<string, any>) =>
    `Ride confirmed${data['pickupDate'] ? ` — ${data['pickupDate']}` : data['pickupAt'] ? ` — ${data['pickupAt']}` : ''}`,
  displayName: 'Driver ride confirmation',
  previewData: {
    driverName: 'Alex',
    reference: 'BW-1042',
    pickupDate: 'Friday, September 5, 2026',
    pickupTime: '4:30 PM',
    dropoffAt: 'Fri, Sep 5, 2026 at 5:45 PM',
    pickupAddress: '120 Park Ave, New York, NY',
    dropoffAddress: 'JFK International Airport',
    stops: ['300 Madison Ave, New York, NY'],
    passengerName: 'J. Rivera',
    passengerPhone: '(212) 555-0142',
    passengerCount: 2,
    vehicleClass: 'Executive Sedan',
    vehicleName: 'Unit 12',
    vehicleMake: 'Cadillac',
    vehicleModel: 'XTS',
    vehiclePlate: 'T123456C',
    vehicleColor: 'Black',
    airportName: 'John F. Kennedy International Airport',
    flightNumber: 'DL 402',
    flightDirection: 'departure',
    terminalLevel: 'Terminal 4',
    doorNumber: '3',
    notes: 'Passenger has two large suitcases.',
  },
} satisfies TemplateEntry
