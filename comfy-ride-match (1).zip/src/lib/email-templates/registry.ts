import type { ComponentType } from 'react'
import { template as driverAssignment } from './driver-assignment'
import { template as driverConfirmation } from './driver-confirmation'
import { template as clientInvoice } from './client-invoice'
import { template as driverPayment } from './driver-payment'
import { template as paymentReceipt } from './payment-receipt'
import { template as clientTripNotice } from './client-trip-notice'
import { template as clientQuote } from './client-quote'
import { template as rideReport } from './ride-report'
import { template as chauffeurDetails } from './chauffeur-details'
import { template as rideTrackLink } from './ride-track-link'
import { template as affiliateStatement } from './affiliate-statement'

export interface TemplateEntry {
  component: ComponentType<any>
  subject: string | ((data: Record<string, any>) => string)
  displayName?: string
  previewData?: Record<string, any>
  /** Fixed recipient — overrides caller-provided recipientEmail when set. */
  to?: string
}

/**
 * Template registry — maps template names to their React Email components.
 * Import and register new templates here after creating them in this directory.
 *
 * Example:
 *   import { template as welcomeTemplate } from './welcome'
 *   // then add to TEMPLATES: 'welcome': welcomeTemplate
 */
export const TEMPLATES: Record<string, TemplateEntry> = {
  'driver-assignment': driverAssignment,
  'driver-confirmation': driverConfirmation,
  'client-invoice': clientInvoice,
  'driver-payment': driverPayment,
  'payment-receipt': paymentReceipt,
  'client-trip-notice': clientTripNotice,
  'client-quote': clientQuote,
  'ride-report': rideReport,
  'chauffeur-details': chauffeurDetails,
  'ride-track-link': rideTrackLink,
  'affiliate-statement': affiliateStatement,
}
