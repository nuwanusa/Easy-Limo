import * as React from 'react'
import {
  Body,
  Column,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Row,
  Section,
  Text,
} from '@react-email/components'
import type { TemplateEntry } from './registry'

export interface PaymentTripRow {
  date?: string
  pickupTime?: string
  dropoffTime?: string
  passenger?: string
  route?: string
  vehicle?: string
  flatRate?: string
  waitingTime?: string
  hourlyRate?: string
  distance?: string
  amount?: string
}

export interface PaymentReceiptProps {
  /** "Client" receipt or the internal dispatch alert. */
  audience?: 'client' | 'dispatch'
  clientName?: string
  reference?: string
  description?: string
  amount?: string
  paidOn?: string
  cardBrand?: string
  last4?: string
  /** Manual payment method label, e.g. "Zelle". */
  method?: string
  /** Full invoice detail */
  trips?: PaymentTripRow[]
  charges?: Array<{ label?: string; amount?: string }>
  subtotal?: string
  discount?: string
  totalPaid?: string
  /** "full" or "partial" — shown in the banner and subject. */
  paymentStatus?: 'full' | 'partial'
  balanceDue?: string
  period?: string
  tripCount?: string
}

const navy = '#0b3a75'
const navyMid = '#0b3a75'
const blue = '#1665d8'
const soft = '#eef4fd'
const border = '#d7e4f7'
const muted = '#5b7391'

const th: React.CSSProperties = {
  background: navy,
  color: '#ffffff',
  fontSize: '11px',
  letterSpacing: '0.6px',
  textTransform: 'uppercase',
  padding: '10px 10px',
  textAlign: 'left',
  borderRight: '1px solid #1d3a6d',
}

const td: React.CSSProperties = {
  fontSize: '13px',
  color: navy,
  padding: '10px',
  borderBottom: `1px solid ${border}`,
  borderRight: `1px solid ${border}`,
  verticalAlign: 'top',
}

export function PaymentReceipt({
  audience = 'client',
  clientName,
  reference,
  description,
  amount,
  paidOn,
  cardBrand,
  last4,
  method,
  trips,
  charges,
  subtotal,
  discount,
  totalPaid,
  period,
  tripCount,
  paymentStatus,
  balanceDue,
}: PaymentReceiptProps) {
  const isDispatch = audience === 'dispatch'
  const meta: Array<[string, string | undefined]> = [
    ['Reference', reference],
    ['Description', description],
    ['Billing period', period],
    ['Trips', tripCount],
    ['Paid on', paidOn],
    ['Payment method', method],
    ['Card', cardBrand && last4 ? `${cardBrand} ending ${last4}` : undefined],
    ['Status', paymentStatus === 'full' ? 'Paid in full' : paymentStatus === 'partial' ? 'Paid partially' : undefined],
    ['Balance due', paymentStatus === 'partial' ? balanceDue : '$0.00'],
  ]

  return (
    <Html>
      <Head />
      <Preview>
        {isDispatch
          ? `Payment received ${amount ?? ''}`
          : `Payment received. Thank you — ${amount ?? ''}`}
      </Preview>
      <Body
        style={{
          backgroundColor: '#eef2fa',
          margin: 0,
          padding: '24px 0',
          fontFamily: 'Arial, Helvetica, sans-serif',
        }}
      >
        <Container style={{ width: '100%', maxWidth: '1800px', margin: '0 auto' }}>
          {/* Header */}
          <Section
            style={{
              background: navy,
              backgroundImage: `linear-gradient(90deg, ${navy}, ${navyMid})`,
              borderRadius: '12px 12px 0 0',
              padding: '26px 30px',
            }}
          >
            <Row>
              <Column>
                <Heading style={{ color: '#ffffff', fontSize: '22px', margin: 0, letterSpacing: '0.5px' }}>
                  BlackWave Transportation
                </Heading>
                <Text style={{ color: '#b8cdf7', fontSize: '12px', margin: '6px 0 0', lineHeight: '18px' }}>
                  52 Meredith Avenue, Staten Island, NY 10314
                  <br />
                  (917) 325-3211 · info@rideblackwave.com · www.rideblackwave.com
                </Text>
              </Column>
              <Column style={{ textAlign: 'right' }}>
                <Text
                  style={{
                    color: '#b8cdf7',
                    fontSize: '11px',
                    margin: 0,
                    textTransform: 'uppercase',
                    letterSpacing: '1.4px',
                  }}
                >
                  Payment receipt
                </Text>
                <Text style={{ color: '#ffffff', fontSize: '20px', fontWeight: 'bold', margin: '4px 0 0' }}>
                  {reference ?? ''}
                </Text>
              </Column>
            </Row>
          </Section>

          {/* Paid in full banner directly under header */}
          <Section
            style={{
              background: '#0f7a4d',
              backgroundImage: 'linear-gradient(90deg, #0f7a4d, #14a06a)',
              padding: '14px 30px',
              textAlign: 'center',
            }}
          >
            <Text
              style={{
                color: '#ffffff',
                fontSize: '18px',
                fontWeight: 'bold',
                margin: 0,
                letterSpacing: '1px',
              }}
            >
              {paymentStatus === 'partial'
                ? `PARTIAL PAYMENT RECEIVED${balanceDue ? ` · BALANCE DUE ${balanceDue}` : ''}`
                : paymentStatus === 'full'
                  ? 'INVOICE PAID IN FULL. THANK YOU.'
                  : 'PAYMENT RECEIVED. THANK YOU.'}
            </Text>
          </Section>

          <Section
            style={{
              background: '#ffffff',
              padding: '26px 30px',
              border: `1px solid ${border}`,
              borderTop: 'none',
            }}
          >
            <Text style={{ color: navy, fontSize: '15px', margin: '0 0 18px' }}>
              {isDispatch
                ? `A payment was completed${clientName ? ` by ${clientName}` : ''}${method ? ` via ${method}` : ''}.`
                : `Thank you${clientName ? `, ${clientName}` : ''}. Your payment has been received.`}
            </Text>

            <Row>
              <Column style={{ width: '58%', verticalAlign: 'top', paddingRight: '14px' }}>
                <Section
                  style={{
                    background: soft,
                    border: `1px solid ${border}`,
                    borderRadius: '10px',
                    padding: '16px 18px',
                  }}
                >
                  {meta
                    .filter(([, value]) => Boolean(value))
                    .map(([label, value]) => (
                      <Text key={label} style={{ color: navy, fontSize: '13px', margin: '0 0 7px' }}>
                        <span style={{ color: muted }}>{label}: </span>
                        {value}
                      </Text>
                    ))}
                </Section>
              </Column>
              <Column style={{ width: '42%', verticalAlign: 'top' }}>
                <Section
                  style={{
                    background: navy,
                    borderRadius: '10px',
                    padding: '18px 20px',
                    textAlign: 'right',
                  }}
                >
                  <Text
                    style={{
                      color: '#b8cdf7',
                      fontSize: '11px',
                      margin: 0,
                      textTransform: 'uppercase',
                      letterSpacing: '1.2px',
                    }}
                  >
                    Amount paid
                  </Text>
                  <Text style={{ color: '#ffffff', fontSize: '16px', margin: '4px 0 0' }}>
                    {totalPaid ?? amount ?? '—'}
                  </Text>
                  <Text
                    style={{
                      color: '#b8cdf7',
                      fontSize: '11px',
                      margin: '10px 0 0',
                      textTransform: 'uppercase',
                      letterSpacing: '1.2px',
                    }}
                  >
                    Amount due
                  </Text>
                  <Text
                    style={{
                      color: paymentStatus === 'partial' ? '#ffd27d' : '#7ee2a8',
                      fontSize: '32px',
                      fontWeight: 'bold',
                      margin: '4px 0 0',
                    }}
                  >
                    {paymentStatus === 'partial' ? balanceDue ?? '—' : '$0.00'}
                  </Text>
                </Section>
              </Column>
            </Row>

            {trips && trips.length > 0 && (
              <Section style={{ paddingTop: '24px' }}>
                <Text
                  style={{
                    color: navy,
                    fontSize: '13px',
                    fontWeight: 'bold',
                    margin: '0 0 10px',
                    textTransform: 'uppercase',
                    letterSpacing: '1px',
                  }}
                >
                  Trip details
                </Text>
                <table
                  width="100%"
                  cellPadding={0}
                  cellSpacing={0}
                  style={{ borderCollapse: 'collapse', border: `1px solid ${border}`, width: '100%' }}
                >
                  <thead>
                    <tr>
                      <th style={th}>Date</th>
                      <th style={th}>Pickup</th>
                      <th style={th}>Drop-off</th>
                      <th style={th}>Passenger</th>
                      <th style={th}>Route</th>
                      <th style={th}>Vehicle</th>
                      <th style={th}>Flat</th>
                      <th style={th}>Waiting</th>
                      <th style={th}>Hourly</th>
                      <th style={th}>Distance</th>
                      <th style={{ ...th, textAlign: 'right', borderRight: 'none' }}>Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {trips.map((t, i) => (
                      <tr key={i} style={{ background: i % 2 ? '#f7faff' : '#ffffff' }}>
                        <td style={td}>{t.date ?? '—'}</td>
                        <td style={td}>{t.pickupTime ?? '—'}</td>
                        <td style={td}>{t.dropoffTime ?? '—'}</td>
                        <td style={td}>{t.passenger ?? '—'}</td>
                        <td style={{ ...td, fontSize: '12px' }}>{t.route ?? '—'}</td>
                        <td style={td}>{t.vehicle ?? '—'}</td>
                        <td style={td}>{t.flatRate ?? '—'}</td>
                        <td style={td}>{t.waitingTime ?? '—'}</td>
                        <td style={td}>{t.hourlyRate ?? '—'}</td>
                        <td style={td}>{t.distance ?? '—'}</td>
                        <td style={{ ...td, textAlign: 'right', fontWeight: 'bold', borderRight: 'none' }}>
                          {t.amount ?? '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Section>
            )}

            {charges && charges.length > 0 && (
              <Section style={{ paddingTop: '22px' }}>
                <Row>
                  <Column style={{ width: '55%' }} />
                  <Column style={{ width: '45%', verticalAlign: 'top' }}>
                    <Section
                      style={{
                        background: soft,
                        border: `1px solid ${border}`,
                        borderRadius: '10px',
                        padding: '14px 18px',
                      }}
                    >
                      {charges.map((c, i) => (
                        <Row key={i}>
                          <Column>
                            <Text style={{ color: muted, fontSize: '13px', margin: '0 0 6px' }}>{c.label}</Text>
                          </Column>
                          <Column style={{ textAlign: 'right' }}>
                            <Text style={{ color: navy, fontSize: '13px', margin: '0 0 6px' }}>{c.amount}</Text>
                          </Column>
                        </Row>
                      ))}
                      {subtotal && (
                        <Row>
                          <Column>
                            <Text style={{ color: navy, fontSize: '13px', fontWeight: 'bold', margin: '6px 0 0' }}>
                              Subtotal
                            </Text>
                          </Column>
                          <Column style={{ textAlign: 'right' }}>
                            <Text style={{ color: navy, fontSize: '13px', fontWeight: 'bold', margin: '6px 0 0' }}>
                              {subtotal}
                            </Text>
                          </Column>
                        </Row>
                      )}
                      {discount && (
                        <Row>
                          <Column>
                            <Text style={{ color: muted, fontSize: '13px', margin: '6px 0 0' }}>Discount</Text>
                          </Column>
                          <Column style={{ textAlign: 'right' }}>
                            <Text style={{ color: muted, fontSize: '13px', margin: '6px 0 0' }}>-{discount}</Text>
                          </Column>
                        </Row>
                      )}
                      <Row>
                        <Column>
                          <Text style={{ color: blue, fontSize: '15px', fontWeight: 'bold', margin: '10px 0 0' }}>
                            Total paid
                          </Text>
                        </Column>
                        <Column style={{ textAlign: 'right' }}>
                          <Text style={{ color: blue, fontSize: '15px', fontWeight: 'bold', margin: '10px 0 0' }}>
                            {totalPaid ?? amount ?? '—'}
                          </Text>
                        </Column>
                      </Row>
                      <Row>
                        <Column>
                          <Text style={{ color: navy, fontSize: '15px', fontWeight: 'bold', margin: '8px 0 0' }}>
                            Amount due
                          </Text>
                        </Column>
                        <Column style={{ textAlign: 'right' }}>
                          <Text
                            style={{
                              color: navy,
                              fontSize: '15px',
                              fontWeight: 'bold',
                              margin: '8px 0 0',
                            }}
                          >
                            {paymentStatus === 'partial' ? balanceDue ?? '—' : '$0.00'}
                          </Text>
                        </Column>
                      </Row>
                    </Section>
                  </Column>
                </Row>
              </Section>
            )}

            {!isDispatch && (
              <Text style={{ color: '#41567f', fontSize: '13px', margin: '22px 0 0', lineHeight: '20px' }}>
                Thank you for choosing BlackWave Transportation. We appreciate your business and look forward to serving
                you again. For reservations or inquiries, please contact us at info@rideblackwave.com.
              </Text>
            )}
          </Section>

          <Section
            style={{
              background: '#f0f4fc',
              border: `1px solid ${border}`,
              borderTop: 'none',
              borderRadius: '0 0 12px 12px',
              padding: '16px 30px',
            }}
          >
            <Text style={{ color: muted, fontSize: '12px', margin: 0 }}>
              BlackWave Transportation LLC · 52 Meredith Avenue, Staten Island, NY 10314 · (917) 325-3211 ·
              www.rideblackwave.com
            </Text>
          </Section>
        </Container>
      </Body>
    </Html>
  )
}

export const template = {
  component: PaymentReceipt,
  subject: (data: Record<string, any>) =>
    data['paymentStatus'] === 'full'
      ? `Invoice paid in full${data['amount'] ? ` — ${data['amount']}` : ''}${data['reference'] ? ` (${data['reference']})` : ''}`
      : data['paymentStatus'] === 'partial'
      ? `Invoice paid partially${data['amount'] ? ` — ${data['amount']}` : ''}${data['reference'] ? ` (${data['reference']})` : ''}`
      : data['audience'] === 'dispatch'
      ? `Payment received${data['amount'] ? ` — ${data['amount']}` : ''}${data['reference'] ? ` (${data['reference']})` : ''}`
      : `Payment received${data['reference'] ? ` — ${data['reference']}` : ''} · BlackWave Transportation`,
  displayName: 'Payment receipt',
  previewData: {
    audience: 'client',
    clientName: 'Northline Capital',
    reference: 'INV-1003',
    description: 'Invoice INV-1003 — Northline Capital',
    amount: '$420.00',
    totalPaid: '$420.00',
    subtotal: '$420.00',
    tripCount: '2',
    period: 'Mar 1, 2026 – Mar 31, 2026',
    paidOn: 'September 5, 2026',
    method: 'Zelle',
    trips: [
      {
        date: 'Mar 3, 2026',
        pickupTime: '9:00 AM',
        dropoffTime: '10:05 AM',
        passenger: 'J. Rivera',
        route: 'PU: 12 Wall St → DO: JFK Terminal 4',
        vehicle: 'Sedan',
        flatRate: '$220.00',
        waitingTime: '—',
        hourlyRate: '—',
        distance: '18 mi',
        amount: '$220.00',
      },
    ],
    charges: [{ label: 'Flat rate rides (2)', amount: '$420.00' }],
  },
} satisfies TemplateEntry
