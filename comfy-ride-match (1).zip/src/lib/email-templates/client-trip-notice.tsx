import React from 'react'
import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'
import type { TemplateEntry } from './registry'

export interface ClientTripNoticeProps {
  kind?: 'reservation' | 'accepted' | 'reminder'
  headline?: string
  intro?: string
  greetingName?: string
  clientName?: string
  clientPhone?: string
  reference?: string
  pickupDate?: string
  pickupTime?: string
  dropoffTime?: string
  pickupAddress?: string
  dropoffAddress?: string
  stops?: string[]
  passengerName?: string
  passengerPhone?: string
  passengerCount?: string
  vehicleClass?: string
  paymentMethod?: string
  driverName?: string
  driverPhone?: string
  vehicle?: string
  vehiclePlate?: string
  vehicleColor?: string
  airportName?: string
  airline?: string
  flightNumber?: string
  flightDirection?: string
  terminalLevel?: string
  doorNumber?: string
  bookingType?: string
  onMyWayAt?: string
  arrivedAtPickupAt?: string
  passengerOnBoardAt?: string
  droppedOffAt?: string
  waitingTime?: string
  distance?: string
  fareRows?: { label: string; amount: string; muted?: boolean }[]
  fareTotal?: string
}

const navy = '#0B1F3B'
const blue = '#1D4ED8'
const soft = '#EFF4FF'

const Row = ({
  label,
  value,
  nowrapLabel,
}: {
  label: string
  value?: string | null | undefined
  nowrapLabel?: boolean
}) =>
  value ? (
    <tr>
      <td
        className={nowrapLabel ? 'detail-label detail-label-nowrap' : 'detail-label'}
        style={{
          padding: '7px 0',
          fontSize: nowrapLabel ? '11px' : '12px',
          letterSpacing: nowrapLabel ? '0.05em' : '0.08em',
          textTransform: 'uppercase',
          color: '#64748B',
          width: nowrapLabel ? undefined : '34%',
          whiteSpace: nowrapLabel ? 'nowrap' : undefined,
          verticalAlign: 'top',
        }}
      >
        {label}
      </td>
      <td
        className="detail-value"
        style={{
          padding: '7px 0 7px 12px',
          fontSize: '15px',
          color: '#0F172A',
          fontWeight: 600,
          overflowWrap: 'anywhere',
          verticalAlign: 'top',
        }}
      >
        {value}
      </td>
    </tr>
  ) : null

const Card = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <table
    width="100%"
    cellPadding={0}
    cellSpacing={0}
    style={{
      backgroundColor: soft,
      border: '1px solid #DBEAFE',
      borderRadius: '10px',
      borderCollapse: 'separate',
      height: '100%',
    }}
  >
    <tbody>
      <tr>
        <td style={{ padding: '16px 20px', verticalAlign: 'top' }}>
          <Text
            style={{
              margin: '0 0 6px',
              fontSize: '12px',
              letterSpacing: '0.16em',
              textTransform: 'uppercase',
              color: blue,
              fontWeight: 700,
            }}
          >
            {title}
          </Text>
          <table width="100%" cellPadding={0} cellSpacing={0}>
            <tbody>{children}</tbody>
          </table>
        </td>
      </tr>
    </tbody>
  </table>
)

const cellLeft = {
  width: '50%',
  height: '100%',
  verticalAlign: 'top' as const,
  paddingRight: '7px',
  paddingBottom: '14px',
}
const cellRight = {
  width: '50%',
  height: '100%',
  verticalAlign: 'top' as const,
  paddingLeft: '7px',
  paddingBottom: '14px',
}

const CardRow = ({ left, right }: { left: React.ReactNode; right: React.ReactNode }) =>
  left || right ? (
      <tr className="card-row" style={{ height: '1px' }}>
       <td className="card-cell card-cell-left" width="50%" align="left" valign="top" style={cellLeft}>
        {left}
      </td>
       <td className="card-cell card-cell-right" width="50%" align="left" valign="top" style={cellRight}>
        {right}
      </td>
    </tr>
  ) : null


const Email = (props: ClientTripNoticeProps) => {
  const {
    headline = 'Reservation confirmed',
    intro,
    greetingName,
    clientName,
    clientPhone,
    reference,
    pickupDate,
    pickupTime,
    dropoffTime,
    pickupAddress,
    dropoffAddress,
    stops = [],
    passengerName,
    passengerPhone,
    passengerCount,
    vehicleClass,
    paymentMethod,
    driverName,
    driverPhone,
    vehicle,
    vehiclePlate,
    vehicleColor,
    airportName,
    airline,
    flightNumber,
    flightDirection,
    terminalLevel,
    doorNumber,
    bookingType,
    onMyWayAt,
    arrivedAtPickupAt,
    passengerOnBoardAt,
    droppedOffAt,
    waitingTime,
    distance,
    fareRows = [],
    fareTotal,
  } = props

  const hasAirport = Boolean(airportName || airline || flightNumber || terminalLevel || doorNumber)
  const hasTimeline = Boolean(onMyWayAt || arrivedAtPickupAt || passengerOnBoardAt || droppedOffAt)
  const hasFare = fareRows.length > 0 || Boolean(fareTotal)

  return (
    <Html lang="en" dir="ltr">
      <Head>
        <style>{`
          @media only screen and (max-width: 640px) {
            .email-header { padding: 24px 20px !important; }
            .email-intro { padding: 18px 20px 4px !important; }
            .email-content { padding: 0 20px !important; }
            .email-footer { padding: 8px 20px 0 !important; }
            .card-row, .card-cell { display: block !important; width: 100% !important; height: auto !important; }
            .card-cell-left, .card-cell-right { padding-left: 0 !important; padding-right: 0 !important; padding-bottom: 12px !important; }
            .detail-label { width: 38% !important; font-size: 10px !important; line-height: 15px !important; white-space: normal !important; }
            .detail-label-nowrap { white-space: normal !important; }
            .detail-value { width: 62% !important; padding-left: 10px !important; font-size: 14px !important; line-height: 19px !important; white-space: normal !important; overflow-wrap: anywhere !important; }
          }
        `}</style>
      </Head>
      <Preview>{`${headline}${reference ? ` — ${reference}` : ''}`}</Preview>
      <Body style={{ backgroundColor: '#ffffff', fontFamily: 'Arial, Helvetica, sans-serif', margin: 0 }}>
        <Container style={{ maxWidth: '1800px', width: '100%', padding: '0 0 28px' }}>
          <Section className="email-header" style={{ backgroundColor: navy, padding: '30px 36px', borderRadius: '10px 10px 0 0' }}>
            <Text style={{ margin: 0, color: '#93C5FD', fontSize: '12px', letterSpacing: '0.28em' }}>
              BLACKWAVE TRANSPORTATION
            </Text>
            <Heading style={{ margin: '8px 0 0', color: '#FFFFFF', fontSize: '26px' }}>{headline}</Heading>
            {reference ? (
              <Text style={{ margin: '6px 0 0', color: '#BFDBFE', fontSize: '14px' }}>
                Reservation {reference}
              </Text>
            ) : null}
          </Section>

          <Section className="email-intro" style={{ padding: '22px 36px 4px' }}>
            <Text style={{ margin: '0 0 14px', fontSize: '15px', color: '#0F172A' }}>
              {greetingName || clientName ? `Hello ${greetingName ?? clientName},` : 'Hello,'} {intro}
            </Text>
          </Section>

          <Section className="email-content" style={{ padding: '0 36px' }}>
            <table
              width="100%"
              cellPadding={0}
              cellSpacing={0}
              style={{ tableLayout: 'fixed', height: '1px' }}
            >

              <tbody>
                <CardRow
                  left={
                    <Card title="Pickup & route">
                      <Row label="Pickup date" value={pickupDate} />
                      <Row label="Pickup time" value={pickupTime} />
                      <Row label="Drop-off time" value={dropoffTime} />
                      <Row label="Pickup address" value={pickupAddress} />
                      {stops.map((s, i) => (
                        <Row key={i} label={`Stop ${i + 1}`} value={s} />
                      ))}
                      <Row label="Drop-off address" value={dropoffAddress} />
                    </Card>
                  }
                  right={
                    <Card title="Client & passenger">
                      <Row label="Client" value={clientName} />
                      <Row label="Client phone" value={clientPhone} />
                      <Row label="Passenger" value={passengerName} />
                      <Row label="Passenger phone" value={passengerPhone} />
                      <Row label="Passengers" value={passengerCount} />
                      <Row label="Vehicle class" value={vehicleClass} />
                    </Card>
                  }
                />
                <CardRow
                  left={
                    <Card title="Payment">
                      <Row label="Payment method" value={paymentMethod ?? 'To be confirmed'} />
                      <Row label="Booking type" value={bookingType} />
                      <Row label="Waiting time" value={waitingTime} />
                      <Row label="Distance" value={distance} />
                    </Card>
                  }
                  right={
                    hasTimeline ? (
                      <Card title="Trip timeline">
                        <Row label="Chauffeur on the way" value={onMyWayAt} />
                        <Row label="Arrived at pickup" value={arrivedAtPickupAt} />
                        <Row label="Passenger on board" value={passengerOnBoardAt} />
                        <Row label="Dropped off" value={droppedOffAt} />
                      </Card>
                    ) : null
                  }
                />
                <CardRow
                  left={
                    hasFare ? (
                      <Card title="Fare breakdown">
                        {fareRows.map((row, i) => (
                          <Row key={i} label={row.label} value={row.amount} nowrapLabel />
                        ))}
                        {fareTotal ? (
                          <tr>
                            <td
                              style={{
                                padding: '9px 0 2px',
                                fontSize: '12px',
                                letterSpacing: '0.08em',
                                textTransform: 'uppercase',
                                color: '#0F172A',
                                fontWeight: 700,
                                borderTop: '1px solid #BFDBFE',
                                whiteSpace: 'nowrap',
                              }}
                            >
                              Total
                            </td>
                            <td
                              style={{
                                padding: '9px 0 2px',
                                fontSize: '16px',
                                color: '#0F172A',
                                fontWeight: 700,
                                borderTop: '1px solid #BFDBFE',
                              }}
                            >
                              {fareTotal}
                            </td>
                          </tr>
                        ) : null}
                      </Card>
                    ) : null
                  }
                  right={
                    driverName || vehicle ? (
                      <Card title="Chauffeur & vehicle">
                        <Row label="Chauffeur" value={driverName} />
                        <Row label="Phone" value={driverPhone} />
                        <Row label="Vehicle" value={vehicle} />
                        <Row label="Color" value={vehicleColor} />
                        <Row label="License plate" value={vehiclePlate} />
                      </Card>
                    ) : null
                  }
                />
                <CardRow
                  left={null}
                  right={
                    hasAirport ? (
                      <Card title="Airport & flight">
                        <Row label="Airport" value={airportName} />
                        <Row label="Airline" value={airline} />
                        <Row label="Flight #" value={flightNumber} />
                        <Row label="Arrival / departure" value={flightDirection} />
                        <Row label="Terminal / level" value={terminalLevel} />
                        <Row label="Door #" value={doorNumber} />
                      </Card>
                    ) : null
                  }
                />
              </tbody>
            </table>
          </Section>

          <Section className="email-footer" style={{ padding: '10px 36px 0' }}>
            <Text style={{ fontSize: '13px', color: '#475569', margin: 0 }}>
              Thank you for choosing BlackWave Transportation. We appreciate your business and look forward to
              serving you again. For reservations or inquiries, please contact us at info@rideblackwave.com.
            </Text>
          </Section>
        </Container>
      </Body>
    </Html>
  )
}

export const template = {
  component: Email,
  subject: (data: Record<string, any>) =>
    `${data?.['headline'] ?? 'Reservation update'}${data?.['reference'] ? ` — ${data['reference']}` : ''}`,
  displayName: 'Client trip notice',
  previewData: {
    kind: 'reservation',
    headline: 'Reservation confirmed',
    intro: 'your reservation has been booked. Here are the details.',
    clientName: 'Acme Corp',
    clientPhone: '(212) 555-0139',
    reference: 'AUR-1042',
    pickupDate: 'Monday, September 14, 2026',
    pickupTime: '4:30 PM',
    dropoffTime: '5:40 PM',
    pickupAddress: '11 Wall St, New York, NY',
    dropoffAddress: 'JFK Terminal 4',
    stops: ['200 Park Ave, New York, NY'],
    passengerName: 'David Miller',
    passengerPhone: '(917) 555-0110',
    passengerCount: '2',
    vehicleClass: 'sedan',
    paymentMethod: 'Credit card',
    airportName: 'John F. Kennedy International (JFK)',
    airline: 'Delta Air Lines',
    flightNumber: 'DL 405',
    flightDirection: 'Departure',
    terminalLevel: 'Terminal 4 · Level 3',
    doorNumber: 'Door 5',
  },
} satisfies TemplateEntry
