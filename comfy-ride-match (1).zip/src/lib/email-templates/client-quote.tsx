import * as React from 'react'
import {
  Body,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'
import type { TemplateEntry } from './registry'

export interface ClientQuoteProps {
  name?: string
  amount?: string
  validUntil?: string
  message?: string
  serviceType?: string
  pickupAt?: string
  pickupAddress?: string
  stops?: string[]
  dropoffAddress?: string
  passengers?: string
  luggage?: string
  vehicle?: string
  roundTrip?: boolean
  notes?: string
}

const COMPANY = {
  name: 'Blackwave Transportation LLC',
  address: '52 Meredith Avenue, Staten Island, NY 10314',
  phone: '(917) 325-3211',
  email: 'info@rideblackwave.com',
  site: 'www.rideblackwave.com',
}

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, Helvetica, sans-serif', color: '#111827' }
const container = { padding: '24px', maxWidth: '640px' }
const header = { backgroundColor: '#0b1b34', borderRadius: '8px', padding: '20px 24px', color: '#ffffff' }
const headerTitle = { color: '#ffffff', fontSize: '20px', margin: '0 0 6px' }
const headerLine = { color: '#c7d2e5', fontSize: '12px', margin: '2px 0' }
const priceBox = {
  border: '1px solid #d8b45a',
  borderRadius: '8px',
  padding: '18px 24px',
  margin: '20px 0',
  backgroundColor: '#fdf8ec',
}
const priceLabel = { fontSize: '11px', letterSpacing: '2px', textTransform: 'uppercase' as const, color: '#6b7280', margin: 0 }
const priceValue = { fontSize: '30px', fontWeight: 700, margin: '4px 0 0', color: '#0b1b34' }
const card = { border: '1px solid #e5e7eb', borderRadius: '8px', padding: '16px 20px', margin: '12px 0' }
const label = { fontSize: '11px', letterSpacing: '1.5px', textTransform: 'uppercase' as const, color: '#6b7280', margin: '0 0 2px' }
const value = { fontSize: '14px', margin: '0 0 10px', color: '#111827' }
const footer = { fontSize: '12px', color: '#6b7280', margin: '4px 0' }

const Line = ({ k, v }: { k: string; v?: string | undefined }) =>
  v ? (
    <>
      <Text style={label}>{k}</Text>
      <Text style={value}>{v}</Text>
    </>
  ) : null

const Email = ({
  name,
  amount,
  validUntil,
  message,
  serviceType,
  pickupAt,
  pickupAddress,
  stops = [],
  dropoffAddress,
  passengers,
  luggage,
  vehicle,
  roundTrip,
  notes,
}: ClientQuoteProps) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>Your Blackwave quote{amount ? ` — ${amount}` : ''}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Heading style={headerTitle}>{COMPANY.name}</Heading>
          <Text style={headerLine}>{COMPANY.address}</Text>
          <Text style={headerLine}>
            {COMPANY.phone} · {COMPANY.email} · {COMPANY.site}
          </Text>
        </Section>

        <Text style={{ fontSize: '15px', marginTop: '20px' }}>
          {name ? `Hello ${name},` : 'Hello,'}
        </Text>
        <Text style={{ fontSize: '14px', color: '#374151' }}>
          Thank you for your request. Here is your all-in quote for the trip below.
        </Text>

        <Section style={priceBox}>
          <Text style={priceLabel}>Your quote</Text>
          <Text style={priceValue}>{amount ?? '—'}</Text>
          {validUntil ? <Text style={{ ...footer, marginTop: '6px' }}>Valid until {validUntil}</Text> : null}
        </Section>

        {message ? (
          <Section style={card}>
            <Text style={{ ...value, marginBottom: 0, whiteSpace: 'pre-line' }}>{message}</Text>
          </Section>
        ) : null}

        <Section style={card}>
          <Line k="Service" v={serviceType} />
          <Line k="Pickup date & time" v={pickupAt} />
          <Line k="Pickup location" v={pickupAddress} />
          {stops.length > 0 ? <Line k="Stops" v={stops.join(' → ')} /> : null}
          <Line k="Drop-off location" v={dropoffAddress} />
          <Line k="Passengers" v={passengers} />
          <Line k="Luggage" v={luggage} />
          <Line k="Vehicle" v={vehicle} />
          {roundTrip ? <Line k="Trip" v="Round trip" /> : null}
          <Line k="Your notes" v={notes} />
        </Section>

        <Text style={{ fontSize: '14px', color: '#374151' }}>
          Reply to this email or call {COMPANY.phone} to confirm and we will reserve your chauffeur.
        </Text>

        <Hr style={{ borderColor: '#e5e7eb', margin: '20px 0' }} />
        <Text style={footer}>{COMPANY.name} · {COMPANY.address}</Text>
        <Text style={footer}>{COMPANY.phone} · {COMPANY.email} · {COMPANY.site}</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: (data: Record<string, any>) =>
    `Your Blackwave quote${data?.['amount'] ? ` — ${data['amount']}` : ''}`,
  displayName: 'Client quote',
  previewData: {
    name: 'Jane Doe',
    amount: '$285.00',
    validUntil: 'Sep 30, 2026',
    message: 'Price includes tolls, meet & greet and 60 minutes of airport wait time.',
    serviceType: 'Airport transfer',
    pickupAt: 'Fri, Sep 25, 2026 at 4:30 PM',
    pickupAddress: '52 Meredith Ave, Staten Island, NY',
    stops: ['200 Park Ave, New York, NY'],
    dropoffAddress: 'JFK International Airport, Terminal 4',
    passengers: '3',
    luggage: '4',
    vehicle: 'Luxury SUV',
    roundTrip: false,
  },
} satisfies TemplateEntry
