import * as React from 'react'
import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'
import type { TemplateEntry } from './registry'

export interface RideTrackLinkProps {
  greetingName?: string | null
  reference?: string | null
  passengerName?: string | null
  pickupAt?: string | null
  pickupAddress?: string | null
  dropoffAddress?: string | null
  trackUrl?: string
}

const row = (label: string, value?: string | null) =>
  value ? (
    <table key={label} width="100%" cellPadding={0} cellSpacing={0} style={rowTable}>
      <tbody>
        <tr>
          <td style={labelCell}>{label}</td>
          <td style={valueCell}>{value}</td>
        </tr>
      </tbody>
    </table>
  ) : null

const Email = (props: RideTrackLinkProps) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>Track your Blackwave vehicle live</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={heading}>Track your vehicle</Heading>
        <Text style={intro}>
          {props.greetingName ? `Hello ${props.greetingName}, ` : ''}
          you can follow your Blackwave vehicle live on the map with the link below.
        </Text>
        <Section style={{ margin: '0 0 18px' }}>
          <Button href={props.trackUrl} style={button}>
            Open live map
          </Button>
        </Section>
        <Text style={linkText}>{props.trackUrl}</Text>
        <Section style={card}>
          {row('Reservation', props.reference)}
          {row('Passenger', props.passengerName)}
          {row('Pickup', props.pickupAt)}
          {row('Pickup location', props.pickupAddress)}
          {row('Drop-off', props.dropoffAddress)}
        </Section>
        <Text style={footer}>Blackwave Transportation LLC</Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: (data: Record<string, any>) =>
    `Track your vehicle${data['reference'] ? ` — ${data['reference']}` : ''} — Blackwave Transportation`,
  displayName: 'Passenger tracking link',
  previewData: {
    reference: 'BW-1042',
    passengerName: 'J. Rivera',
    pickupAt: 'Friday, September 25, 2026 at 4:30 PM',
    pickupAddress: '120 Park Ave, New York, NY',
    dropoffAddress: 'JFK International Airport',
    trackUrl: 'https://rideblackwave.com/t/example',
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, Helvetica, sans-serif' }
const container = { padding: '24px', maxWidth: '600px' }
const heading = { fontSize: '22px', margin: '0 0 8px', color: '#0b1220' }
const intro = { fontSize: '14px', color: '#475569', margin: '0 0 16px' }
const button = {
  backgroundColor: '#0b1220',
  color: '#ffffff',
  borderRadius: '8px',
  padding: '12px 20px',
  fontSize: '14px',
  fontWeight: 'bold' as const,
  textDecoration: 'none',
}
const linkText = { fontSize: '12px', color: '#2563eb', wordBreak: 'break-all' as const, margin: '0 0 16px' }
const card = {
  border: '1px solid #dbe4f0',
  backgroundColor: '#f4f8ff',
  borderRadius: '8px',
  padding: '12px 14px',
  marginBottom: '12px',
}
const rowTable = { marginBottom: '6px' }
const labelCell = {
  fontSize: '11px',
  textTransform: 'uppercase' as const,
  letterSpacing: '1px',
  color: '#64748b',
  width: '40%',
  verticalAlign: 'top' as const,
  padding: '3px 0',
}
const valueCell = {
  fontSize: '14px',
  color: '#0b1220',
  fontWeight: 'bold' as const,
  padding: '3px 0',
}
const footer = { fontSize: '12px', color: '#64748b', marginTop: '16px' }
