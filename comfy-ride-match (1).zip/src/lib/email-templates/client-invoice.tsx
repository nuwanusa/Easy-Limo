import * as React from 'react'
import { Body, Container, Head, Html, Preview, Section, Text } from '@react-email/components'
import type { TemplateEntry } from './registry'

export interface InvoiceLine {
  label: string
  amount: string
}

export interface InvoiceTrip {
  date?: string
  pickupTime?: string
  dropoffTime?: string
  passenger?: string
  notesLine?: string
  route?: string
  vehicle?: string
  baseRate?: string
  flatRate?: string
  flatDetail?: string
  others?: string
  othersDetail?: InvoiceLine[]
  waitingTime?: string
  waitingDetail?: string
  hourlyRate?: string
  hourlyDetail?: string
  distance?: string
  amount?: string
  charges?: InvoiceLine[]
}

export interface ClientInvoiceProps {
  clientName?: string
  contactName?: string
  addressLine1?: string
  addressLine2?: string
  clientEmail?: string
  accountNumber?: string
  invoiceNumber?: string
  status?: string
  createdOn?: string
  dueDate?: string
  issuedOn?: string
  period?: string
  periodSubject?: string
  tripCount?: string
  trips?: InvoiceTrip[]
  lines?: InvoiceLine[]
  otherFees?: InvoiceLine[]
  subtotal?: string
  discount?: string
  payments?: string
  totalDue?: string
  notes?: string
  invoiceUrl?: string
  payUrl?: string
}

const NAVY = '#0b3a75'
const BLUE = '#1665d8'
const LIGHT = '#eef4fd'
const BORDER = '#d7e4f7'
const INK = '#132132'
const MUTED = '#5b7391'

const main = { backgroundColor: '#f2f6fc', fontFamily: 'Arial, Helvetica, sans-serif', padding: '24px 0' }
const container = {
  padding: '0 0 24px',
  maxWidth: '1800px',
  width: '100%',
  backgroundColor: '#ffffff',
  borderRadius: '14px',
  overflow: 'hidden' as const,
  border: `1px solid ${BORDER}`,
}
const header = { backgroundColor: NAVY, padding: '30px 32px' }
const accentBar = { height: '5px', backgroundColor: '#4d9bff', fontSize: '1px', lineHeight: '1px' }
const brand = { color: '#ffffff', fontSize: '30px', margin: '0 0 12px', fontWeight: 700 }
const headLine = { color: '#d7e7ff', fontSize: '15px', margin: '0 0 4px', lineHeight: '1.5' }
const invoiceWord = { color: '#ffffff', fontSize: '24px', margin: '0 0 10px', textAlign: 'right' as const, letterSpacing: '3px', textTransform: 'uppercase' as const }
const headRight = { color: '#d7e7ff', fontSize: '14px', margin: '0 0 3px', textAlign: 'right' as const }

const inner = { padding: '26px 32px 0' }
const billBox = { backgroundColor: LIGHT, borderLeft: `4px solid ${BLUE}`, borderRadius: '10px', padding: '14px 18px', verticalAlign: 'top' as const }
const miniLabel = { fontSize: '11px', color: BLUE, margin: '0 0 4px', letterSpacing: '1px', textTransform: 'uppercase' as const, fontWeight: 700 }
const billName = { fontSize: '14px', color: INK, margin: '0 0 2px', fontWeight: 700 }
const billMuted = { fontSize: '13px', color: MUTED, margin: '0 0 2px' }
const bigNumber = { fontSize: '28px', color: NAVY, margin: '0', fontWeight: 700 }
const colTop = { verticalAlign: 'top' as const, padding: '0 0 0 24px' }

const th = {
  fontSize: '10px',
  letterSpacing: '1px',
  color: '#ffffff',
  textTransform: 'uppercase' as const,
  textAlign: 'left' as const,
  padding: '11px 8px',
  backgroundColor: NAVY,
  fontWeight: 700,
}
const thRight = { ...th, textAlign: 'right' as const }
const td = { fontSize: '13px', color: INK, padding: '12px 8px', borderBottom: `1px solid ${BORDER}`, verticalAlign: 'top' as const }
const tdAlt = { ...td, backgroundColor: '#f7faff' }
const tdRight = { ...td, textAlign: 'right' as const, whiteSpace: 'nowrap' as const }
const tdRightAlt = { ...tdRight, backgroundColor: '#f7faff' }
const subText = { fontSize: '11px', color: MUTED, margin: '4px 0 0', lineHeight: '1.4' }

const sectionLabel = { fontSize: '11px', color: BLUE, margin: '0 0 10px', letterSpacing: '1px', textTransform: 'uppercase' as const, fontWeight: 700 }
const rowLabel = { fontSize: '14px', color: INK, padding: '6px 0', borderBottom: `1px solid ${BORDER}` }
const rowValue = { fontSize: '14px', color: INK, padding: '6px 0', textAlign: 'right' as const, whiteSpace: 'nowrap' as const, borderBottom: `1px solid ${BORDER}` }
const payBox = { backgroundColor: LIGHT, border: `1px solid ${BORDER}`, borderRadius: '10px', padding: '14px 18px', marginTop: '20px' }
const dueBox = { backgroundColor: NAVY, padding: '18px 20px', borderRadius: '10px', marginTop: '14px' }
const dueLabel = { color: '#d7e7ff', fontSize: '13px', margin: '0', display: 'inline-block', letterSpacing: '1px', textTransform: 'uppercase' as const }
const dueValue = { color: '#ffffff', fontSize: '30px', margin: '0', textAlign: 'right' as const, fontWeight: 700 }
const payLabel = { fontSize: '15px', color: INK, fontWeight: 400, textAlign: 'left' as const, whiteSpace: 'nowrap' as const, padding: '0 12px 14px 0', verticalAlign: 'middle', lineHeight: '1.35' }
const payValue = { fontSize: '15px', color: INK, fontWeight: 400, textAlign: 'right' as const, padding: '0 0 14px', verticalAlign: 'middle', lineHeight: '1.5' }
const footer = { fontSize: '11px', color: MUTED, margin: '22px 0 0', textAlign: 'center' as const, letterSpacing: '1px' }
const detailLabel = { fontSize: '10px', color: BLUE, margin: '0 0 4px', letterSpacing: '1px', textTransform: 'uppercase' as const, fontWeight: 700 }
const detailValue = { fontSize: '14px', color: INK, margin: '0', lineHeight: '1.45', fontWeight: 700 }
const detailCell = { width: '25%', padding: '12px', verticalAlign: 'top' as const, border: `1px solid ${BORDER}`, backgroundColor: '#f7faff' }
const routeCell = { padding: '14px 16px', verticalAlign: 'top' as const, border: `1px solid ${BORDER}`, backgroundColor: LIGHT }
const chargeCell = { width: '25%', padding: '12px', verticalAlign: 'top' as const, border: `1px solid ${BORDER}` }


const Row = ({ label, value }: { label: string; value?: string | undefined }) => (
  <tr>
    <td style={rowLabel}>{label}</td>
    <td style={rowValue}>{value ?? '—'}</td>
  </tr>
)

export function ClientInvoiceEmail({
  clientName,
  contactName,
  addressLine1,
  addressLine2,
  clientEmail,
  accountNumber,
  invoiceNumber,
  createdOn,
  dueDate,
  issuedOn,
  period,
  tripCount,
  trips = [],
  lines = [],
  subtotal,
  discount,
  payments,
  totalDue,
  notes,
  invoiceUrl,
  payUrl,
}: ClientInvoiceProps) {
  return (
    <Html>
      <Head />
      <Preview>{`Billing Statement ${invoiceNumber ?? ''} from Blackwave Transportation LLC`}</Preview>
      <Body style={main}>
        <Container style={container}>
          <Section style={header}>
            <table width="100%" cellPadding={0} cellSpacing={0} style={{ width: '100%' }}>
              <tbody>
                <tr>
                  <td style={{ verticalAlign: 'top' }}>
                    <Text style={brand}>Blackwave Transportation LLC</Text>
                    <Text style={headLine}>52 Meredith Avenue</Text>
                    <Text style={headLine}>Staten Island, NY 10314</Text>
                    <Text style={headLine}>Tel: (917) 325-3211</Text>
                    <Text style={headLine}>info@rideblackwave.com</Text>
                    <Text style={headLine}>www.rideblackwave.com</Text>
                  </td>
                  <td style={{ verticalAlign: 'top' }}>
                    <Text style={invoiceWord}>Billing Statement</Text>
                    <Text style={headRight}>Statement #{invoiceNumber}</Text>
                    <Text style={headRight}>Billing period: {period ?? '—'}</Text>
                    <Text style={headRight}>Due date: {dueDate ?? 'Due on receipt'}</Text>
                    <Text style={headRight}># of trips: {tripCount ?? String(trips.length)}</Text>

                  </td>
                </tr>
              </tbody>
            </table>
          </Section>
          <Section style={accentBar}>&nbsp;</Section>


          <Section style={inner}>
            <table width="100%" cellPadding={0} cellSpacing={0} style={{ width: '100%' }}>
              <tbody>
                <tr>
                  <td width="34%" style={billBox}>
                    <Text style={miniLabel}>Bill to</Text>
                    <Text style={billName}>{contactName ?? clientName ?? '—'}</Text>
                    {contactName && clientName ? <Text style={billMuted}>{clientName}</Text> : null}
                    {addressLine1 ? <Text style={billMuted}>{addressLine1}</Text> : null}
                    {addressLine2 ? <Text style={billMuted}>{addressLine2}</Text> : null}
                  </td>
                  <td width="33%" style={colTop}>
                    <Text style={miniLabel}>Account #</Text>
                    <Text style={billName}>{accountNumber ?? '—'}</Text>
                    <Text style={{ ...miniLabel, margin: '14px 0 4px' }}>Billing period</Text>
                    <Text style={billMuted}>{period ?? '—'}</Text>
                  </td>
                  <td width="33%" style={colTop}>
                    <Text style={miniLabel}>Trips</Text>
                    <Text style={bigNumber}>{tripCount ?? String(trips.length)}</Text>
                  </td>
                </tr>
              </tbody>
            </table>

            <table
              width="100%"
              cellPadding={0}
              cellSpacing={0}
              style={{ width: '100%', marginTop: '26px', borderCollapse: 'collapse' as const }}
            >
              <thead>
                <tr>
                  <th style={th}>Date</th>
                  <th style={th}>Pickup time</th>
                  <th style={th}>Drop-off time</th>
                  <th style={th}>Passenger</th>
                  <th style={th}>Vehicle</th>
                  <th style={thRight}>Base rate</th>
                  <th style={thRight}>Flat rate</th>
                  <th style={thRight}>Others</th>
                  <th style={thRight}>Total</th>
                </tr>
              </thead>
              <tbody>
                {trips.map((t, i) => {
                  const cell = i % 2 === 1 ? tdAlt : td
                  const cellRight = i % 2 === 1 ? tdRightAlt : tdRight
                  const breakdown = t.othersDetail ?? []
                  return (
                  <tr key={i}>
                    <td style={cell}>{t.date}</td>
                    <td style={cell}>{t.pickupTime ?? '—'}</td>
                    <td style={cell}>{t.dropoffTime ?? '—'}</td>
                    <td style={cell}>
                      {t.passenger ?? '—'}
                      {t.notesLine ? <Text style={subText}>{t.notesLine}</Text> : null}
                      <Text style={subText}>
                        {t.route}
                        {t.distance && t.distance !== '—' ? ` · ${t.distance}` : ''}
                      </Text>
                      {breakdown.map((b, k) => (
                        <Text key={k} style={{ ...subText, margin: '2px 0 0' }}>{b.label}</Text>
                      ))}
                    </td>
                    <td style={cell}>{t.vehicle ?? '—'}</td>
                    <td style={cellRight}>{t.baseRate ?? '—'}</td>
                    <td style={cellRight}>
                      {t.flatRate ?? '—'}
                      {t.flatDetail ? <Text style={subText}>{t.flatDetail}</Text> : null}
                    </td>
                    <td style={cellRight}>{t.others ?? '—'}</td>
                    <td style={cellRight}>{t.amount}</td>
                  </tr>
                  )
                })}

              </tbody>
            </table>

            <table
              role="presentation"
              width="100%"
              cellPadding={0}
              cellSpacing={0}
              style={{ width: '100%', marginTop: '28px', tableLayout: 'fixed' as const }}
            >
              <tbody>
                <tr>
                  <td width="50%" style={{ width: '50%', verticalAlign: 'top', paddingRight: '10px' }}>
                    <Section style={{ ...payBox, marginTop: '0', padding: '18px 22px', height: '190px', boxSizing: 'border-box' as const }}>
                      <Text style={{ fontSize: '14px', color: INK, margin: '0 0 10px', fontWeight: 600 }}>Payment methods</Text>
                      <table width="100%" cellPadding={0} cellSpacing={0} style={{ width: '100%' }}>
                        <tbody>
                          <tr>
                            <td align="left" style={payLabel}>Zelle</td>
                            <td align="right" style={payValue}>
                              <a href="tel:+19173253211" style={{ color: INK, textDecoration: 'none' }}>917-325-3211</a>
                            </td>
                          </tr>
                          <tr>
                            <td align="left" valign="top" style={{ ...payLabel, verticalAlign: 'top' }}>ACH</td>
                            <td align="right" style={payValue}>
                              Chase Bank<br />
                              Account # 507675562<br />
                              Routing # 021000021
                            </td>
                          </tr>
                          <tr>
                            <td align="left" style={payLabel}>Venmo</td>
                            <td align="right" style={payValue}>@nuwanusa</td>
                          </tr>
                          <tr>
                            <td align="left" style={{ ...payLabel, paddingBottom: '0' }}>Cash App</td>
                            <td align="right" style={{ ...payValue, paddingBottom: '0' }}>$blackwavelimo</td>
                          </tr>
                        </tbody>
                      </table>
                    </Section>

                  </td>
                  <td width="50%" style={{ width: '50%', verticalAlign: 'top', paddingLeft: '10px' }}>
                    <Section style={{ ...payBox, marginTop: '0', padding: '18px 22px', height: '190px', boxSizing: 'border-box' as const }}>
                      <table width="100%" cellPadding={0} cellSpacing={0} style={{ width: '100%' }}>
                        <tbody>
                          <Row label="Subtotal" value={subtotal ?? totalDue} />
                          <Row label="Discount" value={discount} />
                          <Row label="Payments" value={payments} />
                        </tbody>
                      </table>
                      <Section style={dueBox}>
                        <table width="100%" cellPadding={0} cellSpacing={0} style={{ width: '100%' }}>
                          <tbody>
                            <tr>
                              <td style={{ verticalAlign: 'bottom' }}>
                                <Text style={dueLabel}>Total due</Text>
                              </td>
                              <td style={{ verticalAlign: 'bottom' }}>
                                <Text style={dueValue}>{totalDue}</Text>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </Section>
                    </Section>
                  </td>
                </tr>
              </tbody>
            </table>

            {(payUrl || invoiceUrl) ? (
              <Section style={{ marginTop: '22px' }}>
                <table
                  role="presentation"
                  width="100%"
                  cellPadding={0}
                  cellSpacing={0}
                  border={0}
                  style={{ width: '100%', tableLayout: 'fixed' as const, borderCollapse: 'collapse' as const }}
                >
                  <tbody>
                    <tr>
                      <td width="50%" align="left" style={{ width: '50%', verticalAlign: 'top', padding: '0 5px 0 0' }}>
                        {payUrl ? (
                          <table role="presentation" width="100%" cellPadding={0} cellSpacing={0} border={0} style={{ width: '100%' }}>
                            <tbody>
                              <tr>
                                <td align="center" style={{ backgroundColor: BLUE, borderRadius: '8px' }}>
                                  <a
                                    href={payUrl}
                                    style={{
                                      display: 'block',
                                      color: '#ffffff',
                                      fontSize: '15px',
                                      fontWeight: 700,
                                      padding: '15px 8px',
                                      textDecoration: 'none',
                                    }}
                                  >
                                    Pay by credit card
                                  </a>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        ) : null}
                      </td>
                      <td width="50%" align="right" style={{ width: '50%', verticalAlign: 'top', padding: '0 0 0 5px' }}>
                        {invoiceUrl ? (
                          <table role="presentation" width="100%" cellPadding={0} cellSpacing={0} border={0} style={{ width: '100%' }}>
                            <tbody>
                              <tr>
                                <td align="center" style={{ backgroundColor: NAVY, borderRadius: '8px' }}>
                                  <a
                                    href={invoiceUrl}
                                    style={{
                                      display: 'block',
                                      color: '#ffffff',
                                      fontSize: '15px',
                                      fontWeight: 700,
                                      padding: '15px 8px',
                                      textDecoration: 'none',
                                    }}
                                  >
                                    Download PDF Billing Statement
                                  </a>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        ) : null}
                      </td>
                    </tr>
                  </tbody>
                </table>
                <Text style={{ fontSize: '12px', color: MUTED, margin: '8px 0 0', textAlign: 'center' as const }}>
                  {payUrl && invoiceUrl
                    ? 'Secure card payment — a 3% processing fee is added to card payments. The PDF link opens your statement — tap Download PDF / Print to save it.'
                    : payUrl
                      ? 'Secure card payment — a 3% processing fee is added to card payments.'
                      : 'Opens your statement — tap Download PDF / Print to save it.'}
                </Text>
              </Section>
            ) : null}

            {notes ? <Text style={{ fontSize: '13px', color: '#1c2430', marginTop: '18px' }}>{notes}</Text> : null}

            <Text style={{ ...footer, fontSize: '13px', letterSpacing: '0' }}>
              Thank you for choosing BlackWave Transportation. We appreciate your business and look forward to serving you again.
            </Text>
            <Text style={{ ...footer, margin: '6px 0 0', fontSize: '13px', letterSpacing: '0' }}>
              For reservations or inquiries, please contact us at info@rideblackwave.com.
            </Text>

          </Section>
        </Container>
      </Body>
    </Html>
  )
}

export const template: TemplateEntry = {
  component: ClientInvoiceEmail,
  subject: (data) => {
    const period = String(
      data?.['periodSubject'] ?? data?.['period'] ?? '',
    ).trim()
    return period
      ? `Billing Statement - ${period} - Blackwave Transportation`
      : 'Billing Statement - Blackwave Transportation'
  },

  displayName: 'Client invoice',
}

export default ClientInvoiceEmail
