import * as React from 'react'
import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'
import type { TemplateEntry } from './registry'

export interface PaymentRide {
  date?: string
  reference?: string
  passengerName?: string
  pickupAddress?: string
  dropoffAddress?: string
  fare?: string
  parking?: string
  airportFee?: string
  waiting?: string
  total?: string
  pay?: string
}

export interface DriverPaymentProps {
  driverName?: string
  paidOn?: string
  periodLabel?: string
  rides?: PaymentRide[]
  payoutTotal?: string
  note?: string
}

const navy = '#0b1e3f'
const navyMid = '#14357a'
const blue = '#1d4ed8'
const iceBlue = '#eaf1ff'
const border = '#c9d8f5'
const slate = '#334155'

const main = {
  backgroundColor: '#ffffff',
  fontFamily: 'Segoe UI, Helvetica, Arial, sans-serif',
  padding: '0',
}
const container = { padding: '0 0 36px', maxWidth: '1800px', width: '100%' }
const header = {
  background: `linear-gradient(135deg, ${navy} 0%, ${navyMid} 55%, ${blue} 100%)`,
  backgroundColor: navyMid,
  padding: '32px 36px 28px',
}
const brand = {
  color: '#ffffff',
  fontSize: '24px',
  letterSpacing: '4px',
  margin: '0',
  fontWeight: 'bold' as const,
}
const headline = { color: '#dbeafe', fontSize: '13px', letterSpacing: '3px', margin: '6px 0 0' }
const contactLine = { color: '#e2ecff', fontSize: '12px', lineHeight: '18px', margin: '2px 0 0' }
const metaLabel = {
  color: '#bfd4ff',
  fontSize: '10px',
  letterSpacing: '2px',
  margin: '0',
  fontWeight: 'bold' as const,
}
const metaValue = { color: '#ffffff', fontSize: '15px', margin: '2px 0 0', fontWeight: 'bold' as const }
const badge = {
  display: 'inline-block',
  marginTop: '18px',
  padding: '7px 16px',
  borderRadius: '999px',
  backgroundColor: '#ffffff',
  color: navy,
  fontSize: '12px',
  letterSpacing: '2px',
  fontWeight: 'bold' as const,
}
const body = { padding: '28px 36px 0' }
const card = {
  border: `1px solid ${border}`,
  borderRadius: '12px',
  backgroundColor: '#ffffff',
  padding: '0',
  marginBottom: '22px',
  overflow: 'hidden' as const,
}
const cardTitle = {
  margin: '0',
  padding: '12px 18px',
  backgroundColor: iceBlue,
  color: navy,
  fontSize: '12px',
  letterSpacing: '2px',
  fontWeight: 'bold' as const,
  borderBottom: `1px solid ${border}`,
}
const th = {
  padding: '10px 12px',
  textAlign: 'left' as const,
  fontSize: '11px',
  letterSpacing: '1px',
  color: '#ffffff',
  backgroundColor: navy,
  whiteSpace: 'nowrap' as const,
}
const td = {
  padding: '11px 12px',
  fontSize: '13px',
  color: slate,
  borderBottom: `1px solid ${border}`,
  verticalAlign: 'top' as const,
}
const tdNum = { ...td, textAlign: 'right' as const, whiteSpace: 'nowrap' as const }
const totalCard = {
  borderRadius: '12px',
  background: `linear-gradient(135deg, ${navy} 0%, ${blue} 100%)`,
  backgroundColor: navy,
  padding: '20px 24px',
  color: '#ffffff',
}
const footer = { padding: '4px 36px 0', color: '#64748b', fontSize: '12px', lineHeight: '20px' }

const dash = (v?: string) => (v && v.trim() ? v : '—')

const Email = ({
  driverName,
  paidOn,
  periodLabel,
  rides = [],
  payoutTotal,
  note,
}: DriverPaymentProps) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>{`Payment sent${payoutTotal ? ` — ${payoutTotal}` : ''} for your completed trips`}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <table width="100%" cellPadding={0} cellSpacing={0} style={{ width: '100%' }}>
            <tbody>
              <tr>
                <td style={{ verticalAlign: 'top' }}>
                  <Heading style={brand}>BLACKWAVE TRANSPORTATION LLC</Heading>
                  <Text style={headline}>CHAUFFEUR PAYMENT STATEMENT</Text>
                  <Text style={contactLine}>52 Meredith Avenue, Staten Island, NY 10314</Text>
                  <Text style={contactLine}>Tel: (917) 325-3211</Text>
                  <Text style={contactLine}>info@rideblackwave.com</Text>
                  <Text style={contactLine}>www.rideblackwave.com</Text>
                  <Text style={badge}>PAYMENT SENT</Text>
                </td>
                <td style={{ verticalAlign: 'top', textAlign: 'right' }}>
                  <Text style={metaLabel}>PAYMENT PERIOD</Text>
                  <Text style={metaValue}>{dash(periodLabel)}</Text>
                  <Text style={{ ...metaLabel, marginTop: '12px' }}>TOTAL TRIPS PAID</Text>
                  <Text style={metaValue}>{rides.length}</Text>
                  {paidOn ? (
                    <>
                      <Text style={{ ...metaLabel, marginTop: '12px' }}>PAID ON</Text>
                      <Text style={metaValue}>{paidOn}</Text>
                    </>
                  ) : null}
                </td>
              </tr>
            </tbody>
          </table>
        </Section>

        <Section style={body}>
          <Text style={{ fontSize: '15px', color: slate, margin: '0 0 18px' }}>
            {driverName ? `Hi ${driverName},` : 'Hi,'} your payment for the completed trips below has
            been sent{paidOn ? ` on ${paidOn}` : ''}.{periodLabel ? ` Period: ${periodLabel}.` : ''}
          </Text>

          <Section style={card}>
            <Text style={cardTitle}>COMPLETED RESERVATIONS</Text>
            <table width="100%" cellPadding={0} cellSpacing={0} style={{ borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  <th style={th}>Date</th>
                  <th style={th}>Reservation #</th>
                  <th style={th}>Passenger</th>
                  <th style={th}>Pickup</th>
                  <th style={th}>Drop-off</th>
                  <th style={{ ...th, textAlign: 'right' }}>Parking</th>
                  <th style={{ ...th, textAlign: 'right' }}>Airport fee</th>
                  <th style={{ ...th, textAlign: 'right' }}>Waiting</th>
                  <th style={{ ...th, textAlign: 'right' }}>Your pay</th>
                </tr>
              </thead>
              <tbody>
                {rides.map((r, i) => (
                  <tr key={`${r.reference ?? i}`} style={{ backgroundColor: i % 2 ? iceBlue : '#ffffff' }}>
                    <td style={td}>{dash(r.date)}</td>
                    <td style={{ ...td, fontWeight: 'bold', color: navy }}>{dash(r.reference)}</td>
                    <td style={td}>{dash(r.passengerName)}</td>
                    <td style={td}>{dash(r.pickupAddress)}</td>
                    <td style={td}>{dash(r.dropoffAddress)}</td>
                    <td style={tdNum}>{dash(r.parking)}</td>
                    <td style={tdNum}>{dash(r.airportFee)}</td>
                    <td style={tdNum}>{dash(r.waiting)}</td>
                    <td style={{ ...tdNum, fontWeight: 'bold', color: blue }}>{dash(r.pay)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Section>

          <Section style={totalCard}>
            <Text style={{ margin: '0', fontSize: '12px', letterSpacing: '2px', color: '#dbeafe' }}>
              TRIPS PAID: {rides.length}
            </Text>
            <Text style={{ margin: '6px 0 0', fontSize: '13px', letterSpacing: '2px', color: '#dbeafe' }}>
              PAYMENT SENT TO YOU
            </Text>
            <Text style={{ margin: '2px 0 0', fontSize: '34px', fontWeight: 'bold', color: '#ffffff' }}>
              {payoutTotal ?? '—'}
            </Text>
          </Section>

          {note ? (
            <Section style={{ ...card, padding: '16px 18px', marginTop: '22px' }}>
              <Text style={{ margin: '0', fontSize: '13px', color: slate }}>{note}</Text>
            </Section>
          ) : null}
        </Section>

        <Section style={footer}>
          <Text style={{ margin: '18px 0 0' }}>
            Thank you for driving with BlackWave Transportation. Questions about this payment? Contact
            us at info@rideblackwave.com.
          </Text>
        </Section>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: Email,
  subject: (data: Record<string, any>) =>
    `BlackWave Transportation – Payment sent${data['payoutTotal'] ? ` (${data['payoutTotal']})` : ''}`,
  displayName: 'Driver payment statement',
  previewData: {
    driverName: 'Alex',
    paidOn: 'September 5, 2026',
    periodLabel: 'August 2026',
    payoutTotal: '$420',
    rides: [
      {
        date: 'Aug 12, 2026 · 4:30 PM',
        reference: 'BW-1042',
        passengerName: 'J. Rivera',
        pickupAddress: 'JFK Terminal 4',
        dropoffAddress: '230 Park Ave, New York',
        fare: '$180',
        parking: '$10',
        airportFee: '$15',
        waiting: '$25',
        total: '$230',
        pay: '$115',
      },
    ],
  },
} satisfies TemplateEntry
