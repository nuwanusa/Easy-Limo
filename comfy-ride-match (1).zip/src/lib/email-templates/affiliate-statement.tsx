import * as React from 'react'
import { Body, Container, Head, Heading, Html, Preview, Section, Text } from '@react-email/components'
import type { TemplateEntry } from './registry'

export interface AffiliateStatementLine {
  reference?: string
  date?: string
  route?: string
  kind?: string
  amount?: string
}

export interface AffiliateStatementProps {
  partnerName?: string
  statementNumber?: string
  period?: string
  total?: string
  lines?: AffiliateStatementLine[]
}

const COMPANY = {
  name: 'Blackwave Transportation LLC',
  address: '52 Meredith Avenue, Staten Island, NY 10314',
  phone: '(917) 325-3211',
  email: 'info@rideblackwave.com',
}

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, Helvetica, sans-serif', color: '#111827' }
const container = { padding: '24px', maxWidth: '640px' }
const header = { backgroundColor: '#0b1b34', borderRadius: '8px', padding: '20px 24px', color: '#ffffff' }
const headerTitle = { color: '#ffffff', fontSize: '20px', margin: '0 0 6px' }
const headerLine = { color: '#c7d2e5', fontSize: '12px', margin: '2px 0' }
const card = {
  border: '1px solid #cfe0f5',
  backgroundColor: '#f2f7fd',
  borderRadius: '8px',
  padding: '16px 20px',
  margin: '16px 0',
}
const label = { fontSize: '11px', letterSpacing: '1.5px', textTransform: 'uppercase' as const, color: '#6b7280', margin: '0 0 2px' }
const value = { fontSize: '14px', margin: '0 0 10px', color: '#111827' }
const totalValue = { fontSize: '26px', fontWeight: 700, margin: '4px 0 0', color: '#0b1b34' }
const footer = { fontSize: '12px', color: '#6b7280', margin: '4px 0' }

const Email = ({ partnerName, statementNumber, period, total, lines = [] }: AffiliateStatementProps) => (
  <Html>
    <Head />
    <Preview>{`Statement ${statementNumber ?? ''} — ${COMPANY.name}`}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Heading style={headerTitle}>Partner statement</Heading>
          <Text style={headerLine}>{COMPANY.name}</Text>
          <Text style={headerLine}>{COMPANY.address}</Text>
        </Section>

        <Text style={{ fontSize: '14px', margin: '18px 0 0' }}>Hello {partnerName ?? 'Partner'},</Text>
        <Text style={{ fontSize: '14px', margin: '6px 0 0' }}>
          Here is your statement for the rides below.
        </Text>

        <Section style={card}>
          <Text style={label}>Statement</Text>
          <Text style={value}>{statementNumber}</Text>
          {period ? (
            <>
              <Text style={label}>Billing period</Text>
              <Text style={value}>{period}</Text>
            </>
          ) : null}
          <Text style={label}>Amount due to you</Text>
          <Text style={totalValue}>{total}</Text>
        </Section>

        <table width="100%" cellPadding={0} cellSpacing={0} style={{ borderCollapse: 'collapse', margin: '8px 0 18px' }}>
          <tbody>
            {lines.map((line, i) => (
              <tr key={i}>
                <td style={{ padding: '10px 0', borderBottom: '1px solid #e5e7eb', fontSize: '13px' }}>
                  <strong style={{ whiteSpace: 'nowrap' }}>{line.reference}</strong>
                  <span style={{ color: '#6b7280' }}>{line.date ? ` · ${line.date}` : ''}</span>
                  <br />
                  <span style={{ color: '#374151' }}>{line.route}</span>
                  <br />
                  <span style={{ color: '#6b7280', fontSize: '12px' }}>{line.kind}</span>
                </td>
                <td
                  align="right"
                  style={{ padding: '10px 0', borderBottom: '1px solid #e5e7eb', fontSize: '14px', whiteSpace: 'nowrap' }}
                >
                  {line.amount}
                </td>
              </tr>
            ))}
            <tr>
              <td style={{ padding: '12px 0', fontSize: '14px', fontWeight: 700 }}>Total</td>
              <td align="right" style={{ padding: '12px 0', fontSize: '16px', fontWeight: 700, whiteSpace: 'nowrap' }}>
                {total}
              </td>
            </tr>
          </tbody>
        </table>

        <Text style={footer}>Questions? {COMPANY.phone} · {COMPANY.email}</Text>
      </Container>
    </Body>
  </Html>
)

export const template: TemplateEntry = {
  component: Email,
  displayName: 'Affiliate statement',
  subject: (data: Record<string, any>) =>
    `Statement ${data?.['statementNumber'] ?? ''}${data?.['period'] ? ` - ${data['period']}` : ''} - Blackwave Transportation`,
  previewData: {
    partnerName: 'Skyline Limo',
    statementNumber: 'AF-202612345',
    period: 'Sep 1, 2026 to Sep 30, 2026',
    total: '$480.00',
    lines: [
      { reference: 'AUR-1234', date: 'Sep 4, 2026', route: 'JFK → Manhattan', kind: 'Farm-out payout', amount: '$280.00' },
      { reference: 'AUR-1290', date: 'Sep 19, 2026', route: 'Brooklyn → LGA', kind: 'Referral commission', amount: '$200.00' },
    ],
  },
}

export default Email
