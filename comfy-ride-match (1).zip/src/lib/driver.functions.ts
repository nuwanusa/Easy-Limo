import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Links the signed-in user to a roster driver whose email matches their account
 * email. Returns the driver id when linked (or already linked), else null.
 */
export const linkDriverAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const userId = context.userId;
    const email = (context.claims as { email?: string } | null)?.email?.toLowerCase() ?? null;

    const { data: existing } = await supabaseAdmin
      .from("drivers")
      .select("id")
      .eq("user_id", userId)
      .maybeSingle();
    if (existing) return { driverId: existing.id as string };

    if (!email) return { driverId: null };

    const { data: match } = await supabaseAdmin
      .from("drivers")
      .select("id")
      .ilike("email", email)
      .is("user_id", null)
      .maybeSingle();
    if (!match) return { driverId: null };

    const { error } = await supabaseAdmin
      .from("drivers")
      .update({ user_id: userId })
      .eq("id", match.id);
    if (error) throw error;

    return { driverId: match.id as string };
  });

/** Records a current GPS fix for the signed-in chauffeur's active ride. */
export const recordDriverLocation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z
      .object({
        reservationId: z.string().uuid(),
        lat: z.number().min(-90).max(90),
        lng: z.number().min(-180).max(180),
        capturedAt: z.number().int().positive(),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: driver } = await supabaseAdmin
      .from("drivers")
      .select("id")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (!driver) throw new Error("This account is not linked to a chauffeur.");

    const { data: ride } = await supabaseAdmin
      .from("reservations")
      .select("id, status")
      .eq("id", data.reservationId)
      .eq("driver_id", driver.id)
      .maybeSingle();
    if (!ride || !["en_route", "on_location", "passenger_on_board"].includes(ride.status)) {
      throw new Error("This ride is not currently trackable.");
    }

    const now = Date.now();
    if (Math.abs(now - data.capturedAt) > 30_000) {
      throw new Error("The phone returned an old GPS reading.");
    }
    const recordedAt = new Date(data.capturedAt).toISOString();
    const { error: driverError } = await supabaseAdmin
      .from("drivers")
      .update({
        last_lat: data.lat,
        last_lng: data.lng,
        last_seen_at: recordedAt,
        is_online: true,
      })
      .eq("id", driver.id);
    if (driverError) throw driverError;

    const { error: pointError } = await supabaseAdmin.from("ride_track_points").insert({
      reservation_id: ride.id,
      driver_id: driver.id,
      lat: data.lat,
      lng: data.lng,
      recorded_at: recordedAt,
    });
    if (pointError) throw pointError;

    return { ok: true as const, recordedAt };
  });
