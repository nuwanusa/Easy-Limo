import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const money = (v: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(v);

const ordinal = (n: number) => {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return `${String(n).padStart(2, "0")}${s[(v - 20) % 10] ?? s[v] ?? s[0]}`;
};

const longDayLabel = (v: string | null | undefined) => {
  if (!v) return null;
  const d = new Date(/^\d{4}-\d{2}-\d{2}$/.test(v) ? `${v}T12:00:00Z` : v);
  if (Number.isNaN(d.getTime())) return null;
  const parts = new Intl.DateTimeFormat("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
    timeZone: "America/New_York",
  }).formatToParts(d);
  const get = (t: string) => parts.find((x) => x.type === t)?.value ?? "";
  return `${get("month")} ${ordinal(Number(get("day")))} ${get("year")}`;
};

const dayLabel = (v: string | null | undefined) => {
  if (!v) return "—";
  const d = new Date(/^\d{4}-\d{2}-\d{2}$/.test(v) ? `${v}T12:00:00Z` : v);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "America/New_York",
  });
};

const clockTime = (v: string | null | undefined) => {
  if (!v) return "—";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    timeZone: "America/New_York",
  });
};

type Ride = any;

const shortDayLabel = (v: string | null | undefined) => {
  if (!v) return null;
  const d = new Date(/^\d{4}-\d{2}-\d{2}$/.test(v) ? `${v}T12:00:00Z` : v);
  if (Number.isNaN(d.getTime())) return null;
  return new Intl.DateTimeFormat("en-US", {
    month: "numeric",
    day: "numeric",
    year: "numeric",
    timeZone: "America/New_York",
  }).format(d);
};

const billingPeriodSubject = (
  start: string | null | undefined,
  end: string | null | undefined,
  rides: Ride[],
) => {
  const rideDates = rides
    .map((ride) => ride.pickup_at as string | null | undefined)
    .filter((value): value is string => Boolean(value))
    .sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
  const first = shortDayLabel(start ?? rideDates[0]);
  const last = shortDayLabel(end ?? rideDates[rideDates.length - 1]);
  if (first && last) return first === last ? first : `${first} – ${last}`;
  return first ?? last ?? undefined;
};

const num = (v: unknown) => Number(v ?? 0) || 0;

/** Main passenger plus any additional passenger names entered on the reservation. */
const passengerNames = (r: Ride) => {
  const main = (r.passenger_name ?? "").trim();
  const extras = Array.isArray(r.extra_passengers)
    ? (r.extra_passengers as any[])
        .map((p) => (typeof p?.name === "string" ? p.name.trim() : ""))
        .filter(Boolean)
    : [];
  const all = [main, ...extras].filter(Boolean);
  return all.length ? all.join(", ") : "—";
};

const billableHours = (r: Ride) => Math.max(num(r.hours), num(r.minimum_hours));
const baseRate = (r: Ride) => num(r.base_rate);
const flatRate = (r: Ride) => (r.booking_type === "hourly" ? 0 : num(r.base_fare));
const hourlyCharge = (r: Ride) => (r.booking_type === "hourly" ? num(r.hourly_rate) * billableHours(r) : 0);
const waitingCharge = (r: Ride) => (num(r.waiting_minutes) / 60) * num(r.waiting_rate);
const carSeatCharge = (r: Ride) => num(r.car_seat_count) * num(r.car_seat_fee);
const otherCharges = (r: Ride, stopCount: number) =>
  num(r.tolls) +
  num(r.airport_fee) +
  num(r.parking_fee) +
  num(r.meet_greet_fee) +
  waitingCharge(r) +
  carSeatCharge(r) +
  num(r.gratuity) +
  num(r.stop_fee) * stopCount;
const rideTotal = (r: Ride, stopCount: number) =>
  baseRate(r) + flatRate(r) + hourlyCharge(r) + otherCharges(r, stopCount);

const tollNames = (r: Ride): { label: string; amount: number }[] => {
  const legs: any[] = Array.isArray(r.tolls_breakdown) ? r.tolls_breakdown : [];
  const out: { label: string; amount: number }[] = [];
  for (const leg of legs) {
    for (const t of leg?.tolls ?? []) {
      const amount = num(t?.amount);
      if (!amount) continue;
      out.push({ label: [t?.name ?? leg?.label ?? "Toll", t?.agency, t?.payment].filter(Boolean).join(" · "), amount });
    }
  }
  return out;
};

const otherBreakdown = (r: Ride, stopCount: number) => {
  const rows: { label: string; amount: string }[] = [];
  const push = (label: string, v: number) => {
    if (v > 0) rows.push({ label, amount: money(v) });
  };
  const named = tollNames(r);
  if (named.length && Math.abs(named.reduce((s, t) => s + t.amount, 0) - num(r.tolls)) < 0.02) {
    for (const t of named) rows.push({ label: `Toll — ${t.label}`, amount: money(t.amount) });
  } else {
    push("Tolls", num(r.tolls));
    for (const t of named) rows.push({ label: t.label, amount: money(t.amount) });
  }
  push("Airport fee", num(r.airport_fee));
  push("Parking", num(r.parking_fee));
  push("Meet & greet", num(r.meet_greet_fee));
  if (num(r.waiting_minutes) > 0)
    rows.push({
      label: `Waiting time (${num(r.waiting_minutes)} min @ ${money(num(r.waiting_rate))}/hr)`,
      amount: money(waitingCharge(r)),
    });
  push("Gratuity", num(r.gratuity));
  if (num(r.car_seat_count) > 0)
    push(`Car seats (${num(r.car_seat_count)})`, carSeatCharge(r));
  if (stopCount > 0) push(`Extra stops (${stopCount})`, num(r.stop_fee) * stopCount);
  return rows;
};

const chargeItems = (r: Ride, stopCount: number) => {
  const rows: { label: string; amount: string }[] = [];
  const push = (label: string, value: number) => {
    if (value > 0) rows.push({ label, amount: money(value) });
  };
  push("Base rate", baseRate(r));
  push("Flat rate", flatRate(r));
  if (hourlyCharge(r) > 0)
    push(
      `Other - ${money(num(r.hourly_rate))} / hour X ${billableHours(r)} hours = ${money(hourlyCharge(r))}`,
      hourlyCharge(r),
    );
  push("Tolls", num(r.tolls));
  push("Parking fee", num(r.parking_fee));
  push("Airport fee", num(r.airport_fee));
  push("Meet & greet", num(r.meet_greet_fee));
  if (waitingCharge(r) > 0)
    push(`Waiting time · ${num(r.waiting_minutes)} min`, waitingCharge(r));
  push("Gratuity", num(r.gratuity));
  if (stopCount > 0) push(`Extra stops · ${stopCount}`, num(r.stop_fee) * stopCount);
  if (carSeatCharge(r) > 0) push(`Car seats · ${num(r.car_seat_count)}`, carSeatCharge(r));
  return rows;
};

const tripRow = (r: Ride, counts: Map<string, string[]>) => {
  const stopAddrs = counts.get(r.id) ?? [];
  const stops = stopAddrs.length;
  const routeParts = [r.pickup_address ? `PU: ${r.pickup_address}` : "", ...stopAddrs, r.dropoff_address ? `DO: ${r.dropoff_address}` : ""].filter(Boolean);
  return {
    date: dayLabel(r.pickup_at),
    pickupTime: clockTime(r.pickup_at),
    dropoffTime: clockTime(r.dropoff_at),
    passenger: passengerNames(r),
    notesLine: `Notes: ${num(r.passenger_count) || 0} passenger${(num(r.passenger_count) || 0) === 1 ? "" : "s"} · ${num(r.luggage_count)} luggage`,
    route: routeParts.join(" → "),
    vehicle: r.vehicle_class ?? "—",
    baseRate: money(baseRate(r)),
    flatRate: r.booking_type === "hourly" ? undefined : money(flatRate(r)),
    flatDetail: undefined,
    others: r.booking_type === "hourly" ? money(otherCharges(r, stops) + hourlyCharge(r)) : money(otherCharges(r, stops)),
    othersDetail:
      r.booking_type === "hourly"
        ? [
            {
              label: `Other - ${money(num(r.hourly_rate))} / hour X ${billableHours(r)} hours = ${money(hourlyCharge(r))}`,
              amount: money(hourlyCharge(r)),
            },
            ...otherBreakdown(r, stops),
          ]
        : otherBreakdown(r, stops),
    distance: num(r.distance_miles) > 0 ? `${num(r.distance_miles)} mi` : "—",
    amount: money(rideTotal(r, stops)),
    charges: chargeItems(r, stops),
  };
};

async function stopCounts(supabase: any, ids: string[]) {
  const map = new Map<string, string[]>();
  if (!ids.length) return map;
  const { data } = await supabase
    .from("reservation_stops")
    .select("reservation_id, address, position")
    .in("reservation_id", ids)
    .order("position");
  for (const row of data ?? []) {
    const list = map.get(row.reservation_id) ?? [];
    if (row.address) list.push(row.address as string);
    map.set(row.reservation_id, list);
  }
  return map;
}

function buildLines(rides: Ride[], counts: Map<string, string[]>) {
  const sum = (fn: (r: Ride) => number) => rides.reduce((s, r) => s + fn(r), 0);
  const hours = sum(billableHours);
  const waitMin = sum((r) => num(r.waiting_minutes));
  const stops = rides.reduce((s, r) => s + (counts.get(r.id) ?? []).length, 0);
  const lines = [
    { label: `Base rate (${rides.length} rides)`, amount: money(sum(baseRate)) },
    { label: `Flat rate rides (${rides.filter((r) => r.booking_type !== "hourly").length})`, amount: money(sum(flatRate)) },
    { label: `Hourly rides (${hours} hr)`, amount: money(sum(hourlyCharge)) },
    { label: `Waiting time (${Math.round(waitMin)} min)`, amount: money(sum(waitingCharge)) },
  ];
  if (stops > 0) lines.push({ label: `Extra stops (${stops})`, amount: money(sum((r) => num(r.stop_fee) * (counts.get(r.id) ?? []).length)) });
  return lines;
}

function buildOtherFees(rides: Ride[]) {
  const sum = (fn: (r: Ride) => number) => rides.reduce((s, r) => s + fn(r), 0);
  return [
    { label: "Meet & greet", amount: money(sum((r) => num(r.meet_greet_fee))) },
    { label: "Airport fee", amount: money(sum((r) => num(r.airport_fee))) },
    { label: "Parking fee", amount: money(sum((r) => num(r.parking_fee))) },
    { label: "Tolls", amount: money(sum((r) => num(r.tolls))) },
    { label: "Gratuity", amount: money(sum((r) => num(r.gratuity))) },
  ];
}

const randomToken = () =>
  Array.from(crypto.getRandomValues(new Uint8Array(18)))
    .map((b) => "abcdefghijkmnpqrstuvwxyz23456789"[b % 32])
    .join("");

/** Public printable-invoice link (client can save it as a PDF). */
async function invoiceUrlFor(clientId: string | null | undefined, docId: string): Promise<string | undefined> {
  if (!clientId) return undefined;
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: client } = await supabaseAdmin
    .from("clients")
    .select("id, portal_token")
    .eq("id", clientId)
    .maybeSingle();
  if (!client) return undefined;
  let token = (client.portal_token as string | null) ?? "";
  if (!token) {
    token = randomToken();
    await supabaseAdmin.from("clients").update({ portal_token: token }).eq("id", clientId);
  }
  return `https://rideblackwave.com/i/${token}/${docId}`;
}

async function send(
  recipient: string,
  data: Record<string, unknown>,
  idempotencyKey: string,
) {
  const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");
  try {
    const result = await sendTemplateEmail("client-invoice", recipient, {
      templateData: data,
      idempotencyKey,
    });
    return result?.sent ? { sent: true as const } : { sent: false as const, reason: result?.reason ?? "not_sent" };
  } catch (e) {
    return { sent: false as const, reason: e instanceof Error ? e.message : "send_failed" };
  }
}

/** Email a consolidated (multi-trip) invoice to the client on file. */
export const sendClientInvoiceEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { invoiceId: string }) => data)
  .handler(async ({ data, context }) => {
    const supabase = (context as any).supabase;
    const { data: invoice, error } = await supabase
      .from("invoices")
      .select("*")
      .eq("id", data.invoiceId)
      .maybeSingle();
    if (error) throw error;
    if (!invoice) throw new Error("Invoice not found");

    const { data: client } = invoice.client_id
      ? await supabase.from("clients").select("*").eq("id", invoice.client_id).maybeSingle()
      : { data: null };
    if (!client?.email) return { sent: false as const, reason: "no_client_email" };

    const { data: rides = [] } = await supabase
      .from("reservations")
      .select("*")
      .eq("invoice_id", invoice.id)
      .order("pickup_at", { ascending: true });

    const counts = await stopCounts(supabase, rides.map((r: Ride) => r.id));
    const subtotal = rides.reduce((s: number, r: Ride) => s + rideTotal(r, (counts.get(r.id) ?? []).length), 0);
    const totalDue = subtotal - num(invoice.discount) - num(invoice.payments);

    const result = await send(
      client.email,
      {
        clientName: client.name,
        contactName:
          rides
            .map((r: Ride) => (typeof r.billing_contact_name === "string" ? r.billing_contact_name.trim() : ""))
            .find(Boolean) || client.contact_name || undefined,
        addressLine1: client.address_line1 ?? undefined,
        addressLine2: client.address_line2 ?? undefined,
        clientEmail: client.email ?? undefined,
        accountNumber: client.account_number ?? undefined,
        createdOn: dayLabel(invoice.created_at),
        dueDate: invoice.paid_at
          ? `Paid ${dayLabel(invoice.paid_at)}`
          : (client.terms ?? (invoice.issued_at ? dayLabel(invoice.issued_at) : "Due on receipt")),
        tripCount: String(rides.length),
        invoiceNumber: invoice.invoice_number,
        issuedOn: dayLabel(invoice.issued_at ?? invoice.created_at),
        period: billingPeriodSubject(invoice.period_start, invoice.period_end, rides),
        periodSubject: billingPeriodSubject(invoice.period_start, invoice.period_end, rides),
        trips: rides.map((r: Ride) => tripRow(r, counts)),
        lines: buildLines(rides, counts),
        otherFees: buildOtherFees(rides),
        subtotal: money(subtotal),
        discount: money(num(invoice.discount)),
        payments: money(num(invoice.payments)),
        totalDue: money(totalDue),
        notes: invoice.notes ?? undefined,
        invoiceUrl: await invoiceUrlFor(invoice.client_id, invoice.id),
        payUrl: invoice.paid_at
          ? undefined
          : await (await import("@/lib/payment-links.server")).publicPaymentUrl("invoice", invoice.id),
      },
      `invoice-${invoice.id}-${Date.now()}`,
    );

    if (result.sent) {
      await supabase.from("invoices").update({ sent_at: new Date().toISOString() }).eq("id", invoice.id);
    }
    return result;
  });

/** Email a single-ride invoice to the passenger email on the reservation. */
export const sendRideInvoiceEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { reservationId: string }) => data)
  .handler(async ({ data, context }) => {
    const supabase = (context as any).supabase;
    const { data: ride, error } = await supabase
      .from("reservations")
      .select("*")
      .eq("id", data.reservationId)
      .maybeSingle();
    if (error) throw error;
    if (!ride) throw new Error("Reservation not found");

    let recipient: string | null = ride.passenger_email ?? null;
    let name: string | null = ride.passenger_name ?? null;
    if (!recipient && ride.client_id) {
      const { data: client } = await supabase
        .from("clients")
        .select("name, email")
        .eq("id", ride.client_id)
        .maybeSingle();
      recipient = client?.email ?? null;
      name = client?.name ?? name;
    }
    if (!recipient) return { sent: false as const, reason: "no_client_email" };

    const counts = await stopCounts(supabase, [ride.id]);
    const stops = (counts.get(ride.id) ?? []).length;
    const total = rideTotal(ride, stops);

    const result = await send(
      recipient,
      {
        clientName: name,
        invoiceNumber: ride.invoice_number ?? `INV-${ride.reference}`,
        issuedOn: dayLabel(ride.invoice_issued_at ?? new Date().toISOString()),
        period: dayLabel(ride.pickup_at),
        periodSubject: billingPeriodSubject(undefined, undefined, [ride]),
        trips: [tripRow(ride, counts)],
        lines: buildLines([ride], counts),
        otherFees: buildOtherFees([ride]),
        tripCount: "1",
        dueDate: "Due on receipt",
        createdOn: dayLabel(ride.created_at ?? new Date().toISOString()),
        subtotal: money(total),
        discount: money(0),
        payments: money(0),
        totalDue: money(total),
        notes: undefined,
        invoiceUrl: await invoiceUrlFor(ride.client_id, ride.id),
        payUrl: ride.invoice_paid_at
          ? undefined
          : await (await import("@/lib/payment-links.server")).publicPaymentUrl("reservation", ride.id),
      },
      `ride-invoice-${ride.id}-${Date.now()}`,
    );

    if (result.sent) {
      await supabase
        .from("reservations")
        .update({ invoice_sent_at: new Date().toISOString() })
        .eq("id", ride.id);
    }
    return result;
  });

/** Staff: emails an invoice to any address (e.g. an accounts-payable contact). */
export const staffForwardInvoiceByEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { invoiceId: string; to: string; name?: string }) => {
    if (!/^[0-9a-fA-F-]{36}$/.test(data?.invoiceId ?? "")) throw new Error("Missing invoice");
    const to = (data?.to ?? "").trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(to)) throw new Error("Enter a valid email address");
    const name = (data?.name ?? "").trim().slice(0, 120);
    return { invoiceId: data.invoiceId, to, name: name || undefined };
  })
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: roles } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", (context as any).userId)
      .in("role", ["admin", "dispatcher"])
      .limit(1);
    if (!roles || roles.length === 0) throw new Error("Only staff can email invoices");

    const { data: invoice } = await supabaseAdmin
      .from("invoices")
      .select("id, client_id")
      .eq("id", data.invoiceId)
      .maybeSingle();
    if (!invoice?.client_id) throw new Error("Invoice not found");

    const { emailInvoiceToAddress } = await import("@/lib/portal-invoice-email.server");
    return emailInvoiceToAddress({ clientId: invoice.client_id, target: "invoice", id: invoice.id, to: data.to, recipientName: (data as any).name });
  });
