import { isFinishedTrip } from "@/lib/trip-status";
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { fareTotal, driverPayout, waitingCharge } from "@/lib/dispatch";

const money = (v: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(v);

const fmtDate = (v: string | null | undefined) => {
  if (!v) return undefined;
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return undefined;
  return d.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
    timeZone: "America/New_York",
  });
};

/**
 * Marks a chauffeur's completed, unpaid rides as paid out and emails them a
 * navy payment statement listing every reservation covered by the payment.
 * Staff only — drivers cannot mark their own rides paid (RLS enforces it).
 */
export const sendDriverPaymentEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { driverId: string; note?: string; reservationIds?: string[]; periodLabel?: string }) => {
    if (!input?.driverId) throw new Error("Driver is required");
    return input;
  })
  .handler(async ({ data, context }) => {
    const supabase = context.supabase;

    const { data: driver, error: driverError } = await supabase
      .from("drivers")
      .select("id, full_name, email, pay_type, pay_rate")
      .eq("id", data.driverId)
      .maybeSingle();
    if (driverError) throw driverError;
    if (!driver) throw new Error("Driver not found");
    if (!driver.email) return { sent: false, reason: "no_driver_email" as const };

    const { data: allRides, error: ridesError } = await supabase
      .from("reservations")
      .select("*")
      .eq("driver_id", driver.id)
      .neq("status", "cancelled")
      .is("driver_paid_at", null)
      .order("pickup_at", { ascending: true });
    if (ridesError) throw ridesError;
    const finished = (allRides ?? []).filter((r: { status: string; pickup_at: string }) => isFinishedTrip(r));
    const picked = data.reservationIds?.length ? new Set(data.reservationIds) : null;
    const rides = picked ? finished.filter((r: { id: string }) => picked.has(r.id)) : finished;
    if (!rides || rides.length === 0) return { sent: false, reason: "nothing_due" as const };

    const ids = rides.map((r: { id: string }) => r.id);

    const { data: stops } = await supabase
      .from("reservation_stops")
      .select("reservation_id")
      .in("reservation_id", ids);
    const stopCount = new Map<string, number>();
    for (const s of stops ?? []) {
      stopCount.set(s.reservation_id, (stopCount.get(s.reservation_id) ?? 0) + 1);
    }

    let ridesTotal = 0;
    let payoutTotal = 0;
    const lines = rides.map((r: any) => {
      const total = fareTotal(r, stopCount.get(r.id) ?? 0);
      const pay = driverPayout(r, driver, stopCount.get(r.id) ?? 0);
      ridesTotal += total;
      payoutTotal += pay;
      return {
        date: fmtDate(r.pickup_at),
        reference: r.reference,
        passengerName: r.passenger_name,
        pickupAddress: r.pickup_address,
        dropoffAddress: r.dropoff_address,
        parking: money(Number(r.parking_fee ?? 0)),
        airportFee: money(Number(r.airport_fee ?? 0)),
        waiting: money(waitingCharge(r)),
        pay: money(pay),
      };
    });

    const paidAt = new Date().toISOString();
    const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");

    try {
      const result = await sendTemplateEmail("driver-payment", driver.email, {
        templateData: {
          driverName: driver.full_name?.split(" ")[0] ?? null,
          paidOn: fmtDate(paidAt),
          periodLabel:
            data.periodLabel ??
            (lines.length > 1 ? `${lines[0]?.date ?? ""} – ${lines[lines.length - 1]?.date ?? ""}` : null),
          rides: lines,
          payoutTotal: money(payoutTotal),
          note: data.note ?? null,
        },
        idempotencyKey: `driver-payment-${driver.id}-${Date.now()}`,
      });
      if (!result.sent) return { sent: false, reason: result.reason };
    } catch (err) {
      console.error("driver payment email failed", err);
      return { sent: false, reason: err instanceof Error ? err.message : "send_failed" };
    }

    const { error: markError } = await supabase
      .from("reservations")
      .update({ driver_paid_at: paidAt })
      .in("id", ids);
    if (markError) throw markError;

    return { sent: true as const, email: driver.email, trips: ids.length, amount: money(payoutTotal) };
  });
