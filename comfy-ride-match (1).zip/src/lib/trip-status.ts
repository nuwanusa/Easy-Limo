/** Pure helpers for reasoning about where a trip sits in its lifecycle. */
export const ACTIVE_STATUSES = ["en_route", "on_location", "passenger_on_board"] as const;

export const isStopStatus = (status: string) => /^at_stop_\d+$/.test(status);

export const isActiveStatus = (status: string) =>
  (ACTIVE_STATUSES as readonly string[]).includes(status) || isStopStatus(status);

/**
 * A trip counts as finished for pay purposes when it is explicitly completed,
 * or when its pickup time has passed and the chauffeur is not still working it.
 */
export const isFinishedTrip = (t: { status: string; pickup_at: string }) => {
  if (t.status === "completed") return true;
  if (t.status === "cancelled" || isActiveStatus(t.status)) return false;
  const ts = new Date(t.pickup_at).getTime();
  return Number.isFinite(ts) && ts < Date.now();
};
