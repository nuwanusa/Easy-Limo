import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Platform-owner guard: only these accounts may create or suspend companies. */
async function assertPlatformOwner(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("platform_owners")
    .select("user_id")
    .eq("user_id", userId)
    .maybeSingle();
  if (!data) throw new Error("Only the platform owner can manage companies");
  return supabaseAdmin;
}

function tempPassword() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
  const bytes = new Uint8Array(12);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => chars[b % chars.length]).join("");
}

export const listCompanies = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const supabaseAdmin = await assertPlatformOwner(context.userId);
    const { data: companies, error } = await supabaseAdmin
      .from("companies")
      .select("id, name, code, contact_email, status, created_at")
      .order("created_at", { ascending: true });
    if (error) throw error;

    const { data: members } = await supabaseAdmin
      .from("company_users")
      .select("company_id, user_id, must_change_password");
    const { data: list } = await supabaseAdmin.auth.admin.listUsers();
    const emailById = new Map((list?.users ?? []).map((u) => [u.id, u.email ?? ""]));

    return (companies ?? []).map((c) => {
      const own = (members ?? []).filter((m) => m.company_id === c.id);
      return {
        id: c.id as string,
        name: c.name as string,
        code: c.code as string,
        contactEmail: (c.contact_email as string | null) ?? "",
        status: c.status as string,
        createdAt: c.created_at as string,
        members: own.length,
        admins: own.map((m) => ({
          userId: m.user_id as string,
          email: emailById.get(m.user_id as string) ?? "",
          mustChangePassword: Boolean(m.must_change_password),
        })),
      };
    });
  });

type CreateCompanyInput = { name: string; code: string; adminEmail: string };

export const createCompany = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: CreateCompanyInput) => {
    const name = input.name?.trim();
    const code = input.code?.trim().toUpperCase();
    const adminEmail = input.adminEmail?.trim().toLowerCase();
    if (!name) throw new Error("Company name is required");
    if (!code || !/^[A-Z0-9-]{3,20}$/.test(code))
      throw new Error("Company ID must be 3-20 letters, numbers or dashes");
    if (!adminEmail || !adminEmail.includes("@")) throw new Error("A valid admin email is required");
    return { name, code, adminEmail };
  })
  .handler(async ({ data, context }) => {
    const supabaseAdmin = await assertPlatformOwner(context.userId);

    const { data: existing } = await supabaseAdmin
      .from("companies")
      .select("id")
      .eq("code", data.code)
      .maybeSingle();
    if (existing) throw new Error("That Company ID is already taken");

    const { data: company, error: companyError } = await supabaseAdmin
      .from("companies")
      .insert({ name: data.name, code: data.code, contact_email: data.adminEmail })
      .select("id")
      .single();
    if (companyError) throw companyError;

    const password = tempPassword();
    let userId: string | null = null;
    const created = await supabaseAdmin.auth.admin.createUser({
      email: data.adminEmail,
      password,
      email_confirm: true,
    });
    if (created.error) {
      const { data: list } = await supabaseAdmin.auth.admin.listUsers();
      const found = list?.users?.find((u) => u.email?.toLowerCase() === data.adminEmail);
      if (!found) {
        await supabaseAdmin.from("companies").delete().eq("id", company.id);
        throw new Error(created.error.message);
      }
      const { data: already } = await supabaseAdmin
        .from("company_users")
        .select("company_id")
        .eq("user_id", found.id)
        .maybeSingle();
      if (already) {
        await supabaseAdmin.from("companies").delete().eq("id", company.id);
        throw new Error("That email already belongs to another company");
      }
      userId = found.id;
      await supabaseAdmin.auth.admin.updateUserById(found.id, { password, email_confirm: true });
    } else {
      userId = created.data.user?.id ?? null;
    }
    if (!userId) {
      await supabaseAdmin.from("companies").delete().eq("id", company.id);
      throw new Error("Could not create the admin account");
    }

    await supabaseAdmin
      .from("company_users")
      .upsert(
        { user_id: userId, company_id: company.id, must_change_password: true },
        { onConflict: "user_id" },
      );
    await supabaseAdmin.from("user_roles").delete().eq("user_id", userId);
    await supabaseAdmin.from("user_roles").insert({ user_id: userId, role: "admin" });
    await supabaseAdmin
      .from("profiles")
      .upsert({ id: userId, full_name: data.name, job_title: "Administrator" });

    return {
      ok: true,
      companyId: company.id as string,
      code: data.code,
      adminEmail: data.adminEmail,
      temporaryPassword: password,
    };
  });

export const setCompanyStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { companyId: string; status: "active" | "suspended" }) => {
    if (!input?.companyId) throw new Error("Missing company");
    if (input.status !== "active" && input.status !== "suspended")
      throw new Error("Invalid status");
    return { companyId: input.companyId, status: input.status };
  })
  .handler(async ({ data, context }) => {
    const supabaseAdmin = await assertPlatformOwner(context.userId);
    const { error } = await supabaseAdmin
      .from("companies")
      .update({ status: data.status })
      .eq("id", data.companyId);
    if (error) throw error;
    return { ok: true };
  });

export const resetCompanyAdminPassword = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { userId: string }) => {
    if (!input?.userId) throw new Error("Missing account");
    return { userId: input.userId };
  })
  .handler(async ({ data, context }) => {
    const supabaseAdmin = await assertPlatformOwner(context.userId);
    const password = tempPassword();
    const { error } = await supabaseAdmin.auth.admin.updateUserById(data.userId, {
      password,
      email_confirm: true,
    });
    if (error) throw new Error(error.message);
    await supabaseAdmin
      .from("company_users")
      .update({ must_change_password: true })
      .eq("user_id", data.userId);
    return { ok: true, temporaryPassword: password };
  });
