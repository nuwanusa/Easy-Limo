import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { linkDriverAccount } from "./driver.functions";
import type { Driver, Reservation, ReservationStop } from "./dispatch";

/** Driver-visible trip statuses, in the order a shift moves through them. */
export const DRIVER_FLOW = [
  { status: "en_route", label: "En route to pickup" },
  { status: "on_location", label: "On location" },
  { status: "passenger_on_board", label: "Passenger on board" },
  { status: "completed", label: "Dropped off — complete trip" },
] as const;

export { ACTIVE_STATUSES, isStopStatus, isActiveStatus, isFinishedTrip } from "./trip-status";
import { isActiveStatus } from "./trip-status";

/** Builds the button flow for a trip, inserting a step per intermediate stop. */
export const driverFlowFor = (stopCount: number) => {
  const stopSteps = Array.from({ length: stopCount }, (_, i) => ({
    status: `at_stop_${i + 1}`,
    label: `At stop ${i + 1}`,
  }));
  return [
    { status: "en_route", label: "En route to pickup" },
    { status: "on_location", label: "On location" },
    { status: "passenger_on_board", label: "Passenger on board" },
    ...stopSteps,
    { status: "completed", label: "Dropped off — complete trip" },
  ];
};


/** Resolves (and links on first sign-in) the roster driver for the current user. */
export function useDriverAccount() {
  const link = useServerFn(linkDriverAccount);
  return useQuery({
    queryKey: ["driver-account"],
    queryFn: async (): Promise<Driver | null> => {
      const { data: sessionData } = await supabase.auth.getSession();
      const userId = sessionData.session?.user.id;
      if (!userId) return null;
      await link({ data: undefined }).catch(() => null);
      const { data, error } = await supabase
        .from("drivers")
        .select("*")
        .eq("user_id", userId)
        .limit(1);
      if (error) throw error;
      return ((data ?? [])[0] as Driver | undefined) ?? null;
    },
  });
}


export const driverTripsQuery = (driverId: string | undefined) => ({
  queryKey: ["driver-trips", driverId],
  enabled: !!driverId,
  queryFn: async (): Promise<Reservation[]> => {
    const { data, error } = await supabase
      .from("reservations")
      .select("*")
      .eq("driver_id", driverId!)
      .neq("status", "cancelled")
      .order("pickup_at", { ascending: true });
    if (error) throw error;
    return (data ?? []) as Reservation[];
  },
});

export const driverStopsQuery = (driverId: string | undefined) => ({
  queryKey: ["driver-stops", driverId],
  enabled: !!driverId,
  queryFn: async (): Promise<ReservationStop[]> => {
    const { data, error } = await supabase
      .from("reservation_stops")
      .select("*")
      .order("position", { ascending: true });
    if (error) throw error;
    return (data ?? []) as ReservationStop[];
  },
});

export const mapsUrl = (address: string) =>
  `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(address)}`;

export const wazeUrl = (address: string) =>
  `https://waze.com/ul?q=${encodeURIComponent(address)}&navigate=yes`;

export type NavApp = "google" | "waze";

export const NAV_APP_KEY = "blackwave.nav-app";

/** Deep link for the driver's preferred navigation app. */
export const navUrl = (app: NavApp, address: string) =>
  app === "waze" ? wazeUrl(address) : mapsUrl(address);
