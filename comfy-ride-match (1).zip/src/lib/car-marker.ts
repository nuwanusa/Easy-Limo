/** Cartoon car marker used on the dispatch live maps, with the chauffeur's name under it. */
export const carMarkerHtml = (name: string, size: "sm" | "md" = "md") => {
  const w = size === "sm" ? 34 : 44;
  const h = Math.round(w * 0.62);
  const escaped = name.replace(/[&<>"]/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c] as string,
  );
  return `
<div style="display:flex;flex-direction:column;align-items:center;line-height:1;pointer-events:none">
  <svg width="${w}" height="${h}" viewBox="0 0 64 40" xmlns="http://www.w3.org/2000/svg">
    <g>
      <ellipse cx="32" cy="35" rx="24" ry="3.5" fill="rgba(0,0,0,.18)"/>
      <path d="M6 26c0-4 2-6 5-6.6l4.5-7.2C16.8 10.2 18.8 9 21 9h20c2.4 0 4.6 1.3 5.8 3.4L51 20c4 .8 7 3 7 6.4V29a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2z" fill="#0f172a"/>
      <path d="M20.5 12.5h8.7v7H15.7zM33 12.5h7.8c1 0 2 .5 2.5 1.4l3.2 5.6H33z" fill="#bfe3ff"/>
      <circle cx="18" cy="31" r="6" fill="#111827"/>
      <circle cx="18" cy="31" r="2.4" fill="#e5e7eb"/>
      <circle cx="46" cy="31" r="6" fill="#111827"/>
      <circle cx="46" cy="31" r="2.4" fill="#e5e7eb"/>
      <rect x="54" y="23" width="4" height="3" rx="1.5" fill="#fde68a"/>
      <rect x="6" y="23" width="3.5" height="3" rx="1.5" fill="#fca5a5"/>
    </g>
  </svg>
  <span style="margin-top:2px;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;background:#0f172a;color:#fff;font:600 10px/1.4 system-ui,sans-serif;letter-spacing:.04em;padding:2px 6px;border-radius:9999px;box-shadow:0 1px 3px rgba(0,0,0,.3)">${escaped}</span>
</div>`;
};
