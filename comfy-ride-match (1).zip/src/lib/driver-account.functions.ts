import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type Input = { driverId: string; email: string; password: string };

/**
 * Staff-only: creates (or resets) the login account for a roster driver and
 * links it to the driver record.
 */
export const createDriverLogin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: Input) => {
    const email = input.email?.trim().toLowerCase();
    if (!email || !email.includes("@")) throw new Error("A valid email is required");
    if (!input.password || input.password.length < 8)
      throw new Error("Password must be at least 8 characters");
    if (!input.driverId) throw new Error("Missing driver");
    return { driverId: input.driverId, email, password: input.password };
  })
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Only staff (users who are not themselves drivers) may create logins.
    const { data: self } = await supabaseAdmin
      .from("drivers")
      .select("id")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (self) throw new Error("Forbidden");

    const { data: driver, error: driverError } = await supabaseAdmin
      .from("drivers")
      .select("id, user_id")
      .eq("id", data.driverId)
      .maybeSingle();
    if (driverError) throw driverError;
    if (!driver) throw new Error("Driver not found");

    let userId = driver.user_id as string | null;

    if (userId) {
      const { error } = await supabaseAdmin.auth.admin.updateUserById(userId, {
        email: data.email,
        password: data.password,
        email_confirm: true,
      });
      if (error) throw new Error(error.message);
    } else {
      const created = await supabaseAdmin.auth.admin.createUser({
        email: data.email,
        password: data.password,
        email_confirm: true,
      });
      if (created.error) {
        // Account already exists for this email — reuse and reset its password.
        const { data: list } = await supabaseAdmin.auth.admin.listUsers();
        const existing = list?.users?.find(
          (u) => u.email?.toLowerCase() === data.email,
        );
        if (!existing) throw new Error(created.error.message);
        userId = existing.id;
        const { error } = await supabaseAdmin.auth.admin.updateUserById(existing.id, {
          password: data.password,
          email_confirm: true,
        });
        if (error) throw new Error(error.message);
      } else {
        userId = created.data.user?.id ?? null;
      }
    }

    if (!userId) throw new Error("Could not create the login");

    await supabaseAdmin
      .from("user_roles")
      .upsert({ user_id: userId, role: "driver" }, { onConflict: "user_id,role" });

    // Keep the new login inside the same company as the staff member creating it.
    const { data: myCompany } = await supabaseAdmin
      .from("company_users")
      .select("company_id")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (myCompany?.company_id) {
      await supabaseAdmin
        .from("company_users")
        .upsert(
          { user_id: userId, company_id: myCompany.company_id, must_change_password: false },
          { onConflict: "user_id" },
        );
    }

    const { error: linkError } = await supabaseAdmin
      .from("drivers")
      .update({ user_id: userId, email: data.email })
      .eq("id", data.driverId);
    if (linkError) throw linkError;

    return { ok: true, email: data.email };
  });
