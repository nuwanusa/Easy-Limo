import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Called by the chauffeur app right after a trip is marked dropped off:
 * works out the tolls for the route driven and files them on the reservation
 * for dispatch. Staff-entered tolls are never overwritten.
 */
export const submitRideTolls = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ reservation_id: z.string().uuid() }).parse(data))
  .handler(async ({ data }) => {
    const { recordRideTolls } = await import("@/lib/tolls.server");
    const tolls = await recordRideTolls(data.reservation_id);
    return { tolls };
  });
