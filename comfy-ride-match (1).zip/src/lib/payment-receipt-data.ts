/**
 * Builds the full invoice/ride detail payload attached to payment receipt
 * emails so the client sees exactly what was paid for.
 */

const money = (v: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(v);

const dayLabel = (v: string | null | undefined) => {
  if (!v) return "—";
  const d = new Date(/^\d{4}-\d{2}-\d{2}$/.test(v) ? `${v}T12:00:00Z` : v);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    timeZone: "America/New_York",
  });
};

const clockTime = (v: string | null | undefined) => {
  if (!v) return "—";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    timeZone: "America/New_York",
  });
};

type Ride = any;

const num = (v: unknown) => Number(v ?? 0) || 0;

const billableHours = (r: Ride) => Math.max(num(r.hours), num(r.minimum_hours));
const flatRate = (r: Ride) => (r.booking_type === "hourly" ? 0 : num(r.base_fare));
const hourlyCharge = (r: Ride) => (r.booking_type === "hourly" ? num(r.hourly_rate) * billableHours(r) : 0);
const waitingCharge = (r: Ride) => (num(r.waiting_minutes) / 60) * num(r.waiting_rate);

const rideTotal = (r: Ride, stopCount: number) =>
  num(r.base_rate) +
  flatRate(r) +
  hourlyCharge(r) +
  waitingCharge(r) +
  num(r.airport_fee) +
  num(r.meet_greet_fee) +
  num(r.parking_fee) +
  num(r.tolls) +
  num(r.gratuity) +
  num(r.stop_fee) * stopCount;

async function stopCounts(supabase: any, ids: string[]) {
  const map = new Map<string, number>();
  if (!ids.length) return map;
  const { data } = await supabase
    .from("reservation_stops")
    .select("reservation_id")
    .in("reservation_id", ids);
  for (const row of data ?? []) map.set(row.reservation_id, (map.get(row.reservation_id) ?? 0) + 1);
  return map;
}

const tripRow = (r: Ride, counts: Map<string, number>) => ({
  date: dayLabel(r.pickup_at),
  pickupTime: clockTime(r.pickup_at),
  dropoffTime: clockTime(r.dropoff_at),
  passenger: r.passenger_name ?? "—",
  route: `PU: ${r.pickup_address ?? ""} → DO: ${r.dropoff_address ?? ""}`,
  vehicle: r.vehicle_class ?? "—",
  flatRate: r.booking_type === "hourly" ? "—" : money(flatRate(r)),
  waitingTime: num(r.waiting_minutes) > 0 ? money(waitingCharge(r)) : "—",
  hourlyRate: r.booking_type === "hourly" ? money(hourlyCharge(r)) : "—",
  distance: num(r.distance_miles) > 0 ? `${num(r.distance_miles)} mi` : "—",
  amount: money(rideTotal(r, counts.get(r.id) ?? 0)),
});

function buildFees(rides: Ride[], counts: Map<string, number>) {
  const sum = (fn: (r: Ride) => number) => rides.reduce((s, r) => s + fn(r), 0);
  const stops = rides.reduce((s, r) => s + (counts.get(r.id) ?? 0), 0);
  const rows: Array<{ label: string; amount: string }> = [];
  const push = (label: string, value: number) => {
    if (value > 0) rows.push({ label, amount: money(value) });
  };
  push(`Base rate (${rides.length} rides)`, sum((r) => num(r.base_rate)));
  push(`Flat rate rides (${rides.filter((r) => r.booking_type !== "hourly").length})`, sum(flatRate));
  push(`Hourly rides (${sum(billableHours)} hr)`, sum(hourlyCharge));
  push(`Waiting time (${Math.round(sum((r) => num(r.waiting_minutes)))} min)`, sum(waitingCharge));
  if (stops > 0) push(`Extra stops (${stops})`, sum((r) => num(r.stop_fee) * (counts.get(r.id) ?? 0)));
  push("Meet & greet", sum((r) => num(r.meet_greet_fee)));
  push("Airport fee", sum((r) => num(r.airport_fee)));
  push("Parking fee", sum((r) => num(r.parking_fee)));
  push("Tolls", sum((r) => num(r.tolls)));
  push("Gratuity", sum((r) => num(r.gratuity)));
  return rows;
}

export interface PaymentInvoiceDetails {
  trips: Array<ReturnType<typeof tripRow>>;
  charges: Array<{ label: string; amount: string }>;
  subtotal: string;
  discount?: string | undefined;
  totalPaid: string;
  period?: string | undefined;
  tripCount: string;
}

/** Loads the trips + charge breakdown behind a paid invoice or ride. */
export async function buildPaymentInvoiceDetails(
  supabase: any,
  target: "invoice" | "reservation",
  id: string,
  amountPaid: number,
): Promise<PaymentInvoiceDetails | undefined> {
  try {
    let rides: Ride[] = [];
    let discount = 0;
    let period: string | undefined;

    if (target === "invoice") {
      const { data: invoice } = await supabase.from("invoices").select("*").eq("id", id).maybeSingle();
      if (!invoice) return undefined;
      discount = num(invoice.discount);
      const { data } = await supabase
        .from("reservations")
        .select("*")
        .eq("invoice_id", id)
        .order("pickup_at", { ascending: true });
      rides = data ?? [];
      const firstRideDate = rides[0]?.pickup_at as string | null | undefined;
      const lastRideDate = rides[rides.length - 1]?.pickup_at as string | null | undefined;
      const from = dayLabel(invoice.period_start ?? firstRideDate);
      const to = dayLabel(invoice.period_end ?? lastRideDate);
      if (from !== "—" || to !== "—") period = from === to ? from : `${from} – ${to}`;
    } else {
      const { data: ride } = await supabase.from("reservations").select("*").eq("id", id).maybeSingle();
      if (!ride) return undefined;
      rides = [ride];
    }

    const counts = await stopCounts(supabase, rides.map((r) => r.id));
    const subtotal = rides.reduce((s, r) => s + rideTotal(r, counts.get(r.id) ?? 0), 0);

    return {
      trips: rides.map((r) => tripRow(r, counts)),
      charges: buildFees(rides, counts),
      subtotal: money(subtotal),
      discount: discount > 0 ? money(discount) : undefined,
      totalPaid: money(amountPaid || subtotal - discount),
      period,
      tripCount: String(rides.length),
    };
  } catch (e) {
    console.error("payment receipt details failed", e);
    return undefined;
  }
}
