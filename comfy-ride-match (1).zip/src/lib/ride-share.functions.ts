import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { fareBreakdownRows, fareTotal, money, waitingCharge } from "@/lib/dispatch";

const part = (value: string | null | undefined, opts: Intl.DateTimeFormatOptions) => {
  if (!value) return undefined;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return undefined;
  return d.toLocaleString("en-US", { ...opts, timeZone: "America/New_York" });
};
const fmtDate = (v: string | null | undefined) =>
  part(v, { weekday: "long", month: "long", day: "numeric", year: "numeric" });
const fmtTime = (v: string | null | undefined) =>
  part(v, { hour: "numeric", minute: "2-digit", hour12: true });

/**
 * Emails the full trip details (route, passenger, chauffeur, vehicle,
 * airport/flight) for one reservation to any address the staff member enters.
 */
export const sendRideDetailsEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { reservationId: string; to: string; name?: string }) => {
    const reservationId = input.reservationId?.trim();
    const to = input.to?.trim().toLowerCase();
    const name = input.name?.trim() || null;
    if (!reservationId) throw new Error("Reservation is required");
    if (!to || !to.includes("@")) throw new Error("Enter a valid email address");
    return { reservationId, to, name };
  })
  .handler(async ({ data, context }) => {
    const supabase = context.supabase;
    const { data: reservation, error } = await supabase
      .from("reservations")
      .select("*")
      .eq("id", data.reservationId)
      .maybeSingle();
    if (error) throw error;
    if (!reservation) throw new Error("Reservation not found");

    const [{ data: stops }, { data: events }, { data: driver }, { data: client }] = await Promise.all([
      supabase
        .from("reservation_stops")
        .select("address, position")
        .eq("reservation_id", reservation.id)
        .order("position", { ascending: true }),
      supabase
        .from("reservation_status_events")
        .select("status, occurred_at")
        .eq("reservation_id", reservation.id)
        .order("occurred_at", { ascending: true }),
      reservation.driver_id
        ? supabase
            .from("drivers")
            .select("full_name, phone, default_vehicle_id")
            .eq("id", reservation.driver_id)
            .maybeSingle()
        : Promise.resolve({ data: null }),
      reservation.client_id
        ? supabase
            .from("clients")
            .select("name, phone")
            .eq("id", reservation.client_id)
            .maybeSingle()
        : Promise.resolve({ data: null }),
    ]);

    const vehicleId = reservation.vehicle_id ?? driver?.default_vehicle_id ?? null;
    const { data: vehicle } = vehicleId
      ? await supabase
          .from("vehicles")
          .select("name, vehicle_class, make, model, plate, color")
          .eq("id", vehicleId)
          .maybeSingle()
      : { data: null };

    const vehicleLine =
      [vehicle?.make, vehicle?.model].filter(Boolean).join(" ") || vehicle?.name || null;

    const stopCount = stops?.length ?? 0;
    const firstEvent = (status: string) =>
      (events ?? []).find((e: { status: string; occurred_at: string }) => e.status === status)
        ?.occurred_at ?? null;

    const fareRows = fareBreakdownRows(reservation, stopCount).map((row) => ({
      label: row.label,
      amount: money(row.amount),
      muted: row.muted ?? false,
    }));
    const waitingMins = Number(reservation.waiting_minutes ?? 0);
    const distance = Number(reservation.distance_miles ?? 0);

    const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");
    const result = await sendTemplateEmail("client-trip-notice", data.to, {
      idempotencyKey: `ride-details-${reservation.id}-${data.to}-${Date.now()}`,
      templateData: {
        kind: "reservation",
        headline: "Trip details",
        intro: "here are the details for this reservation.",
        greetingName: data.name,
        clientName: client?.name ?? null,
        clientPhone: client?.phone ?? null,
        reference: reservation.reference,
        pickupDate: fmtDate(reservation.pickup_at),
        pickupTime: fmtTime(reservation.pickup_at),
        dropoffTime: fmtTime(reservation.dropoff_at),
        pickupAddress: reservation.pickup_address,
        dropoffAddress: reservation.dropoff_address,
        stops: (stops ?? []).map((s: { address: string }) => s.address),
        passengerName: reservation.passenger_name,
        passengerPhone: reservation.passenger_phone,
        passengerCount:
          reservation.passenger_count != null
            ? `${reservation.passenger_count}${reservation.luggage_count != null ? ` · ${reservation.luggage_count} luggage` : ""}`
            : null,
        vehicleClass: vehicle?.vehicle_class ?? reservation.vehicle_class,
        paymentMethod: reservation.payment_method,
        driverName: driver?.full_name ?? null,
        driverPhone: driver?.phone ?? null,
        vehicle: vehicleLine,
        vehiclePlate: vehicle?.plate ?? null,
        vehicleColor: vehicle?.color ?? null,
        airportName: reservation.airport_name,
        airline: reservation.airline,
        flightNumber: reservation.flight_number,
        flightDirection: reservation.flight_number ? reservation.flight_direction : null,
        terminalLevel: reservation.terminal_level,
        doorNumber: reservation.door_number,
        bookingType: reservation.booking_type === "hourly" ? "Hourly" : "Point to point",
        onMyWayAt: fmtTime(firstEvent("en_route")),
        arrivedAtPickupAt: fmtTime(firstEvent("on_location")),
        passengerOnBoardAt: fmtTime(firstEvent("passenger_on_board")),
        droppedOffAt: fmtTime(firstEvent("completed") ?? reservation.dropoff_at),
        waitingTime:
          waitingMins > 0
            ? `${waitingMins} min${waitingCharge(reservation) > 0 ? ` (${money(waitingCharge(reservation))})` : ""}`
            : null,
        distance: distance > 0 ? `${distance} mi` : null,
        fareRows,
        fareTotal: money(fareTotal(reservation, stopCount)),
      },
    });
    return result;
  });
