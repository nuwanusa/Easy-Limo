/**
 * Named toll crossings in the New York metro area.
 *
 * Google Routes returns toll amounts but not the name of the crossing, so we
 * match the driven route against this catalogue of toll plaza locations to
 * label each charge (e.g. "Queens-Midtown Tunnel - E-ZPass").
 */

export interface TollFacility {
  name: string;
  agency: string;
  payment: string;
  lat: number;
  lng: number;
  /** Match radius in metres. */
  radius?: number;
  /** Published E-ZPass passenger-car rate for one crossing, in USD. */
  rate?: number;
  /** Direction the toll is collected in; crossings the other way are free. */
  chargedWhen?: (from: { lat: number; lng: number }, to: { lat: number; lng: number }) => boolean;
}

const eastbound = (a: { lng: number }, b: { lng: number }) => b.lng > a.lng;
const westbound = (a: { lng: number }, b: { lng: number }) => b.lng < a.lng;
const southbound = (a: { lat: number }, b: { lat: number }) => b.lat < a.lat;

export const TOLL_FACILITIES: TollFacility[] = [
  { name: "Queens-Midtown Tunnel", agency: "MTA", payment: "E-ZPass", lat: 40.7466, lng: -73.968, rate: 7.55 },
  { name: "Hugh L. Carey Tunnel", agency: "MTA", payment: "E-ZPass", lat: 40.6935, lng: -74.012, rate: 7.55 },
  { name: "Verrazzano-Narrows Bridge", agency: "MTA", payment: "E-ZPass", lat: 40.6066, lng: -74.0447, radius: 1500, rate: 7.55, chargedWhen: westbound },
  { name: "Robert F. Kennedy Bridge", agency: "MTA", payment: "E-ZPass", lat: 40.7888, lng: -73.925, radius: 1200, rate: 7.55 },
  { name: "Throgs Neck Bridge", agency: "MTA", payment: "E-ZPass", lat: 40.8018, lng: -73.794, radius: 1200, rate: 7.55 },
  { name: "Bronx-Whitestone Bridge", agency: "MTA", payment: "E-ZPass", lat: 40.801, lng: -73.833, radius: 1200, rate: 7.55 },
  { name: "Henry Hudson Bridge", agency: "MTA", payment: "E-ZPass", lat: 40.878, lng: -73.922, rate: 3.18 },
  { name: "Cross Bay Veterans Memorial Bridge", agency: "MTA", payment: "E-ZPass", lat: 40.59, lng: -73.818, rate: 2.85 },
  { name: "Marine Parkway-Gil Hodges Bridge", agency: "MTA", payment: "E-ZPass", lat: 40.5735, lng: -73.885, rate: 2.85 },
  { name: "George Washington Bridge", agency: "Port Authority", payment: "E-ZPass", lat: 40.8517, lng: -73.9527, radius: 1500, rate: 14.06, chargedWhen: eastbound },
  { name: "Lincoln Tunnel", agency: "Port Authority", payment: "E-ZPass", lat: 40.7648, lng: -74.011, rate: 14.06, chargedWhen: eastbound },
  { name: "Holland Tunnel", agency: "Port Authority", payment: "E-ZPass", lat: 40.727, lng: -74.021, rate: 14.06, chargedWhen: eastbound },
  { name: "Goethals Bridge", agency: "Port Authority", payment: "E-ZPass", lat: 40.635, lng: -74.197, radius: 1200, rate: 14.06, chargedWhen: eastbound },
  { name: "Outerbridge Crossing", agency: "Port Authority", payment: "E-ZPass", lat: 40.524, lng: -74.247, radius: 1200, rate: 14.06, chargedWhen: eastbound },
  { name: "Bayonne Bridge", agency: "Port Authority", payment: "E-ZPass", lat: 40.6415, lng: -74.142, radius: 1200, rate: 14.06, chargedWhen: southbound },
  { name: "Gov. Mario M. Cuomo Bridge", agency: "NYS Thruway", payment: "E-ZPass", lat: 41.07, lng: -73.908, radius: 2000, rate: 6.28 },
  { name: "Bear Mountain Bridge", agency: "NYS Bridge Authority", payment: "E-ZPass", lat: 41.319, lng: -73.986, rate: 1.85 },
  { name: "Atlantic Beach Bridge", agency: "Nassau County", payment: "E-ZPass", lat: 40.589, lng: -73.733, rate: 2.5 },
  { name: "Newark Airport exit (NJ Turnpike 14)", agency: "NJTA", payment: "E-ZPass", lat: 40.7035, lng: -74.1725, radius: 1200 },
  { name: "New Jersey Turnpike (Hudson County Extension)", agency: "NJTA", payment: "E-ZPass", lat: 40.718, lng: -74.09, radius: 1500 },
  { name: "New Jersey Turnpike", agency: "NJTA", payment: "E-ZPass", lat: 40.5, lng: -74.35, radius: 4000 },
  { name: "Garden State Parkway", agency: "NJTA", payment: "E-ZPass", lat: 40.6, lng: -74.22, radius: 3000 },
];

/** Decodes a Google encoded polyline into [lat, lng] pairs. */
export function decodePolyline(encoded: string): Array<[number, number]> {
  const points: Array<[number, number]> = [];
  let index = 0;
  let lat = 0;
  let lng = 0;

  while (index < encoded.length) {
    let result = 0;
    let shift = 0;
    let byte: number;
    do {
      byte = encoded.charCodeAt(index++) - 63;
      result |= (byte & 0x1f) << shift;
      shift += 5;
    } while (byte >= 0x20);
    lat += result & 1 ? ~(result >> 1) : result >> 1;

    result = 0;
    shift = 0;
    do {
      byte = encoded.charCodeAt(index++) - 63;
      result |= (byte & 0x1f) << shift;
      shift += 5;
    } while (byte >= 0x20);
    lng += result & 1 ? ~(result >> 1) : result >> 1;

    points.push([lat / 1e5, lng / 1e5]);
  }
  return points;
}

const metresBetween = (aLat: number, aLng: number, bLat: number, bLng: number) => {
  const toRad = Math.PI / 180;
  const dLat = (bLat - aLat) * toRad;
  const dLng = (bLng - aLng) * toRad;
  const lat = ((aLat + bLat) / 2) * toRad;
  const x = dLng * Math.cos(lat);
  return Math.sqrt(dLat * dLat + x * x) * 6371000;
};

/** Toll crossings the given encoded route passes through, in travel order. */
export function facilitiesOnRoute(encodedPolyline: string): TollFacility[] {
  if (!encodedPolyline) return [];
  const path = decodePolyline(encodedPolyline);
  if (path.length < 2) return [];

  const hits: Array<{ facility: TollFacility; at: number }> = [];
  for (const facility of TOLL_FACILITIES) {
    // Planned-route matching: keep the radius tight so a line that merely
    // passes near a plaza (parallel road, neighbouring bridge) is not charged.
    const radius = facility.radius ?? 450;
    let bestIndex = -1;
    let bestDistance = Infinity;
    for (let i = 0; i < path.length; i++) {
      const p = path[i]!;
      const d = metresBetween(p[0], p[1], facility.lat, facility.lng);
      if (d < bestDistance) {
        bestDistance = d;
        bestIndex = i;
      }
    }
    if (bestDistance <= radius) hits.push({ facility, at: bestIndex });
  }

  return hits.sort((a, b) => a.at - b.at).map((h) => h.facility);
}

export interface TrailPoint {
  lat: number;
  lng: number;
  recorded_at: string;
}

export interface TrailCrossing {
  name: string;
  agency: string;
  payment: string;
  /** Published rate for this crossing, or null when the agency prices by distance. */
  amount: number | null;
  /** When the chauffeur passed the booth. */
  at: string;
}

/** Metres from a facility to the straight segment between two trail points. */
const metresToSegment = (
  f: TollFacility,
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
) => {
  const toRad = Math.PI / 180;
  const scale = Math.cos(f.lat * toRad);
  const ax = (a.lng - f.lng) * scale;
  const ay = a.lat - f.lat;
  const bx = (b.lng - f.lng) * scale;
  const by = b.lat - f.lat;
  const dx = bx - ax;
  const dy = by - ay;
  const len2 = dx * dx + dy * dy;
  let t = len2 === 0 ? 0 : -(ax * dx + ay * dy) / len2;
  t = Math.max(0, Math.min(1, t));
  const cx = ax + t * dx;
  const cy = ay + t * dy;
  return Math.sqrt(cx * cx + cy * cy) * 111_320;
};

/** Metres between two positions. */
export function metresApart(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const toRad = Math.PI / 180;
  const dLat = (b.lat - a.lat) * toRad;
  const dLng = (b.lng - a.lng) * toRad;
  const lat = ((a.lat + b.lat) / 2) * toRad;
  const x = dLng * Math.cos(lat);
  return Math.sqrt(dLat * dLat + x * x) * 6_371_000;
}

/** Miles actually driven along the recorded GPS trail. */
export function trailMiles(points: TrailPoint[]) {
  let metres = 0;
  for (let i = 1; i < points.length; i++) metres += metresApart(points[i - 1]!, points[i]!);
  return Math.round((metres / 1609.344) * 10) / 10;
}

/**
 * Toll booths the chauffeur actually drove through, taken from the recorded
 * GPS trail rather than from a planned route. A booth is only counted when the
 * trail passes within its radius, and repeat hits inside ten minutes (traffic,
 * idling near a plaza) count once.
 */
/** Longest straight hop between GPS fixes that is still trusted for toll matching. */
export const MAX_TRUSTED_HOP_METRES = 2500;

/** Stretches where the GPS signal dropped (tunnels, app in background). */
export function trailGaps(points: TrailPoint[]): Array<[TrailPoint, TrailPoint]> {
  const gaps: Array<[TrailPoint, TrailPoint]> = [];
  for (let i = 1; i < points.length; i++) {
    if (metresApart(points[i - 1]!, points[i]!) > MAX_TRUSTED_HOP_METRES) gaps.push([points[i - 1]!, points[i]!]);
  }
  return gaps;
}

export function crossingsFromTrail(points: TrailPoint[]): TrailCrossing[] {
  const trail = points.filter((p) => Number.isFinite(p.lat) && Number.isFinite(p.lng));
  if (trail.length < 2) return [];

  const hits: TrailCrossing[] = [];
  for (const facility of TOLL_FACILITIES) {
    const radius = facility.radius ?? 800;
    let lastAt = 0;
    for (let i = 1; i < trail.length; i++) {
      const a = trail[i - 1]!;
      const b = trail[i]!;
      // A long straight hop is a guess, not the road driven — gaps are
      // resolved separately with a real route.
      if (metresApart(a, b) > MAX_TRUSTED_HOP_METRES) continue;
      if (metresToSegment(facility, a, b) > radius) continue;
      if (facility.chargedWhen && !facility.chargedWhen(a, b)) continue;
      const when = new Date(b.recorded_at).getTime();
      if (!Number.isFinite(when)) continue;
      if (lastAt && when - lastAt < 10 * 60 * 1000) {
        lastAt = when;
        continue;
      }
      lastAt = when;
      hits.push({
        name: facility.name,
        agency: facility.agency,
        payment: facility.payment,
        amount: facility.rate ?? null,
        at: new Date(when).toISOString(),
      });
    }
  }

  return hits.sort((a, b) => a.at.localeCompare(b.at));
}
