import { supabase } from "@/integrations/supabase/client";

export type Driver = {
  id: string;
  company_id: string;
  full_name: string;
  phone: string | null;
  license_number: string | null;
  email: string | null;
  user_id: string | null;
  status: string;
  address_line1?: string | null;
  address_line2?: string | null;
  city?: string | null;
  state?: string | null;
  postal_code?: string | null;
  date_of_birth?: string | null;
  license_class?: string | null;
  license_state?: string | null;
  license_expiry?: string | null;
  tlc_number?: string | null;
  tlc_expiry?: string | null;
  badge_number?: string | null;
  hire_date?: string | null;
  emergency_contact_name?: string | null;
  emergency_contact_phone?: string | null;
  insurance_provider?: string | null;
  insurance_policy?: string | null;
  insurance_expiry?: string | null;
  default_vehicle_id?: string | null;
  pay_type?: string;
  pay_rate?: number;
  notes?: string | null;
  is_online?: boolean;
  is_active?: boolean;
  last_lat?: number | null;
  last_lng?: number | null;
  last_seen_at?: string | null;
};

export type ClientRate = {
  id: string;
  client_id: string;
  label: string;
  rate_type: string;
  amount: number;
  vehicle_class: string;
  minimum_hours: number;
  notes: string | null;
};

export type Vehicle = {
  id: string;
  fleet_code: string;
  name: string;
  vehicle_class: string;
  make: string | null;
  model: string | null;
  year: number | null;
  plate: string | null;
  color: string | null;
  capacity: number;
  status: string;
};

export type Reservation = {
  driver_confirmed_at?: string | null;
  driver_note?: string | null;

  id: string;
  reference: string;
  passenger_name: string;
  passenger_phone: string | null;
  passenger_email: string | null;
  invoice_number: string | null;
  invoice_issued_at: string | null;
  invoice_sent_at: string | null;
  invoice_paid_at: string | null;
  driver_paid_at?: string | null;

  passenger_count: number;
  pickup_address: string;
  pickup_at: string;
  dropoff_address: string;
  dropoff_at: string | null;
  flight_number: string | null;
  airline?: string | null;
  payment_method?: string | null;
  airport_name: string | null;
  flight_direction: string;
  terminal_level: string | null;
  door_number: string | null;
  vehicle_class: string;
  base_fare: number;
  base_rate?: number;
  airport_fee: number;
  meet_greet_fee?: number;
  parking_fee?: number;
  car_seat_count?: number;
  car_seat_fee?: number;
  tolls: number;
  gratuity: number;
  status: string;
  notes: string | null;
  driver_id: string | null;
  vehicle_id: string | null;
  client_id: string | null;
  invoice_id: string | null;
  booking_type: string;
  hourly_rate: number;
  hours: number;
  minimum_hours: number;
  stop_fee: number;
  waiting_minutes: number;
  waiting_rate: number;
  distance_miles: number;
  driver_pay?: number;
  driver_hourly_pay?: number;
  driver_minimum_hours?: number;
  driver_total_hours?: number;
  driver_airport_fee?: number;
  driver_parking_fee?: number;
  driver_waiting_pay?: number;
  driver_waiting_hours?: number;
  driver_tolls?: number;
};

export type ReservationStop = {
  id: string;
  reservation_id: string;
  position: number;
  address: string;
  stop_at: string | null;
  note: string | null;
};

export type Client = {
  id: string;
  account_number: string;
  name: string;
  contact_name: string | null;
  billing_contact_phone?: string | null;
  billing_contact_email?: string | null;
  booking_contact_name?: string | null;
  booking_contact_phone?: string | null;
  booking_contact_email?: string | null;
  email: string | null;
  phone: string | null;
  address_line1: string | null;
  address_line2: string | null;
  terms: string;
  notify_reservation?: boolean;
  notify_driver_accepted?: boolean;
  notify_ride_reminder?: boolean;
  notify_invoice?: boolean;
  notify_payment?: boolean;
};

export type Invoice = {
  id: string;
  invoice_number: string;
  client_id: string | null;
  period_start: string | null;
  period_end: string | null;
  issued_at: string | null;
  sent_at: string | null;
  paid_at: string | null;
  discount: number;
  payments: number;
  notes: string | null;
  created_at: string;
  updated_at: string;
};

export const RESERVATION_STATUSES = [
  "quoted",
  "confirmed",
  "unassigned",
  "en_route",
  "completed",
  "cancelled",
] as const;

export const VEHICLE_CLASSES = ["sedan", "suv", "sprinter", "stretch"] as const;

export const statusLabel = (status: string) => {
  const m = /^at_stop_(\d+)$/.exec(status);
  if (m) return `at stop ${m[1]}`;
  if (status === "passenger_on_board") return "passenger on board";
  return status.replace(/_/g, " ");
};

export const BOOKING_TYPES = ["point_to_point", "hourly"] as const;

export const bookingTypeLabel = (t: string) => (t === "hourly" ? "Hourly / As-directed" : "Point to point");

type FareLike = Pick<Reservation, "base_fare" | "airport_fee" | "tolls" | "gratuity"> &
  Partial<
    Pick<
      Reservation,
      "base_rate" | "meet_greet_fee" | "parking_fee" | "car_seat_count" | "car_seat_fee" | "booking_type" | "hourly_rate" | "hours" | "minimum_hours" | "stop_fee" | "waiting_minutes" | "waiting_rate"
    >
  >;

/** Base rate charged on every reservation, on top of the flat or hourly rate. */
export const baseRate = (r: FareLike) => Number(r.base_rate ?? 0);

/** Car seats billed at the per-seat fee. */
export const carSeatCharge = (r: FareLike) =>
  Number(r.car_seat_count ?? 0) * Number(r.car_seat_fee ?? 0);

/** "Others" = tolls + airport fee + parking + meet & greet + car seats. */
export const otherCharges = (r: FareLike) =>
  Number(r.tolls ?? 0) + Number(r.airport_fee ?? 0) + Number(r.parking_fee ?? 0) + Number(r.meet_greet_fee ?? 0) + carSeatCharge(r);

export type TollCharge = { name?: string; agency?: string; payment?: string; amount?: number | null; at?: string };
export type TollLeg = { label?: string; distanceMiles?: number; toll?: number | null; tolls?: TollCharge[] };

/** Named toll crossings recorded on a ride, if any. */
export const tollRows = (r: { tolls_breakdown?: unknown; tolls?: number | string | null }) => {
  const legs: TollLeg[] = Array.isArray(r.tolls_breakdown) ? (r.tolls_breakdown as TollLeg[]) : [];
  const rows: { label: string; amount: number }[] = [];
  for (const leg of legs) {
    for (const t of leg.tolls ?? []) {
      const amount = Number(t.amount ?? 0);
      if (!amount) continue;
      const parts = [t.name ?? leg.label ?? "Toll", t.agency, t.payment].filter(Boolean);
      rows.push({ label: parts.join(" · "), amount });
    }
  }
  return rows;
};

/** Line-item detail behind the "Others" column on an invoice. */
export const otherBreakdownRows = (
  r: FareLike & { tolls_breakdown?: unknown; waiting_minutes?: number | null },
  stopCount = 0,
) => {
  const rows: { label: string; amount: number }[] = [];
  const push = (label: string, v: number) => {
    if (v > 0) rows.push({ label, amount: v });
  };
  const named = tollRows(r as { tolls_breakdown?: unknown });
  const tolls = Number(r.tolls ?? 0);
  const namedTotal = named.reduce((s, t) => s + t.amount, 0);
  if (named.length && Math.abs(namedTotal - tolls) < 0.02) {
    for (const t of named) rows.push({ label: `Toll — ${t.label}`, amount: t.amount });
  } else {
    push("Tolls", tolls);
    for (const t of named) rows.push({ label: `  ${t.label}`, amount: t.amount });
  }
  push("Airport fee", Number(r.airport_fee ?? 0));
  push("Parking", Number(r.parking_fee ?? 0));
  push("Meet & greet", Number(r.meet_greet_fee ?? 0));
  if (carSeatCharge(r) > 0)
    rows.push({
      label: `Car seats (${Number(r.car_seat_count ?? 0)} @ ${money(Number(r.car_seat_fee ?? 0))})`,
      amount: carSeatCharge(r),
    });
  if (Number(r.waiting_minutes ?? 0) > 0)
    rows.push({
      label: `Waiting time (${Number(r.waiting_minutes)} min @ ${money(Number(r.waiting_rate ?? 0))}/hr)`,
      amount: waitingCharge(r),
    });
  push("Gratuity", Number(r.gratuity ?? 0));
  if (stopCount > 0) push(`Extra stops (${stopCount})`, Number(r.stop_fee ?? 0) * stopCount);
  return rows;
};

/** Everything on an invoice line that is not the base rate or the flat/hourly rate. */
export const invoiceOthers = (r: FareLike, stopCount = 0) =>
  otherCharges(r) + waitingCharge(r) + Number(r.gratuity ?? 0) + stopCharge(r, stopCount);

/** Billable hours = hours booked, never less than the contracted minimum. */
export const billableHours = (r: FareLike) =>
  Math.max(Number(r.hours ?? 0), Number(r.minimum_hours ?? 0));

/** Flat (point-to-point) rate for the ride — zero on hourly bookings. */
export const flatRate = (r: FareLike) => (r.booking_type === "hourly" ? 0 : Number(r.base_fare ?? 0));

/** Hourly service charge — zero on point-to-point bookings. */
export const hourlyCharge = (r: FareLike) =>
  r.booking_type === "hourly" ? Number(r.hourly_rate ?? 0) * billableHours(r) : 0;

/** Waiting time billed pro-rata against the waiting rate (per hour). */
export const waitingCharge = (r: FareLike) =>
  (Number(r.waiting_minutes ?? 0) / 60) * Number(r.waiting_rate ?? 0);

/** Ride charge before fees: hourly rate x billable hours, or the flat base fare. */
export const rideCharge = (r: FareLike) => (r.booking_type === "hourly" ? hourlyCharge(r) : flatRate(r));

/** stopCount = number of extra stops between pickup and drop-off. */
export const stopCharge = (r: FareLike, stopCount = 0) => Number(r.stop_fee ?? 0) * stopCount;

export const fareTotal = (r: FareLike, stopCount = 0) =>
  baseRate(r) +
  rideCharge(r) +
  waitingCharge(r) +
  Number(r.airport_fee) +
  Number(r.meet_greet_fee ?? 0) +
  Number(r.parking_fee ?? 0) +
  carSeatCharge(r) +
  Number(r.tolls) +
  Number(r.gratuity) +
  stopCharge(r, stopCount);

/** Every line that makes up the fare a client is charged, for display. */
export const fareBreakdownRows = (
  r: FareLike & { tolls_breakdown?: unknown; waiting_minutes?: number | null },
  stopCount = 0,
) => {
  const rows: { label: string; amount: number; muted?: boolean }[] = [];
  const push = (label: string, v: number) => {
    if (v > 0) rows.push({ label, amount: v });
  };
  push("Base rate", baseRate(r));
  if (r.booking_type === "hourly") {
    push(
      `Hourly rate (${billableHours(r)} hr @ ${money(Number(r.hourly_rate ?? 0))}/hr)`,
      hourlyCharge(r),
    );
  } else {
    push("Flat rate", flatRate(r));
  }
  for (const row of otherBreakdownRows(r, stopCount)) {
    rows.push({ label: row.label.trim(), amount: row.amount, muted: row.label.startsWith("  ") });
  }
  return rows;
};

/** Estimated chauffeur payout for a ride: percentage of the fare, or a flat trip rate. */
export const driverPayEstimate = (
  fare: number,
  driver: { pay_type?: string | null; pay_rate?: number | null } | null | undefined,
) => {
  if (!driver) return 0;
  const rate = Number(driver.pay_rate ?? 0);
  if (!rate) return 0;
  return driver.pay_type === "percentage" ? (fare * rate) / 100 : rate;
};

/**
 * What the chauffeur actually gets paid for a ride.
 * Uses the amounts staff entered on the reservation when any are set,
 * otherwise falls back to the percentage/flat estimate from the driver profile.
 */
export const driverPayout = (
  r: Partial<Reservation> & FareLike,
  driver: { pay_type?: string | null; pay_rate?: number | null } | null | undefined,
  stopCount = 0,
) => {
  const ride = Number(r.driver_pay ?? 0);
  const hourlyRide = Number(r.driver_hourly_pay ?? 0) * Math.max(
    Number(r.driver_minimum_hours ?? 0),
    Number(r.driver_total_hours ?? 0),
  );
  const airport = Number(r.driver_airport_fee ?? 0);
  const parking = Number(r.driver_parking_fee ?? 0);
  const waitingHours = Number(r.driver_waiting_hours ?? 0);
  const waitingRate = Number(r.driver_waiting_pay ?? 0);
  // Older reservations stored the total waiting pay in driver_waiting_pay.
  const wait = waitingHours > 0 ? waitingRate * waitingHours : waitingRate;
  const tolls = Number((r as { driver_tolls?: number }).driver_tolls ?? 0);
  const ridePay = r.booking_type === "hourly" ? hourlyRide : ride;
  if (ridePay || airport || parking || wait || tolls) return ridePay + airport + parking + wait + tolls;
  return driverPayEstimate(fareTotal(r, stopCount), driver);
};

export const money = (value: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);

export const clockTime = (iso: string | null) =>
  iso ? new Date(iso).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true }) : "—";

export const dayLabel = (iso: string | null) =>
  iso ? new Date(iso).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" }) : "—";

export const shortDate = (iso: string | null | undefined) =>
  iso
    ? new Date(/^\d{4}-\d{2}-\d{2}$/.test(iso) ? `${iso}T12:00:00Z` : iso).toLocaleDateString("en-US", {
        month: "numeric",
        day: "numeric",
        year: "numeric",
        timeZone: "America/New_York",
      })
    : "";

export const periodLabel = (start?: string | null, end?: string | null) => {
  if (!start && !end) return "—";
  const from = shortDate(start ?? end);
  const to = shortDate(end ?? start);
  return from === to ? from : `${from} – ${to}`;
};

export const reservationsQuery = {
  queryKey: ["reservations"],
  queryFn: async (): Promise<Reservation[]> => {
    const { data, error } = await supabase
      .from("reservations")
      .select("*")
      .order("pickup_at", { ascending: true });
    if (error) throw error;
    return (data ?? []) as Reservation[];
  },
};

export const stopsQuery = {
  queryKey: ["reservation_stops"],
  queryFn: async (): Promise<ReservationStop[]> => {
    const { data, error } = await supabase
      .from("reservation_stops")
      .select("*")
      .order("position", { ascending: true });
    if (error) throw error;
    return (data ?? []) as ReservationStop[];
  },
};

/** Stops grouped by reservation id. */
export const groupStops = (stops: ReservationStop[]) => {
  const map = new Map<string, ReservationStop[]>();
  for (const s of stops) {
    const list = map.get(s.reservation_id) ?? [];
    list.push(s);
    map.set(s.reservation_id, list);
  }
  return map;
};

/** Main passenger plus every additional passenger name entered on the reservation. */
export const passengerNames = (r: { passenger_name?: string | null; extra_passengers?: unknown }) => {
  const main = (r.passenger_name ?? "").trim();
  const extras = Array.isArray(r.extra_passengers)
    ? (r.extra_passengers as { name?: string }[])
        .map((p) => (typeof p?.name === "string" ? p.name.trim() : ""))
        .filter(Boolean)
    : [];
  const all = [main, ...extras].filter(Boolean);
  return all.length ? all.join(", ") : "—";
};

export const driversQuery = {
  queryKey: ["drivers"],
  queryFn: async (): Promise<Driver[]> => {
    const { data, error } = await supabase.from("drivers").select("*").order("full_name");
    if (error) throw error;
    return (data ?? []) as Driver[];
  },
};

export const clientsQuery = {
  queryKey: ["clients"],
  queryFn: async (): Promise<Client[]> => {
    const { data, error } = await supabase.from("clients").select("*").order("name");
    if (error) throw error;
    return (data ?? []) as Client[];
  },
};

export const invoicesQuery = {
  queryKey: ["invoices"],
  queryFn: async (): Promise<Invoice[]> => {
    const { data, error } = await supabase.from("invoices").select("*").order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []) as Invoice[];
  },
};

export const vehiclesQuery = {
  queryKey: ["vehicles"],
  queryFn: async (): Promise<Vehicle[]> => {
    const { data, error } = await supabase.from("vehicles").select("*").order("fleet_code");
    if (error) throw error;
    return (data ?? []) as Vehicle[];
  },
};

export const clientRatesQuery = {
  queryKey: ["client_rates"],
  queryFn: async (): Promise<ClientRate[]> => {
    const { data, error } = await supabase
      .from("client_rates")
      .select("*")
      .order("label");
    if (error) throw error;
    return (data ?? []) as unknown as ClientRate[];
  },
};

export type ClientPassenger = {
  id: string;
  client_id: string;
  full_name: string;
  phone: string | null;
  email: string | null;
  notes: string | null;
};

export const clientPassengersQuery = {
  queryKey: ["client_passengers"],
  queryFn: async (): Promise<ClientPassenger[]> => {
    const { data, error } = await supabase.from("client_passengers").select("*").order("full_name");
    if (error) throw error;
    return (data ?? []) as unknown as ClientPassenger[];
  },
};

export type ZoneRate = {
  id: string;
  client_id: string | null;
  from_label: string;
  from_type: string;
  to_label: string;
  to_type: string;
  vehicle_class: string;
  amount: number;
  notes: string | null;
};

export const zoneRatesQuery = {
  queryKey: ["zone_rates"],
  queryFn: async (): Promise<ZoneRate[]> => {
    const { data, error } = await supabase
      .from("zone_rates")
      .select("*")
      .order("from_label");
    if (error) throw error;
    return (data ?? []) as unknown as ZoneRate[];
  },
};
