// Catalog of vehicle makes and models commonly sold in the US.
// Used to power the make/model pickers on the Fleet page.

export const VEHICLE_CATALOG: Record<string, string[]> = {
  Acura: ["ILX", "Integra", "MDX", "RDX", "TLX", "ZDX"],
  "Alfa Romeo": ["Giulia", "Stelvio", "Tonale"],
  "Aston Martin": ["DB11", "DB12", "DBX", "Vantage"],
  Audi: ["A3", "A4", "A5", "A6", "A7", "A8", "e-tron GT", "Q3", "Q5", "Q7", "Q8", "Q8 e-tron", "S4", "S5", "TT"],
  Bentley: ["Bentayga", "Continental GT", "Flying Spur"],
  BMW: ["2 Series", "3 Series", "4 Series", "5 Series", "7 Series", "8 Series", "i4", "i5", "i7", "iX", "X1", "X3", "X4", "X5", "X6", "X7", "Z4"],
  Buick: ["Enclave", "Encore", "Encore GX", "Envision", "Envista"],
  Cadillac: ["CT4", "CT5", "CT6", "Celestiq", "Escalade", "Escalade ESV", "Lyriq", "XT4", "XT5", "XT6"],
  Chevrolet: ["Blazer", "Bolt EUV", "Camaro", "Colorado", "Corvette", "Equinox", "Express 2500", "Express 3500", "Malibu", "Silverado 1500", "Suburban", "Tahoe", "Traverse", "Trailblazer", "Trax"],
  Chrysler: ["300", "Pacifica", "Voyager"],
  Dodge: ["Challenger", "Charger", "Durango", "Hornet"],
  Ford: ["Bronco", "Bronco Sport", "E-Transit", "Edge", "Escape", "Expedition", "Expedition MAX", "Explorer", "F-150", "F-250", "Maverick", "Mustang", "Mustang Mach-E", "Ranger", "Transit 250", "Transit 350", "Transit Connect"],
  Genesis: ["G70", "G80", "G90", "GV60", "GV70", "GV80"],
  GMC: ["Acadia", "Canyon", "Hummer EV", "Savana 2500", "Savana 3500", "Sierra 1500", "Terrain", "Yukon", "Yukon XL"],
  Honda: ["Accord", "Civic", "CR-V", "HR-V", "Odyssey", "Passport", "Pilot", "Prologue", "Ridgeline"],
  Hyundai: ["Elantra", "Ioniq 5", "Ioniq 6", "Kona", "Palisade", "Santa Cruz", "Santa Fe", "Sonata", "Tucson", "Venue"],
  Infiniti: ["Q50", "QX50", "QX55", "QX60", "QX80"],
  Jaguar: ["E-Pace", "F-Pace", "F-Type", "I-Pace", "XF"],
  Jeep: ["Cherokee", "Compass", "Gladiator", "Grand Cherokee", "Grand Cherokee L", "Grand Wagoneer", "Wagoneer", "Wrangler"],
  Kia: ["Carnival", "EV6", "EV9", "Forte", "K5", "Niro", "Seltos", "Sorento", "Soul", "Sportage", "Telluride"],
  "Land Rover": ["Defender", "Discovery", "Range Rover", "Range Rover Evoque", "Range Rover Sport", "Range Rover Velar"],
  Lexus: ["ES", "GX", "IS", "LC", "LS", "LX", "NX", "RX", "RZ", "TX", "UX"],
  Lincoln: ["Aviator", "Continental", "Corsair", "MKT", "MKZ", "Nautilus", "Navigator", "Navigator L", "Town Car"],
  Lucid: ["Air", "Gravity"],
  Maserati: ["Ghibli", "Grecale", "Levante", "Quattroporte"],
  Mazda: ["CX-30", "CX-5", "CX-50", "CX-90", "Mazda3", "MX-5 Miata"],
  "Mercedes-Benz": ["A-Class", "C-Class", "E-Class", "EQB", "EQE", "EQS", "G-Class", "GLA", "GLB", "GLC", "GLE", "GLS", "Maybach S-Class", "Metris", "S-Class", "Sprinter 2500", "Sprinter 3500", "V-Class"],
  Mini: ["Clubman", "Cooper", "Countryman"],
  Mitsubishi: ["Eclipse Cross", "Outlander", "Outlander Sport"],
  Nissan: ["Altima", "Ariya", "Armada", "Frontier", "Kicks", "Leaf", "Maxima", "Murano", "NV200", "Pathfinder", "Rogue", "Sentra", "Titan", "Versa"],
  Polestar: ["Polestar 2", "Polestar 3"],
  Porsche: ["718 Cayman", "911", "Cayenne", "Macan", "Panamera", "Taycan"],
  Ram: ["1500", "2500", "3500", "ProMaster 1500", "ProMaster 2500", "ProMaster 3500"],
  "Rolls-Royce": ["Cullinan", "Ghost", "Phantom", "Spectre"],
  Rivian: ["R1S", "R1T"],
  Subaru: ["Ascent", "Crosstrek", "Forester", "Impreza", "Legacy", "Outback", "Solterra", "WRX"],
  Tesla: ["Cybertruck", "Model 3", "Model S", "Model X", "Model Y"],
  Toyota: ["4Runner", "Avalon", "bZ4X", "Camry", "Corolla", "Crown", "Grand Highlander", "Highlander", "Land Cruiser", "Prius", "RAV4", "Sequoia", "Sienna", "Tacoma", "Tundra", "Venza"],
  Volkswagen: ["Atlas", "Atlas Cross Sport", "Golf GTI", "ID.4", "ID. Buzz", "Jetta", "Passat", "Taos", "Tiguan"],
  Volvo: ["EX30", "EX90", "S60", "S90", "V60 Cross Country", "XC40", "XC60", "XC90"],
};

export const VEHICLE_MAKES = Object.keys(VEHICLE_CATALOG).sort((a, b) => a.localeCompare(b));

export function modelsForMake(make: string): string[] {
  const key = VEHICLE_MAKES.find((m) => m.toLowerCase() === make.trim().toLowerCase());
  return key ? VEHICLE_CATALOG[key]! : [];
}
