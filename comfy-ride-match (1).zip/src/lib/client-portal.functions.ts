import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type PortalStop = { position: number; address: string; stop_at: string | null; note: string | null };

export type PortalRide = {
  id: string;
  reference: string;
  passenger_name: string;
  passenger_count: number;
  luggage_count: number;
  car_seat_count: number;
  car_seat_fee: number;
  pickup_address: string;
  pickup_at: string;
  dropoff_address: string;
  dropoff_at: string | null;
  vehicle_class: string;
  booking_type: string;
  status: string;
  distance_miles: number;
  hours: number;
  hourly_rate: number;
  base_fare: number;
  base_rate: number;
  waiting_minutes: number;
  waiting_rate: number;
  stop_fee: number;
  airport_fee: number;
  parking_fee: number;
  meet_greet_fee: number;
  tolls: number;
  tolls_breakdown: {
    label?: string;
    distanceMiles?: number;
    toll?: number | null;
    tolls?: { name?: string; agency?: string; payment?: string; amount?: number | null; at?: string }[];
  }[];
  gratuity: number;
  passenger_phone: string | null;
  extra_passengers: { name?: string; phone?: string }[];
  vehicle_make: string | null;
  vehicle_model: string | null;
  vehicle_year: number | null;
  vehicle_color: string | null;
  vehicle_plate: string | null;
  airport_name: string | null;
  airline: string | null;
  flight_number: string | null;
  flight_direction: string | null;
  terminal_level: string | null;
  door_number: string | null;
  invoice_id: string | null;
  invoice_number: string | null;
  invoice_paid_at: string | null;
  invoice_issued_at: string | null;
  stops: PortalStop[];
};

export type PortalInvoice = {
  id: string;
  invoice_number: string;
  period_start: string | null;
  period_end: string | null;
  issued_at: string | null;
  sent_at: string | null;
  paid_at: string | null;
  discount: number;
  payments: number;
  notes: string | null;
};

export type PortalData = {
  companyId: string;
  client: {
    id: string;
    name: string;
    account_number: string;
    email: string | null;
    phone: string | null;
    terms: string;
    address_line1: string | null;
    address_line2: string | null;
    billing_contact_email: string | null;
  };
  invoices: PortalInvoice[];
  rides: PortalRide[];
  rates: PortalRate[];
  zoneRates: PortalZoneRate[];
};

export type PortalRate = {
  id: string;
  label: string;
  rate_type: string;
  amount: number;
  vehicle_class: string;
  minimum_hours: number;
  notes: string | null;
};

export type PortalZoneRate = {
  id: string;
  from_label: string;
  to_label: string;
  vehicle_class: string;
  amount: number;
  notes: string | null;
  client_specific: boolean;
};

const n = (v: unknown) => Number(v ?? 0) || 0;

async function loadPortal(supabase: any, clientId: string): Promise<PortalData> {
  const { data: client, error } = await supabase
    .from("clients")
    .select(
      "id, company_id, name, account_number, email, phone, terms, address_line1, address_line2, billing_contact_email",
    )
    .eq("id", clientId)
    .maybeSingle();
  if (error) throw error;
  if (!client) throw new Error("Client account not found");

  const [{ data: invoices = [] }, { data: rides = [] }] = await Promise.all([
    supabase.from("invoices").select("*").eq("client_id", clientId).order("created_at", { ascending: false }),
    supabase.from("reservations").select("*").eq("client_id", clientId).order("pickup_at", { ascending: false }),
  ]);

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const [{ data: rateRows = [] }, { data: zoneRows = [] }] = await Promise.all([
    supabaseAdmin
      .from("client_rates")
      .select("id, label, rate_type, amount, vehicle_class, minimum_hours, notes")
      .eq("client_id", clientId)
      .order("label", { ascending: true }),
    supabaseAdmin
      .from("zone_rates")
      .select("id, client_id, from_label, to_label, vehicle_class, amount, notes")
      .eq("client_id", clientId)
      .order("from_label", { ascending: true }),
  ]);

  const ids = (rides ?? []).map((r: any) => r.id);
  const stopsByRide = new Map<string, PortalStop[]>();
  if (ids.length) {
    const { data: stops = [] } = await supabase
      .from("reservation_stops")
      .select("reservation_id, position, address, stop_at, note")
      .in("reservation_id", ids)
      .order("position", { ascending: true });
    for (const s of stops ?? []) {
      const list = stopsByRide.get(s.reservation_id) ?? [];
      list.push({ position: s.position, address: s.address, stop_at: s.stop_at, note: s.note });
      stopsByRide.set(s.reservation_id, list);
    }
  }

  const vehicleIds = [...new Set((rides ?? []).map((r: any) => r.vehicle_id).filter(Boolean))];
  const vehicleById = new Map<string, any>();
  if (vehicleIds.length) {
    const { data: vRows = [] } = await supabaseAdmin
      .from("vehicles")
      .select("id, make, model, year, color, plate")
      .in("id", vehicleIds as string[]);
    for (const v of vRows ?? []) vehicleById.set(v.id, v);
  }

  return {
    companyId: client.company_id as string,
    client: client as PortalData["client"],
    invoices: (invoices ?? []).map((i: any) => ({
      id: i.id,
      invoice_number: i.invoice_number,
      period_start: i.period_start,
      period_end: i.period_end,
      issued_at: i.issued_at,
      sent_at: i.sent_at,
      paid_at: i.paid_at,
      discount: n(i.discount),
      payments: n(i.payments),
      notes: i.notes,
    })),
    rides: (rides ?? []).map((r: any) => ({
      id: r.id,
      reference: r.reference,
      passenger_name: r.passenger_name,
      passenger_count: r.passenger_count,
      luggage_count: Number(r.luggage_count ?? 0),
      car_seat_count: n(r.car_seat_count),
      car_seat_fee: n(r.car_seat_fee),
      pickup_address: r.pickup_address,
      pickup_at: r.pickup_at,
      dropoff_address: r.dropoff_address,
      dropoff_at: r.dropoff_at,
      vehicle_class: r.vehicle_class,
      booking_type: r.booking_type,
      status: r.status,
      distance_miles: n(r.distance_miles),
      hours: n(r.hours),
      hourly_rate: n(r.hourly_rate),
      base_fare: n(r.base_fare),
      base_rate: n((r as any).base_rate),
      waiting_minutes: n(r.waiting_minutes),
      waiting_rate: n(r.waiting_rate),
      stop_fee: n(r.stop_fee),
      airport_fee: n(r.airport_fee),
      parking_fee: n(r.parking_fee),
      meet_greet_fee: n(r.meet_greet_fee),
      tolls: n(r.tolls),
      tolls_breakdown: Array.isArray(r.tolls_breakdown) ? r.tolls_breakdown : [],
      gratuity: n(r.gratuity),
      passenger_phone: r.passenger_phone ?? null,
      extra_passengers: Array.isArray(r.extra_passengers) ? r.extra_passengers : [],
      vehicle_make: vehicleById.get(r.vehicle_id)?.make ?? null,
      vehicle_model: vehicleById.get(r.vehicle_id)?.model ?? null,
      vehicle_year: vehicleById.get(r.vehicle_id)?.year ?? null,
      vehicle_color: vehicleById.get(r.vehicle_id)?.color ?? null,
      vehicle_plate: vehicleById.get(r.vehicle_id)?.plate ?? null,
      airport_name: r.airport_name,
      airline: r.airline,
      flight_number: r.flight_number,
      flight_direction: r.flight_direction ?? null,
      terminal_level: r.terminal_level,
      door_number: r.door_number,
      invoice_id: r.invoice_id,
      invoice_number: r.invoice_number,
      invoice_paid_at: r.invoice_paid_at,
      invoice_issued_at: r.invoice_issued_at,
      stops: stopsByRide.get(r.id) ?? [],
    })),
    rates: (rateRows ?? []).map((r: any) => ({
      id: r.id,
      label: r.label,
      rate_type: r.rate_type,
      amount: n(r.amount),
      vehicle_class: r.vehicle_class,
      minimum_hours: n(r.minimum_hours),
      notes: r.notes ?? null,
    })),
    zoneRates: (zoneRows ?? []).map((z: any) => ({
      id: z.id,
      from_label: z.from_label,
      to_label: z.to_label,
      vehicle_class: z.vehicle_class,
      amount: n(z.amount),
      notes: z.notes ?? null,
      client_specific: Boolean(z.client_id),
    })),
  };
}

/** Portal data for a signed-in client account. */
export const getMyPortal = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<PortalData> => {
    const supabase = (context as any).supabase;
    const { data: link } = await supabase
      .from("client_users")
      .select("client_id")
      .eq("user_id", (context as any).userId)
      .maybeSingle();
    if (!link) throw new Error("This sign-in is not linked to a client account");
    return loadPortal(supabase, link.client_id);
  });

/** Portal data for a private share link (token is the secret). */
export const getPortalByToken = createServerFn({ method: "POST" })
  .inputValidator((data: { token: string }) => {
    if (!data?.token || !/^[A-Za-z0-9_-]{10,80}$/.test(data.token)) throw new Error("Invalid link");
    return data;
  })
  .handler(async ({ data }): Promise<PortalData> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: client } = await supabaseAdmin
      .from("clients")
      .select("id")
      .eq("portal_token", data.token)
      .maybeSingle();
    if (!client) throw new Error("This link is no longer valid");
    return loadPortal(supabaseAdmin, client.id);
  });

/** Public: resolves a client's web name (rideblackwave.com/<slug>) to their display name. */
export const getPortalClientBySlug = createServerFn({ method: "POST" })
  .inputValidator((data: { slug: string }) => {
    if (!data?.slug || !/^[a-z0-9-]{1,80}$/.test(data.slug)) throw new Error("Unknown page");
    return data;
  })
  .handler(async ({ data }): Promise<{ id: string; name: string; slug: string } | null> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: client } = await supabaseAdmin
      .from("clients")
      .select("id, name, portal_slug")
      .eq("portal_slug", data.slug)
      .maybeSingle();
    if (!client) return null;
    return { id: client.id as string, name: client.name as string, slug: data.slug };
  });

async function assertStaff(context: any) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", context.userId)
    .in("role", ["admin", "dispatcher"])
    .limit(1);
  if (!data || data.length === 0) throw new Error("Only staff can manage client portal access");
  return supabaseAdmin;
}

const randomToken = () =>
  Array.from(crypto.getRandomValues(new Uint8Array(18)))
    .map((b) => "abcdefghijkmnpqrstuvwxyz23456789"[b % 32])
    .join("");

/** Creates (or returns) the private portal link code for a client. */
export const ensureClientPortalToken = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { clientId: string; rotate?: boolean }) => data)
  .handler(async ({ data, context }) => {
    const supabaseAdmin = await assertStaff(context);
    const { data: client, error } = await supabaseAdmin
      .from("clients")
      .select("id, portal_token")
      .eq("id", data.clientId)
      .maybeSingle();
    if (error) throw error;
    if (!client) throw new Error("Client not found");
    if (client.portal_token && !data.rotate) return { token: client.portal_token as string };
    const token = randomToken();
    const { error: upErr } = await supabaseAdmin
      .from("clients")
      .update({ portal_token: token })
      .eq("id", data.clientId);
    if (upErr) throw upErr;
    return { token };
  });

const slugify = (name: string) =>
  name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "client";

const sixDigit = () => String(100000 + Math.floor(Math.random() * 900000));

/** Staff: web address name + six-digit access code for a client portal. */
export const ensureClientPortalAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { clientId: string; rotateCode?: boolean }) => data)
  .handler(async ({ data, context }): Promise<{ slug: string; code: string }> => {
    const supabaseAdmin = await assertStaff(context);
    const { data: client, error } = await supabaseAdmin
      .from("clients")
      .select("id, name, portal_slug, portal_code")
      .eq("id", data.clientId)
      .maybeSingle();
    if (error) throw error;
    if (!client) throw new Error("Client not found");

    const patch: { portal_slug?: string; portal_code?: string } = {};

    let slug = (client.portal_slug as string | null) ?? "";
    if (!slug) {
      const base = slugify(client.name as string);
      slug = base;
      for (let i = 2; i < 50; i++) {
        const { data: taken } = await supabaseAdmin
          .from("clients")
          .select("id")
          .eq("portal_slug", slug)
          .maybeSingle();
        if (!taken) break;
        slug = `${base}-${i}`;
      }
      patch.portal_slug = slug;
    }

    let code = (client.portal_code as string | null) ?? "";
    if (!code || data.rotateCode) {
      for (let i = 0; i < 30; i++) {
        const candidate = sixDigit();
        const { data: taken } = await supabaseAdmin
          .from("clients")
          .select("id")
          .eq("portal_code", candidate)
          .maybeSingle();
        if (!taken) {
          code = candidate;
          break;
        }
      }
      if (!code) throw new Error("Could not generate an access code");
      patch.portal_code = code;
    }

    if (Object.keys(patch).length) {
      const { error: upErr } = await supabaseAdmin.from("clients").update(patch).eq("id", data.clientId);
      if (upErr) throw upErr;
    }
    return { slug, code };
  });

/** Route names that can never be used as a client's short link. */
const RESERVED_SLUGS = new Set([
  "auth", "portal", "c", "d", "t", "i", "api", "admin", "driver", "drivers", "invoices", "pay",
  "contact", "about", "services", "our-fleet", "fleet", "dashboard", "reservations", "clients",
  "quotes", "reviews", "billing", "accounting", "platform", "map", "reset-password",
  "set-password", "client-login", "lovable", "assets", "public",
]);

/** Staff: set a short custom web address (rideblackwave.com/<slug>) for a client. */
export const setClientPortalSlug = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { clientId: string; slug: string }) => {
    const slug = (data?.slug ?? "")
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9-]+/g, "-")
      .replace(/^-+|-+$/g, "");
    if (slug.length < 2) throw new Error("Use at least 2 letters or numbers");
    if (slug.length > 40) throw new Error("Keep the short link under 40 characters");
    if (RESERVED_SLUGS.has(slug)) throw new Error("That name is reserved — pick another");
    return { clientId: data.clientId, slug };
  })
  .handler(async ({ data, context }): Promise<{ slug: string }> => {
    const supabaseAdmin = await assertStaff(context);
    const { data: taken } = await supabaseAdmin
      .from("clients")
      .select("id")
      .eq("portal_slug", data.slug)
      .neq("id", data.clientId)
      .maybeSingle();
    if (taken) throw new Error("That short link is already used by another client");
    const { error } = await supabaseAdmin
      .from("clients")
      .update({ portal_slug: data.slug })
      .eq("id", data.clientId);
    if (error) throw error;
    return { slug: data.slug };
  });

/** Public: opens a client's invoices with their six-digit access code. */
export const getPortalByCode = createServerFn({ method: "POST" })
  .inputValidator((data: { code: string; slug?: string }) => {
    if (!/^\d{6}$/.test(data?.code ?? "")) throw new Error("Enter the six-digit code");
    return data;
  })
  .handler(async ({ data }): Promise<PortalData> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let q = supabaseAdmin.from("clients").select("id").eq("portal_code", data.code);
    if (data.slug) q = q.eq("portal_slug", data.slug);
    const { data: client } = await q.maybeSingle();
    if (!client) throw new Error("That code is not valid");
    return loadPortal(supabaseAdmin, client.id);
  });



/** Creates a portal sign-in for a client company. */
export const createClientPortalLogin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { clientId: string; email: string; password: string }) => {
    if (!data.email?.includes("@")) throw new Error("Enter a valid email address");
    if (!data.password || data.password.length < 8) throw new Error("Password must be at least 8 characters");
    return data;
  })
  .handler(async ({ data, context }) => {
    await assertStaff(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
    });
    if (error || !created?.user) throw new Error(error?.message ?? "Could not create the login");

    const { error: linkErr } = await supabaseAdmin
      .from("client_users")
      .insert({ client_id: data.clientId, user_id: created.user.id, email: data.email });
    if (linkErr) {
      await supabaseAdmin.auth.admin.deleteUser(created.user.id);
      throw linkErr;
    }
    return { email: data.email };
  });

/** Lists the portal logins attached to a client. */
export const listClientPortalLogins = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { clientId: string }) => data)
  .handler(async ({ data, context }) => {
    const supabaseAdmin = await assertStaff(context);
    const { data: rows = [] } = await supabaseAdmin
      .from("client_users")
      .select("id, email, created_at")
      .eq("client_id", data.clientId);
    return rows as Array<{ id: string; email: string | null; created_at: string }>;
  });

/** Removes a portal sign-in. */
export const removeClientPortalLogin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data, context }) => {
    await assertStaff(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row } = await supabaseAdmin.from("client_users").select("user_id").eq("id", data.id).maybeSingle();
    await supabaseAdmin.from("client_users").delete().eq("id", data.id);
    if (row?.user_id) await supabaseAdmin.auth.admin.deleteUser(row.user_id);
    return { ok: true };
  });

/** Resolves the client behind a portal link, code, or signed-in session. */
async function resolvePortalClient(input: { token?: string | undefined; code?: string | undefined }, context?: any) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  if (input.token && /^[A-Za-z0-9_-]{10,80}$/.test(input.token)) {
    const { data } = await supabaseAdmin.from("clients").select("id").eq("portal_token", input.token).maybeSingle();
    if (data?.id) return data.id as string;
  }
  if (input.code && /^\d{6}$/.test(input.code)) {
    const { data } = await supabaseAdmin.from("clients").select("id").eq("portal_code", input.code).maybeSingle();
    if (data?.id) return data.id as string;
  }
  if (context?.userId) {
    const { data } = await supabaseAdmin
      .from("client_users")
      .select("client_id")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (data?.client_id) return data.client_id as string;
  }
  throw new Error("Your session expired — reopen your invoice link");
}

const validateForward = (data: {
  target: "invoice" | "reservation";
  id: string;
  to: string;
  token?: string | undefined;
  code?: string | undefined;
}) => {
  if (!data?.id || (data.target !== "invoice" && data.target !== "reservation")) throw new Error("Missing invoice");
  const to = (data.to ?? "").trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(to)) throw new Error("Enter a valid email address");
  return { ...data, to };
};

/** Client emails one of their invoices to any address, from a link or code. */
export const forwardInvoiceByEmail = createServerFn({ method: "POST" })
  .inputValidator(validateForward)
  .handler(async ({ data }) => {
    const clientId = await resolvePortalClient(data);
    const { emailInvoiceToAddress } = await import("@/lib/portal-invoice-email.server");
    return emailInvoiceToAddress({ clientId, target: data.target, id: data.id, to: data.to });
  });

/** Client emails one of their invoices to any address while signed in. */
export const forwardMyInvoiceByEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(validateForward)
  .handler(async ({ data, context }) => {
    const clientId = await resolvePortalClient(data, context);
    const { emailInvoiceToAddress } = await import("@/lib/portal-invoice-email.server");
    return emailInvoiceToAddress({ clientId, target: data.target, id: data.id, to: data.to });
  });

/** Records a client's dispute about a charge on one ride. */
async function insertDispute(
  admin: any,
  clientId: string,
  input: { reservationId: string; message: string; amount?: number | undefined; contactEmail?: string | undefined },
) {
  const { data: ride } = await admin
    .from("reservations")
    .select("id, client_id, invoice_id")
    .eq("id", input.reservationId)
    .maybeSingle();
  if (!ride || ride.client_id !== clientId) throw new Error("That ride is not on your account");

  const { error } = await admin.from("ride_disputes").insert({
    reservation_id: ride.id,
    client_id: clientId,
    invoice_id: ride.invoice_id,
    message: input.message,
    amount: Number(input.amount ?? 0) || 0,
    contact_email: input.contactEmail ?? null,
  });
  if (error) throw error;
  return { ok: true };
}

const validateDispute = (data: {
  reservationId: string;
  message: string;
  amount?: number | undefined;
  contactEmail?: string | undefined;
  token?: string | undefined;
  code?: string | undefined;
}) => {
  if (!data?.reservationId) throw new Error("Missing ride");
  if (!data.message || data.message.trim().length < 5) throw new Error("Please describe the issue");
  return { ...data, message: data.message.trim().slice(0, 2000) };
};

/** Dispute a charge from a private link or six-digit code. */
export const submitRideDispute = createServerFn({ method: "POST" })
  .inputValidator(validateDispute)
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let clientId: string | null = null;
    if (data.token && /^[A-Za-z0-9_-]{10,80}$/.test(data.token)) {
      const { data: c } = await supabaseAdmin.from("clients").select("id").eq("portal_token", data.token).maybeSingle();
      clientId = (c?.id as string) ?? null;
    } else if (data.code && /^\d{6}$/.test(data.code)) {
      const { data: c } = await supabaseAdmin.from("clients").select("id").eq("portal_code", data.code).maybeSingle();
      clientId = (c?.id as string) ?? null;
    }
    if (!clientId) throw new Error("Your session expired — reopen your invoice link");
    return insertDispute(supabaseAdmin, clientId, data);
  });

/** Dispute a charge while signed in to the portal. */
export const submitMyRideDispute = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(validateDispute)
  .handler(async ({ data, context }) => {
    const supabase = (context as any).supabase;
    const { data: link } = await supabase
      .from("client_users")
      .select("client_id")
      .eq("user_id", (context as any).userId)
      .maybeSingle();
    if (!link) throw new Error("This sign-in is not linked to a client account");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    return insertDispute(supabaseAdmin, link.client_id as string, data);
  });

const validateCodeChange = (data: { newCode: string; token?: string | undefined; code?: string | undefined }) => {
  const newCode = (data?.newCode ?? "").trim();
  if (!/^\d{6}$/.test(newCode)) throw new Error("Choose a six-digit number");
  return { ...data, newCode };
};

async function applyCodeChange(clientId: string, newCode: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: taken } = await supabaseAdmin
    .from("clients")
    .select("id")
    .eq("portal_code", newCode)
    .maybeSingle();
  if (taken && taken.id !== clientId) throw new Error("That code is already in use — pick another");
  const { error } = await supabaseAdmin.from("clients").update({ portal_code: newCode }).eq("id", clientId);
  if (error) throw error;
  return { ok: true, code: newCode };
}

/** Client changes their own six-digit access code from a link or current code. */
export const changePortalCode = createServerFn({ method: "POST" })
  .inputValidator(validateCodeChange)
  .handler(async ({ data }) => {
    const clientId = await resolvePortalClient(data);
    return applyCodeChange(clientId, data.newCode);
  });

/** Signed-in client changes their own six-digit access code. */
export const changeMyPortalCode = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(validateCodeChange)
  .handler(async ({ data, context }) => {
    const clientId = await resolvePortalClient(data, context);
    return applyCodeChange(clientId, data.newCode);
  });

export const REVIEW_TAGS = [
  "Smooth ride",
  "Driver was punctual",
  "Driver was helpful with luggage",
  "Clean car",
  "Fully dressed",
  "Fiji water available",
  "Bad driving",
  "Smelly car",
  "Driver rude",
  "Didn't follow instructions",
  "No meet and greet",
  "Driver using phone while driving",
] as const;

const validateReview = (data: {
  reservationId: string;
  rating: number;
  tags?: string[] | undefined;
  comment?: string | undefined;
  token?: string | undefined;
  code?: string | undefined;
}) => {
  if (!data?.reservationId) throw new Error("Missing ride");
  const rating = Math.round(Number(data.rating));
  if (!(rating >= 1 && rating <= 5)) throw new Error("Choose 1 to 5 stars");
  const tags = (data.tags ?? []).filter((t) => (REVIEW_TAGS as readonly string[]).includes(t)).slice(0, 12);
  return { ...data, rating, tags, comment: (data.comment ?? "").trim().slice(0, 2000) };
};

async function saveReview(
  clientId: string,
  input: { reservationId: string; rating: number; tags: string[]; comment: string },
) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: ride } = await supabaseAdmin
    .from("reservations")
    .select("id, client_id, company_id")
    .eq("id", input.reservationId)
    .maybeSingle();
  if (!ride || ride.client_id !== clientId) throw new Error("That ride is not on your account");

  const { error } = await supabaseAdmin.from("ride_reviews").upsert(
    {
      reservation_id: ride.id,
      client_id: clientId,
      company_id: ride.company_id as string,
      rating: input.rating,
      tags: input.tags,
      comment: input.comment || null,
    },
    { onConflict: "reservation_id" },
  );
  if (error) throw error;
  return { ok: true };
}

/** Client rates a ride from a private link or six-digit code. */
export const submitRideReview = createServerFn({ method: "POST" })
  .inputValidator(validateReview)
  .handler(async ({ data }) => {
    const clientId = await resolvePortalClient(data);
    return saveReview(clientId, data);
  });

/** Signed-in client rates a ride. */
export const submitMyRideReview = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(validateReview)
  .handler(async ({ data, context }) => {
    const clientId = await resolvePortalClient(data, context);
    return saveReview(clientId, data);
  });
