import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const GATEWAY_URL = "https://connector-gateway.lovable.dev/microsoft_outlook";

type Ctx = { supabase: any; userId: string };

async function assertStaff(ctx: Ctx) {
  const { data, error } = await ctx.supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", ctx.userId)
    .in("role", ["admin", "dispatcher"]);
  if (error || !data?.length) throw new Error("Only admin or dispatch staff can use the inbox.");
}

async function graph(path: string, init?: RequestInit) {
  const lovable = process.env["LOVABLE_API_KEY"];
  const conn = process.env["MICROSOFT_OUTLOOK_API_KEY"];
  if (!lovable || !conn) throw new Error("Outlook is not connected.");
  const res = await fetch(`${GATEWAY_URL}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${lovable}`,
      "X-Connection-Api-Key": conn,
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  if (!res.ok) {
    const body = await res.text();
    console.error(`Outlook request failed [${res.status}]: ${body}`);
    throw new Error(`Outlook request failed [${res.status}]: ${body.slice(0, 300)}`);
  }
  if (res.status === 202 || res.status === 204) return null;
  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

export type InboxMessage = {
  id: string;
  subject: string;
  fromName: string;
  fromEmail: string;
  preview: string;
  receivedAt: string;
  isRead: boolean;
  hasAttachments: boolean;
};

const folderSchema = z.enum(["inbox", "sentitems", "archive"]);

export const listInbox = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ folder: folderSchema.default("inbox"), search: z.string().max(200).optional(), clientEmail: z.string().email().optional() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertStaff(context as Ctx);
    const params = new URLSearchParams({
      $top: "40",
      $select: "id,subject,from,toRecipients,bodyPreview,receivedDateTime,isRead,hasAttachments",
    });
    if (data.clientEmail) {
      params.set("$search", `"participants:${data.clientEmail.replace(/"/g, "")}"`);
    } else if (data.search?.trim()) {
      params.set("$search", `"${data.search.replace(/"/g, "")}"`);
    } else {
      params.set("$orderby", "receivedDateTime desc");
    }
    const path = data.clientEmail ? `/me/messages?${params}` : `/me/mailFolders/${data.folder}/messages?${params}`;
    let json: any;
    try {
      json = await graph(path);
    } catch (e) {
      return { messages: [] as InboxMessage[], error: "Outlook needs to be reconnected." };
    }
    const messages: InboxMessage[] = (json?.value ?? []).map((m: any) => {
      const who = data.folder === "sentitems" ? m.toRecipients?.[0]?.emailAddress : m.from?.emailAddress;
      return {
        id: m.id,
        subject: m.subject || "(no subject)",
        fromName: who?.name ?? "",
        fromEmail: who?.address ?? "",
        preview: m.bodyPreview ?? "",
        receivedAt: m.receivedDateTime,
        isRead: !!m.isRead,
        hasAttachments: !!m.hasAttachments,
      };
    });
    messages.sort((a, b) => b.receivedAt.localeCompare(a.receivedAt));
    return { messages };
  });

export const getInboxMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().min(1).max(500) }).parse(d))
  .handler(async ({ data, context }) => {
    const ctx = context as Ctx;
    await assertStaff(ctx);
    const id = encodeURIComponent(data.id);
    const m = await graph(`/me/messages/${id}?$select=id,subject,from,toRecipients,ccRecipients,body,receivedDateTime,isRead`, {
      headers: { Prefer: 'outlook.body-content-type="text"' },
    });
    if (!m.isRead) {
      await graph(`/me/messages/${id}`, { method: "PATCH", body: JSON.stringify({ isRead: true }) }).catch(() => null);
    }
    const fromEmail: string = m.from?.emailAddress?.address ?? "";
    let client: { id: string; name: string } | null = null;
    if (fromEmail) {
      const { data: rows } = await ctx.supabase
        .from("clients")
        .select("id,name")
        .or(`email.ilike.${fromEmail},billing_contact_email.ilike.${fromEmail},booking_contact_email.ilike.${fromEmail}`)
        .limit(1);
      client = rows?.[0] ?? null;
    }
    return {
      id: m.id as string,
      subject: (m.subject as string) || "(no subject)",
      fromName: m.from?.emailAddress?.name ?? "",
      fromEmail,
      to: (m.toRecipients ?? []).map((r: any) => r.emailAddress?.address).filter(Boolean) as string[],
      cc: (m.ccRecipients ?? []).map((r: any) => r.emailAddress?.address).filter(Boolean) as string[],
      body: (m.body?.content as string) ?? "",
      receivedAt: m.receivedDateTime as string,
      client,
    };
  });

export const replyInboxMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().min(1).max(500), comment: z.string().min(1).max(20000), replyAll: z.boolean().default(false) }).parse(d))
  .handler(async ({ data, context }) => {
    await assertStaff(context as Ctx);
    await graph(`/me/messages/${encodeURIComponent(data.id)}/${data.replyAll ? "replyAll" : "reply"}`, {
      method: "POST",
      body: JSON.stringify({ comment: data.comment }),
    });
    return { ok: true };
  });

export const sendInboxEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ to: z.string().email(), cc: z.string().email().optional().or(z.literal("")), subject: z.string().min(1).max(300), body: z.string().min(1).max(20000) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertStaff(context as Ctx);
    await graph(`/me/sendMail`, {
      method: "POST",
      body: JSON.stringify({
        message: {
          subject: data.subject,
          body: { contentType: "Text", content: data.body },
          toRecipients: [{ emailAddress: { address: data.to } }],
          ccRecipients: data.cc ? [{ emailAddress: { address: data.cc } }] : [],
        },
      }),
    });
    return { ok: true };
  });

export const updateInboxMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().min(1).max(500), action: z.enum(["archive", "read", "unread"]) }).parse(d))
  .handler(async ({ data, context }) => {
    await assertStaff(context as Ctx);
    const id = encodeURIComponent(data.id);
    if (data.action === "archive") {
      await graph(`/me/messages/${id}/move`, { method: "POST", body: JSON.stringify({ destinationId: "archive" }) });
    } else {
      await graph(`/me/messages/${id}`, { method: "PATCH", body: JSON.stringify({ isRead: data.action === "read" }) });
    }
    return { ok: true };
  });
