/** Resolves which client account a portal visitor belongs to (server only). */
export async function resolvePortalClientId(
  admin: any,
  input: { token?: string | undefined; code?: string | undefined; userId?: string | undefined },
): Promise<string> {
  if (input.token && /^[A-Za-z0-9_-]{10,80}$/.test(input.token)) {
    const { data } = await admin.from("clients").select("id").eq("portal_token", input.token).maybeSingle();
    if (data?.id) return data.id as string;
  }
  if (input.code && /^\d{6}$/.test(input.code)) {
    const { data } = await admin.from("clients").select("id").eq("portal_code", input.code).maybeSingle();
    if (data?.id) return data.id as string;
  }
  if (input.userId) {
    const { data } = await admin
      .from("client_users")
      .select("client_id")
      .eq("user_id", input.userId)
      .maybeSingle();
    if (data?.client_id) return data.client_id as string;
  }
  throw new Error("Your session expired — reopen your portal link");
}
