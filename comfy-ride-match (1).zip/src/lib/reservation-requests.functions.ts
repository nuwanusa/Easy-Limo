import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type ReservationRequest = {
  id: string;
  client_id: string;
  client_name?: string | null;
  pickup_at: string;
  pickup_address: string;
  dropoff_address: string;
  vehicle_class: string;
  booking_type: string;
  hours: number;
  passenger_count: number;
  luggage_count: number;
  passenger_name: string | null;
  contact_phone: string | null;
  contact_email: string | null;
  notes: string | null;
  status: string;
  reservation_id: string | null;
  created_at: string;
};

export type RequestInput = {
  pickup_at: string;
  pickup_address: string;
  dropoff_address: string;
  vehicle_class: string;
  booking_type: "point_to_point" | "hourly";
  hours: number;
  passenger_count: number;
  luggage_count: number;
  passenger_name: string;
  contact_phone: string;
  contact_email: string;
  notes: string;
  token?: string | undefined;
  code?: string | undefined;
};

const validate = (data: RequestInput): RequestInput => {
  const pickup = new Date(data.pickup_at);
  if (!data.pickup_at || Number.isNaN(pickup.getTime())) throw new Error("Choose a pickup date and time");
  if (!data.pickup_address?.trim()) throw new Error("Enter a pickup location");
  const hourly = data.booking_type === "hourly";
  if (!hourly && !data.dropoff_address?.trim()) throw new Error("Enter a drop-off location");
  if (hourly && (!Number(data.hours) || Number(data.hours) <= 0)) throw new Error("Enter the number of hours");
  return {
    ...data,
    pickup_at: pickup.toISOString(),
    pickup_address: data.pickup_address.trim(),
    dropoff_address: (data.dropoff_address ?? "").trim(),
    vehicle_class: (data.vehicle_class || "sedan").trim(),
    booking_type: hourly ? "hourly" : "point_to_point",
    hours: hourly ? Number(data.hours) : 0,
    passenger_count: Math.max(1, Math.min(Number(data.passenger_count) || 1, 60)),
    luggage_count: Math.max(0, Math.min(Number(data.luggage_count) || 0, 60)),
    passenger_name: (data.passenger_name ?? "").trim().slice(0, 120),
    contact_phone: (data.contact_phone ?? "").trim().slice(0, 40),
    contact_email: (data.contact_email ?? "").trim().slice(0, 160),
    notes: (data.notes ?? "").trim().slice(0, 1000),
  };
};

async function insertRequest(data: RequestInput, userId?: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { resolvePortalClientId } = await import("@/lib/portal-client.server");
  const clientId = await resolvePortalClientId(supabaseAdmin, {
    token: data.token,
    code: data.code,
    userId,
  });
  const { data: client } = await supabaseAdmin
    .from("clients")
    .select("company_id, name, contact_name, phone, email")
    .eq("id", clientId)
    .maybeSingle();
  if (!client) throw new Error("Client account not found");

  const { error } = await supabaseAdmin.from("reservation_requests").insert({
    client_id: clientId,
    company_id: client.company_id,
    pickup_at: data.pickup_at,
    pickup_address: data.pickup_address,
    dropoff_address: data.dropoff_address,
    vehicle_class: data.vehicle_class,
    booking_type: data.booking_type,
    hours: data.hours,
    passenger_count: data.passenger_count,
    luggage_count: data.luggage_count,
    passenger_name: data.passenger_name || client.contact_name || client.name,
    contact_phone: data.contact_phone || client.phone,
    contact_email: data.contact_email || client.email,
    notes: data.notes || null,
    status: "pending",
  });
  if (error) throw error;
  return { ok: true as const };
}

/** A client sends a reservation request from a portal link or access code. */
export const submitReservationRequest = createServerFn({ method: "POST" })
  .inputValidator(validate)
  .handler(async ({ data }) => insertRequest(data));

/** A signed-in client account sends a reservation request. */
export const submitMyReservationRequest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(validate)
  .handler(async ({ data, context }) => insertRequest(data, (context as any).userId));

/** The client's own requests, for the portal list. */
export const listMyReservationRequests = createServerFn({ method: "POST" })
  .inputValidator((data: { token?: string | undefined; code?: string | undefined }) => data ?? {})
  .handler(async ({ data }): Promise<ReservationRequest[]> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { resolvePortalClientId } = await import("@/lib/portal-client.server");
    const clientId = await resolvePortalClientId(supabaseAdmin, data);
    const { data: rows = [] } = await supabaseAdmin
      .from("reservation_requests")
      .select("*")
      .eq("client_id", clientId)
      .order("created_at", { ascending: false });
    return (rows ?? []) as ReservationRequest[];
  });

async function assertStaff(context: any) {
  const { data } = await context.supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", context.userId);
  const roles = (data ?? []).map((r: { role: string }) => r.role);
  if (!roles.includes("admin") && !roles.includes("dispatcher")) throw new Error("Not allowed");
}

/** Staff list of reservation requests waiting for approval. */
export const listReservationRequests = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<ReservationRequest[]> => {
    await assertStaff(context);
    const { data: rows = [] } = await (context as any).supabase
      .from("reservation_requests")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(200);
    const list = (rows ?? []) as ReservationRequest[];
    const ids = [...new Set(list.map((r) => r.client_id))];
    if (ids.length) {
      const { data: clients = [] } = await (context as any).supabase
        .from("clients")
        .select("id, name")
        .in("id", ids);
      const byId = new Map<string, string>((clients ?? []).map((c: any) => [c.id as string, c.name as string]));
      for (const r of list) r.client_name = byId.get(r.client_id) ?? null;
    }
    return list;
  });

/** Staff approves a request: creates the reservation and emails the confirmation. */
export const approveReservationRequest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { id: string }) => {
    if (!/^[0-9a-fA-F-]{36}$/.test(data?.id ?? "")) throw new Error("Invalid request");
    return data;
  })
  .handler(async ({ data, context }) => {
    await assertStaff(context);
    const supabase = (context as any).supabase;
    const { data: req, error } = await supabase
      .from("reservation_requests")
      .select("*")
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw error;
    if (!req) throw new Error("Request not found");
    if (req.status === "approved" && req.reservation_id) return { reservationId: req.reservation_id as string };

    const { data: ride, error: insertError } = await supabase
      .from("reservations")
      .insert({
        reference: `AUR-${Math.floor(1000 + Math.random() * 9000)}`,
        client_id: req.client_id,
        company_id: req.company_id,
        passenger_name: req.passenger_name || "Client passenger",
        passenger_phone: req.contact_phone,
        passenger_email: req.contact_email,
        passenger_count: req.passenger_count,
        luggage_count: req.luggage_count,
        pickup_address: req.pickup_address,
        pickup_at: req.pickup_at,
        dropoff_address: req.dropoff_address || req.pickup_address,
        vehicle_class: req.vehicle_class,
        booking_type: req.booking_type,
        hours: req.hours,
        notes: req.notes,
        status: "unassigned",
      })
      .select("id")
      .single();
    if (insertError) throw insertError;

    await supabase
      .from("reservation_requests")
      .update({ status: "approved", reservation_id: ride.id })
      .eq("id", req.id);

    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const { sendClientTripNotice } = await import("@/lib/client-notify.server");
      await sendClientTripNotice(supabaseAdmin, ride.id as string, "reservation");
    } catch (e) {
      console.error("confirmation email failed", e);
    }

    return { reservationId: ride.id as string };
  });

/** Staff declines a request. */
export const declineReservationRequest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { id: string }) => {
    if (!/^[0-9a-fA-F-]{36}$/.test(data?.id ?? "")) throw new Error("Invalid request");
    return data;
  })
  .handler(async ({ data, context }) => {
    await assertStaff(context);
    const { error } = await (context as any).supabase
      .from("reservation_requests")
      .update({ status: "declined" })
      .eq("id", data.id);
    if (error) throw error;
    return { ok: true as const };
  });

export type TrackedRide = {
  id: string;
  reference: string;
  status: string;
  pickup_at: string;
  pickup_address: string;
  dropoff_address: string;
  driver_name: string | null;
  driver_phone: string | null;
  vehicle: string | null;
  vehicle_plate: string | null;
  vehicle_color: string | null;
  lat: number | null;
  lng: number | null;
  last_seen_at: string | null;
  eta_minutes: number | null;
  eta_arrival: string | null;
  eta_destination: string | null;
};

const TRACKABLE = ["confirmed", "assigned", "en_route", "on_location", "passenger_on_board"];
const LIVE_LOCATION_MAX_AGE_MS = 90_000;

const freshLocationAt = (value: string | null | undefined) => {
  if (!value) return false;
  const timestamp = new Date(value).getTime();
  return Number.isFinite(timestamp) && Date.now() - timestamp <= LIVE_LOCATION_MAX_AGE_MS;
};

/** Live vehicle position for the client's confirmed / in-progress rides. */
export const getMyRideTracking = createServerFn({ method: "POST" })
  .inputValidator((data: { token?: string | undefined; code?: string | undefined }) => data ?? {})
  .handler(async ({ data }): Promise<TrackedRide[]> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { resolvePortalClientId } = await import("@/lib/portal-client.server");
    const clientId = await resolvePortalClientId(supabaseAdmin, data);

    const since = new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString();
    const { data: rides = [] } = await supabaseAdmin
      .from("reservations")
      .select("id, reference, status, pickup_at, pickup_address, dropoff_address, driver_id, vehicle_id")
      .eq("client_id", clientId)
      .in("status", TRACKABLE)
      .gte("pickup_at", since)
      .order("pickup_at", { ascending: true })
      .limit(10);

    const out: TrackedRide[] = [];
    for (const r of rides ?? []) {
      let driver: any = null;
      if (r.driver_id) {
        const { data } = await supabaseAdmin
          .from("drivers")
          .select("full_name, phone, last_lat, last_lng, last_seen_at, default_vehicle_id")
          .eq("id", r.driver_id)
          .maybeSingle();
        driver = data;
      }
      // Prefer the freshest GPS ping recorded for this ride over the driver's last known spot.
      const { data: ping } = await supabaseAdmin
        .from("ride_track_points")
        .select("lat, lng, recorded_at")
        .eq("reservation_id", r.id)
        .order("recorded_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      const vehicleId = r.vehicle_id ?? driver?.default_vehicle_id ?? null;
      let vehicle: any = null;
      if (vehicleId) {
        const { data } = await supabaseAdmin
          .from("vehicles")
          .select("make, model, name, plate, color")
          .eq("id", vehicleId)
          .maybeSingle();
        vehicle = data;
      }
      const pingFresh = freshLocationAt(ping?.recorded_at);
      const driverFresh = freshLocationAt(driver?.last_seen_at);
      const lat = pingFresh ? ping?.lat ?? null : driverFresh ? driver?.last_lat ?? null : null;
      const lng = pingFresh ? ping?.lng ?? null : driverFresh ? driver?.last_lng ?? null : null;
      const locationAt = pingFresh ? ping?.recorded_at ?? null : driverFresh ? driver?.last_seen_at ?? null : null;

      // ETA to the pickup (before boarding) or drop-off (once on board).
      let eta: { minutes: number; arrival: string; destination: string } | null = null;
      if (lat != null && lng != null) {
        const onboard = r.status === "passenger_on_board";
        const destination = onboard ? r.dropoff_address : r.pickup_address;
        eta = await driveEta(Number(lat), Number(lng), destination);
      }

      out.push({
        id: r.id,
        reference: r.reference,
        status: r.status,
        pickup_at: r.pickup_at,
        pickup_address: r.pickup_address,
        dropoff_address: r.dropoff_address,
        driver_name: driver?.full_name ?? null,
        driver_phone: driver?.phone ?? null,
        vehicle: vehicle ? [vehicle.make, vehicle.model].filter(Boolean).join(" ") || vehicle.name : null,
        vehicle_plate: vehicle?.plate ?? null,
        vehicle_color: vehicle?.color ?? null,
        lat,
        lng,
        last_seen_at: locationAt,
        eta_minutes: eta?.minutes ?? null,
        eta_arrival: eta?.arrival ?? null,
        eta_destination: eta?.destination ?? null,
      });
    }
    return out;
  });

const ETA_GATEWAY = "https://connector-gateway.lovable.dev/google_maps";

/** Traffic-aware drive time from the chauffeur's live position to an address. */
async function driveEta(lat: number, lng: number, destination: string) {
  const lovableKey = process.env["LOVABLE_API_KEY"];
  const mapsKey = process.env["GOOGLE_MAPS_API_KEY"];
  if (!lovableKey || !mapsKey || !destination?.trim()) return null;
  try {
    const response = await fetch(`${ETA_GATEWAY}/routes/directions/v2:computeRoutes`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${lovableKey}`,
        "X-Connection-Api-Key": mapsKey,
        "Content-Type": "application/json",
        "X-Goog-FieldMask": "routes.duration",
      },
      body: JSON.stringify({
        origin: { location: { latLng: { latitude: lat, longitude: lng } } },
        destination: { address: destination },
        travelMode: "DRIVE",
        routingPreference: "TRAFFIC_AWARE",
        regionCode: "US",
      }),
    });
    if (!response.ok) return null;
    const json = (await response.json()) as { routes?: Array<{ duration?: string }> };
    const duration = json.routes?.[0]?.duration;
    if (!duration) return null;
    const seconds = Number(String(duration).replace("s", ""));
    return {
      minutes: Math.max(1, Math.round(seconds / 60)),
      arrival: new Date(Date.now() + seconds * 1000).toISOString(),
      destination,
    };
  } catch {
    return null;
  }
}
