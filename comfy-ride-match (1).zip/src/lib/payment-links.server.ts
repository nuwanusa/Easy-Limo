// Server-only helpers for short card-payment links (/pay/<code>).
// Each invoice/reservation gets one stable short code stored in payment_links.

const ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; // no easily-confused characters

function randomCode(length = 8) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  let out = "";
  for (const b of bytes) out += ALPHABET[b % ALPHABET.length];
  return out;
}

/** Returns the existing short code for a payment target, creating one on first use. */
export async function ensurePaymentLinkCode(
  target: "invoice" | "reservation",
  targetId: string,
): Promise<string> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: existing } = await supabaseAdmin
    .from("payment_links")
    .select("code")
    .eq("target", target)
    .eq("target_id", targetId)
    .maybeSingle();
  if (existing?.code) return existing.code as string;
  for (let attempt = 0; attempt < 5; attempt++) {
    const code = randomCode();
    const { data, error } = await supabaseAdmin
      .from("payment_links")
      .upsert({ target, target_id: targetId, code }, { onConflict: "target,target_id" })
      .select("code")
      .single();
    if (!error && data?.code) return data.code as string;
  }
  throw new Error("Could not allocate a short payment code");
}

/** Looks a short code back up to its payment target. Returns null when unknown. */
export async function resolvePaymentLinkCode(code: string) {
  const normalized = code.trim().toUpperCase();
  if (!/^[A-Z0-9]{4,16}$/.test(normalized)) return null;
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("payment_links")
    .select("target, target_id")
    .eq("code", normalized)
    .maybeSingle();
  if (!data) return null;
  return { target: data.target as "invoice" | "reservation", id: data.target_id as string };
}

/**
 * Public absolute payment URL used in emails: a short /pay/<code> link,
 * falling back to the long payment page if the code cannot be allocated.
 */
export async function publicPaymentUrl(target: "invoice" | "reservation", id: string) {
  try {
    const code = await ensurePaymentLinkCode(target, id);
    return `https://rideblackwave.com/p/${code}`;
  } catch {
    return `https://rideblackwave.com/paycard/${target}/${id}`;
  }
}
