import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type CreateInput = { email: string; password: string; role: "admin" | "dispatcher" };

async function assertAdmin(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  if (!data) throw new Error("Only the main admin can manage staff accounts");
  return supabaseAdmin;
}

/** The company the signed-in admin belongs to (null for legacy platform accounts). */
async function companyOf(
  supabaseAdmin: Awaited<ReturnType<typeof assertAdmin>>,
  userId: string,
): Promise<string | null> {
  const { data } = await supabaseAdmin
    .from("company_users")
    .select("company_id")
    .eq("user_id", userId)
    .maybeSingle();
  return (data?.company_id as string | undefined) ?? null;
}

export const listStaffAccounts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const supabaseAdmin = await assertAdmin(context.userId);
    const { data: roles, error } = await supabaseAdmin
      .from("user_roles")
      .select("user_id, role")
      .in("role", ["admin", "dispatcher"]);
    if (error) throw error;
    const company = await companyOf(supabaseAdmin, context.userId);
    let sameCompany: Set<string> | null = null;
    if (company) {
      const { data: members } = await supabaseAdmin
        .from("company_users")
        .select("user_id")
        .eq("company_id", company);
      sameCompany = new Set((members ?? []).map((m) => m.user_id as string));
    }
    const { data: list } = await supabaseAdmin.auth.admin.listUsers();
    const byId = new Map((list?.users ?? []).map((u) => [u.id, u.email ?? ""]));
    return (roles ?? [])
      .filter((r) => !sameCompany || sameCompany.has(r.user_id as string))
      .map((r) => ({
        userId: r.user_id as string,
        role: r.role as "admin" | "dispatcher",
        email: byId.get(r.user_id as string) ?? "",
      }));
  });

export const createStaffAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: CreateInput) => {
    const email = input.email?.trim().toLowerCase();
    if (!email || !email.includes("@")) throw new Error("A valid email is required");
    if (!input.password || input.password.length < 8)
      throw new Error("Password must be at least 8 characters");
    if (input.role !== "admin" && input.role !== "dispatcher")
      throw new Error("Invalid role");
    return { email, password: input.password, role: input.role };
  })
  .handler(async ({ data, context }) => {
    const supabaseAdmin = await assertAdmin(context.userId);

    let userId: string | null = null;
    const created = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
    });
    if (created.error) {
      const { data: list } = await supabaseAdmin.auth.admin.listUsers();
      const existing = list?.users?.find((u) => u.email?.toLowerCase() === data.email);
      if (!existing) throw new Error(created.error.message);
      userId = existing.id;
      const { error } = await supabaseAdmin.auth.admin.updateUserById(existing.id, {
        password: data.password,
        email_confirm: true,
      });
      if (error) throw new Error(error.message);
    } else {
      userId = created.data.user?.id ?? null;
    }
    if (!userId) throw new Error("Could not create the account");

    await supabaseAdmin.from("user_roles").delete().eq("user_id", userId).in("role", ["admin", "dispatcher"]);
    const { error: roleError } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: userId, role: data.role });
    if (roleError) throw roleError;

    const company = await companyOf(supabaseAdmin, context.userId);
    if (company) {
      await supabaseAdmin
        .from("company_users")
        .upsert(
          { user_id: userId, company_id: company, must_change_password: false },
          { onConflict: "user_id" },
        );
    }

    return { ok: true, email: data.email, role: data.role };
  });

export const removeStaffAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { userId: string }) => {
    if (!input?.userId) throw new Error("Missing account");
    return { userId: input.userId };
  })
  .handler(async ({ data, context }) => {
    const supabaseAdmin = await assertAdmin(context.userId);
    if (data.userId === context.userId) throw new Error("You cannot remove your own access");
    const { error } = await supabaseAdmin
      .from("user_roles")
      .delete()
      .eq("user_id", data.userId)
      .in("role", ["admin", "dispatcher"]);
    if (error) throw error;
    return { ok: true };
  });
