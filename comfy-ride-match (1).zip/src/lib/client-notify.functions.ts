import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Emails the client about a reservation (booked, chauffeur accepted or a
 * reminder), when that client has the matching notification enabled.
 * Runs with elevated access so an assigned chauffeur can trigger the
 * "accepted" notice without being able to read client records directly.
 */
export const sendClientRideNotice = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: { reservationId: string; kind: "reservation" | "accepted" | "reminder" }) => {
    if (!/^[0-9a-fA-F-]{36}$/.test(data.reservationId)) throw new Error("Invalid reservation id");
    if (!["reservation", "accepted", "reminder"].includes(data.kind)) throw new Error("Invalid kind");
    return data;
  })
  .handler(async ({ data, context }) => {
    // The caller must be able to see the ride under their own RLS.
    const { data: visible, error } = await context.supabase
      .from("reservations")
      .select("id")
      .eq("id", data.reservationId)
      .maybeSingle();
    if (error) throw error;
    if (!visible) return { sent: false, reason: "not_allowed" as const };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { sendClientTripNotice } = await import("@/lib/client-notify.server");
    return sendClientTripNotice(supabaseAdmin, data.reservationId, data.kind);
  });
