export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      affiliate_earnings: {
        Row: {
          affiliate_id: string
          amount: number
          company_id: string
          created_at: string
          id: string
          kind: string
          notes: string | null
          reservation_id: string | null
          statement_id: string | null
          updated_at: string
        }
        Insert: {
          affiliate_id: string
          amount?: number
          company_id: string
          created_at?: string
          id?: string
          kind?: string
          notes?: string | null
          reservation_id?: string | null
          statement_id?: string | null
          updated_at?: string
        }
        Update: {
          affiliate_id?: string
          amount?: number
          company_id?: string
          created_at?: string
          id?: string
          kind?: string
          notes?: string | null
          reservation_id?: string | null
          statement_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "affiliate_earnings_affiliate_id_fkey"
            columns: ["affiliate_id"]
            isOneToOne: false
            referencedRelation: "affiliates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "affiliate_earnings_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "affiliate_earnings_reservation_id_fkey"
            columns: ["reservation_id"]
            isOneToOne: false
            referencedRelation: "reservations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "affiliate_earnings_statement_id_fkey"
            columns: ["statement_id"]
            isOneToOne: false
            referencedRelation: "affiliate_statements"
            referencedColumns: ["id"]
          },
        ]
      }
      affiliate_statements: {
        Row: {
          affiliate_id: string
          company_id: string
          created_at: string
          id: string
          notes: string | null
          paid_at: string | null
          period_end: string | null
          period_start: string | null
          sent_at: string | null
          statement_number: string
          status: string
          total: number
          updated_at: string
        }
        Insert: {
          affiliate_id: string
          company_id: string
          created_at?: string
          id?: string
          notes?: string | null
          paid_at?: string | null
          period_end?: string | null
          period_start?: string | null
          sent_at?: string | null
          statement_number: string
          status?: string
          total?: number
          updated_at?: string
        }
        Update: {
          affiliate_id?: string
          company_id?: string
          created_at?: string
          id?: string
          notes?: string | null
          paid_at?: string | null
          period_end?: string | null
          period_start?: string | null
          sent_at?: string | null
          statement_number?: string
          status?: string
          total?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "affiliate_statements_affiliate_id_fkey"
            columns: ["affiliate_id"]
            isOneToOne: false
            referencedRelation: "affiliates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "affiliate_statements_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      affiliates: {
        Row: {
          address_line1: string | null
          city: string | null
          company_id: string
          contact_name: string | null
          created_at: string
          default_percent: number
          email: string | null
          id: string
          kind: string
          name: string
          notes: string | null
          phone: string | null
          portal_code: string
          postal_code: string | null
          referral_percent: number
          state: string | null
          status: string
          updated_at: string
        }
        Insert: {
          address_line1?: string | null
          city?: string | null
          company_id: string
          contact_name?: string | null
          created_at?: string
          default_percent?: number
          email?: string | null
          id?: string
          kind?: string
          name: string
          notes?: string | null
          phone?: string | null
          portal_code?: string
          postal_code?: string | null
          referral_percent?: number
          state?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          address_line1?: string | null
          city?: string | null
          company_id?: string
          contact_name?: string | null
          created_at?: string
          default_percent?: number
          email?: string | null
          id?: string
          kind?: string
          name?: string
          notes?: string | null
          phone?: string | null
          portal_code?: string
          postal_code?: string | null
          referral_percent?: number
          state?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "affiliates_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      client_cards: {
        Row: {
          billing_city: string | null
          billing_country: string
          billing_line1: string | null
          billing_line2: string | null
          billing_postal_code: string | null
          billing_state: string | null
          brand: string
          cardholder_email: string | null
          cardholder_name: string
          cardholder_phone: string | null
          client_id: string
          created_at: string
          exp_month: number
          exp_year: number
          id: string
          is_default: boolean
          last4: string
          stripe_customer_id: string
          stripe_payment_method_id: string
          updated_at: string
        }
        Insert: {
          billing_city?: string | null
          billing_country?: string
          billing_line1?: string | null
          billing_line2?: string | null
          billing_postal_code?: string | null
          billing_state?: string | null
          brand?: string
          cardholder_email?: string | null
          cardholder_name?: string
          cardholder_phone?: string | null
          client_id: string
          created_at?: string
          exp_month?: number
          exp_year?: number
          id?: string
          is_default?: boolean
          last4?: string
          stripe_customer_id: string
          stripe_payment_method_id: string
          updated_at?: string
        }
        Update: {
          billing_city?: string | null
          billing_country?: string
          billing_line1?: string | null
          billing_line2?: string | null
          billing_postal_code?: string | null
          billing_state?: string | null
          brand?: string
          cardholder_email?: string | null
          cardholder_name?: string
          cardholder_phone?: string | null
          client_id?: string
          created_at?: string
          exp_month?: number
          exp_year?: number
          id?: string
          is_default?: boolean
          last4?: string
          stripe_customer_id?: string
          stripe_payment_method_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_cards_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      client_passengers: {
        Row: {
          client_id: string
          created_at: string
          email: string | null
          full_name: string
          id: string
          notes: string | null
          phone: string | null
          updated_at: string
        }
        Insert: {
          client_id: string
          created_at?: string
          email?: string | null
          full_name: string
          id?: string
          notes?: string | null
          phone?: string | null
          updated_at?: string
        }
        Update: {
          client_id?: string
          created_at?: string
          email?: string | null
          full_name?: string
          id?: string
          notes?: string | null
          phone?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_passengers_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      client_rates: {
        Row: {
          amount: number
          client_id: string
          created_at: string
          id: string
          label: string
          minimum_hours: number
          notes: string | null
          rate_type: string
          updated_at: string
          vehicle_class: string
        }
        Insert: {
          amount?: number
          client_id: string
          created_at?: string
          id?: string
          label: string
          minimum_hours?: number
          notes?: string | null
          rate_type?: string
          updated_at?: string
          vehicle_class?: string
        }
        Update: {
          amount?: number
          client_id?: string
          created_at?: string
          id?: string
          label?: string
          minimum_hours?: number
          notes?: string | null
          rate_type?: string
          updated_at?: string
          vehicle_class?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_rates_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      client_users: {
        Row: {
          client_id: string
          created_at: string
          email: string | null
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          client_id: string
          created_at?: string
          email?: string | null
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          client_id?: string
          created_at?: string
          email?: string | null
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "client_users_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      clients: {
        Row: {
          account_number: string
          address_line1: string | null
          address_line2: string | null
          billing_contact_email: string | null
          billing_contact_phone: string | null
          booking_contact_email: string | null
          booking_contact_name: string | null
          booking_contact_phone: string | null
          company_id: string
          contact_name: string | null
          created_at: string
          email: string | null
          id: string
          name: string
          notify_driver_accepted: boolean
          notify_invoice: boolean
          notify_payment: boolean
          notify_reservation: boolean
          notify_ride_reminder: boolean
          phone: string | null
          portal_code: string | null
          portal_slug: string | null
          portal_token: string | null
          referral_percent: number
          referred_by_affiliate_id: string | null
          terms: string
          updated_at: string
        }
        Insert: {
          account_number?: string
          address_line1?: string | null
          address_line2?: string | null
          billing_contact_email?: string | null
          billing_contact_phone?: string | null
          booking_contact_email?: string | null
          booking_contact_name?: string | null
          booking_contact_phone?: string | null
          company_id?: string
          contact_name?: string | null
          created_at?: string
          email?: string | null
          id?: string
          name: string
          notify_driver_accepted?: boolean
          notify_invoice?: boolean
          notify_payment?: boolean
          notify_reservation?: boolean
          notify_ride_reminder?: boolean
          phone?: string | null
          portal_code?: string | null
          portal_slug?: string | null
          portal_token?: string | null
          referral_percent?: number
          referred_by_affiliate_id?: string | null
          terms?: string
          updated_at?: string
        }
        Update: {
          account_number?: string
          address_line1?: string | null
          address_line2?: string | null
          billing_contact_email?: string | null
          billing_contact_phone?: string | null
          booking_contact_email?: string | null
          booking_contact_name?: string | null
          booking_contact_phone?: string | null
          company_id?: string
          contact_name?: string | null
          created_at?: string
          email?: string | null
          id?: string
          name?: string
          notify_driver_accepted?: boolean
          notify_invoice?: boolean
          notify_payment?: boolean
          notify_reservation?: boolean
          notify_ride_reminder?: boolean
          phone?: string | null
          portal_code?: string | null
          portal_slug?: string | null
          portal_token?: string | null
          referral_percent?: number
          referred_by_affiliate_id?: string | null
          terms?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "clients_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "clients_referred_by_affiliate_id_fkey"
            columns: ["referred_by_affiliate_id"]
            isOneToOne: false
            referencedRelation: "affiliates"
            referencedColumns: ["id"]
          },
        ]
      }
      companies: {
        Row: {
          address_line1: string | null
          address_line2: string | null
          billing_email: string | null
          city: string | null
          code: string
          contact_email: string | null
          created_at: string
          default_email: string | null
          fax: string | null
          id: string
          logo_url: string | null
          name: string
          phone_primary: string | null
          phone_secondary: string | null
          postal_code: string | null
          state: string | null
          status: string
          support_email: string | null
          updated_at: string
          website: string | null
        }
        Insert: {
          address_line1?: string | null
          address_line2?: string | null
          billing_email?: string | null
          city?: string | null
          code: string
          contact_email?: string | null
          created_at?: string
          default_email?: string | null
          fax?: string | null
          id?: string
          logo_url?: string | null
          name: string
          phone_primary?: string | null
          phone_secondary?: string | null
          postal_code?: string | null
          state?: string | null
          status?: string
          support_email?: string | null
          updated_at?: string
          website?: string | null
        }
        Update: {
          address_line1?: string | null
          address_line2?: string | null
          billing_email?: string | null
          city?: string | null
          code?: string
          contact_email?: string | null
          created_at?: string
          default_email?: string | null
          fax?: string | null
          id?: string
          logo_url?: string | null
          name?: string
          phone_primary?: string | null
          phone_secondary?: string | null
          postal_code?: string | null
          state?: string | null
          status?: string
          support_email?: string | null
          updated_at?: string
          website?: string | null
        }
        Relationships: []
      }
      company_subscriptions: {
        Row: {
          company_id: string
          created_at: string
          plan_code: string
          status: string
          trial_ends_at: string | null
          updated_at: string
          wake_up_calls_enabled: boolean
          wake_up_monthly_cents: number
          wake_up_per_call_cents: number
        }
        Insert: {
          company_id: string
          created_at?: string
          plan_code: string
          status?: string
          trial_ends_at?: string | null
          updated_at?: string
          wake_up_calls_enabled?: boolean
          wake_up_monthly_cents?: number
          wake_up_per_call_cents?: number
        }
        Update: {
          company_id?: string
          created_at?: string
          plan_code?: string
          status?: string
          trial_ends_at?: string | null
          updated_at?: string
          wake_up_calls_enabled?: boolean
          wake_up_monthly_cents?: number
          wake_up_per_call_cents?: number
        }
        Relationships: [
          {
            foreignKeyName: "company_subscriptions_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: true
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "company_subscriptions_plan_code_fkey"
            columns: ["plan_code"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["code"]
          },
        ]
      }
      company_users: {
        Row: {
          company_id: string
          created_at: string
          id: string
          must_change_password: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          company_id: string
          created_at?: string
          id?: string
          must_change_password?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          company_id?: string
          created_at?: string
          id?: string
          must_change_password?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "company_users_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      drivers: {
        Row: {
          address_line1: string | null
          address_line2: string | null
          badge_number: string | null
          city: string | null
          company_id: string
          created_at: string
          date_of_birth: string | null
          default_vehicle_id: string | null
          email: string | null
          emergency_contact_name: string | null
          emergency_contact_phone: string | null
          full_name: string
          hire_date: string | null
          id: string
          insurance_expiry: string | null
          insurance_policy: string | null
          insurance_provider: string | null
          is_active: boolean
          is_guest: boolean
          is_online: boolean
          last_lat: number | null
          last_lng: number | null
          last_seen_at: string | null
          license_class: string | null
          license_expiry: string | null
          license_number: string | null
          license_state: string | null
          notes: string | null
          pay_rate: number
          pay_type: string
          payout_account_number: string | null
          payout_bank_name: string | null
          payout_handle: string | null
          payout_method: string | null
          payout_routing_number: string | null
          phone: string | null
          postal_code: string | null
          state: string | null
          status: string
          tlc_expiry: string | null
          tlc_number: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          address_line1?: string | null
          address_line2?: string | null
          badge_number?: string | null
          city?: string | null
          company_id?: string
          created_at?: string
          date_of_birth?: string | null
          default_vehicle_id?: string | null
          email?: string | null
          emergency_contact_name?: string | null
          emergency_contact_phone?: string | null
          full_name: string
          hire_date?: string | null
          id?: string
          insurance_expiry?: string | null
          insurance_policy?: string | null
          insurance_provider?: string | null
          is_active?: boolean
          is_guest?: boolean
          is_online?: boolean
          last_lat?: number | null
          last_lng?: number | null
          last_seen_at?: string | null
          license_class?: string | null
          license_expiry?: string | null
          license_number?: string | null
          license_state?: string | null
          notes?: string | null
          pay_rate?: number
          pay_type?: string
          payout_account_number?: string | null
          payout_bank_name?: string | null
          payout_handle?: string | null
          payout_method?: string | null
          payout_routing_number?: string | null
          phone?: string | null
          postal_code?: string | null
          state?: string | null
          status?: string
          tlc_expiry?: string | null
          tlc_number?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          address_line1?: string | null
          address_line2?: string | null
          badge_number?: string | null
          city?: string | null
          company_id?: string
          created_at?: string
          date_of_birth?: string | null
          default_vehicle_id?: string | null
          email?: string | null
          emergency_contact_name?: string | null
          emergency_contact_phone?: string | null
          full_name?: string
          hire_date?: string | null
          id?: string
          insurance_expiry?: string | null
          insurance_policy?: string | null
          insurance_provider?: string | null
          is_active?: boolean
          is_guest?: boolean
          is_online?: boolean
          last_lat?: number | null
          last_lng?: number | null
          last_seen_at?: string | null
          license_class?: string | null
          license_expiry?: string | null
          license_number?: string | null
          license_state?: string | null
          notes?: string | null
          pay_rate?: number
          pay_type?: string
          payout_account_number?: string | null
          payout_bank_name?: string | null
          payout_handle?: string | null
          payout_method?: string | null
          payout_routing_number?: string | null
          phone?: string | null
          postal_code?: string | null
          state?: string | null
          status?: string
          tlc_expiry?: string | null
          tlc_number?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "drivers_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "drivers_default_vehicle_id_fkey"
            columns: ["default_vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      invoices: {
        Row: {
          client_id: string | null
          company_id: string
          created_at: string
          discount: number
          id: string
          invoice_number: string
          issued_at: string | null
          notes: string | null
          paid_at: string | null
          payments: number
          period_end: string | null
          period_start: string | null
          sent_at: string | null
          updated_at: string
        }
        Insert: {
          client_id?: string | null
          company_id?: string
          created_at?: string
          discount?: number
          id?: string
          invoice_number?: string
          issued_at?: string | null
          notes?: string | null
          paid_at?: string | null
          payments?: number
          period_end?: string | null
          period_start?: string | null
          sent_at?: string | null
          updated_at?: string
        }
        Update: {
          client_id?: string | null
          company_id?: string
          created_at?: string
          discount?: number
          id?: string
          invoice_number?: string
          issued_at?: string | null
          notes?: string | null
          paid_at?: string | null
          payments?: number
          period_end?: string | null
          period_start?: string | null
          sent_at?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "invoices_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoices_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      message_threads: {
        Row: {
          admin_read_at: string | null
          client_id: string | null
          company_id: string
          created_at: string
          driver_id: string | null
          id: string
          last_message_at: string
          participant_read_at: string | null
          party_type: string
          updated_at: string
        }
        Insert: {
          admin_read_at?: string | null
          client_id?: string | null
          company_id: string
          created_at?: string
          driver_id?: string | null
          id?: string
          last_message_at?: string
          participant_read_at?: string | null
          party_type: string
          updated_at?: string
        }
        Update: {
          admin_read_at?: string | null
          client_id?: string | null
          company_id?: string
          created_at?: string
          driver_id?: string | null
          id?: string
          last_message_at?: string
          participant_read_at?: string | null
          party_type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "message_threads_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "message_threads_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "message_threads_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "drivers"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          body: string
          created_at: string
          id: string
          sender_type: string
          sender_user_id: string
          thread_id: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          sender_type: string
          sender_user_id: string
          thread_id: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          sender_type?: string
          sender_user_id?: string
          thread_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "message_threads"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_links: {
        Row: {
          code: string
          created_at: string
          id: string
          target: string
          target_id: string
        }
        Insert: {
          code: string
          created_at?: string
          id?: string
          target: string
          target_id: string
        }
        Update: {
          code?: string
          created_at?: string
          id?: string
          target?: string
          target_id?: string
        }
        Relationships: []
      }
      platform_owners: {
        Row: {
          created_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          full_name: string
          id: string
          job_title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          full_name?: string
          id: string
          job_title?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          full_name?: string
          id?: string
          job_title?: string
          updated_at?: string
        }
        Relationships: []
      }
      quote_requests: {
        Row: {
          company: string | null
          company_id: string
          created_at: string
          dropoff_address: string | null
          email: string
          full_name: string
          id: string
          luggage_count: number
          notes: string | null
          passenger_count: number
          phone: string | null
          pickup_address: string | null
          pickup_at: string | null
          quote_amount: number
          quote_message: string | null
          quote_sent_at: string | null
          quote_valid_until: string | null
          round_trip: boolean
          service_type: string
          status: string
          stops: Json
          updated_at: string
          vehicle_class: string | null
        }
        Insert: {
          company?: string | null
          company_id?: string
          created_at?: string
          dropoff_address?: string | null
          email: string
          full_name: string
          id?: string
          luggage_count?: number
          notes?: string | null
          passenger_count?: number
          phone?: string | null
          pickup_address?: string | null
          pickup_at?: string | null
          quote_amount?: number
          quote_message?: string | null
          quote_sent_at?: string | null
          quote_valid_until?: string | null
          round_trip?: boolean
          service_type?: string
          status?: string
          stops?: Json
          updated_at?: string
          vehicle_class?: string | null
        }
        Update: {
          company?: string | null
          company_id?: string
          created_at?: string
          dropoff_address?: string | null
          email?: string
          full_name?: string
          id?: string
          luggage_count?: number
          notes?: string | null
          passenger_count?: number
          phone?: string | null
          pickup_address?: string | null
          pickup_at?: string | null
          quote_amount?: number
          quote_message?: string | null
          quote_sent_at?: string | null
          quote_valid_until?: string | null
          round_trip?: boolean
          service_type?: string
          status?: string
          stops?: Json
          updated_at?: string
          vehicle_class?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "quote_requests_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      reservation_receipts: {
        Row: {
          amount: number
          created_at: string
          file_path: string
          id: string
          kind: string
          reservation_id: string
        }
        Insert: {
          amount?: number
          created_at?: string
          file_path: string
          id?: string
          kind?: string
          reservation_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          file_path?: string
          id?: string
          kind?: string
          reservation_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "reservation_receipts_reservation_id_fkey"
            columns: ["reservation_id"]
            isOneToOne: false
            referencedRelation: "reservations"
            referencedColumns: ["id"]
          },
        ]
      }
      reservation_requests: {
        Row: {
          booking_type: string
          client_id: string
          company_id: string
          contact_email: string | null
          contact_phone: string | null
          created_at: string
          dropoff_address: string
          hours: number
          id: string
          luggage_count: number
          notes: string | null
          passenger_count: number
          passenger_name: string | null
          pickup_address: string
          pickup_at: string
          reservation_id: string | null
          status: string
          updated_at: string
          vehicle_class: string
        }
        Insert: {
          booking_type?: string
          client_id: string
          company_id: string
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          dropoff_address?: string
          hours?: number
          id?: string
          luggage_count?: number
          notes?: string | null
          passenger_count?: number
          passenger_name?: string | null
          pickup_address: string
          pickup_at: string
          reservation_id?: string | null
          status?: string
          updated_at?: string
          vehicle_class?: string
        }
        Update: {
          booking_type?: string
          client_id?: string
          company_id?: string
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          dropoff_address?: string
          hours?: number
          id?: string
          luggage_count?: number
          notes?: string | null
          passenger_count?: number
          passenger_name?: string | null
          pickup_address?: string
          pickup_at?: string
          reservation_id?: string | null
          status?: string
          updated_at?: string
          vehicle_class?: string
        }
        Relationships: [
          {
            foreignKeyName: "reservation_requests_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reservation_requests_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reservation_requests_reservation_id_fkey"
            columns: ["reservation_id"]
            isOneToOne: false
            referencedRelation: "reservations"
            referencedColumns: ["id"]
          },
        ]
      }
      reservation_status_events: {
        Row: {
          created_at: string
          id: string
          occurred_at: string
          reservation_id: string
          status: string
        }
        Insert: {
          created_at?: string
          id?: string
          occurred_at?: string
          reservation_id: string
          status: string
        }
        Update: {
          created_at?: string
          id?: string
          occurred_at?: string
          reservation_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "reservation_status_events_reservation_id_fkey"
            columns: ["reservation_id"]
            isOneToOne: false
            referencedRelation: "reservations"
            referencedColumns: ["id"]
          },
        ]
      }
      reservation_stops: {
        Row: {
          address: string
          created_at: string
          id: string
          note: string | null
          position: number
          reservation_id: string
          stop_at: string | null
          updated_at: string
        }
        Insert: {
          address: string
          created_at?: string
          id?: string
          note?: string | null
          position?: number
          reservation_id: string
          stop_at?: string | null
          updated_at?: string
        }
        Update: {
          address?: string
          created_at?: string
          id?: string
          note?: string | null
          position?: number
          reservation_id?: string
          stop_at?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "reservation_stops_reservation_id_fkey"
            columns: ["reservation_id"]
            isOneToOne: false
            referencedRelation: "reservations"
            referencedColumns: ["id"]
          },
        ]
      }
      reservations: {
        Row: {
          affiliate_driver_name: string | null
          affiliate_driver_phone: string | null
          affiliate_id: string | null
          affiliate_notes: string | null
          affiliate_payout: number
          affiliate_percent: number
          affiliate_status: string | null
          affiliate_vehicle: string | null
          airline: string | null
          airport_fee: number
          airport_name: string | null
          auth_amount: number
          auth_captured_amount: number
          auth_captured_at: string | null
          auth_card_brand: string | null
          auth_card_last4: string | null
          auth_payment_intent_id: string | null
          auth_status: string | null
          authorized_at: string | null
          base_fare: number
          base_rate: number
          billing_contact_email: string | null
          billing_contact_name: string | null
          billing_contact_phone: string | null
          booked_by_email: string | null
          booked_by_name: string | null
          booked_by_phone: string | null
          booking_type: string
          car_seat_count: number
          car_seat_fee: number
          client_id: string | null
          company_id: string
          created_at: string
          distance_miles: number
          door_number: string | null
          driver_airport_fee: number
          driver_confirmed_at: string | null
          driver_contact_role: string
          driver_hourly_pay: number
          driver_id: string | null
          driver_minimum_hours: number
          driver_note: string | null
          driver_paid_at: string | null
          driver_parking_fee: number
          driver_pay: number
          driver_tolls: number
          driver_total_hours: number
          driver_waiting_hours: number
          driver_waiting_pay: number
          dropoff_address: string
          dropoff_at: string | null
          extra_passengers: Json
          flight_direction: string
          flight_number: string | null
          gratuity: number
          guest_link_token: string | null
          hourly_rate: number
          hours: number
          id: string
          invoice_id: string | null
          invoice_issued_at: string | null
          invoice_number: string | null
          invoice_paid_at: string | null
          invoice_sent_at: string | null
          luggage_count: number
          meet_greet_fee: number
          minimum_hours: number
          notes: string | null
          parking_fee: number
          passenger_count: number
          passenger_email: string | null
          passenger_name: string
          passenger_phone: string | null
          payment_method: string | null
          pickup_address: string
          pickup_at: string
          reference: string
          reminder_sent_at: string | null
          status: string
          stop_fee: number
          terminal_level: string | null
          tolls: number
          tolls_breakdown: Json
          track_token: string | null
          updated_at: string
          vehicle_class: string
          vehicle_id: string | null
          waiting_minutes: number
          waiting_rate: number
        }
        Insert: {
          affiliate_driver_name?: string | null
          affiliate_driver_phone?: string | null
          affiliate_id?: string | null
          affiliate_notes?: string | null
          affiliate_payout?: number
          affiliate_percent?: number
          affiliate_status?: string | null
          affiliate_vehicle?: string | null
          airline?: string | null
          airport_fee?: number
          airport_name?: string | null
          auth_amount?: number
          auth_captured_amount?: number
          auth_captured_at?: string | null
          auth_card_brand?: string | null
          auth_card_last4?: string | null
          auth_payment_intent_id?: string | null
          auth_status?: string | null
          authorized_at?: string | null
          base_fare?: number
          base_rate?: number
          billing_contact_email?: string | null
          billing_contact_name?: string | null
          billing_contact_phone?: string | null
          booked_by_email?: string | null
          booked_by_name?: string | null
          booked_by_phone?: string | null
          booking_type?: string
          car_seat_count?: number
          car_seat_fee?: number
          client_id?: string | null
          company_id?: string
          created_at?: string
          distance_miles?: number
          door_number?: string | null
          driver_airport_fee?: number
          driver_confirmed_at?: string | null
          driver_contact_role?: string
          driver_hourly_pay?: number
          driver_id?: string | null
          driver_minimum_hours?: number
          driver_note?: string | null
          driver_paid_at?: string | null
          driver_parking_fee?: number
          driver_pay?: number
          driver_tolls?: number
          driver_total_hours?: number
          driver_waiting_hours?: number
          driver_waiting_pay?: number
          dropoff_address: string
          dropoff_at?: string | null
          extra_passengers?: Json
          flight_direction?: string
          flight_number?: string | null
          gratuity?: number
          guest_link_token?: string | null
          hourly_rate?: number
          hours?: number
          id?: string
          invoice_id?: string | null
          invoice_issued_at?: string | null
          invoice_number?: string | null
          invoice_paid_at?: string | null
          invoice_sent_at?: string | null
          luggage_count?: number
          meet_greet_fee?: number
          minimum_hours?: number
          notes?: string | null
          parking_fee?: number
          passenger_count?: number
          passenger_email?: string | null
          passenger_name: string
          passenger_phone?: string | null
          payment_method?: string | null
          pickup_address: string
          pickup_at: string
          reference: string
          reminder_sent_at?: string | null
          status?: string
          stop_fee?: number
          terminal_level?: string | null
          tolls?: number
          tolls_breakdown?: Json
          track_token?: string | null
          updated_at?: string
          vehicle_class?: string
          vehicle_id?: string | null
          waiting_minutes?: number
          waiting_rate?: number
        }
        Update: {
          affiliate_driver_name?: string | null
          affiliate_driver_phone?: string | null
          affiliate_id?: string | null
          affiliate_notes?: string | null
          affiliate_payout?: number
          affiliate_percent?: number
          affiliate_status?: string | null
          affiliate_vehicle?: string | null
          airline?: string | null
          airport_fee?: number
          airport_name?: string | null
          auth_amount?: number
          auth_captured_amount?: number
          auth_captured_at?: string | null
          auth_card_brand?: string | null
          auth_card_last4?: string | null
          auth_payment_intent_id?: string | null
          auth_status?: string | null
          authorized_at?: string | null
          base_fare?: number
          base_rate?: number
          billing_contact_email?: string | null
          billing_contact_name?: string | null
          billing_contact_phone?: string | null
          booked_by_email?: string | null
          booked_by_name?: string | null
          booked_by_phone?: string | null
          booking_type?: string
          car_seat_count?: number
          car_seat_fee?: number
          client_id?: string | null
          company_id?: string
          created_at?: string
          distance_miles?: number
          door_number?: string | null
          driver_airport_fee?: number
          driver_confirmed_at?: string | null
          driver_contact_role?: string
          driver_hourly_pay?: number
          driver_id?: string | null
          driver_minimum_hours?: number
          driver_note?: string | null
          driver_paid_at?: string | null
          driver_parking_fee?: number
          driver_pay?: number
          driver_tolls?: number
          driver_total_hours?: number
          driver_waiting_hours?: number
          driver_waiting_pay?: number
          dropoff_address?: string
          dropoff_at?: string | null
          extra_passengers?: Json
          flight_direction?: string
          flight_number?: string | null
          gratuity?: number
          guest_link_token?: string | null
          hourly_rate?: number
          hours?: number
          id?: string
          invoice_id?: string | null
          invoice_issued_at?: string | null
          invoice_number?: string | null
          invoice_paid_at?: string | null
          invoice_sent_at?: string | null
          luggage_count?: number
          meet_greet_fee?: number
          minimum_hours?: number
          notes?: string | null
          parking_fee?: number
          passenger_count?: number
          passenger_email?: string | null
          passenger_name?: string
          passenger_phone?: string | null
          payment_method?: string | null
          pickup_address?: string
          pickup_at?: string
          reference?: string
          reminder_sent_at?: string | null
          status?: string
          stop_fee?: number
          terminal_level?: string | null
          tolls?: number
          tolls_breakdown?: Json
          track_token?: string | null
          updated_at?: string
          vehicle_class?: string
          vehicle_id?: string | null
          waiting_minutes?: number
          waiting_rate?: number
        }
        Relationships: [
          {
            foreignKeyName: "reservations_affiliate_id_fkey"
            columns: ["affiliate_id"]
            isOneToOne: false
            referencedRelation: "affiliates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reservations_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reservations_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reservations_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "drivers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reservations_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reservations_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      ride_disputes: {
        Row: {
          amount: number
          client_id: string | null
          company_id: string
          contact_email: string | null
          created_at: string
          id: string
          invoice_id: string | null
          message: string
          reservation_id: string
          resolved_at: string | null
          staff_reply: string | null
          status: string
          updated_at: string
        }
        Insert: {
          amount?: number
          client_id?: string | null
          company_id?: string
          contact_email?: string | null
          created_at?: string
          id?: string
          invoice_id?: string | null
          message: string
          reservation_id: string
          resolved_at?: string | null
          staff_reply?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          client_id?: string | null
          company_id?: string
          contact_email?: string | null
          created_at?: string
          id?: string
          invoice_id?: string | null
          message?: string
          reservation_id?: string
          resolved_at?: string | null
          staff_reply?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "ride_disputes_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ride_disputes_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ride_disputes_invoice_id_fkey"
            columns: ["invoice_id"]
            isOneToOne: false
            referencedRelation: "invoices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ride_disputes_reservation_id_fkey"
            columns: ["reservation_id"]
            isOneToOne: false
            referencedRelation: "reservations"
            referencedColumns: ["id"]
          },
        ]
      }
      ride_reviews: {
        Row: {
          client_id: string | null
          comment: string | null
          company_id: string
          created_at: string
          id: string
          rating: number
          reservation_id: string
          tags: string[]
          updated_at: string
        }
        Insert: {
          client_id?: string | null
          comment?: string | null
          company_id: string
          created_at?: string
          id?: string
          rating: number
          reservation_id: string
          tags?: string[]
          updated_at?: string
        }
        Update: {
          client_id?: string | null
          comment?: string | null
          company_id?: string
          created_at?: string
          id?: string
          rating?: number
          reservation_id?: string
          tags?: string[]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "ride_reviews_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ride_reviews_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ride_reviews_reservation_id_fkey"
            columns: ["reservation_id"]
            isOneToOne: true
            referencedRelation: "reservations"
            referencedColumns: ["id"]
          },
        ]
      }
      ride_track_points: {
        Row: {
          created_at: string
          driver_id: string | null
          id: string
          lat: number
          lng: number
          recorded_at: string
          reservation_id: string
        }
        Insert: {
          created_at?: string
          driver_id?: string | null
          id?: string
          lat: number
          lng: number
          recorded_at?: string
          reservation_id: string
        }
        Update: {
          created_at?: string
          driver_id?: string | null
          id?: string
          lat?: number
          lng?: number
          recorded_at?: string
          reservation_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ride_track_points_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "drivers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ride_track_points_reservation_id_fkey"
            columns: ["reservation_id"]
            isOneToOne: false
            referencedRelation: "reservations"
            referencedColumns: ["id"]
          },
        ]
      }
      subscription_plans: {
        Row: {
          code: string
          created_at: string
          features: Json
          name: string
          price_cents: number
          sort: number
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          features?: Json
          name: string
          price_cents?: number
          sort?: number
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          features?: Json
          name?: string
          price_cents?: number
          sort?: number
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vehicles: {
        Row: {
          capacity: number
          color: string | null
          company_id: string
          created_at: string
          fleet_code: string
          id: string
          make: string | null
          model: string | null
          name: string
          plate: string | null
          status: string
          updated_at: string
          vehicle_class: string
          year: number | null
        }
        Insert: {
          capacity?: number
          color?: string | null
          company_id?: string
          created_at?: string
          fleet_code: string
          id?: string
          make?: string | null
          model?: string | null
          name: string
          plate?: string | null
          status?: string
          updated_at?: string
          vehicle_class?: string
          year?: number | null
        }
        Update: {
          capacity?: number
          color?: string | null
          company_id?: string
          created_at?: string
          fleet_code?: string
          id?: string
          make?: string | null
          model?: string | null
          name?: string
          plate?: string | null
          status?: string
          updated_at?: string
          vehicle_class?: string
          year?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "vehicles_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      wake_up_calls: {
        Row: {
          attempts: number
          charge_cents: number
          company_id: string
          confirmed_at: string | null
          created_at: string
          driver_id: string | null
          id: string
          last_attempt_at: string | null
          last_error: string | null
          phone: string | null
          reservation_id: string
          status: string
          updated_at: string
        }
        Insert: {
          attempts?: number
          charge_cents?: number
          company_id: string
          confirmed_at?: string | null
          created_at?: string
          driver_id?: string | null
          id?: string
          last_attempt_at?: string | null
          last_error?: string | null
          phone?: string | null
          reservation_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          attempts?: number
          charge_cents?: number
          company_id?: string
          confirmed_at?: string | null
          created_at?: string
          driver_id?: string | null
          id?: string
          last_attempt_at?: string | null
          last_error?: string | null
          phone?: string | null
          reservation_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "wake_up_calls_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wake_up_calls_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "drivers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wake_up_calls_reservation_id_fkey"
            columns: ["reservation_id"]
            isOneToOne: true
            referencedRelation: "reservations"
            referencedColumns: ["id"]
          },
        ]
      }
      zone_rates: {
        Row: {
          amount: number
          client_id: string | null
          company_id: string
          created_at: string
          from_label: string
          from_type: string
          id: string
          notes: string | null
          to_label: string
          to_type: string
          updated_at: string
          vehicle_class: string
        }
        Insert: {
          amount?: number
          client_id?: string | null
          company_id?: string
          created_at?: string
          from_label: string
          from_type?: string
          id?: string
          notes?: string | null
          to_label: string
          to_type?: string
          updated_at?: string
          vehicle_class?: string
        }
        Update: {
          amount?: number
          client_id?: string | null
          company_id?: string
          created_at?: string
          from_label?: string
          from_type?: string
          id?: string
          notes?: string | null
          to_label?: string
          to_type?: string
          updated_at?: string
          vehicle_class?: string
        }
        Relationships: [
          {
            foreignKeyName: "zone_rates_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "zone_rates_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      cron_token_matches: { Args: { _token: string }; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "dispatcher" | "driver"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "dispatcher", "driver"],
    },
  },
} as const
