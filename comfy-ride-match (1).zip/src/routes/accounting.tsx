import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { BarChart3, CalendarDays, Car, CheckCircle2, Download, RefreshCw, Search, Users, Wallet } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { AppShell, StatusChip } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { clientsQuery, clockTime, dayLabel, driversQuery, fareTotal, groupStops, money, reservationsQuery, stopsQuery } from "@/lib/dispatch";
import { useRole } from "@/lib/roles";
import { MoneyTabs } from "@/components/MoneyTabs";

export const Route = createFileRoute("/accounting")({
  head: () => ({ meta: [
    { title: "Accounting — Blackwave Transportation LLC" },
    { name: "description", content: "Search chauffeur rides by date, week, month or time window and see total rides, revenue earned and per-client totals for Blackwave Transportation LLC." },
    { property: "og:title", content: "Accounting — Blackwave Transportation LLC" },
    { property: "og:description", content: "Ride counts and revenue totals by period, client and search term." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: () => <AppShell><AccountingPage /></AppShell>,
});

const ymd = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
type Preset = "week" | "month" | "today" | "all" | "custom";
const chartColors = ["var(--dashboard-blue)", "var(--dashboard-amber)", "var(--dashboard-green)", "var(--dashboard-red)", "var(--dashboard-steel)"];

function AccountingPage() {
  const { isAdmin, loading: roleLoading } = useRole();
  const { data: reservations = [] } = useQuery(reservationsQuery);
  const { data: stops = [] } = useQuery(stopsQuery);
  const { data: clients = [] } = useQuery(clientsQuery);
  const { data: drivers = [] } = useQuery(driversQuery);
  const stopsByRide = groupStops(stops);
  const today = new Date();
  const [preset, setPreset] = useState<Preset>("month");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [timeFrom, setTimeFrom] = useState("");
  const [timeTo, setTimeTo] = useState("");
  const [clientId, setClientId] = useState("");
  const [driverId, setDriverId] = useState("");
  const [search, setSearch] = useState("");

  const range = useMemo(() => {
    if (preset === "all") return { start: null as Date | null, end: null as Date | null };
    if (preset === "custom") return { start: from ? new Date(`${from}T00:00:00`) : null, end: to ? new Date(`${to}T23:59:59`) : null };
    const end = new Date(today); end.setHours(23, 59, 59, 999);
    const start = new Date(today); start.setHours(0, 0, 0, 0);
    if (preset === "week") start.setDate(start.getDate() - 6);
    if (preset === "month") start.setDate(start.getDate() - 29);
    return { start, end };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preset, from, to]);

  const clientName = (id: string | null) => clients.find((c) => c.id === id)?.name ?? "No account";
  const driverName = (id: string | null) => drivers.find((d) => d.id === id)?.full_name ?? "Unassigned";
  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    const minute = (iso: string) => { const d = new Date(iso); return d.getHours() * 60 + d.getMinutes(); };
    const parse = (v: string) => { const [h, m] = v.split(":"); return Number(h) * 60 + Number(m ?? 0); };
    return reservations.filter((r) => {
      const at = new Date(r.pickup_at);
      if (range.start && at < range.start) return false;
      if (range.end && at > range.end) return false;
      if (timeFrom && minute(r.pickup_at) < parse(timeFrom)) return false;
      if (timeTo && minute(r.pickup_at) > parse(timeTo)) return false;
      if (clientId && r.client_id !== clientId) return false;
      if (driverId && r.driver_id !== driverId) return false;
      return !q || [r.reference, r.passenger_name, r.pickup_address, r.dropoff_address, r.invoice_number ?? "", clientName(r.client_id), driverName(r.driver_id)].join(" ").toLowerCase().includes(q);
    }).sort((a, b) => new Date(b.pickup_at).getTime() - new Date(a.pickup_at).getTime());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reservations, range, timeFrom, timeTo, clientId, driverId, search, clients, drivers]);

  const amountOf = (r: (typeof rows)[number]) => fareTotal(r, (stopsByRide.get(r.id) ?? []).length);
  const totalEarned = rows.reduce((sum, ride) => sum + amountOf(ride), 0);
  const completed = rows.filter((ride) => ride.status === "completed");
  const completedEarned = completed.reduce((sum, ride) => sum + amountOf(ride), 0);
  const byClient = useMemo(() => {
    const map = new Map<string, { name: string; rides: number; amount: number }>();
    rows.forEach((ride) => { const key = ride.client_id ?? "none"; const item = map.get(key) ?? { name: clientName(ride.client_id), rides: 0, amount: 0 }; item.rides += 1; item.amount += amountOf(ride); map.set(key, item); });
    return [...map.values()].sort((a, b) => b.amount - a.amount);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows, clients, stops]);
  const revenueByDay = useMemo(() => {
    const map = new Map<string, number>();
    rows.forEach((ride) => { const label = new Date(ride.pickup_at).toLocaleDateString("en-US", { month: "short", day: "numeric" }); map.set(label, (map.get(label) ?? 0) + amountOf(ride)); });
    return [...map.entries()].reverse().slice(-10).map(([date, revenue]) => ({ date, revenue }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows, stops]);
  const periodLabel = range.start && range.end ? `${range.start.toLocaleDateString()} – ${range.end.toLocaleDateString()}` : "All time";
  const presets: { key: Preset; label: string }[] = [{ key: "today", label: "Today" }, { key: "week", label: "Last 7 days" }, { key: "month", label: "Last 30 days" }, { key: "custom", label: "Custom" }, { key: "all", label: "All time" }];

  const reset = () => { setPreset("month"); setFrom(""); setTo(""); setTimeFrom(""); setTimeTo(""); setClientId(""); setDriverId(""); setSearch(""); };
  const exportCsv = () => {
    const csv = [["Date", "Time", "Reference", "Passenger", "Client", "Chauffeur", "Status", "Amount"], ...rows.map((r) => [dayLabel(r.pickup_at), clockTime(r.pickup_at), r.reference, r.passenger_name, clientName(r.client_id), driverName(r.driver_id), r.status, amountOf(r).toFixed(2)])].map((line) => line.map((v) => `"${String(v).replaceAll('"', '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" })); const anchor = document.createElement("a"); anchor.href = url; anchor.download = `blackwave-accounting-${ymd(today)}.csv`; anchor.click(); URL.revokeObjectURL(url);
  };

  if (roleLoading) return <div className="px-6 py-10 text-sm text-muted-foreground">Loading…</div>;
  if (!isAdmin) return <div className="bg-dashboard-canvas px-5 py-8"><h1 className="font-admin-display text-3xl font-bold text-dashboard-navy">Accounting</h1><p className="mt-4 text-sm text-dashboard-muted">Accounting is available to the main admin account only.</p></div>;

  return <div className="min-h-screen bg-dashboard-canvas px-3 pb-10 pt-5 sm:px-5">
    <header className="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-4 sm:flex sm:justify-between">
      <div className="min-w-0"><p className="text-[10px] font-bold uppercase tracking-[0.2em] text-dashboard-blue">Accounting</p><h1 className="truncate font-admin-display text-3xl font-bold text-dashboard-navy">Accounting</h1><p className="mt-1 text-sm text-dashboard-muted">Track revenue, ride details, and business performance.</p></div>
      <div className="flex shrink-0 gap-2"><span className="hidden items-center gap-2 rounded-md border border-dashboard-line bg-card px-3 text-xs font-semibold text-dashboard-navy md:flex"><CalendarDays className="size-4" />{periodLabel}</span><Button onClick={exportCsv}><Download /> Export</Button></div>
    </header>
    <div className="mt-4"><MoneyTabs /></div>
    <section className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      <Stat icon={<Car />} tone="blue" label="Total rides" value={String(rows.length)} note="Selected period" />
      <Stat icon={<Wallet />} tone="green" label="Total amount" value={money(totalEarned)} note="All filtered rides" />
      <Stat icon={<CheckCircle2 />} tone="violet" label="Completed rides" value={String(completed.length)} note={`${rows.length ? Math.round(completed.length / rows.length * 100) : 0}% completion rate`} />
      <Stat icon={<BarChart3 />} tone="amber" label="Completed revenue" value={money(completedEarned)} note={`${totalEarned ? Math.round(completedEarned / totalEarned * 100) : 0}% of total amount`} />
    </section>
    <section className="mt-3 rounded-md border border-dashboard-line bg-card p-3 shadow-sm">
      <div className="grid grid-cols-2 gap-2 md:grid-cols-5">{presets.map((item) => <Button key={item.key} variant={preset === item.key ? "default" : "outline"} onClick={() => { setPreset(item.key); if (item.key === "custom" && !from) { setFrom(ymd(today)); setTo(ymd(today)); } }}>{item.label}</Button>)}</div>
      <div className="mt-3 grid gap-3 md:grid-cols-3 xl:grid-cols-6"><Control label="From date"><input type="date" value={from} onChange={(e) => { setFrom(e.target.value); setPreset("custom"); }} /></Control><Control label="To date"><input type="date" value={to} onChange={(e) => { setTo(e.target.value); setPreset("custom"); }} /></Control><Control label="Time from"><input type="time" value={timeFrom} onChange={(e) => setTimeFrom(e.target.value)} /></Control><Control label="Time to"><input type="time" value={timeTo} onChange={(e) => setTimeTo(e.target.value)} /></Control><Control label="Client"><select value={clientId} onChange={(e) => setClientId(e.target.value)}><option value="">All clients</option>{clients.map((client) => <option key={client.id} value={client.id}>{client.name}</option>)}</select></Control><Control label="Chauffeur"><select value={driverId} onChange={(e) => setDriverId(e.target.value)}><option value="">All chauffeurs</option>{drivers.map((driver) => <option key={driver.id} value={driver.id}>{driver.full_name}</option>)}</select></Control></div>
      <div className="mt-3 grid grid-cols-[minmax(0,1fr)_auto] gap-2"><div className="relative min-w-0"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-dashboard-muted" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Reference, passenger, address, invoice…" className="h-10 w-full rounded-md border border-dashboard-line bg-background pl-9 pr-3 text-sm" /></div><Button variant="outline" onClick={reset}><RefreshCw /> <span className="hidden sm:inline">Reset</span></Button></div>
    </section>
    <section className="mt-3 grid items-start gap-3 xl:grid-cols-[1.15fr_0.85fr]">
      <ChartPanel title="Revenue overview" icon={<BarChart3 />}><ResponsiveContainer width="100%" height={230}><BarChart data={revenueByDay}><CartesianGrid vertical={false} stroke="var(--dashboard-line)" /><XAxis dataKey="date" tick={{ fontSize: 10 }} /><YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `$${v}`} /><Tooltip formatter={(value) => money(Number(value))} /><Bar dataKey="revenue" fill="var(--dashboard-blue)" radius={[3, 3, 0, 0]} /></BarChart></ResponsiveContainer></ChartPanel>
      <ChartPanel title="Rides by client" icon={<Users />}><div className="grid items-center gap-4 sm:grid-cols-[220px_1fr]"><ResponsiveContainer width="100%" height={230}><PieChart><Pie data={byClient} dataKey="rides" nameKey="name" innerRadius={55} outerRadius={82} paddingAngle={2}>{byClient.map((entry, index) => <Cell key={entry.name} fill={chartColors[index % chartColors.length]} />)}</Pie><Tooltip /></PieChart></ResponsiveContainer><div className="space-y-3">{byClient.slice(0, 5).map((client, index) => <div key={client.name} className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-2 text-xs"><span className="size-2.5 rounded-full" style={{ background: chartColors[index % chartColors.length] }} /><span className="truncate text-dashboard-navy"><b>{client.name}</b><small className="block text-dashboard-muted">{client.rides} {client.rides === 1 ? "ride" : "rides"}</small></span><b className="text-dashboard-blue">{money(client.amount)}</b></div>)}</div></div></ChartPanel>
    </section>
    <section className="mt-3 overflow-hidden rounded-md border border-dashboard-line bg-card shadow-sm"><header className="flex items-center gap-2 border-b border-dashboard-line px-4 py-3"><Car className="size-4 text-dashboard-blue" /><h2 className="font-admin-display font-bold text-dashboard-navy">Rides ({rows.length})</h2></header><div className="overflow-x-auto"><table className="w-full min-w-[920px] text-left"><thead className="bg-dashboard-soft text-[9px] uppercase text-dashboard-muted"><tr><th className="px-4 py-2">Date</th><th>Time</th><th>Ref</th><th>Passenger</th><th>Client</th><th>Chauffeur</th><th>Status</th><th className="pr-4 text-right">Amount</th></tr></thead><tbody className="divide-y divide-dashboard-line text-xs">{rows.map((ride) => <tr key={ride.id} className="hover:bg-dashboard-canvas"><td className="whitespace-nowrap px-4 py-3">{dayLabel(ride.pickup_at)}</td><td>{clockTime(ride.pickup_at)}</td><td><Link to="/reservations" search={{ edit: ride.id }} className="font-semibold text-dashboard-blue hover:underline">{ride.reference}</Link></td><td>{ride.passenger_name}</td><td>{clientName(ride.client_id)}</td><td>{driverName(ride.driver_id)}</td><td><StatusChip status={ride.status} /></td><td className="pr-4 text-right font-bold text-dashboard-blue">{money(amountOf(ride))}</td></tr>)}{rows.length === 0 && <tr><td colSpan={8} className="px-4 py-8 text-center text-dashboard-muted">No rides match these filters.</td></tr>}</tbody></table></div></section>
  </div>;
}

function Stat({ icon, tone, label, value, note }: { icon: React.ReactNode; tone: "blue" | "green" | "violet" | "amber"; label: string; value: string; note: string }) {
  const styles = { blue: "bg-dashboard-ice text-dashboard-blue", green: "bg-success/10 text-dashboard-green", violet: "bg-accent text-accent-foreground", amber: "bg-warning/15 text-dashboard-amber" };
  return <div className="flex min-h-24 items-center gap-4 rounded-md border border-dashboard-line bg-card p-4 shadow-sm"><span className={`grid size-12 shrink-0 place-items-center rounded-full [&>svg]:size-6 ${styles[tone]}`}>{icon}</span><div className="min-w-0"><p className="truncate text-[9px] font-bold uppercase text-dashboard-muted">{label}</p><p className="truncate font-admin-display text-2xl font-bold text-dashboard-navy">{value}</p><p className="truncate text-[10px] text-dashboard-muted">{note}</p></div></div>;
}

function Control({ label, children }: { label: string; children: React.ReactElement<{ className?: string }> }) {
  return <label className="text-[10px] font-bold text-dashboard-muted">{label}<span className="mt-1 block [&>*]:h-10 [&>*]:w-full [&>*]:rounded-md [&>*]:border [&>*]:border-dashboard-line [&>*]:bg-background [&>*]:px-3 [&>*]:text-xs">{children}</span></label>;
}

function ChartPanel({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return <div className="min-w-0 rounded-md border border-dashboard-line bg-card p-4 shadow-sm"><h2 className="mb-4 flex items-center gap-2 font-admin-display font-bold text-dashboard-navy"><span className="text-dashboard-blue [&>svg]:size-5">{icon}</span>{title}</h2>{children}</div>;
}