import { useMemo, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { DriverShell } from "@/components/DriverShell";
import { useDriverAccount, driverTripsQuery, driverStopsQuery, isActiveStatus } from "@/lib/driver";
import { clockTime, dayLabel, statusLabel, type Reservation, driverPayout, fareTotal, money, groupStops } from "@/lib/dispatch";
import { mapsUrl, wazeUrl } from "@/lib/nav-links";
import { useServerFn } from "@tanstack/react-start";
import { sendDriverConfirmationEmail } from "@/lib/driver-notify.functions";
import { sendClientRideNotice } from "@/lib/client-notify.functions";
import { useRideTrail } from "@/hooks/useRideTrail";


export const Route = createFileRoute("/driver/")({
  head: () => ({
    meta: [
      { title: "Driver Trips — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Blackwave chauffeurs: view assigned trips, passenger details, routes and update trip status from your phone.",
      },
      { property: "og:title", content: "Driver Trips — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Assigned trips, routes and live status updates for Blackwave chauffeurs.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: DriverTripsPage,
});

const TABS = [
  { id: "pending", label: "Pending" },
  { id: "upcoming", label: "Upcoming" },
  { id: "in_progress", label: "In-Progress" },
  { id: "completed", label: "Completed" },
] as const;

type TabId = (typeof TABS)[number]["id"];

const isPastPickup = (pickupAt: string) => {
  const t = new Date(pickupAt).getTime();
  return Number.isFinite(t) && t < Date.now();
};

const bucketOf = (
  status: string,
  pickupAt: string,
  driverConfirmedAt: string | null | undefined,
): TabId => {
  if (status === "completed") return "completed";
  if (isActiveStatus(status)) return "in_progress";
  // A ride whose pickup time has passed is no longer upcoming.
  const t = new Date(pickupAt).getTime();
  if (Number.isFinite(t) && t < Date.now()) return "completed";
  return !driverConfirmedAt ? "pending" : "upcoming";
};


function DriverTripsPage() {
  const { data: driver, isLoading } = useDriverAccount();
  const { data: trips = [] } = useQuery(driverTripsQuery(driver?.id));
  const { data: stops = [] } = useQuery(driverStopsQuery(driver?.id));
  const activeTrip = trips.find((trip) => isActiveStatus(trip.status));
  useRideTrail(activeTrip?.id, driver?.id, activeTrip?.status);
  const stopsByRide = useMemo(() => groupStops(stops), [stops]);
  const [tab, setTab] = useState<TabId>("pending");
  const [q, setQ] = useState("");

  const counts = useMemo(() => {
    const c: Record<TabId, number> = {
      pending: 0,
      upcoming: 0,
      in_progress: 0,
      
      completed: 0,
    };
    trips.forEach((t) => (c[bucketOf(t.status, t.pickup_at, t.driver_confirmed_at)] += 1));
    return c;
  }, [trips]);

  const visible = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return trips.filter(
      (t) =>
        bucketOf(t.status, t.pickup_at, t.driver_confirmed_at) === tab &&
        (!needle ||
          `${t.reference} ${t.passenger_name} ${t.pickup_address} ${t.dropoff_address}`
            .toLowerCase()
            .includes(needle)),
    );
  }, [trips, tab, q]);

  return (
    <DriverShell driver={driver ?? null} loading={isLoading}>
      <div className="-mx-4 flex overflow-x-auto border-b border-border bg-card">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex-1 whitespace-nowrap border-b-2 px-4 py-3 font-cond text-[12px] uppercase tracking-widest transition-colors ${
              tab === t.id
                ? "border-brand text-brand"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.label}
            <span className="ml-1 opacity-60">{counts[t.id]}</span>
          </button>
        ))}
      </div>

      <input
        id="driver-search"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search trips, passengers, addresses"
        className="mt-4 w-full rounded-md border border-input bg-surface px-3 py-2.5 font-cond text-sm outline-none placeholder:text-muted-foreground focus:border-brand/60"
      />

      <TripList trips={visible} driver={driver ?? null} stopsByRide={stopsByRide} />
    </DriverShell>
  );
}

function ConfirmButton({ trip }: { trip: Reservation }) {
  const qc = useQueryClient();
  const notifyConfirmed = useServerFn(sendDriverConfirmationEmail);
  const notifyClient = useServerFn(sendClientRideNotice);
  const confirm = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("reservations")
        .update({ driver_confirmed_at: new Date().toISOString(), status: "confirmed" })
        .eq("id", trip.id);
      if (error) throw error;
      try {
        await notifyClient({ data: { reservationId: trip.id, kind: "accepted" } });
      } catch (err) {
        console.error("client chauffeur email failed", err);
      }
      try {
        return await notifyConfirmed({ data: { reservationId: trip.id } });
      } catch (err) {
        return {
          sent: false,
          reason: err instanceof Error ? err.message : ("send_failed" as const),
        };
      }
    },
    onSuccess: (res) => {
      if (res?.sent) toast.success("Ride confirmed — confirmation email sent");
      else if (res?.reason === "no_driver_email")
        toast.success("Ride confirmed (no email on your profile)");
      else toast.warning(`Ride confirmed, but email failed: ${res?.reason ?? "unknown"}`);
      qc.invalidateQueries({ queryKey: ["driver-trips"] });
    },

    onError: (e: Error) => toast.error(e.message),
  });


  return (
    <button
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        confirm.mutate();
      }}
      disabled={confirm.isPending}
      className="mt-3 w-full rounded-md bg-brand px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-brand-foreground disabled:opacity-60"
    >
      {confirm.isPending ? "Confirming…" : "Confirm ride"}
    </button>
  );
}

function TripList({
  trips,
  driver,
  stopsByRide,
}: {
  trips: Reservation[];
  driver: { pay_type?: string | null; pay_rate?: number | null } | null;
  stopsByRide: Map<string, Array<unknown>>;
}) {
  if (trips.length === 0) {
    return (
      <div className="mt-10 grid place-items-center py-16 text-center">
        <div className="grid size-16 place-items-center rounded-full border-2 border-border font-display text-2xl text-muted-foreground">
          E
        </div>
        <p className="mt-4 font-cond text-sm text-muted-foreground">No trips here.</p>
      </div>
    );
  }

  return (
    <div className="mt-4 space-y-3">
      {trips.map((t) => (
        <TripCard key={t.id} trip={t} driver={driver} stopsByRide={stopsByRide} />
      ))}
    </div>
  );
}

const navBtn =
  "rounded-md border border-border px-3 py-2 text-center font-cond text-[11px] font-bold uppercase tracking-widest text-brand transition-colors hover:border-brand/60 active:bg-brand/10";

function TripCard({
  trip: t,
  driver,
  stopsByRide,
}: {
  trip: Reservation;
  driver: { pay_type?: string | null; pay_rate?: number | null } | null;
  stopsByRide: Map<string, Array<unknown>>;
}) {
  const navigate = useNavigate();

  const openNav = (e: React.MouseEvent, url: string) => {
    e.preventDefault();
    e.stopPropagation();
    window.open(url, "_blank", "noreferrer");
  };

  return (
    <div
      role="link"
      tabIndex={0}
      onClick={() => navigate({ to: "/driver/$id", params: { id: t.id } })}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") navigate({ to: "/driver/$id", params: { id: t.id } });
      }}
      className="block cursor-pointer rounded-lg border border-border bg-card p-4 transition-colors hover:border-brand/50"
    >
      <div className="flex items-baseline justify-between gap-3">
        <div className="font-display text-2xl font-bold uppercase leading-none">
          {clockTime(t.pickup_at)}
        </div>
        <div className="font-cond text-[10px] font-bold uppercase tracking-widest text-brand">
          {statusLabel(t.status)}
        </div>
      </div>
      <div className="mt-1 flex items-baseline gap-2 whitespace-nowrap font-cond text-[15px] font-bold uppercase tracking-wide text-muted-foreground">
        <span>{dayLabel(t.pickup_at)}</span>
        <span className="text-brand">·</span>
        <span className="truncate text-foreground">{t.reference}</span>
      </div>
      <div className="mt-3 font-cond text-sm font-bold">{t.passenger_name}</div>
      <div className="mt-3 grid gap-3 font-cond text-[13px] font-bold leading-snug">
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest text-brand">Pickup</div>
          <div className="mt-0.5 font-bold text-muted-foreground">{t.pickup_address}</div>
          <div className="mt-2 grid grid-cols-2 gap-2">
            <button type="button" className={navBtn} onClick={(e) => openNav(e, mapsUrl(t.pickup_address))}>
              Google Maps
            </button>
            <button type="button" className={navBtn} onClick={(e) => openNav(e, wazeUrl(t.pickup_address))}>
              Waze
            </button>
          </div>
        </div>
        <div>
          <div className="text-[10px] font-bold uppercase tracking-widest text-brand">Drop-off</div>
          <div className="mt-0.5 font-bold text-muted-foreground">{t.dropoff_address}</div>
          <div className="mt-2 grid grid-cols-2 gap-2">
            <button type="button" className={navBtn} onClick={(e) => openNav(e, mapsUrl(t.dropoff_address))}>
              Google Maps
            </button>
            <button type="button" className={navBtn} onClick={(e) => openNav(e, wazeUrl(t.dropoff_address))}>
              Waze
            </button>
          </div>
        </div>
      </div>
      <div className="mt-3 rounded-md border border-brand/40 bg-brand/5 px-3 py-2 font-cond text-[12px] font-bold uppercase tracking-widest text-brand">
        Est. pay{" "}
        {money(driverPayout(t, driver, (stopsByRide.get(t.id) ?? []).length))}
      </div>
      {!t.driver_confirmed_at &&
        t.status !== "completed" &&
        !isPastPickup(t.pickup_at) && <ConfirmButton trip={t} />}
    </div>
  );
}

