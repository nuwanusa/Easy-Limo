import { useEffect, useRef } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getTrackedRide, type PublicTrackedRide } from "@/lib/ride-track.functions";
import { carMarkerHtml } from "@/lib/car-marker";

export const Route = createFileRoute("/t/$token")({
  head: () => ({
    meta: [
      { title: "Track your vehicle — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Follow your Blackwave chauffeur live on the map and see the estimated arrival time for your ride.",
      },
      { property: "og:title", content: "Track your vehicle — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Live vehicle location and arrival time for your Blackwave ride.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TrackPage,
});

const statusLabel = (s: string) =>
  ({
    confirmed: "Confirmed",
    assigned: "Chauffeur assigned",
    en_route: "Chauffeur on the way",
    on_location: "Chauffeur on location",
    passenger_on_board: "On board",
    completed: "Completed",
  })[s] ?? s.replace(/_/g, " ");

const clock = (v: string | null) =>
  v
    ? new Date(v).toLocaleString("en-US", {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
        timeZone: "America/New_York",
      })
    : "—";

function LiveMap({ ride }: { ride: PublicTrackedRide }) {
  const ref = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const layerRef = useRef<any>(null);
  const key = `${ride.lat},${ride.lng}`;

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (ride.lat == null || ride.lng == null) return;
      const L = (await import("leaflet")).default;
      await import("leaflet/dist/leaflet.css");
      if (cancelled || !ref.current) return;
      const pos: [number, number] = [ride.lat, ride.lng];
      if (!mapRef.current) {
        mapRef.current = L.map(ref.current).setView(pos, 13);
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          maxZoom: 19,
          attribution: "© OpenStreetMap",
        }).addTo(mapRef.current);
      }
      layerRef.current?.remove();
      layerRef.current = L.layerGroup().addTo(mapRef.current);
      L.marker(pos, {
        icon: L.divIcon({
          className: "",
          html: carMarkerHtml(ride.driver_name ?? "Chauffeur", "sm"),
          iconSize: [110, 38],
          iconAnchor: [55, 24],
        }),
      }).addTo(layerRef.current);
      mapRef.current.setView(pos, 13);
      setTimeout(() => mapRef.current?.invalidateSize(), 100);
    })().catch(() => undefined);
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  if (ride.lat == null || ride.lng == null)
    return (
      <div className="rounded-lg border border-dashed border-border px-4 py-10 text-center font-cond text-sm text-muted-foreground">
        Waiting for a current GPS reading from your chauffeur’s phone.
      </div>
    );

  return <div ref={ref} className="h-[55vh] min-h-[320px] w-full overflow-hidden rounded-lg border border-border" />;
}

function TrackPage() {
  const { token } = Route.useParams();
  const load = useServerFn(getTrackedRide);
  const { data, isLoading } = useQuery({
    queryKey: ["public-track", token],
    queryFn: () => load({ data: { token } }),
    refetchInterval: 20_000,
  });

  if (isLoading)
    return <div className="p-8 text-center font-cond text-sm text-muted-foreground">Loading your ride…</div>;

  if (!data)
    return (
      <div className="p-8 text-center font-cond text-sm text-muted-foreground">
        This tracking link is no longer available.
      </div>
    );

  const shareUrl = typeof window !== "undefined" ? window.location.href : "";

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-8">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <div>
          <div className="font-cond text-[11px] uppercase tracking-widest text-brand">
            Track your vehicle · {data.reference}
          </div>
          <div className="font-cond text-sm text-muted-foreground">
            Pickup {clock(data.pickup_at)} · {data.pickup_address ?? "—"}
          </div>
        </div>
        <span className="rounded-full bg-emerald-500/15 px-3 py-1 font-cond text-[10px] uppercase tracking-widest text-emerald-500">
          {statusLabel(data.status)}
        </span>
      </div>

      <LiveMap ride={data} />

      {data.driver_name && (
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border bg-card px-4 py-3">
          <div>
            <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
              Your chauffeur
            </div>
            <div className="font-cond text-base font-bold">{data.driver_name}</div>
            {data.driver_phone ? (
              <a
                href={`tel:${data.driver_phone.replace(/[^\d+]/g, "")}`}
                className="font-cond text-sm text-brand hover:underline"
              >
                {data.driver_phone}
              </a>
            ) : (
              <div className="font-cond text-sm text-muted-foreground">Phone not available</div>
            )}
          </div>
          {data.driver_phone && (
            <div className="flex gap-2">
              <a
                className="rounded border border-border px-3 py-1.5 font-cond text-[10px] uppercase tracking-widest hover:border-brand hover:text-brand"
                href={`tel:${data.driver_phone.replace(/[^\d+]/g, "")}`}
              >
                Call
              </a>
              <a
                className="rounded border border-border px-3 py-1.5 font-cond text-[10px] uppercase tracking-widest hover:border-brand hover:text-brand"
                href={`sms:${data.driver_phone.replace(/[^\d+]/g, "")}`}
              >
                Text
              </a>
            </div>
          )}
        </div>
      )}

      {data.eta_minutes != null && (
        <div className="mt-3 rounded-lg border border-brand/40 bg-brand/5 px-4 py-3">
          <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
            Estimated arrival
          </div>
          <div className="font-cond text-lg font-bold">
            {data.eta_minutes} min · {clock(data.eta_arrival)}
          </div>
          {data.eta_destination && (
            <div className="font-cond text-xs text-muted-foreground">{data.eta_destination}</div>
          )}
        </div>
      )}

      <div className="mt-3 grid gap-2 sm:grid-cols-3">
        <div className="rounded-lg border border-border bg-card px-3 py-2">
          <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">Chauffeur</div>
          <div className="font-cond text-sm">{data.driver_name ?? "Being assigned"}</div>
        </div>
        <div className="rounded-lg border border-border bg-card px-3 py-2">
          <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">Vehicle</div>
          <div className="font-cond text-sm">
            {[data.vehicle_color, data.vehicle].filter(Boolean).join(" ") || "—"}
            {data.vehicle_plate ? ` · ${data.vehicle_plate}` : ""}
          </div>
        </div>
        <div className="rounded-lg border border-border bg-card px-3 py-2">
          <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">Drop-off</div>
          <div className="font-cond text-sm">{data.dropoff_address ?? "—"}</div>
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <a
          className="rounded border border-border px-3 py-1.5 font-cond text-[10px] uppercase tracking-widest hover:border-brand hover:text-brand"
          href={`sms:?&body=${encodeURIComponent(`Track my Blackwave vehicle: ${shareUrl}`)}`}
        >
          Text
        </a>
        <a
          className="rounded border border-border px-3 py-1.5 font-cond text-[10px] uppercase tracking-widest hover:border-brand hover:text-brand"
          href={`https://wa.me/?text=${encodeURIComponent(`Track my Blackwave vehicle: ${shareUrl}`)}`}
          target="_blank"
          rel="noreferrer"
        >
          WhatsApp
        </a>
        <a
          className="rounded border border-border px-3 py-1.5 font-cond text-[10px] uppercase tracking-widest hover:border-brand hover:text-brand"
          href={`mailto:?subject=${encodeURIComponent("Track my Blackwave vehicle")}&body=${encodeURIComponent(shareUrl)}`}
        >
          Email
        </a>
      </div>
    </div>
  );
}
