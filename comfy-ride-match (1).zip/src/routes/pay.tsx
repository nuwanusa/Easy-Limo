import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { isFinishedTrip } from "@/lib/driver";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { MoneyTabs } from "@/components/MoneyTabs";
import { Button } from "@/components/ui/button";
import { Car, CheckCircle2, Download, Search, Send, Users, Wallet } from "lucide-react";
import { sendDriverPaymentEmail } from "@/lib/driver-pay.functions";
import {
  clockTime,
  dayLabel,
  driverPayout,
  driversQuery,
  fareTotal,
  groupStops,
  money,
  reservationsQuery,
  stopsQuery,
  type Driver,
  type Reservation,
} from "@/lib/dispatch";

export const Route = createFileRoute("/pay")({
  head: () => ({
    meta: [
      { title: "Chauffeur Pay — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Track chauffeur payouts: amounts due for completed Blackwave trips, payments already settled, and one-click payment statements.",
      },
      { property: "og:title", content: "Chauffeur Pay — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Review outstanding and settled chauffeur payouts and send payment statements.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <AppShell>
      <PayPage />
    </AppShell>
  ),
});

const startOfDay = (d: Date) => {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
};
const endOfDay = (d: Date) => {
  const x = new Date(d);
  x.setHours(23, 59, 59, 999);
  return x;
};
const isoDay = (d: Date) => {
  const x = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return x.toISOString().slice(0, 10);
};

type Period = "day" | "week" | "month" | "all" | "custom";

function PayPage() {
  const qc = useQueryClient();
  const [selected, setSelected] = useState("");
  const [period, setPeriod] = useState<Period>("day");
  const [fromDate, setFromDate] = useState(isoDay(new Date()));
  const [toDate, setToDate] = useState(isoDay(new Date()));
  const [picked, setPicked] = useState<string[]>([]);
  const [search, setSearch] = useState("");
  const toggle = (id: string) =>
    setPicked((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));
  const { data: drivers = [] } = useQuery(driversQuery);
  const { data: reservations = [] } = useQuery(reservationsQuery);
  const { data: stops = [] } = useQuery(stopsQuery);
  const stopsByRide = useMemo(() => groupStops(stops), [stops]);

  const dayText = (v: string) =>
    new Date(`${v}T00:00:00`).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  const today = new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  const periodLabel =
    period === "day"
      ? `Today · ${today}`
      : period === "week"
        ? `Last 7 days · through ${today}`
        : period === "month"
          ? `Last 30 days · through ${today}`
          : period === "custom"
            ? `${dayText(fromDate)} – ${dayText(toDate)}`
            : "All time";

  const [paidIds, setPaidIds] = useState<string[]>([]);
  const payDriver = useServerFn(sendDriverPaymentEmail);
  const sendPay = useMutation({
    mutationFn: ({ driverId, ids }: { driverId: string; ids: string[] }) => {
      const chosen = picked.filter((id) => ids.includes(id));
      const reservationIds = chosen.length ? chosen : ids;
      return payDriver({ data: { driverId, reservationIds, periodLabel } });
    },
    onSuccess: (res: any, vars) => {
      if (res?.sent) {
        toast.success(`Payment statement sent to ${res.email} — ${res.amount} for ${res.trips} trips.`);
        const chosen = picked.filter((id) => vars.ids.includes(id));
        setPaidIds((p) => [...p, ...(chosen.length ? chosen : vars.ids)]);
        qc.invalidateQueries({ queryKey: ["reservations"] });
        setPicked([]);
      } else if (res?.reason === "nothing_due") {
        toast.error("No completed unpaid rides for this chauffeur.");
      } else if (res?.reason === "no_driver_email") {
        toast.error("Add an email address for this chauffeur first.");
      } else {
        toast.error(`Payment email failed: ${res?.reason ?? "unknown error"}`);
      }
    },
    onError: (e: unknown) => toast.error(e instanceof Error ? e.message : "Payment email failed"),
  });

  const range = useMemo(() => {
    const now = new Date();
    if (period === "all") return null;
    if (period === "day") return { from: startOfDay(now), to: endOfDay(now) };
    if (period === "week") {
      const from = startOfDay(new Date(now.getTime() - 6 * 86400000));
      return { from, to: endOfDay(now) };
    }
    if (period === "month") {
      const from = startOfDay(new Date(now.getTime() - 29 * 86400000));
      return { from, to: endOfDay(now) };
    }
    return { from: startOfDay(new Date(`${fromDate}T00:00:00`)), to: endOfDay(new Date(`${toDate}T00:00:00`)) };
  }, [period, fromDate, toDate]);

  const inRange = (t: Reservation) => {
    if (!range) return true;
    const d = new Date(t.pickup_at).getTime();
    return d >= range.from.getTime() && d <= range.to.getTime();
  };

  const completed = reservations.filter(
    (r) => isFinishedTrip(r) && r.driver_id && inRange(r) && !paidIds.includes(r.id),
  );
  const payOf = (t: Reservation, d: Driver | null) =>
    driverPayout(t, d, (stopsByRide.get(t.id) ?? []).length);
  const totalOf = (t: Reservation) => fareTotal(t, (stopsByRide.get(t.id) ?? []).length);

  const rows = drivers
    .map((d) => {
      const trips = completed.filter((t) => t.driver_id === d.id);
      const due = trips.filter((t) => !t.driver_paid_at);
      const paid = trips.filter((t) => t.driver_paid_at);
      const sum = (list: Reservation[]) => list.reduce((n, t) => n + payOf(t, d), 0);
      return { driver: d, due, paid, dueTotal: sum(due), paidTotal: sum(paid) };
    })
    .filter((r) => r.due.length > 0)
    .sort((a, b) => b.dueTotal - a.dueTotal);

  const grandDue = rows.reduce((n, r) => n + r.dueTotal, 0);
  const paidTrips = completed.filter((ride) => ride.driver_paid_at);
  const grandPaid = paidTrips.reduce((sum, ride) => sum + payOf(ride, drivers.find((driver) => driver.id === ride.driver_id) ?? null), 0);
  const activeChauffeurs = new Set(completed.map((ride) => ride.driver_id).filter(Boolean)).size;

  const pickedTotal = completed
    .filter((t) => picked.includes(t.id))
    .reduce((n, t) => n + payOf(t, drivers.find((d) => d.id === t.driver_id) ?? null), 0);

  const base = selected ? rows.filter((r) => r.driver.id === selected) : rows;
  const needle = search.trim().toLowerCase();
  const shown = !needle
    ? base
    : base
        .map((r) => {
          if (r.driver.full_name?.toLowerCase().includes(needle)) return r;
          const due = r.due.filter((t) =>
            `${t.reference} ${t.passenger_name} ${t.pickup_address} ${t.dropoff_address}`
              .toLowerCase()
              .includes(needle),
          );
          return { ...r, due };
        })
        .filter((r) => r.due.length > 0);

  const exportCsv = () => {
    const all = shown.flatMap(({ driver, due }) => due.map((ride) => [dayLabel(ride.pickup_at), clockTime(ride.pickup_at), ride.reference, ride.passenger_name, driver.full_name, `${ride.pickup_address} → ${ride.dropoff_address}`, payOf(ride, driver).toFixed(2), ride.driver_paid_at ? "Paid" : "Due"]));
    const csv = [["Date", "Time", "Reference", "Passenger", "Chauffeur", "Trip details", "Amount", "Status"], ...all].map((line) => line.map((value) => `"${String(value).replaceAll('"', '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const anchor = document.createElement("a"); anchor.href = url; anchor.download = "blackwave-chauffeur-pay.csv"; anchor.click(); URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-dashboard-canvas px-3 pb-10 pt-5 font-admin-body sm:px-5">
      <header className="border-b border-dashboard-line pb-4">
        <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-dashboard-blue">Payouts</p>
        <h1 className="font-admin-display text-3xl font-bold text-dashboard-navy sm:text-4xl">Chauffeur Pay</h1>
        <p className="mt-1 text-sm text-dashboard-muted">Track chauffeur earnings, view completed rides, and manage payments.</p>
      </header>
      <div className="mt-4"><MoneyTabs /></div>

      <section className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <PayStat icon={<Wallet />} label="Total due" value={money(grandDue)} note="Pending payments" tone="blue" />
        <PayStat icon={<CheckCircle2 />} label="Paid out" value={money(grandPaid)} note="Total paid" tone="green" />
        <PayStat icon={<Car />} label="Completed rides" value={completed.length.toString()} note="With chauffeur assigned" tone="blue" />
        <PayStat icon={<Users />} label="Chauffeurs" value={activeChauffeurs.toString()} note="Active chauffeurs" tone="violet" />
      </section>

      <section className="mt-4 grid gap-4 rounded-md border border-dashboard-line bg-card p-4 shadow-sm xl:grid-cols-[1.35fr_0.8fr_0.95fr]">
        <div>
          <span className="text-xs font-bold text-dashboard-navy">Payment period</span>
          <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-5">
            {([
              ["day", "Today"],
              ["week", "Last 7 days"],
              ["month", "Last 30 days"],
              ["custom", "Custom"],
              ["all", "All time"],
            ] as [Period, string][]).map(([value, label]) => (
              <Button
                key={value}
                type="button"
                variant={period === value ? "default" : "outline"}
                onClick={() => setPeriod(value)}
                className="w-full px-2 text-xs"
              >
                {label}
              </Button>
            ))}
          </div>
          {period === "custom" && (
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                aria-label="From date"
                className="h-9 rounded-md border border-dashboard-line bg-background px-2 text-sm"
              />
              <span className="text-sm text-dashboard-muted">to</span>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                aria-label="To date"
                className="h-9 rounded-md border border-dashboard-line bg-background px-2 text-sm"
              />
            </div>
          )}
        </div>
        <label className="text-xs font-bold text-dashboard-navy">Chauffeur<select value={selected} onChange={(event) => setSelected(event.target.value)} className="mt-2 h-10 w-full rounded-md border border-dashboard-line bg-background px-3 text-sm font-normal"><option value="">All chauffeurs</option>{drivers.map((driver) => <option key={driver.id} value={driver.id}>{driver.full_name}</option>)}</select></label>
        <label htmlFor="pay-search" className="text-xs font-bold text-dashboard-navy">Search<div className="relative mt-2"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-dashboard-muted" /><input id="pay-search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Chauffeur, passenger, ref, address…" className="h-10 w-full rounded-md border border-dashboard-line bg-background pl-9 pr-3 text-sm outline-none focus:border-dashboard-blue" /></div></label>
      </section>

      <section className="mt-4 overflow-hidden rounded-md border border-dashboard-line bg-card shadow-sm">
        <header className="flex flex-wrap items-center gap-3 border-b border-dashboard-line px-4 py-3">
          <Wallet className="size-5 text-dashboard-blue" /><h2 className="font-admin-display text-lg font-bold text-dashboard-navy">Chauffeur Payments</h2>
          <div className="ml-auto flex gap-2"><Button variant="outline" onClick={exportCsv}><Download /> Export</Button>{shown.length === 1 && <Button onClick={() => { const item = shown[0]; if (item && confirm(`Email ${item.driver.full_name} a payment statement and mark those rides paid?`)) sendPay.mutate({ driverId: item.driver.id, ids: item.due.map((ride) => ride.id) }); }} disabled={sendPay.isPending}><Send /> Send payment</Button>}</div>
        </header>

        {shown.length === 0 ? (
          <div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[820px] text-left">
                <thead>
                  <tr className="bg-dashboard-soft text-[9px] font-bold uppercase text-dashboard-muted">
                    <th className="rounded-l-md px-3 py-3">Date</th><th className="px-3 py-3">Ref</th><th className="px-3 py-3">Passenger</th><th className="px-3 py-3">Chauffeur</th><th className="px-3 py-3">Trip details</th><th className="px-3 py-3 text-right">Amount</th><th className="px-3 py-3 text-right">Status</th><th className="rounded-r-md px-3 py-3 text-right">Actions</th>
                  </tr>
                </thead>
              </table>
            </div>
          <div className="grid min-h-64 place-items-center p-8 text-center"><div><span className="mx-auto grid size-16 place-items-center rounded-full bg-dashboard-ice text-dashboard-blue"><Wallet className="size-8" /></span><h3 className="mt-4 font-admin-display text-xl font-bold text-dashboard-navy">No payments due</h3><p className="mt-1 max-w-lg text-sm text-dashboard-muted">There are no completed rides with an assigned chauffeur in the selected period. Try changing the date range or chauffeur filter.</p></div></div>
          </div>
        ) : (
          <div className="divide-y divide-dashboard-line">
            {shown.map(({ driver, due, dueTotal, paidTotal }) => (
              <section key={driver.id} className="p-4">
                <div className="flex flex-wrap items-center justify-between gap-3"><div><h3 className="font-admin-display text-base font-bold text-dashboard-navy">{driver.full_name}</h3><p className="text-xs text-dashboard-muted">{money(dueTotal)} due · {money(paidTotal)} paid</p></div><Button variant="outline" onClick={() => { if (confirm(`Email ${driver.full_name} a payment statement and mark those rides paid?`)) sendPay.mutate({ driverId: driver.id, ids: due.map((ride) => ride.id) }); }} disabled={sendPay.isPending || due.length === 0} className="border-success/50 text-success"><Send />{sendPay.isPending ? "Sending…" : "Send payment"}</Button></div>
                <TripTable title="Payment due" trips={due} driver={driver} payOf={payOf} totalOf={totalOf} picked={picked} onToggle={toggle} />
              </section>
            ))}
          </div>
        )}
      </section>

      {picked.length > 0 && (
        <div className="fixed inset-x-0 bottom-16 z-40 border-t border-dashboard-line bg-card/95 px-4 py-3 backdrop-blur sm:px-6"><div className="mx-auto flex max-w-4xl flex-wrap items-center justify-between gap-3"><div><div className="text-[10px] font-bold uppercase text-dashboard-muted">{picked.length} reservation{picked.length === 1 ? "" : "s"} selected</div><div className="font-admin-display text-2xl font-bold text-dashboard-blue">{money(pickedTotal)}</div></div><Button variant="outline" onClick={() => setPicked([])}>Clear</Button></div></div>
      )}
    </div>
  );
}

function TripTable({
  title,
  trips,
  driver,
  payOf,
  totalOf,
  picked,
  onToggle,
}: {
  title: string;
  trips: Reservation[];
  driver: Driver;
  payOf: (t: Reservation, d: Driver | null) => number;
  totalOf: (t: Reservation) => number;
  picked?: string[];
  onToggle?: (id: string) => void;
}) {
  if (trips.length === 0) return null;
  const ordered = [...trips].sort(
    (a, b) => new Date(b.pickup_at).getTime() - new Date(a.pickup_at).getTime(),
  );
  return (
    <div className="mt-4">
      <h3 className="sr-only">{title}</h3>
      <div className="mt-2 overflow-x-auto">
        <table className="w-full min-w-[820px] text-left">
          <thead>
            <tr className="bg-dashboard-soft text-[9px] font-bold uppercase text-dashboard-muted">
              {onToggle && <th className="rounded-l-md px-3 py-3"></th>}
              <th className="px-3 py-3">Date</th><th className="px-3 py-3">Ref</th><th className="px-3 py-3">Passenger</th><th className="px-3 py-3">Trip details</th><th className="px-3 py-3 text-right">Fare</th><th className="rounded-r-md px-3 py-3 text-right">Amount</th>
            </tr>
          </thead>
          <tbody className="font-cond text-sm">
            {ordered.map((t) => (
              <tr key={t.id} className="border-t border-dashboard-line hover:bg-dashboard-canvas">
                {onToggle && (
                  <td className="py-2 pr-3">
                    <input
                      type="checkbox"
                     className="size-4 accent-primary"
                      checked={picked?.includes(t.id) ?? false}
                      onChange={() => onToggle(t.id)}
                      aria-label={`Select reservation ${t.reference}`}
                    />
                  </td>
                )}
                 <td className="whitespace-nowrap px-3 py-3">
                  {dayLabel(t.pickup_at)} · {clockTime(t.pickup_at)}
                </td>
                 <td className="px-3 py-3">
                   <Link to="/reservations" search={{ edit: t.id }} className="font-semibold text-dashboard-blue hover:underline">
                    {t.reference}
                  </Link>
                </td>
                 <td className="px-3 py-3">{t.passenger_name}</td>
                 <td className="max-w-sm truncate px-3 py-3 text-dashboard-muted">
                  {t.pickup_address} → {t.dropoff_address}
                </td>
                 <td className="px-3 py-3 text-right">{money(totalOf(t))}</td>
                 <td className="px-3 py-3 text-right font-bold text-dashboard-blue">{money(payOf(t, driver))}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function PayStat({ icon, label, value, note, tone }: { icon: React.ReactNode; label: string; value: string; note: string; tone: "blue" | "green" | "violet" }) {
  const tones = { blue: "border-dashboard-blue/20 bg-dashboard-ice/50 text-dashboard-blue", green: "border-success/20 bg-success/5 text-success", violet: "border-accent bg-card text-accent-foreground" };
  return <div className={`flex min-h-24 items-center gap-4 rounded-md border p-4 shadow-sm ${tones[tone]}`}><span className="grid size-12 shrink-0 place-items-center rounded-full bg-current/10 [&>svg]:size-6">{icon}</span><div className="min-w-0"><p className="truncate text-[10px] font-bold uppercase text-dashboard-muted">{label}</p><p className="truncate font-admin-display text-2xl font-bold text-dashboard-navy">{value}</p><p className="truncate text-xs text-dashboard-muted">{note}</p></div></div>;
}
