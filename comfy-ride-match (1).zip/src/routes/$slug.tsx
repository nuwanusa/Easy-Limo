import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/auth";
import { getMyPortal, getPortalByCode, getPortalClientBySlug } from "@/lib/client-portal.functions";
import type { PortalData } from "@/lib/client-portal.functions";
import { PortalView } from "@/components/PortalView";

export const Route = createFileRoute("/$slug")({
  head: () => ({
    meta: [
      { title: "Client Portal — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Sign in to your Blackwave Transportation client page to review paid and unpaid invoices with the full breakdown of every ride.",
      },
      { property: "og:title", content: "Client Portal — Blackwave Transportation LLC" },
      { property: "og:description", content: "Your invoices, ride details and online payment." },
      { property: "og:type", content: "website" },
      { name: "robots", content: "noindex" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ClientSlugPage,
});

function ClientSlugPage() {
  const { slug } = Route.useParams();
  const navigate = useNavigate();
  const { session, loading } = useSession();
  const lookup = useServerFn(getPortalClientBySlug);
  const fetchPortal = useServerFn(getMyPortal);
  const fetchByCode = useServerFn(getPortalByCode);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [code, setCode] = useState("");
  const [codeData, setCodeData] = useState<PortalData | null>(null);

  const codeLogin = useMutation({
    mutationFn: () => fetchByCode({ data: { code: code.trim(), slug } }),
    onSuccess: (res) => setCodeData(res),
    onError: (e: Error) => toast.error(e.message),
  });

  const client = useQuery({
    queryKey: ["portal-slug", slug],
    queryFn: () => lookup({ data: { slug } }),
    retry: false,
  });

  const portal = useQuery({
    queryKey: ["client-portal"],
    queryFn: () => fetchPortal(),
    enabled: Boolean(session) && Boolean(client.data),
    retry: false,
  });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Sign in failed");
    } finally {
      setBusy(false);
    }
  };

  if (client.isLoading) {
    return (
      <p className="py-24 text-center font-cond text-xs uppercase tracking-[0.4em] text-muted-foreground">Loading</p>
    );
  }

  if (!client.data) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 px-4 text-center">
        <h1 className="font-display text-3xl uppercase">Page not found</h1>
        <p className="text-sm text-muted-foreground">This client page does not exist.</p>
        <button
          onClick={() => navigate({ to: "/" })}
          className="rounded-md bg-brand px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-brand-foreground"
        >
          Go to Blackwave
        </button>
      </div>
    );
  }

  const name = client.data.name;

  return (
    <div className="cine min-h-screen text-foreground">
      <header className="border-b border-border bg-nav">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:px-6">
          <span className="grid size-10 place-items-center bg-brand font-display text-lg text-brand-foreground">B</span>
          <div className="flex-1">
            <div className="font-display text-lg uppercase leading-none">{name}</div>
            <div className="font-cond text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
              Blackwave client portal
            </div>
          </div>
          {(session || codeData) && (
            <button
              onClick={async () => {
                setCodeData(null);
                setCode("");
                if (session) await supabase.auth.signOut();
              }}
              className="rounded-md border border-border px-3 py-2 font-cond text-[11px] uppercase tracking-widest text-foreground hover:border-brand hover:text-brand"
            >
              {session ? "Sign out" : "Close"}
            </button>
          )}
        </div>
      </header>

      {codeData ? (
        <PortalView data={codeData} auth={{ code: code.trim() }} />
      ) : loading ? (
        <p className="py-24 text-center font-cond text-xs uppercase tracking-[0.4em] text-muted-foreground">Loading</p>
      ) : !session ? (
        <div className="mx-auto w-full max-w-md px-4 py-16">
          <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
            <div className="font-cond text-[11px] uppercase tracking-[0.3em] text-brand">Client sign in</div>
            <h1 className="mt-2 font-display text-2xl uppercase leading-tight">{name}</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Sign in to review your paid and unpaid invoices and every ride in detail.
            </p>
            <form onSubmit={submit} className="mt-5 space-y-3">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@company.com"
                className="w-full rounded-md border border-input bg-surface-2 px-3 py-2.5 text-sm"
              />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                className="w-full rounded-md border border-input bg-surface-2 px-3 py-2.5 text-sm"
              />
              <button
                type="submit"
                disabled={busy}
                className="w-full rounded-md bg-brand px-4 py-2.5 font-cond text-[11px] uppercase tracking-widest text-brand-foreground disabled:opacity-50"
              >
                {busy ? "Signing in…" : "View my invoices"}
              </button>
            </form>
            <div className="my-5 flex items-center gap-3">
              <span className="h-px flex-1 bg-border" />
              <span className="font-cond text-[10px] uppercase tracking-[0.3em] text-muted-foreground">or</span>
              <span className="h-px flex-1 bg-border" />
            </div>

            <div className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
              Enter your six-digit access code
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                codeLogin.mutate();
              }}
              className="mt-2 flex gap-2"
            >
              <input
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={6}
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                placeholder="123456"
                className="w-full rounded-md border border-input bg-surface-2 px-3 py-2.5 text-center text-lg tracking-[0.5em]"
              />
              <button
                type="submit"
                disabled={codeLogin.isPending || code.length !== 6}
                className="shrink-0 rounded-md border border-brand px-4 py-2.5 font-cond text-[11px] uppercase tracking-widest text-brand disabled:opacity-50"
              >
                {codeLogin.isPending ? "Opening…" : "View"}
              </button>
            </form>

            <p className="mt-3 text-center text-xs text-muted-foreground">
              Need access? Contact Blackwave Transportation at info@rideblackwave.com.
            </p>
          </div>
        </div>
      ) : portal.isLoading ? (
        <p className="py-24 text-center font-cond text-xs uppercase tracking-[0.4em] text-muted-foreground">
          Loading invoices
        </p>
      ) : portal.error ? (
        <p className="py-24 text-center text-sm text-destructive">
          {portal.error instanceof Error ? portal.error.message : "Could not load your invoices"}
        </p>
      ) : portal.data ? (
        <PortalView data={portal.data} />
      ) : null}
    </div>
  );
}
