import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { InvoiceShare } from "@/components/InvoiceShare";
import { PayOptions } from "@/components/PayOptions";
import { PayByCardLink } from "@/components/PayByCardLink";
import { SendReceiptButton } from "@/components/SendReceiptButton";
import { SendInvoiceToEmail } from "@/components/SendInvoiceToEmail";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { sendDriverAssignmentEmail } from "@/lib/driver-notify.functions";
import { sendClientInvoiceEmail } from "@/lib/invoice-notify.functions";

import {
  billableHours,
  clientsQuery,
  clockTime,
  dayLabel,
  driversQuery,

  fareTotal,
  groupStops,
  invoicesQuery,
  money,
  passengerNames,
  periodLabel,
  reservationsQuery,
  stopsQuery,
  flatRate,
  hourlyCharge,
  waitingCharge,
  baseRate,
  invoiceOthers,
  otherBreakdownRows,
  type Invoice,
} from "@/lib/dispatch";

export const Route = createFileRoute("/invoices/$id")({
  head: () => ({
    meta: [
      { title: "Billing Statement — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Printable multi-trip invoice listing every chauffeur ride in the billing period with routes, vehicle class, trip totals and a grand total.",
      },
      { property: "og:title", content: "Billing Statement — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Issue, print and settle a client account invoice covering multiple rides.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AppShell>
      <ConsolidatedInvoice />
    </AppShell>
  ),
});

const COMPANY = {
  name: "Blackwave Transportation LLC",
  line1: "52 Meredith Avenue",
  line2: "Staten Island, NY 10314",
  contact: "Tel: (917) 325-3211",
  email: "info@rideblackwave.com",
  website: "www.rideblackwave.com",
};

function ConsolidatedInvoice() {
  const { id } = Route.useParams();
  const qc = useQueryClient();
  const { data: invoices = [], isLoading } = useQuery(invoicesQuery);
  const { data: clients = [] } = useQuery(clientsQuery);
  const { data: reservations = [] } = useQuery(reservationsQuery);
  const { data: stops = [] } = useQuery(stopsQuery);
  const { data: drivers = [] } = useQuery(driversQuery);

  const notifyDriver = useServerFn(sendDriverAssignmentEmail);
  const emailInvoiceFn = useServerFn(sendClientInvoiceEmail);

  const emailInvoice = useMutation({
    mutationFn: async () => emailInvoiceFn({ data: { invoiceId: id } }),
    onSuccess: (res) => {
      qc.invalidateQueries({ queryKey: ["invoices"] });
      if (res?.sent) toast.success("Billing statement emailed to the client");
      else if (res?.reason === "no_client_email") toast.error("No email address on file for this client");
      else toast.error("Billing statement could not be emailed", { description: res?.reason });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const setDriver = useMutation({
    mutationFn: async ({ id: rideId, driverId }: { id: string; driverId: string | null }) => {
      const { error } = await supabase.from("reservations").update({ driver_id: driverId, driver_confirmed_at: null }).eq("id", rideId);
      if (error) throw error;
      if (!driverId) return { notified: null as null | { sent: boolean; reason?: string } };
      return { notified: await notifyDriver({ data: { reservationId: rideId } }) };
    },
    onSuccess: (res) => {
      qc.invalidateQueries({ queryKey: ["reservations"] });
      const n = res?.notified;
      if (!n) toast.success("Chauffeur updated");
      else if (n.sent) toast.success("Chauffeur assigned — confirmation email sent");
      else if (n.reason === "no_driver_email") toast.success("Chauffeur assigned (no email on file)");
      else toast.success("Chauffeur assigned — email could not be sent yet");
    },
    onError: (e: Error) => toast.error(e.message),
  });


  const patch = useMutation({
    mutationFn: async (values: Partial<Invoice>) => {
      const { error } = await supabase.from("invoices").update(values).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["invoices"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const unlink = useMutation({
    mutationFn: async (reservationId: string) => {
      const { error } = await supabase
        .from("reservations")
        .update({ invoice_id: null })
        .eq("id", reservationId);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["reservations"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const navigate = useNavigate();
  const [showEdit, setShowEdit] = useState(false);
  const [showAdd, setShowAdd] = useState(false);

  const addRides = useMutation({
    mutationFn: async (ids: string[]) => {
      if (!ids.length) throw new Error("Select at least one ride");
      const missing = reservations.filter((r) => ids.includes(r.id) && !r.dropoff_at);
      if (missing.length)
        throw new Error(
          `Add a drop-off time to ${missing.map((r) => r.reference).join(", ")} before billing.`,
        );
      const { error } = await supabase.from("reservations").update({ invoice_id: id }).in("id", ids);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["reservations"] });
      setShowAdd(false);
      toast.success("Rides added to this invoice");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const removeInvoice = useMutation({
    mutationFn: async () => {
      const { error: unlinkError } = await supabase
        .from("reservations")
        .update({ invoice_id: null })
        .eq("invoice_id", id);
      if (unlinkError) throw unlinkError;
      const { error } = await supabase.from("invoices").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["invoices"] });
      qc.invalidateQueries({ queryKey: ["reservations"] });
      toast.success("Billing statement deleted");
      navigate({ to: "/invoices" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (isLoading) {
    return (
      <div className="px-6 py-16 font-cond text-xs uppercase tracking-[0.4em] text-muted-foreground">
        Loading invoice
      </div>
    );
  }

  const invoice = invoices.find((i) => i.id === id);
  if (!invoice) {
    return (
      <div className="px-6 py-16">
        <h1 className="font-display text-4xl uppercase">Invoice not found</h1>
        <Link to="/invoices" className="mt-4 inline-block font-cond text-xs uppercase tracking-widest text-brand">
          Back to invoices
        </Link>
      </div>
    );
  }

  const client = clients.find((c) => c.id === invoice.client_id);
  const trips = reservations
    .filter((r) => r.invoice_id === invoice.id)
    .sort((a, b) => new Date(a.pickup_at).getTime() - new Date(b.pickup_at).getTime());
  const billingContact =
    trips.map((r) => (r as { billing_contact_name?: string | null }).billing_contact_name?.trim()).find(Boolean) ||
    client?.contact_name ||
    "";

  const stopsByRide = groupStops(stops);
  const stopCountOf = (id: string) => (stopsByRide.get(id) ?? []).length;

  const sum = (fn: (r: (typeof trips)[number]) => number) => trips.reduce((s, r) => s + fn(r), 0);
  const breakdown = {
    flat: sum((r) => flatRate(r)),
    hourly: sum((r) => hourlyCharge(r)),
    hours: sum((r) => (r.booking_type === "hourly" ? billableHours(r) : 0)),
    waiting: sum((r) => waitingCharge(r)),
    waitingMinutes: sum((r) => Number(r.waiting_minutes ?? 0)),
    stops: sum((r) => Number(r.stop_fee ?? 0) * stopCountOf(r.id)),
    stopCount: sum((r) => stopCountOf(r.id)),
    meetGreet: sum((r) => Number(r.meet_greet_fee ?? 0)),
    airport: sum((r) => Number(r.airport_fee ?? 0)),
    parking: sum((r) => Number(r.parking_fee ?? 0)),
    tolls: sum((r) => Number(r.tolls ?? 0)),
    gratuity: sum((r) => Number(r.gratuity ?? 0)),
  };

  const subtotal = trips.reduce((s, r) => s + fareTotal(r, stopCountOf(r.id)), 0);
  const totalDue = subtotal - Number(invoice.discount) - Number(invoice.payments);

  return (
    <>
      <div className="no-print flex flex-wrap items-center gap-3 border-b border-border px-6 py-4">
        <Link to="/invoices" className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground hover:text-brand">
          ← Statements
        </Link>
        <div className="ml-auto flex flex-wrap items-center gap-2">
          {!invoice.issued_at && (
            <button
              onClick={() => patch.mutate({ issued_at: new Date().toISOString() })}
              className="rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest hover:border-brand hover:text-brand"
            >
              Issue invoice
            </button>
          )}
          {!invoice.paid_at ? (
            <button
              onClick={() => patch.mutate({ paid_at: new Date().toISOString(), payments: subtotal })}
              className="rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest hover:border-brand hover:text-brand"
            >
              Mark paid
            </button>
          ) : (
            <button
              onClick={() => patch.mutate({ paid_at: null, payments: 0 })}
              className="rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-muted-foreground"
            >
              Undo paid
            </button>
          )}
          <button
            onClick={() => { setShowEdit((v) => !v); setShowAdd(false); }}
            className="rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest hover:border-brand hover:text-brand"
          >
            {showEdit ? "Close edit" : "Edit invoice"}
          </button>
          <button
            onClick={() => { setShowAdd((v) => !v); setShowEdit(false); }}
            className="rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest hover:border-brand hover:text-brand"
          >
            {showAdd ? "Close" : "Add rides"}
          </button>
          <button
            onClick={() => {
              if (window.confirm("Delete this invoice? The rides stay in the system and become unbilled.")) removeInvoice.mutate();
            }}
            className="rounded-md border border-destructive/60 px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-destructive hover:bg-destructive hover:text-white"
          >
            Delete invoice
          </button>
          <button
            onClick={() => emailInvoice.mutate()}
            disabled={emailInvoice.isPending}
            className="rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest hover:border-brand hover:text-brand disabled:opacity-50"
          >
            {emailInvoice.isPending ? "Sending…" : "Email client"}
          </button>
          <PayOptions
            target="invoice"
            id={invoice.id}
            amount={totalDue}
            paid={Boolean(invoice.paid_at)}
            label="Pay"
          />
          <SendInvoiceToEmail invoiceId={invoice.id} />
          <SendReceiptButton
            target="invoice"
            id={invoice.id}
            paid={Boolean(invoice.paid_at) || Number(invoice.payments ?? 0) > 0}
          />
          <InvoiceShare number={invoice.invoice_number} />
          <button
            onClick={() => window.print()}
            className="rounded-md bg-brand px-5 py-2 font-cond text-[11px] uppercase tracking-widest text-brand-foreground"
          >
            Print / Save PDF
          </button>
        </div>
      </div>

      {showEdit && (
        <div className="no-print mx-6 mt-4 rounded-lg border border-border bg-card p-5">
          <div className="grid gap-3 md:grid-cols-4">
            <EditField
              label="Period start"
              type="date"
              value={invoice.period_start ?? ""}
              onSave={(v) => patch.mutate({ period_start: v || null })}
            />
            <EditField
              label="Period end"
              type="date"
              value={invoice.period_end ?? ""}
              onSave={(v) => patch.mutate({ period_end: v || null })}
            />
            <EditField
              label="Discount"
              type="number"
              value={String(invoice.discount ?? 0)}
              onSave={(v) => patch.mutate({ discount: Number(v) || 0 })}
            />
            <EditField
              label="Payments received"
              type="number"
              value={String(invoice.payments ?? 0)}
              onSave={(v) => patch.mutate({ payments: Number(v) || 0 })}
            />
            <div className="md:col-span-4">
              <EditField
                label="Notes"
                type="text"
                value={invoice.notes ?? ""}
                onSave={(v) => patch.mutate({ notes: v || null })}
              />
            </div>
          </div>
        </div>
      )}

      {showAdd && (
        <AddRidesPanel
          rides={reservations.filter(
            (r) => !r.invoice_id && (!invoice.client_id || r.client_id === invoice.client_id),
          )}
          stopCountOf={stopCountOf}
          onAdd={(ids) => addRides.mutate(ids)}
          pending={addRides.isPending}
        />
      )}

      <article className="invoice-sheet tpl-azure mx-auto my-8 w-full max-w-[1800px] rounded-lg border border-border bg-card p-10">
        <header className="invoice-head flex items-start justify-between border-b border-border pb-6">
          <div>
            <div className="font-display text-3xl uppercase leading-none tracking-wider">{COMPANY.name}</div>
            <div className="mt-3 font-cond text-base leading-relaxed tracking-wide text-foreground">
              {COMPANY.line1}
              <br />
              {COMPANY.line2}
              <br />
              {COMPANY.contact}
              <br />
              {COMPANY.email}
              <br />
              {COMPANY.website}
            </div>
          </div>
          <div className="text-right">
            <div className="font-display text-3xl uppercase leading-none text-brand">Billing Statement</div>
            <div className="mt-2 font-cond text-sm tracking-wide text-foreground">
              <div>Statement #{invoice.invoice_number}</div>
              <div className="text-muted-foreground">
                Billing period: {periodLabel(invoice.period_start, invoice.period_end)}
              </div>



              <div>
                Due date:{" "}
                {invoice.paid_at
                  ? `Paid ${dayLabel(invoice.paid_at)}`
                  : (client?.terms ?? (invoice.issued_at ? dayLabel(invoice.issued_at) : "Due on receipt"))}
              </div>
            </div>
          </div>
        </header>
        {invoice.paid_at && (
          <div className="mt-6 rounded-md border border-emerald-600/40 bg-emerald-50 px-5 py-3 text-center">
            <div className="font-display text-2xl uppercase tracking-wider text-emerald-700">Paid in full</div>
            <div className="font-cond text-sm text-emerald-800">Thank you for your payment.</div>
          </div>
        )}


        <section className="grid gap-6 border-b border-border py-6 sm:grid-cols-3">
          <div className="invoice-billto">
            <Label>Bill to</Label>
            <div className="font-cond text-sm font-medium">
              {billingContact || client?.name || "—"}
            </div>
            {billingContact && client?.name ? (
              <div className="font-cond text-sm text-muted-foreground">{client.name}</div>
            ) : null}
            {client?.address_line1 && <div className="font-cond text-sm text-muted-foreground">{client.address_line1}</div>}
            {client?.address_line2 && <div className="font-cond text-sm text-muted-foreground">{client.address_line2}</div>}
          </div>
          <div className="invoice-card">
            <Label>Account #</Label>
            <div className="font-cond text-sm">{client?.account_number ?? "—"}</div>
            <Label>Billing period</Label>
            <div className="font-cond text-sm text-muted-foreground">
              {periodLabel(invoice.period_start, invoice.period_end)}
            </div>
          </div>
          <div className="invoice-card">
            <Label>Trips</Label>
            <div className="font-display text-3xl leading-none">{trips.length}</div>
          </div>

        </section>

        <section className="py-6">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                <th className="py-2 text-left">Date</th>
                <th className="py-2 text-left">Pickup time</th>
                <th className="py-2 text-left">Drop-off time</th>
                <th className="py-2 text-left">Passenger</th>
                <th className="py-2 text-left">Vehicle</th>
                <th className="no-print py-2 text-left">Chauffeur</th>
                <th className="py-2 text-right">Base rate</th>
                <th className="py-2 text-right">Flat rate</th>
                <th className="py-2 text-right">Others</th>
                <th className="py-2 text-right">Total</th>
                <th className="no-print py-2"></th>
              </tr>

            </thead>
            <tbody className="divide-y divide-border font-cond text-sm">
              {trips.map((r) => (
                <tr key={r.id} className="align-top">
                  <td className="py-3 pr-3 whitespace-nowrap">{dayLabel(r.pickup_at)}</td>
                  <td className="py-3 pr-3 whitespace-nowrap tabular-nums">{clockTime(r.pickup_at)}</td>
                  <td className="py-3 pr-3 whitespace-nowrap tabular-nums">
                    {r.dropoff_at ? clockTime(r.dropoff_at) : "—"}
                  </td>
                  <td className="py-3 pr-3">
                    {passengerNames(r)}
                    <div className="text-[11px] text-muted-foreground">
                      PU: {[r.pickup_address, ...(stopsByRide.get(r.id) ?? []).map((s) => s.address)].join(" → ")} → DO: {r.dropoff_address}
                      {r.flight_number ? ` · Flt# ${r.flight_number}` : ""}
                      {r.booking_type === "hourly"
                        ? ` · Hourly ${billableHours(r)} hr @ ${money(Number(r.hourly_rate))}/hr`
                        : ""}
                      {stopCountOf(r.id) > 0 ? ` · ${stopCountOf(r.id)} extra stop(s)` : ""}
                    </div>
                    <div className="text-[11px] text-muted-foreground">
                      Notes: {r.passenger_count ?? 0} passenger{(r.passenger_count ?? 0) === 1 ? "" : "s"} ·{" "}
                      {Number((r as any).luggage_count ?? 0)} luggage
                    </div>
                    <div className="mt-1 space-y-0.5 text-[11px] text-muted-foreground">
                      {(r.booking_type === "hourly"
                        ? [
                            {
                              label: `Other - ${money(Number(r.hourly_rate))} / hour X ${billableHours(r)} hours = ${money(hourlyCharge(r))}`,
                              amount: hourlyCharge(r),
                            },
                            ...otherBreakdownRows(r, stopCountOf(r.id)),
                          ]
                        : otherBreakdownRows(r, stopCountOf(r.id))
                      ).map((row) => (
                        <div key={row.label} className="whitespace-nowrap">{row.label}</div>
                      ))}
                    </div>
                  </td>
                  <td className="py-3 pr-3 uppercase text-muted-foreground">{r.vehicle_class}</td>
                  <td className="no-print py-3 pr-3">
                    <select
                      value={r.driver_id ?? ""}
                      onChange={(e) => setDriver.mutate({ id: r.id, driverId: e.target.value || null })}
                      className="no-print w-full rounded-md border border-border bg-background px-2 py-1 font-cond text-xs"
                      aria-label="Change driver"
                    >
                      <option value="">Unassigned</option>
                      {drivers.map((d) => (
                        <option key={d.id} value={d.id}>
                          {d.full_name}
                        </option>
                      ))}
                    </select>
                    {r.driver_id && (
                      <button
                        onClick={() => setDriver.mutate({ id: r.id, driverId: null })}
                        className="no-print mt-1 font-cond text-[10px] uppercase tracking-widest text-destructive underline underline-offset-4 hover:opacity-80"
                      >
                        Remove driver
                      </button>
                    )}
                  </td>


                  <td className="py-3 pr-3 text-right tabular-nums">{money(baseRate(r))}</td>
                  <td className="py-3 pr-3 text-right tabular-nums">
                    {r.booking_type === "hourly" ? "—" : money(flatRate(r))}
                  </td>
                  <td className="py-3 pr-3 text-right tabular-nums">
                    {r.booking_type === "hourly"
                      ? money(invoiceOthers(r, stopCountOf(r.id)) + hourlyCharge(r))
                      : money(invoiceOthers(r, stopCountOf(r.id)))}
                  </td>
                  <td className="py-3 text-right tabular-nums">{money(fareTotal(r, stopCountOf(r.id)))}</td>
                  <td className="no-print py-3 pl-3 text-right">
                    <div className="flex flex-col items-end gap-1">
                      <Link
                        to="/reservations"
                        search={{ edit: r.id }}
                        className="font-cond text-[10px] uppercase tracking-widest text-brand hover:underline"
                      >
                        Edit ride
                      </Link>
                      {(
                        <button
                          onClick={() => unlink.mutate(r.id)}
                          className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground hover:text-destructive"
                        >
                          Remove
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {trips.length === 0 && (
                <tr>
                  <td colSpan={11} className="py-6 text-center text-muted-foreground">

                    No rides on this invoice.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </section>

        <section className="mt-8 grid gap-6 pt-6 md:grid-cols-2">
          <div className="invoice-card font-cond text-sm">
            <Label>Payment methods</Label>
            <Row label="Zelle" value="917-325-3211" />
            <Row label="ACH" value="Chase Bank · Account # 507675562 · Routing # 021000021" />
            <Row label="Venmo" value="@nuwanusa" />
            <Row label="Cash App" value="$blackwavelimo" />
          </div>
          <div className="invoice-summary w-full font-cond text-sm">
            <Row label="Subtotal" value={money(subtotal)} />
            <Row label="Discount" value={money(Number(invoice.discount))} />
            <Row label="Payments" value={money(Number(invoice.payments))} />
            <div className="invoice-total mt-3 flex items-center justify-between">
              <span className="font-cond text-xs uppercase tracking-widest">Total due</span>
              <span className="font-display text-3xl">{money(totalDue)}</span>
            </div>
          </div>
        </section>

        <footer className="mt-8 border-t border-border pt-4 text-center font-cond text-sm text-muted-foreground">
          <p>Thank you for choosing BlackWave Transportation. We appreciate your business and look forward to serving you again.</p>
          <p className="mt-1">For reservations or inquiries, please contact us at info@rideblackwave.com.</p>
        </footer>
        <PayByCardLink target="invoice" id={invoice.id} amount={totalDue} paid={Boolean(invoice.paid_at)} />

      </article>
    </>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-1">
      <span className="text-muted-foreground">{label}</span>
      <span className="tabular-nums">{value}</span>
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <div className="mt-3 mb-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground first:mt-0">
      {children}
    </div>
  );
}

function EditField({
  label,
  value,
  type,
  onSave,
}: {
  label: string;
  value: string;
  type: string;
  onSave: (v: string) => void;
}) {
  const [draft, setDraft] = useState(value);
  useEffect(() => setDraft(value), [value]);
  return (
    <div>
      <div className="mb-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <input
        type={type}
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={() => draft !== value && onSave(draft)}
        className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
      />
    </div>
  );
}

function AddRidesPanel({
  rides,
  stopCountOf,
  onAdd,
  pending,
}: {
  rides: any[];
  stopCountOf: (id: string) => number;
  onAdd: (ids: string[]) => void;
  pending: boolean;
}) {
  const [picked, setPicked] = useState<string[]>([]);
  const sorted = [...rides].sort(
    (a, b) => new Date(b.pickup_at).getTime() - new Date(a.pickup_at).getTime(),
  );
  return (
    <div className="no-print mx-6 mt-4 rounded-lg border border-border bg-card p-5">
      <div className="mb-2 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
        Unbilled rides ({sorted.length})
      </div>
      <div className="max-h-72 overflow-y-auto rounded-md border border-border">
        {sorted.map((r) => (
          <label
            key={r.id}
            className="flex cursor-pointer items-center gap-3 border-b border-border px-3 py-2 font-cond text-sm last:border-0 hover:bg-surface-2/40"
          >
            <input
              type="checkbox"
              checked={picked.includes(r.id)}
              onChange={(e) =>
                setPicked((prev) => (e.target.checked ? [...prev, r.id] : prev.filter((x) => x !== r.id)))
              }
            />
            <span className="w-40 text-muted-foreground">
              {dayLabel(r.pickup_at)} · {clockTime(r.pickup_at)}
            </span>
            <span className="w-24">{r.reference}</span>
            <span className="flex-1 truncate">{r.passenger_name}</span>
            <span className="w-24 text-muted-foreground">{r.status}</span>
            <span className="tabular-nums text-brand">{money(fareTotal(r, stopCountOf(r.id)))}</span>
          </label>
        ))}
        {sorted.length === 0 && (
          <div className="px-3 py-6 text-center font-cond text-sm text-muted-foreground">
            No unbilled rides for this client.
          </div>
        )}
      </div>
      <button
        onClick={() => onAdd(picked)}
        disabled={pending || picked.length === 0}
        className="mt-4 rounded-md bg-brand px-5 py-2 font-cond text-xs uppercase tracking-widest text-brand-foreground disabled:opacity-50"
      >
        Add {picked.length} ride{picked.length === 1 ? "" : "s"}
      </button>
    </div>
  );
}
