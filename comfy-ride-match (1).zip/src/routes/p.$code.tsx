import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { resolveShortPayCode } from "@/lib/payments.functions";

export const Route = createFileRoute("/p/$code")({
  head: () => ({
    meta: [
      { title: "Payment — Blackwave Transportation LLC" },
      { name: "description", content: "Secure card payment for Blackwave Transportation." },
      { name: "robots", content: "noindex" },
    ],
  }),
  // A short code resolves to the same secure card page as the long payment link.
  loader: async ({ params }) => {
    const link = await resolveShortPayCode({ data: { code: params.code } });
    if (!link) return { invalid: true as const };
    throw redirect({
      to: "/paycard/$target/$id",
      params: { target: link.target, id: link.id },
    });
  },
  component: PayShortLinkInvalid,
});

function PayShortLinkInvalid() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-[#0b1220] px-4 text-center text-white">
      <div className="mx-auto max-w-lg rounded-2xl border border-white/10 bg-white/5 p-8">
        <h1 className="text-xl font-semibold">This payment link is not valid</h1>
        <p className="mt-2 text-sm text-white/60">
          Please contact us at info@rideblackwave.com or (917) 325-3211 and we will send you a fresh
          payment link.
        </p>
        <Link
          to="/"
          className="mt-5 inline-flex items-center rounded-lg bg-[#0b3a75] px-6 py-2.5 text-sm font-semibold text-white transition hover:bg-[#1665d8]"
        >
          Go to Blackwave
        </Link>
      </div>
    </div>
  );
}
