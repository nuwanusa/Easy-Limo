import { useEffect, useMemo, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { driversQuery, reservationsQuery, type Driver } from "@/lib/dispatch";
import { isActiveStatus } from "@/lib/driver";
import { carMarkerHtml } from "@/lib/car-marker";
import { Calendar, Car, List, Search } from "lucide-react";

export const Route = createFileRoute("/map")({
  head: () => ({
    meta: [
      { title: "Live Driver Map — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "See which Blackwave chauffeurs are online right now and where they were last located, on a live dispatch map.",
      },
      { property: "og:title", content: "Live Driver Map — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Track online chauffeurs and their last reported position from the dispatch board.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <AppShell>
      <MapPage />
    </AppShell>
  ),
});

const isFresh = (d: Driver) => {
  const seenAt = d.last_seen_at ? new Date(d.last_seen_at).getTime() : 0;
  return d.is_online && d.last_lat != null && d.last_lng != null && Date.now() - seenAt <= 90_000;
};

function MapPage() {
  const { data: drivers = [] } = useQuery({ ...driversQuery, refetchInterval: 30_000 });
  const { data: reservations = [] } = useQuery({ ...reservationsQuery, refetchInterval: 30_000 });
  const [search, setSearch] = useState("");
  const [driverFilter, setDriverFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [satellite, setSatellite] = useState(false);
  const [showList, setShowList] = useState(true);

  const online = drivers.filter(isFresh);
  const activeRides = reservations.filter((r) => isActiveStatus(r.status));
  const todayRides = reservations.filter((r) => {
    if (r.status === "cancelled") return false;
    const d = new Date(r.pickup_at);
    const now = new Date();
    return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate();
  });

  const needle = search.trim().toLowerCase();
  const shownDrivers = useMemo(
    () =>
      drivers.filter((d) => {
        if (driverFilter && d.id !== driverFilter) return false;
        if (statusFilter === "online" && !isFresh(d)) return false;
        if (statusFilter === "offline" && isFresh(d)) return false;
        if (needle && !d.full_name?.toLowerCase().includes(needle)) return false;
        return true;
      }),
    [drivers, driverFilter, statusFilter, needle],
  );

  const ref = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const layerRef = useRef<any>(null);
  const tilesRef = useRef<any>(null);
  const leafletRef = useRef<any>(null);
  const markersDrivers = driverFilter ? shownDrivers.filter(isFresh) : online.filter((d) => shownDrivers.some((s) => s.id === d.id));
  const points = markersDrivers
    .map((d) => `${d.id}:${d.last_lat},${d.last_lng}`)
    .sort()
    .join("|");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const L = (await import("leaflet")).default;
      await import("leaflet/dist/leaflet.css");
      if (cancelled || !ref.current) return;
      leafletRef.current = L;

      if (!mapRef.current) {
        mapRef.current = L.map(ref.current, { zoomControl: true }).setView([40.5795, -74.1502], 10);
        tilesRef.current = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          maxZoom: 19,
          attribution: "© OpenStreetMap",
        }).addTo(mapRef.current);
      }

      layerRef.current?.remove();
      layerRef.current = L.layerGroup().addTo(mapRef.current);

      const latLngs: [number, number][] = [];
      markersDrivers.forEach((d) => {
        const pos: [number, number] = [Number(d.last_lat), Number(d.last_lng)];
        latLngs.push(pos);
        L.marker(pos, {
          icon: L.divIcon({
            className: "",
            html: carMarkerHtml(d.full_name),
            iconSize: [120, 46],
            iconAnchor: [60, 30],
          }),
        })
          .bindTooltip(d.full_name, { direction: "top" })
          .addTo(layerRef.current);
      });

      if (latLngs.length === 1) mapRef.current.setView(latLngs[0]!, 13);
      else if (latLngs.length > 1) mapRef.current.fitBounds(latLngs, { padding: [40, 40] });
      setTimeout(() => mapRef.current?.invalidateSize(), 100);
    })().catch(() => undefined);
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [points]);

  useEffect(() => {
    const L = leafletRef.current;
    if (!L || !mapRef.current) return;
    tilesRef.current?.remove();
    tilesRef.current = satellite
      ? L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
          maxZoom: 19,
          attribution: "© Esri",
        }).addTo(mapRef.current)
      : L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          maxZoom: 19,
          attribution: "© OpenStreetMap",
        }).addTo(mapRef.current);
  }, [satellite]);

  const locate = (d: Driver) => {
    if (d.last_lat != null && d.last_lng != null && mapRef.current) {
      mapRef.current.setView([Number(d.last_lat), Number(d.last_lng)], 14);
    }
  };

  return (
    <div className="min-h-screen bg-dashboard-canvas px-3 pb-10 pt-5 font-admin-body sm:px-5">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-dashboard-blue">Dispatch</p>
          <h1 className="font-admin-display text-3xl font-bold text-dashboard-navy sm:text-4xl">Live Map</h1>
          <p className="mt-1 text-sm text-dashboard-muted">Track your drivers in real time and manage active rides across the region.</p>
        </div>
        <div className="grid flex-1 grid-cols-2 gap-3 sm:grid-cols-4 lg:max-w-3xl">
          <MapStat icon={<span className="size-3 rounded-full bg-dashboard-green" />} label="Online drivers" value={online.length.toString()} note={`${drivers.length} on roster`} />
          <MapStat icon={<span className="size-3 rounded-full bg-dashboard-muted" />} label="Offline drivers" value={(drivers.length - online.length).toString()} note={`${drivers.length} on roster`} />
          <MapStat icon={<Car className="size-5" />} label="Active rides" value={activeRides.length.toString()} note="Currently in progress" />
          <MapStat icon={<Calendar className="size-5" />} label="Today's rides" value={todayRides.length.toString()} note="Scheduled" />
        </div>
      </header>

      <section className="mt-4 flex flex-wrap items-center gap-2 rounded-md border border-dashboard-line bg-card p-3 shadow-sm">
        <div className="relative min-w-52 flex-1">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-dashboard-muted" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search address, airport, zone, or driver…"
            className="h-10 w-full rounded-md border border-dashboard-line bg-background pl-9 pr-3 text-sm outline-none focus:border-dashboard-blue"
          />
        </div>
        <select value={driverFilter} onChange={(e) => setDriverFilter(e.target.value)} className="h-10 rounded-md border border-dashboard-line bg-background px-3 text-sm" aria-label="Filter by driver">
          <option value="">All Drivers</option>
          {drivers.map((d) => (
            <option key={d.id} value={d.id}>{d.full_name}</option>
          ))}
        </select>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="h-10 rounded-md border border-dashboard-line bg-background px-3 text-sm" aria-label="Filter by status">
          <option value="">All Statuses</option>
          <option value="online">Online</option>
          <option value="offline">Offline</option>
        </select>
        <Button variant={showList ? "default" : "outline"} onClick={() => setShowList((v) => !v)}>
          <List /> View List
        </Button>
      </section>

      <div className={`mt-4 grid gap-4 ${showList ? "lg:grid-cols-[1fr_320px]" : ""}`}>
        <div className="relative overflow-hidden rounded-md border border-dashboard-line bg-card shadow-sm">
          <div ref={ref} className="h-[62vh] min-h-[380px] w-full" />
          <div className="absolute right-3 top-3 z-[500] flex overflow-hidden rounded-md border border-dashboard-line bg-card shadow-sm">
            <button type="button" onClick={() => setSatellite(false)} className={`px-3 py-1.5 text-xs font-bold ${!satellite ? "bg-dashboard-blue text-white" : "text-dashboard-navy"}`}>Map</button>
            <button type="button" onClick={() => setSatellite(true)} className={`px-3 py-1.5 text-xs font-bold ${satellite ? "bg-dashboard-blue text-white" : "text-dashboard-navy"}`}>Satellite</button>
          </div>
        </div>

        {showList && (
          <div className="overflow-hidden rounded-md border border-dashboard-line bg-card shadow-sm">
            <div className="flex items-center justify-between border-b border-dashboard-line px-4 py-3">
              <h2 className="font-admin-display text-base font-bold text-dashboard-navy">Drivers ({shownDrivers.length})</h2>
              <span className="flex items-center gap-1.5 text-xs font-semibold text-dashboard-muted">
                <span className="size-2 rounded-full bg-dashboard-green" /> {online.length} Online
              </span>
            </div>
            <ul className="divide-y divide-dashboard-line">
              {shownDrivers.map((d: Driver) => {
                const fresh = isFresh(d);
                return (
                  <li key={d.id} className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <span className={`size-2.5 shrink-0 rounded-full ${fresh ? "bg-dashboard-green" : "bg-dashboard-muted/50"}`} />
                      <span className="min-w-0 flex-1 truncate text-sm font-bold uppercase text-dashboard-navy">{d.full_name}</span>
                      {d.last_lat != null && d.last_lng != null && (
                        <Button variant="outline" size="sm" onClick={() => locate(d)} className="h-7 px-2 text-[10px] font-bold uppercase">
                          Locate
                        </Button>
                      )}
                    </div>
                    <div className="mt-1 flex items-center gap-1.5 pl-4 text-xs text-dashboard-muted">
                      <Car className="size-3.5" />
                      {fresh ? "Online" : "Offline"}
                      {d.last_seen_at ? ` · ${new Date(d.last_seen_at).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}` : ""}
                      {d.is_online && (d.last_lat == null || d.last_lng == null) ? " · Location not shared" : ""}
                    </div>
                    <div className="mt-1.5 pl-4">
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${d.status === "off_duty" ? "bg-dashboard-soft text-dashboard-muted" : "bg-dashboard-ice text-dashboard-blue"}`}>
                        {d.status === "off_duty" ? "Off Duty" : d.status === "on_trip" ? "On Trip" : "On Duty"}
                      </span>
                    </div>
                  </li>
                );
              })}
              {shownDrivers.length === 0 && (
                <li className="px-4 py-8 text-center text-sm text-dashboard-muted">No drivers match these filters.</li>
              )}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}

function MapStat({ icon, label, value, note }: { icon: React.ReactNode; label: string; value: string; note: string }) {
  return (
    <div className="flex items-center gap-3 rounded-md border border-dashboard-line bg-card p-3 shadow-sm">
      <span className="grid size-10 shrink-0 place-items-center rounded-full bg-dashboard-ice text-dashboard-blue [&>svg]:size-5">{icon}</span>
      <div className="min-w-0">
        <p className="truncate text-[9px] font-bold uppercase tracking-wider text-dashboard-muted">{label}</p>
        <p className="font-admin-display text-xl font-bold text-dashboard-navy">{value}</p>
        <p className="truncate text-[10px] text-dashboard-muted">{note}</p>
      </div>
    </div>
  );
}
