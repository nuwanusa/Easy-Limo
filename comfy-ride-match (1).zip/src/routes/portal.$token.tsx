import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getPortalByToken } from "@/lib/client-portal.functions";
import { PortalView } from "@/components/PortalView";
import { BrandLogo } from "@/components/BrandLogo";

export const Route = createFileRoute("/portal/$token")({
  head: () => ({
    meta: [
      { title: "Your Billing Statements — Blackwave Transportation LLC" },
      {
        name: "description",
        content: "Private invoice link: review every Blackwave Transportation ride, its charges, and pay online.",
      },
      { property: "og:title", content: "Your Billing Statements — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Paid and unpaid invoices with full ride detail.",
      },
      { property: "og:type", content: "website" },
      { name: "robots", content: "noindex" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TokenPortalPage,
});

function TokenPortalPage() {
  const { token } = Route.useParams();
  const fetchPortal = useServerFn(getPortalByToken);

  const query = useQuery({
    queryKey: ["client-portal", token],
    queryFn: () => fetchPortal({ data: { token } }),
  });

  return (
    <div className="min-h-screen bg-portal-mist text-portal-ink">
      <header className="relative z-[700] h-[65px] border-b border-portal-line bg-portal-panel">
        <div className="flex h-full items-center gap-3 px-4 sm:px-6">
          <BrandLogo className="size-10" />
          <div>
            <div className="font-portal-display text-base font-bold leading-none text-portal-ink">Blackwave Transportation</div>
            <div className="mt-1 font-portal-body text-[9px] font-bold uppercase tracking-widest text-portal-muted">Live client portal</div>
          </div>
        </div>
      </header>

      {query.isLoading ? (
        <p className="py-20 text-center font-cond text-xs uppercase tracking-[0.4em] text-muted-foreground">
          Loading invoices
        </p>
      ) : query.error ? (
        <p className="py-20 text-center text-sm text-destructive">
          {query.error instanceof Error ? query.error.message : "This link is no longer valid"}
        </p>
      ) : query.data ? (
        <PortalView data={query.data} auth={{ token }} />
      ) : null}
    </div>
  );
}
