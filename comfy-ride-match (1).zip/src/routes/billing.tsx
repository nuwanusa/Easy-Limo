import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  AlarmClock,
  BarChart3,
  CalendarDays,
  CarFront,
  Check,
  Clock3,
  Crown,
  DollarSign,
  Phone,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { getCompanyBilling, listPlans, setWakeUpAddon } from "@/lib/subscriptions.functions";

export const Route = createFileRoute("/billing")({
  head: () => ({
    meta: [
      { title: "Subscription & Billing — Blackwave" },
      {
        name: "description",
        content:
          "Your company plan, the automatic chauffeur wake-up call add-on, and this month's call usage and charges.",
      },
      { property: "og:title", content: "Subscription & Billing — Blackwave" },
      {
        property: "og:description",
        content: "Manage your plan and the chauffeur wake-up call add-on.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <AppShell>
      <BillingPage />
    </AppShell>
  ),
});

const money = (cents: number) =>
  (cents / 100).toLocaleString("en-US", { style: "currency", currency: "USD" });

const monthLabel = new Intl.DateTimeFormat("en-US", { month: "long", year: "numeric" }).format(
  new Date(),
);

const planIcon = {
  starter: CarFront,
  pro: BarChart3,
  elite: Crown,
} as const;

function BillingPage() {
  const qc = useQueryClient();
  const plansFn = useServerFn(listPlans);
  const billingFn = useServerFn(getCompanyBilling);
  const addonFn = useServerFn(setWakeUpAddon);

  const plans = useQuery({ queryKey: ["plans"], queryFn: () => plansFn() });
  const billing = useQuery({ queryKey: ["company-billing"], queryFn: () => billingFn() });

  const toggle = useMutation({
    mutationFn: (enabled: boolean) => addonFn({ data: { enabled } }),
    onSuccess: (r) => {
      toast.success(r.enabled ? "Wake-up calls switched on" : "Wake-up calls switched off");
      qc.invalidateQueries({ queryKey: ["company-billing"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const b = billing.data;
  const currentPlan = b?.plan;

  return (
    <div className="min-h-screen bg-dashboard-canvas px-3 py-5 font-admin-body sm:px-5 lg:px-7">
      <header className="mb-4 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="mb-1 text-xs font-bold uppercase tracking-[0.22em] text-dashboard-blue">Your plan</p>
          <h1 className="font-admin-display text-3xl font-bold text-dashboard-navy sm:text-4xl">Subscription</h1>
          <p className="mt-1 text-sm text-dashboard-muted">Manage your plan, add-ons, and usage for this month.</p>
        </div>
        <div className="flex min-w-64 items-center gap-3 rounded-md border border-dashboard-blue/25 bg-background px-4 py-3 shadow-sm">
          <div className="grid size-11 shrink-0 place-items-center rounded-md bg-dashboard-ice text-dashboard-blue">
            <Crown className="size-6" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs text-dashboard-muted">Current plan</p>
            <p className="font-admin-display text-base font-bold text-dashboard-navy">{currentPlan?.name ?? "No plan"}</p>
            <p className="text-xs text-dashboard-muted">{currentPlan ? `${money(currentPlan.priceCents)} / month` : "Contact your platform owner"}</p>
          </div>
          {b?.status && b.status !== "none" && (
            <span className="rounded-full bg-dashboard-blue px-2.5 py-1 text-[10px] font-bold uppercase text-primary-foreground">
              {b.status}
            </span>
          )}
        </div>
      </header>

      <section className="grid gap-3 lg:grid-cols-3" aria-label="Subscription plans">
        {(plans.data ?? []).map((plan) => {
          const current = b?.plan?.code === plan.code;
          const Icon = planIcon[plan.code as keyof typeof planIcon] ?? BarChart3;
          const elite = plan.code === "elite";
          return (
            <article
              key={plan.code}
              className={`flex min-h-64 flex-col rounded-md border bg-background p-4 shadow-sm ${current ? "border-dashboard-blue ring-1 ring-dashboard-blue/20" : "border-dashboard-line"}`}
            >
              <div className="flex items-start gap-4">
                <div className={`grid size-12 shrink-0 place-items-center rounded-md ${elite ? "bg-dashboard-amber/12 text-dashboard-amber" : "bg-dashboard-ice text-dashboard-blue"}`}>
                  <Icon className="size-6" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <h2 className="font-admin-display text-lg font-bold text-dashboard-navy">{plan.name}</h2>
                    {current && <span className="rounded-full bg-dashboard-blue px-3 py-1 text-[10px] font-bold uppercase text-primary-foreground">Current</span>}
                  </div>
                  <p className="mt-0.5 font-admin-display text-2xl font-bold text-dashboard-blue">
                    {money(plan.priceCents)} <span className="font-admin-body text-xs font-medium text-dashboard-muted">/ month</span>
                  </p>
                  <ul className="mt-4 space-y-2">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-2 text-sm text-dashboard-muted">
                        <span className="mt-0.5 grid size-4 shrink-0 place-items-center rounded-full bg-dashboard-blue text-primary-foreground"><Check className="size-2.5" /></span>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              <div className="mt-auto pt-4">
                <Button type="button" variant={current ? "outline" : "default"} className="w-full" disabled>
                  {current ? "Current plan" : `Upgrade to ${plan.name}`}
                </Button>
              </div>
            </article>
          );
        })}
      </section>

      <section className="mt-3 rounded-md border border-dashboard-line bg-background p-4 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex min-w-0 items-start gap-3">
            <div className="grid size-11 shrink-0 place-items-center rounded-md bg-dashboard-ice text-dashboard-blue"><AlarmClock className="size-6" /></div>
            <div>
              <h2 className="font-admin-display text-base font-bold text-dashboard-navy">Chauffeur Wake-Up Calls</h2>
              <p className="max-w-4xl text-xs leading-relaxed text-dashboard-muted">Automatic phone call two hours before any pickup earlier than 7 AM. Repeats every 10 minutes, up to three times, until the chauffeur presses 1 to confirm.</p>
            </div>
          </div>
          <Button
            type="button"
            onClick={() => toggle.mutate(!b?.wakeUpEnabled)}
            disabled={toggle.isPending || !b}
            variant={b?.wakeUpEnabled ? "secondary" : "default"}
            className={b?.wakeUpEnabled ? "text-dashboard-green" : ""}
          >
            <span className={`h-5 w-9 rounded-full p-0.5 ${b?.wakeUpEnabled ? "bg-dashboard-blue" : "bg-dashboard-muted/30"}`}><span className={`block size-4 rounded-full bg-background transition-transform ${b?.wakeUpEnabled ? "translate-x-4" : ""}`} /></span>
            {toggle.isPending ? "Updating…" : b?.wakeUpEnabled ? "Turned on" : "Turn on"}
          </Button>
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-4">
          <Stat icon={Phone} label="Add-on cost" value={b ? `${money(b.wakeUpMonthlyCents)} / month` : "—"} tone="blue" />
          <Stat icon={Phone} label="Per call" value={b ? money(b.wakeUpPerCallCents) : "—"} tone="green" />
          <Stat icon={CalendarDays} label="Calls this month" value={b ? String(b.monthCalls) : "—"} tone="blue" />
          <Stat icon={DollarSign} label="Estimated this month" value={b ? money(b.monthTotalCents) : "—"} tone="violet" />
        </div>
      </section>

      <section className="mt-3 rounded-md border border-dashboard-line bg-background p-4 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Clock3 className="size-5 text-dashboard-navy" />
            <div>
              <h2 className="font-admin-display text-base font-bold text-dashboard-navy">Recent Wake-Up Calls</h2>
              <p className="text-xs text-dashboard-muted">The most recent automatic wake-up calls sent to chauffeurs.</p>
            </div>
          </div>
          <div className="flex h-9 items-center gap-2 rounded-md border border-dashboard-line px-3 text-xs font-semibold text-dashboard-navy"><CalendarDays className="size-4" />{monthLabel}</div>
        </div>
        {b && b.recent.length > 0 ? (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full min-w-[720px] text-sm">
              <thead className="bg-dashboard-ice text-left text-[10px] font-bold uppercase text-dashboard-muted">
                <tr>
                  <th className="px-3 py-2.5">Date</th><th className="px-3 py-2.5">Time</th><th className="px-3 py-2.5">Ride</th><th className="px-3 py-2.5">Chauffeur</th><th className="px-3 py-2.5">Status</th><th className="px-3 py-2.5">Attempts</th><th className="px-3 py-2.5 text-right">Charge</th>
                </tr>
              </thead>
              <tbody>
                {b.recent.map((r) => {
                  const created = new Date(r.createdAt);
                  return <tr key={r.id} className="border-t border-dashboard-line text-dashboard-navy"><td className="px-3 py-3">{created.toLocaleDateString("en-US")}</td><td className="px-3 py-3">{created.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}</td><td className="px-3 py-3 font-semibold">{r.reference || "—"}</td><td className="px-3 py-3">{r.driver || "—"}</td><td className="px-3 py-3 capitalize">{r.status}</td><td className="px-3 py-3">{r.attempts}</td><td className="px-3 py-3 text-right tabular-nums">{money(r.chargeCents)}</td></tr>;
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="mt-4">
            <div className="hidden grid-cols-6 bg-dashboard-ice px-3 py-2.5 text-[10px] font-bold uppercase text-dashboard-muted sm:grid"><span>Date</span><span>Time</span><span>Chauffeur</span><span>Ride</span><span>Attempts</span><span>Status</span></div>
            <div className="grid min-h-24 place-items-center px-4 py-6 text-center"><div><Phone className="mx-auto mb-2 size-5 text-dashboard-muted" /><p className="text-sm font-semibold text-dashboard-navy">No wake-up calls yet this month.</p><p className="text-xs text-dashboard-muted">Calls will appear here when they are sent to chauffeurs.</p></div></div>
          </div>
        )}
      </section>
    </div>
  );
}

function Stat({ icon: Icon, label, value, tone }: { icon: typeof Phone; label: string; value: string; tone: "blue" | "green" | "violet" }) {
  const toneClass = tone === "green" ? "bg-dashboard-green/10 text-dashboard-green" : tone === "violet" ? "bg-primary/8 text-primary" : "bg-dashboard-ice text-dashboard-blue";
  return (
    <div className="flex min-w-0 items-center gap-3 rounded-md border border-dashboard-line bg-dashboard-canvas/40 p-3">
      <div className={`grid size-10 shrink-0 place-items-center rounded-md ${toneClass}`}><Icon className="size-5" /></div>
      <div className="min-w-0"><div className="text-[10px] font-bold uppercase text-dashboard-muted">{label}</div><div className="truncate text-base font-bold tabular-nums text-dashboard-blue">{value}</div></div>
    </div>
  );
}
