import { useEffect, useMemo, useState, type ReactNode } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowRight, CalendarDays, Car, CircleDollarSign, Clock3, FileText, Mail,
  MapPin, MessageSquare, Plus, ReceiptText, UserPlus,
  Users, Wallet,
} from "lucide-react";
import { AppShell, StatusChip } from "@/components/AppShell";
import { MiniLiveMap } from "@/components/MiniLiveMap";
import { Button } from "@/components/ui/button";
import { useSession } from "@/lib/auth";
import {
  clockTime, driversQuery, fareTotal, invoicesQuery, money, reservationsQuery,
  stopsQuery, type Driver, type Reservation,
} from "@/lib/dispatch";
import { isActiveStatus } from "@/lib/trip-status";

export const Route = createFileRoute("/dashboard")({
  head: () => ({ meta: [
    { title: "Dispatcher Home — Blackwave Transportation LLC" },
    { name: "description", content: "Blackwave dispatch reservations, schedules, drivers, revenue, alerts, and live fleet positions." },
    { property: "og:title", content: "Dispatcher Home — Blackwave Transportation LLC" },
    { property: "og:description", content: "Manage Blackwave rides, drivers, billing, and live fleet activity." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: () => <AppShell><DispatcherHome /></AppShell>,
});

const keyOf = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
const sameDay = (value: string | null | undefined, date: Date) => Boolean(value && keyOf(new Date(value)) === keyOf(date));
const messageTime = (value: string) => {
  const date = new Date(value);
  return sameDay(value, new Date())
    ? date.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })
    : date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
};

function DispatcherHome() {
  const { data: reservations = [] } = useQuery(reservationsQuery);
  const { data: drivers = [] } = useQuery(driversQuery);
  const { data: stops = [] } = useQuery(stopsQuery);
  const { data: invoices = [] } = useQuery(invoicesQuery);
  const { user } = useSession();
  const [now, setNow] = useState(() => new Date());
  const [rideTab, setRideTab] = useState<"today" | "tomorrow" | "upcoming">("today");

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 60_000);
    return () => window.clearInterval(timer);
  }, []);

  const tomorrow = useMemo(() => {
    const value = new Date(now);
    value.setDate(value.getDate() + 1);
    return value;
  }, [now]);
  const future = useMemo(() => reservations.filter((ride) =>
    !["completed", "cancelled"].includes(ride.status) && new Date(ride.pickup_at).getTime() >= new Date(now).setHours(0, 0, 0, 0),
  ).sort((a, b) => a.pickup_at.localeCompare(b.pickup_at)), [reservations, now]);
  const todayRides = future.filter((ride) => sameDay(ride.pickup_at, now));
  const tomorrowRides = future.filter((ride) => sameDay(ride.pickup_at, tomorrow));
  const shownRides = rideTab === "today" ? todayRides : rideTab === "tomorrow" ? tomorrowRides : future;

  const week = useMemo(() => {
    const start = new Date(now);
    start.setDate(start.getDate() - start.getDay());
    start.setHours(0, 0, 0, 0);
    const end = new Date(start);
    end.setDate(end.getDate() + 7);
    const rides = reservations.filter((ride) => ride.status !== "cancelled" && new Date(ride.pickup_at) >= start && new Date(ride.pickup_at) < end);
    return { start, end, rides, value: rides.reduce((sum, ride) => sum + fareTotal(ride, stops.filter((stop) => stop.reservation_id === ride.id).length), 0) };
  }, [now, reservations, stops]);

  const unpaid = invoices.filter((invoice) => !invoice.paid_at);
  const unpaidValue = unpaid.reduce((sum, invoice) => {
    const related = reservations.filter((ride) => ride.invoice_id === invoice.id);
    return sum + Math.max(0, related.reduce((amount, ride) => amount + fareTotal(ride, stops.filter((stop) => stop.reservation_id === ride.id).length), 0) - Number(invoice.payments));
  }, 0);
  const todayRevenue = invoices.filter((invoice) => sameDay(invoice.paid_at ?? invoice.updated_at, now)).reduce((sum, invoice) => sum + Number(invoice.payments), 0);
  const unassigned = future.filter((ride) => !ride.driver_id || ride.status === "unassigned");
  const firstName = ((user?.user_metadata?.["full_name"] as string | undefined) ?? user?.email?.split("@")[0] ?? "Dispatcher").split(/[\s._-]+/)[0] ?? "Dispatcher";
  const greeting = now.getHours() < 12 ? "Good morning" : now.getHours() < 17 ? "Good afternoon" : "Good evening";

  return (
    <div className="min-h-[calc(100vh-3.5rem)] bg-dashboard-canvas p-3 sm:p-5">
      <div className="mx-auto max-w-[1680px] space-y-3">
        <header className="flex flex-wrap items-end justify-between gap-3 px-1 py-1">
          <div>
            <h1 className="font-admin-display text-2xl font-bold text-dashboard-navy sm:text-3xl">{greeting}, {firstName}!</h1>
            <p className="text-sm text-dashboard-muted">Here&apos;s what&apos;s happening with your business today.</p>
          </div>
          <div className="text-right text-xs font-medium leading-5 text-dashboard-muted">
            <p>{now.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}</p>
            <p className="tabular-nums">{now.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })}</p>
          </div>
        </header>

        <section className="grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-6">
          <Metric icon={<CalendarDays />} tone="neutral" label="Today" value={todayRides.length} note={todayRides.length === 1 ? "Ride" : "Rides"} />
          <Metric icon={<CalendarDays />} tone="blue" label="Upcoming" value={future.length} note={future.length === 1 ? "Ride" : "Rides"} />
          <Metric icon={<Users />} tone="amber" label="Unassigned" value={unassigned.length} note={unassigned.length === 1 ? "Ride" : "Rides"} />
          <Metric icon={<ReceiptText />} tone="red" label="Unpaid invoices" value={unpaid.length} note={money(unpaidValue)} />
          <Metric icon={<CircleDollarSign />} tone="green" label="Today’s revenue" value={money(todayRevenue)} note={`${invoices.filter((invoice) => sameDay(invoice.paid_at, now)).length} paid`} />
          <Metric icon={<Wallet />} tone="blue" label="This week" value={money(week.value)} note={`${week.rides.length} rides`} />
        </section>

        <section className="grid gap-3 xl:grid-cols-[minmax(0,1.8fr)_minmax(260px,.9fr)_minmax(270px,.95fr)]">
          <Panel className="min-w-0" title="Today’s rides" subtitle={now.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })} action={
            <Button asChild size="sm" className="bg-dashboard-sidebar hover:bg-dashboard-blue"><Link to="/reservations" search={{ new: "1" }}><Plus /> New reservation</Link></Button>
          }>
            <div className="flex items-center gap-5 border-b border-dashboard-line px-4 pt-1">
              {(["today", "tomorrow", "upcoming"] as const).map((tab) => {
                const count = tab === "today" ? todayRides.length : tab === "tomorrow" ? tomorrowRides.length : future.length;
                return <button key={tab} onClick={() => setRideTab(tab)} className={`border-b-2 py-2 text-xs font-semibold capitalize ${rideTab === tab ? "border-dashboard-blue text-dashboard-blue" : "border-transparent text-dashboard-muted"}`}>{tab} ({count})</button>;
              })}
            </div>
            <div className="max-h-[390px] divide-y divide-dashboard-line overflow-y-auto">
              {shownRides.slice(0, 8).map((ride) => <RideRow key={ride.id} ride={ride} driver={drivers.find((driver) => driver.id === ride.driver_id)} stops={stops.filter((stop) => stop.reservation_id === ride.id).length} />)}
              {shownRides.length === 0 && <Empty icon={<CalendarDays />} text={`No ${rideTab} reservations.`} />}
            </div>
          </Panel>

          <Panel title="Quick actions">
            <div className="grid grid-cols-2 gap-2 p-3">
              <QuickAction icon={<CalendarDays />} label="New reservation" to="/reservations" search={{ new: "1" }} primary />
              <QuickAction icon={<UserPlus />} label="Add new client" to="/clients" />
              <QuickAction icon={<Users />} label="Add driver" to="/drivers" />
              <QuickAction icon={<FileText />} label="Create invoice" to="/invoices" />
              <QuickAction icon={<Wallet />} label="Pay driver" to="/pay" />
              <QuickAction icon={<CalendarDays />} label="View calendar" to="/reservations" />
            </div>
          </Panel>

          <Panel title="Action needed" badge={unpaid.length + unassigned.length}>
            <AlertRow icon={<ReceiptText />} tone="red" title={`${unpaid.length} unpaid invoices`} detail={`Total amount: ${money(unpaidValue)}`} to="/invoices" />
            <AlertRow icon={<Users />} tone="amber" title={`${unassigned.length} unassigned ${unassigned.length === 1 ? "ride" : "rides"}`} detail="Needs driver assignment" to="/reservations" />
            <AlertRow icon={<Car />} tone="neutral" title={`${drivers.filter((driver) => driver.is_online).length} drivers online`} detail={`${drivers.length} chauffeurs on roster`} to="/drivers" />
            <AlertRow icon={<Mail />} tone="blue" title="Email inbox" detail="Read and reply to messages" to="/inbox" />
          </Panel>
        </section>

        <section className="grid items-start gap-3 xl:grid-cols-[1.55fr_1fr]">
          <div className="grid min-w-0 gap-3">
            <SevenDaySchedule rides={future} now={now} />
            <PastSevenDays rides={reservations} now={now} />
            <DriverStatus drivers={drivers} rides={reservations} now={now} />
          </div>
          <div className="grid min-w-0 gap-3">
            <Panel title="Today’s map" action={<Link to="/map" className="flex items-center gap-1 text-xs font-semibold text-dashboard-blue">View full map <ArrowRight className="size-3.5" /></Link>}>
              <div className="p-2"><MiniLiveMap heightClass="h-[190px]" /></div>
            </Panel>
            <RecentActivity reservations={reservations} invoices={invoices} />
          </div>
        </section>
      </div>
    </div>
  );
}

function Panel({ title, subtitle, action, badge, className = "", children }: { title: string; subtitle?: string; action?: ReactNode; badge?: number; className?: string; children: ReactNode }) {
  return <section className={`overflow-hidden rounded-md border border-dashboard-line bg-card shadow-sm ${className}`}>
    <header className="flex min-h-12 items-center justify-between gap-3 border-b border-dashboard-line px-4 py-2.5">
      <div><h2 className="font-admin-display text-base font-bold text-dashboard-navy">{title}</h2>{subtitle && <p className="text-[11px] text-dashboard-muted">{subtitle}</p>}</div>
      {badge != null && badge > 0 ? <span className="grid size-6 place-items-center rounded-full bg-dashboard-red text-xs font-bold text-primary-foreground">{badge}</span> : action}
    </header>{children}
  </section>;
}

const metricStyles = {
  neutral: "bg-dashboard-soft text-dashboard-navy",
  blue: "bg-dashboard-ice text-dashboard-blue",
  amber: "bg-warning/12 text-dashboard-amber",
  red: "bg-destructive/10 text-dashboard-red",
  green: "bg-success/10 text-dashboard-green",
};
function Metric({ icon, tone, label, value, note }: { icon: ReactNode; tone: keyof typeof metricStyles; label: string; value: string | number; note: string }) {
  return <div className="flex min-h-24 items-center gap-3 rounded-md border border-dashboard-line bg-card p-3 shadow-sm">
    <span className={`grid size-10 shrink-0 place-items-center rounded-md [&>svg]:size-5 ${metricStyles[tone]}`}>{icon}</span>
    <div className="min-w-0"><p className="truncate text-[10px] font-bold uppercase text-dashboard-muted">{label}</p><p className="truncate font-admin-display text-xl font-bold tabular-nums text-dashboard-navy">{value}</p><p className="truncate text-[10px] text-dashboard-muted">{note}</p></div>
  </div>;
}

function RideRow({ ride, driver, stops }: { ride: Reservation; driver: Driver | undefined; stops: number }) {
  const pickup = new Date(ride.pickup_at);
  return <div className="p-3 sm:p-4">
    <div className="flex gap-3">
      <div className="w-12 shrink-0 rounded-md bg-dashboard-ice py-2 text-center"><p className="text-[9px] font-bold uppercase text-dashboard-blue">{pickup.toLocaleDateString("en-US", { month: "short" })}</p><p className="font-admin-display text-xl font-bold leading-none text-dashboard-navy">{pickup.getDate()}</p><p className="mt-1 text-[8px] uppercase text-dashboard-muted">{pickup.toLocaleDateString("en-US", { weekday: "short" })}</p></div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2"><span className="text-sm font-bold text-dashboard-navy">{clockTime(ride.pickup_at)}</span><StatusChip status={ride.status} /><span className="ml-auto font-admin-display text-base font-bold text-dashboard-navy">{money(fareTotal(ride, stops))}</span></div>
        <p className="mt-1 font-semibold text-dashboard-navy">{ride.passenger_name}</p>
        <p className="mt-1 flex items-center gap-1.5 truncate text-xs text-dashboard-muted"><MapPin className="size-3 shrink-0" />{ride.pickup_address}</p>
        <p className="mt-1 flex items-center gap-1.5 truncate text-xs text-dashboard-muted"><ArrowRight className="size-3 shrink-0" />{ride.dropoff_address || "Hourly / as directed"}</p>
        <p className="mt-1 flex items-center gap-1.5 text-[10px] text-dashboard-muted"><Car className="size-3" />{ride.vehicle_class} · Driver: {driver?.full_name ?? "Unassigned"}{ride.flight_number ? ` · ${ride.airline ?? "Flight"} ${ride.flight_number}` : ""}</p>
      </div>
    </div>
    <div className="mt-3 flex flex-wrap gap-2 border-t border-dashboard-line pt-3">
      <Button asChild variant="outline" size="sm"><Link to="/rides/$id" params={{ id: ride.id }}>View</Link></Button>
      <Button asChild variant="outline" size="sm"><Link to="/reservations" search={{ edit: ride.id }}>Edit</Link></Button>
      <Button asChild variant="outline" size="sm"><Link to="/map"><MapPin /> Dispatch</Link></Button>
      <Button asChild variant="outline" size="sm"><Link to="/inbox" search={{ client: undefined, folder: undefined, compose: "1", open: undefined }}><MessageSquare /> Message</Link></Button>
    </div>
  </div>;
}

function QuickAction({ icon, label, to, search, primary = false }: { icon: ReactNode; label: string; to: "/reservations" | "/clients" | "/drivers" | "/invoices" | "/pay"; search?: { new: string }; primary?: boolean }) {
  return <Link to={to} search={search as never} className={`grid min-h-20 place-items-center gap-1 rounded-md border p-2 text-center text-[11px] font-semibold transition-colors ${primary ? "border-dashboard-sidebar bg-dashboard-sidebar text-primary-foreground hover:bg-dashboard-blue" : "border-dashboard-line text-dashboard-navy hover:border-dashboard-blue hover:bg-dashboard-ice"}`}><span className="[&>svg]:size-5">{icon}</span>{label}</Link>;
}

function AlertRow({ icon, tone, title, detail, to }: { icon: ReactNode; tone: keyof typeof metricStyles; title: string; detail: string; to: "/invoices" | "/reservations" | "/drivers" | "/inbox" }) {
  return <Link to={to} className="flex items-center gap-3 border-b border-dashboard-line px-4 py-3 last:border-0 hover:bg-dashboard-canvas"><span className={`grid size-8 shrink-0 place-items-center rounded-md [&>svg]:size-4 ${metricStyles[tone]}`}>{icon}</span><span className="min-w-0 flex-1"><span className="block truncate text-xs font-semibold text-dashboard-navy">{title}</span><span className="block truncate text-[10px] text-dashboard-muted">{detail}</span></span><ArrowRight className="size-3.5 text-dashboard-muted" /></Link>;
}

function SevenDaySchedule({ rides, now }: { rides: Reservation[]; now: Date }) {
  const days = Array.from({ length: 7 }, (_, index) => { const day = new Date(now); day.setHours(0, 0, 0, 0); day.setDate(day.getDate() - day.getDay() + index); return day; });
  return <Panel title="7-day schedule" action={<Link to="/reservations" className="flex items-center gap-1 text-xs font-semibold text-dashboard-blue">View calendar <ArrowRight className="size-3.5" /></Link>}>
    <div className="grid grid-cols-7 p-2">{days.map((day) => { const count = rides.filter((ride) => sameDay(ride.pickup_at, day)).length; const active = sameDay(day.toISOString(), now); return <div key={day.toISOString()} className={`min-h-24 border-y border-l border-dashboard-line px-1 py-3 text-center last:border-r ${active ? "bg-dashboard-ice" : "bg-card"}`}><p className="text-[9px] font-bold uppercase text-dashboard-muted">{day.toLocaleDateString("en-US", { weekday: "short" })}</p><p className={`mt-1 text-xs font-semibold ${active ? "text-dashboard-blue" : "text-dashboard-muted"}`}>{day.toLocaleDateString("en-US", { month: "short", day: "numeric" })}</p><p className="mt-3 text-xs font-bold text-dashboard-navy">{count} {count === 1 ? "ride" : "rides"}</p></div>; })}</div>
  </Panel>;
}

function PastSevenDays({ rides, now }: { rides: Reservation[]; now: Date }) {
  const days = Array.from({ length: 7 }, (_, index) => {
    const day = new Date(now);
    day.setHours(0, 0, 0, 0);
    day.setDate(day.getDate() - (6 - index));
    return day;
  });
  const eligible = rides.filter((ride) => ride.status !== "cancelled");
  const total = days.reduce((sum, day) => sum + eligible.filter((ride) => sameDay(ride.pickup_at, day)).length, 0);

  return <Panel title="Past 7 days" subtitle={`${total} ${total === 1 ? "ride" : "rides"} total`} action={<Link to="/accounting" className="flex items-center gap-1 text-xs font-semibold text-dashboard-blue">View report <ArrowRight className="size-3.5" /></Link>}>
    <div className="grid grid-cols-7 p-2">{days.map((day) => {
      const count = eligible.filter((ride) => sameDay(ride.pickup_at, day)).length;
      const today = sameDay(day.toISOString(), now);
      return <div key={day.toISOString()} className={`min-h-24 border-y border-l border-dashboard-line px-1 py-3 text-center last:border-r ${today ? "bg-dashboard-ice" : "bg-card"}`}>
        <p className="text-[9px] font-bold uppercase text-dashboard-muted">{day.toLocaleDateString("en-US", { weekday: "short" })}</p>
        <p className={`mt-1 text-xs font-semibold ${today ? "text-dashboard-blue" : "text-dashboard-muted"}`}>{day.toLocaleDateString("en-US", { month: "short", day: "numeric" })}</p>
        <p className="mt-3 font-admin-display text-lg font-bold tabular-nums text-dashboard-navy">{count}</p>
        <p className="text-[9px] text-dashboard-muted">{count === 1 ? "ride" : "rides"}</p>
      </div>;
    })}</div>
  </Panel>;
}

function DriverStatus({ drivers, rides, now }: { drivers: Driver[]; rides: Reservation[]; now: Date }) {
  const roster = drivers.filter((driver) => driver.is_active !== false);
  return <Panel title="Driver status" subtitle={`${roster.filter((driver) => driver.is_online).length} online · ${roster.length} chauffeurs`} action={<Link to="/drivers" className="flex items-center gap-1 text-xs font-semibold text-dashboard-blue">View roster <ArrowRight className="size-3.5" /></Link>}>
    <div>
      {roster.map((driver) => {
        const trip = rides.find((ride) => ride.driver_id === driver.id && isActiveStatus(ride.status));
        const fresh = Boolean(driver.last_seen_at && now.getTime() - new Date(driver.last_seen_at).getTime() < 90_000);
        const onTrip = Boolean(trip);
        const dot = onTrip || fresh ? "bg-success" : "bg-dashboard-muted/40";
        const label = onTrip ? "On trip" : fresh ? "Available" : "Offline";
        const tone = onTrip || fresh ? "text-dashboard-green" : "text-dashboard-muted";
        return (
          <Link key={driver.id} to="/drivers" className="flex items-center gap-3 border-b border-dashboard-line px-4 py-2.5 last:border-0 hover:bg-dashboard-canvas">
            <span className={`size-2 shrink-0 rounded-full ${dot}`} />
            <span className="min-w-0 flex-1"><span className="block truncate text-xs font-semibold text-dashboard-navy">{driver.full_name}</span><span className={`block truncate text-[10px] ${tone}`}>{label}</span></span>
            <span className="min-w-0 flex-1 truncate text-right text-[10px] text-dashboard-muted">{trip ? `${trip.reference} · ${trip.passenger_name}` : fresh ? "Standing by" : "—"}</span>
            <span className="shrink-0 text-right text-[10px] tabular-nums text-dashboard-muted">{driver.last_seen_at ? messageTime(driver.last_seen_at) : "—"}</span>
          </Link>
        );
      })}
      {roster.length === 0 && <Empty icon={<Users />} text="No chauffeurs on the roster yet." />}
    </div>
  </Panel>;
}

function RecentActivity({ reservations, invoices }: { reservations: Reservation[]; invoices: Array<{ id: string; invoice_number: string; paid_at: string | null; sent_at: string | null; updated_at: string }> }) {
  const recent = [
    ...reservations.map((ride) => ({ id: `r-${ride.id}`, at: ride.pickup_at, icon: <CalendarDays />, title: "Reservation scheduled", detail: `${ride.passenger_name} · ${ride.reference}`, tone: "green" as const })),
    ...invoices.filter((invoice) => invoice.paid_at).map((invoice) => ({ id: `p-${invoice.id}`, at: invoice.paid_at ?? invoice.updated_at, icon: <CircleDollarSign />, title: "Invoice paid", detail: invoice.invoice_number, tone: "green" as const })),
    ...invoices.filter((invoice) => invoice.sent_at).map((invoice) => ({ id: `i-${invoice.id}`, at: invoice.sent_at ?? invoice.updated_at, icon: <Mail />, title: "Invoice emailed", detail: invoice.invoice_number, tone: "blue" as const })),
  ].sort((a, b) => b.at.localeCompare(a.at)).slice(0, 5);
  return <Panel title="Recent activity" action={<Link to="/accounting" className="flex items-center gap-1 text-xs font-semibold text-dashboard-blue">View activity <ArrowRight className="size-3.5" /></Link>}><div>{recent.map((item) => <div key={item.id} className="flex items-center gap-3 border-b border-dashboard-line px-4 py-2.5 last:border-0"><span className={`grid size-7 shrink-0 place-items-center rounded-md [&>svg]:size-3.5 ${metricStyles[item.tone]}`}>{item.icon}</span><div className="min-w-0 flex-1"><p className="truncate text-xs font-semibold text-dashboard-navy">{item.title}</p><p className="truncate text-[10px] text-dashboard-muted">{item.detail}</p></div><time className="shrink-0 text-[10px] text-dashboard-muted">{messageTime(item.at)}</time></div>)}{recent.length === 0 && <Empty icon={<Clock3 />} text="No recent activity." />}</div></Panel>;
}

function Empty({ icon, text }: { icon: ReactNode; text: string }) { return <div className="grid min-h-28 place-items-center px-4 py-6 text-center text-dashboard-muted"><div><span className="mx-auto mb-2 grid size-8 place-items-center [&>svg]:size-5">{icon}</span><p className="text-xs">{text}</p></div></div>; }