import { driverContact } from "@/lib/ride-contact";
import { useEffect, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { BrandLogo } from "@/components/BrandLogo";
import {
  getGuestTrip,
  listGuestReceipts,
  pingGuestLocation,
  saveGuestNote,
  saveGuestPayout,

  setGuestStatus,
  submitGuestDriver,
  uploadGuestReceipt,
} from "@/lib/guest-driver.functions";
import { mapsUrl, wazeUrl } from "@/lib/nav-links";

const contactBtn =
  "rounded-md border border-border px-3 py-1.5 font-cond text-[11px] uppercase tracking-widest text-brand hover:border-brand";
const passengerContactBtn =
  "rounded-md border border-success bg-success px-3 py-2.5 text-center font-cond text-[11px] uppercase tracking-widest text-brand-foreground transition-opacity hover:opacity-90";

/** Opens the address straight in the phone's Google Maps or Waze app. */
function NavLinks({ address }: { address?: string | null }) {
  if (!address) return null;
  return (
    <div className="mt-1 flex flex-wrap gap-2">
      <a href={mapsUrl(address)} target="_blank" rel="noreferrer" className={contactBtn}>
        Google Maps
      </a>
      <a href={wazeUrl(address)} target="_blank" rel="noreferrer" className={contactBtn}>
        Waze
      </a>
    </div>
  );
}


export const Route = createFileRoute("/d/$token")({
  head: () => ({
    meta: [
      { title: "Trip Assignment — Blackwave Transportation" },
      {
        name: "description",
        content:
          "One-time chauffeur trip sheet: confirm your details and vehicle, then update the ride status live.",
      },
      { property: "og:title", content: "Trip Assignment — Blackwave Transportation" },
      {
        property: "og:description",
        content: "Confirm your details and update the ride status for this Blackwave trip.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: GuestDriverPage,
});

const FLOW = [
  { status: "en_route", label: "On my way" },
  { status: "on_location", label: "On location" },
  { status: "passenger_on_board", label: "Passenger on board" },
  { status: "completed", label: "Dropped off" },
] as const;

function splitTerminalLevel(v: string | null): { terminal: string | null; level: string | null } {
  if (!v) return { terminal: null, level: null };
  const parts = v.split("/");
  if (parts.length >= 2) {
    return { terminal: (parts[0] ?? "").trim() || null, level: parts.slice(1).join("/").trim() || null };
  }
  return { terminal: v.trim() || null, level: null };
}

function GuestDriverPage() {
  const { token } = Route.useParams();
  const qc = useQueryClient();
  const load = useServerFn(getGuestTrip);
  const submit = useServerFn(submitGuestDriver);
  const advance = useServerFn(setGuestStatus);
  const ping = useServerFn(pingGuestLocation);

  const { data: trip, isLoading } = useQuery({
    queryKey: ["guest-trip", token],
    queryFn: () => load({ data: { token } }),
    refetchInterval: 60_000,
  });

  const [form, setForm] = useState({
    full_name: "",
    phone: "",
    make: "",
    model: "",
    plate: "",
    color: "",
  });

  const save = useMutation({
    mutationFn: () => submit({ data: { token, ...form } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["guest-trip", token] });
      toast.success("Details saved — you're assigned to this trip");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const step = useMutation({
    mutationFn: (status: (typeof FLOW)[number]["status"] | "confirmed") =>
      advance({ data: { token, status } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["guest-trip", token] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  // Share live position while the ride is running; stops at drop-off.
  const watchRef = useRef<number | null>(null);
  const tracking =
    !!trip?.submitted &&
    ["en_route", "on_location", "passenger_on_board"].includes(trip?.status ?? "");
  useEffect(() => {
    if (!tracking || typeof navigator === "undefined" || !navigator.geolocation) return;
    const report = () => {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          if (Math.abs(Date.now() - pos.timestamp) > 30_000) return;
          void ping({ data: { token, lat: pos.coords.latitude, lng: pos.coords.longitude } }).catch(() => undefined);
        },
        () => undefined,
        { enableHighAccuracy: true, maximumAge: 10_000, timeout: 10_000 }
      );
    };
    report();
    const watch = navigator.geolocation.watchPosition(
      (pos) => {
        if (Math.abs(Date.now() - pos.timestamp) > 30_000) return;
        void ping({ data: { token, lat: pos.coords.latitude, lng: pos.coords.longitude } }).catch(() => undefined);
      },
      () => undefined,
      { enableHighAccuracy: true, maximumAge: 15_000, timeout: 20_000 }
    );
    const timer = setInterval(report, 30_000);
    const refresh = () => { if (document.visibilityState === "visible") report(); };
    document.addEventListener("visibilitychange", refresh);
    window.addEventListener("focus", report);
    return () => {
      navigator.geolocation.clearWatch(watch);
      clearInterval(timer);
      document.removeEventListener("visibilitychange", refresh);
      window.removeEventListener("focus", report);
    };
  }, [tracking, token, ping]);

  if (isLoading) {
    return <Frame><p className="font-cond text-sm text-muted-foreground">Loading trip…</p></Frame>;
  }

  if (!trip) {
    return (
      <Frame>
        <p className="font-cond text-sm text-muted-foreground">
          This trip link is not valid any more. Please contact dispatch.
        </p>
      </Frame>
    );
  }

  const doneIndex = FLOW.findIndex((f) => f.status === trip.status);

  return (
    <Frame>
      <div className="rounded-lg border border-border bg-card p-5">
        <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
          Trip {trip.reference}
        </div>
        <div className="mt-1 flex items-baseline gap-x-2 font-display text-xl uppercase leading-none sm:text-4xl sm:gap-x-3">
          <span className="whitespace-nowrap">
            {new Date(trip.pickup_at).toLocaleDateString("en-US", {
              weekday: "short",
              month: "short",
              day: "numeric",
            })}
          </span>
          <span className="whitespace-nowrap">
            {new Date(trip.pickup_at).toLocaleTimeString("en-US", {
              hour: "numeric",
              minute: "2-digit",
              hour12: true,
            })}
          </span>
        </div>

        <div className="mt-4">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <Label>Passenger</Label>
              <div className="mt-0.5 truncate font-cond text-lg font-semibold">
                {trip.passenger_name}
              </div>
            </div>
            <span className="shrink-0 rounded-full border border-brand/30 bg-brand/10 px-3 py-1 font-cond text-[11px] uppercase tracking-widest text-brand">
              {trip.passenger_count} pax
            </span>
          </div>
          {(() => {
            const contact = driverContact(trip as never);
            if (!contact.phone) return null;
            return (
              <div className="mt-2">
                <Label>
                  Contact · {contact.label}
                  {contact.name ? ` · ${contact.name}` : ""}
                </Label>
                <div className="mt-1 grid grid-cols-3 gap-2">
                  <a href={`tel:${contact.phone}`} className={passengerContactBtn}>
                    Call {contact.phone}
                  </a>
                  <a href={`sms:${contact.phone}`} className={passengerContactBtn}>
                    Text
                  </a>
                  <a
                    href={`https://wa.me/${contact.phone.replace(/\D/g, "")}`}
                    target="_blank"
                    rel="noreferrer"
                    className={passengerContactBtn}
                  >
                    WhatsApp
                  </a>
                </div>
              </div>
            );
          })()}
        </div>

        <div className="mt-4">
          <Label>Pickup</Label>
          <div className="font-cond text-sm">{trip.pickup_address}</div>
          <NavLinks address={trip.pickup_address} />
        </div>
        {trip.stops.map((s, i) => (
          <div key={s.id} className="mt-3">
            <Label>Stop {i + 1}</Label>
            <div className="font-cond text-sm">{s.address}</div>
            {s.note && <div className="font-cond text-xs text-muted-foreground">{s.note}</div>}
            <NavLinks address={s.address} />
          </div>
        ))}
        <div className="mt-3">
          <Label>Drop-off</Label>
          <div className="font-cond text-sm">{trip.dropoff_address}</div>
          <NavLinks address={trip.dropoff_address} />
        </div>

        {(trip.airport_name ||
          trip.flight_number ||
          trip.airline ||
          trip.terminal_level ||
          trip.door_number ||
          trip.flight_direction !== "none") && (
          <div className="mt-4 rounded-lg border border-border bg-muted/50 p-4">
            {trip.airport_name && (
              <div className="flex items-start gap-2.5">
                <PlaneGlyph className="mt-0.5 h-4 w-4 shrink-0 text-brand" />
                <div className="min-w-0">
                  <Label>Airport</Label>
                  <div className="mt-0.5 break-words font-cond text-[15px] font-semibold leading-snug">
                    {trip.airport_name}
                  </div>
                </div>
              </div>
            )}
            <div className="mt-3 grid grid-cols-2 gap-2">
              <SpecTile label="Airline" value={trip.airline} />
              <SpecTile label="Flight" value={trip.flight_number} />
              <SpecTile
                label="Type"
                value={
                  trip.flight_direction === "arrival"
                    ? "Arrival"
                    : trip.flight_direction === "departure"
                      ? "Departure"
                      : null
                }
              />
              <SpecTile label="Terminal" value={splitTerminalLevel(trip.terminal_level).terminal} />
              <SpecTile label="Level" value={splitTerminalLevel(trip.terminal_level).level} />
              <SpecTile label="Door #" value={trip.door_number} />
              <SpecTile label="Passengers" value={String(trip.passenger_count)} />
            </div>
          </div>
        )}

        {trip.notes && (
          <div className="mt-4 rounded-md border border-brand/40 bg-brand/5 p-3">
            <Label>Notes from dispatch</Label>
            <p className="mt-1 whitespace-pre-wrap font-cond text-sm">{trip.notes}</p>
          </div>
        )}
      </div>

      {!trip.submitted ? (
        <form
          className="mt-4 rounded-lg border border-border bg-card p-5"
          onSubmit={(e) => {
            e.preventDefault();
            save.mutate();
          }}
        >
          <h2 className="font-display text-xl">Your details</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <Field label="Full name" value={form.full_name} onChange={(v) => setForm({ ...form, full_name: v })} required />
            <Field label="Phone number" value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} required />
            <Field label="Car make" value={form.make} onChange={(v) => setForm({ ...form, make: v })} />
            <Field label="Car model" value={form.model} onChange={(v) => setForm({ ...form, model: v })} />
            <Field label="Licence plate" value={form.plate} onChange={(v) => setForm({ ...form, plate: v })} required />
            <Field label="Vehicle colour" value={form.color} onChange={(v) => setForm({ ...form, color: v })} />
          </div>
          <button
            type="submit"
            disabled={save.isPending}
            className="mt-5 w-full rounded-md bg-brand py-3 font-cond text-xs uppercase tracking-[0.3em] text-brand-foreground disabled:opacity-50"
          >
            {save.isPending ? "Saving…" : "Submit"}
          </button>
        </form>
      ) : (
        <div className="mt-4 rounded-lg border border-border bg-card p-5">
          <h2 className="font-display text-xl">Ride status</h2>
          <p className="mt-1 font-cond text-xs text-muted-foreground">
            {trip.status === "completed"
              ? "Trip complete — location sharing has stopped."
              : "Keep this page open so dispatch can see you on the live map."}
          </p>
          <p className="mt-2 font-cond text-[11px] text-muted-foreground">
            Tapped the wrong status by mistake? Tap the correct step to change it back — or undo
            "On my way" if the trip hasn't started.
          </p>
          <div className="mt-4 grid gap-1">
            {FLOW.map((f, i) => {
              const done = doneIndex >= 0 && i <= doneIndex;
              const current = trip.status === f.status;
              const backward = doneIndex >= 0 && i < doneIndex;
              return (
                <div key={f.status}>
                  <button
                    disabled={step.isPending || current}
                    onClick={() => {
                      if (backward && !window.confirm(`Change the status back to "${f.label}"?`)) return;
                      step.mutate(f.status);
                    }}
                    className={`w-full rounded-md py-3 font-cond text-xs uppercase tracking-[0.3em] transition-colors disabled:opacity-90 ${
                      current
                        ? "bg-success text-brand-foreground"
                        : done
                          ? "bg-success text-brand-foreground"
                          : "border border-border text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {f.label}
                  </button>
                  {i < FLOW.length - 1 && (
                    <div className="py-1 text-center text-lg leading-none text-muted-foreground">↓</div>
                  )}
                </div>
              );
            })}
            {trip.status === "en_route" && (
              <button
                disabled={step.isPending}
                onClick={() => {
                  if (!window.confirm('Undo "On my way"? The trip goes back to "not started".')) return;
                  step.mutate("confirmed");
                }}
                className="mt-2 w-full rounded-md border border-border py-3 font-cond text-xs uppercase tracking-[0.3em] text-muted-foreground transition-colors hover:text-foreground"
              >
                Undo — not on my way yet
              </button>
            )}
          </div>
        </div>
      )}

      {trip.submitted && (
        <GuestExtras
          token={token}
          initialNote={trip.driver_note ?? ""}
          payout={{
            method: trip.driver?.payout_method ?? "",
            handle: trip.driver?.payout_handle ?? "",
            bank_name: trip.driver?.payout_bank_name ?? "",
            routing_number: trip.driver?.payout_routing_number ?? "",
            account_number: trip.driver?.payout_account_number ?? "",
          }}
        />
      )}

    </Frame>
  );
}

const RECEIPT_KINDS = [
  { id: "parking", label: "Parking receipt" },
  { id: "toll", label: "Toll receipt" },
  { id: "airport", label: "Airport fee receipt" },
  { id: "other", label: "Other receipt" },
] as const;

type Payout = {
  method: string;
  handle: string;
  bank_name: string;
  routing_number: string;
  account_number: string;
};

function GuestExtras({
  token,
  initialNote,
  payout,
}: {
  token: string;
  initialNote: string;
  payout: Payout;
}) {

  const qc = useQueryClient();
  const sendNote = useServerFn(saveGuestNote);
  const sendReceipt = useServerFn(uploadGuestReceipt);
  const loadReceipts = useServerFn(listGuestReceipts);

  const [note, setNote] = useState(initialNote);
  const [kind, setKind] = useState<(typeof RECEIPT_KINDS)[number]["id"]>("parking");
  const [amount, setAmount] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const fileInput = useRef<HTMLInputElement | null>(null);

  const { data: receipts = [] } = useQuery({
    queryKey: ["guest-receipts", token],
    queryFn: () => loadReceipts({ data: { token } }),
  });

  const noteMut = useMutation({
    mutationFn: () => sendNote({ data: { token, note } }),
    onSuccess: () => {
      toast.success("Message sent to dispatch");
      qc.invalidateQueries({ queryKey: ["guest-trip", token] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const uploadMut = useMutation({
    mutationFn: async () => {
      if (!file) throw new Error("Choose a photo or PDF first");
      const buf = await file.arrayBuffer();
      let binary = "";
      const view = new Uint8Array(buf);
      for (let i = 0; i < view.length; i += 8192) {
        binary += String.fromCharCode(...view.subarray(i, i + 8192));
      }
      return sendReceipt({
        data: {
          token,
          kind,
          amount: amount ? Number(amount) : 0,
          filename: file.name,
          content_type: file.type || "application/octet-stream",
          file_base64: btoa(binary),
        },
      });
    },
    onSuccess: () => {
      setFile(null);
      setAmount("");
      if (fileInput.current) fileInput.current.value = "";
      toast.success("Receipt sent to dispatch");
      qc.invalidateQueries({ queryKey: ["guest-receipts", token] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <>
      <div className="mt-4 rounded-lg border border-border bg-card p-5">
        <h2 className="font-display text-xl">Message dispatch</h2>
        <textarea
          value={note}
          rows={4}
          placeholder="Anything dispatch should know about this ride…"
          onChange={(e) => setNote(e.target.value)}
          className="mt-2 w-full rounded-md border border-border bg-transparent px-3 py-2 font-cond text-sm"
        />
        <button
          onClick={() => noteMut.mutate()}
          disabled={noteMut.isPending || !note.trim()}
          className="mt-2 w-full rounded-md bg-brand py-3 font-cond text-xs uppercase tracking-[0.3em] text-brand-foreground disabled:opacity-50"
        >
          {noteMut.isPending ? "Sending…" : "Send message"}
        </button>
      </div>

      <div className="mt-4 rounded-lg border border-border bg-card p-5">
        <h2 className="font-display text-xl">Attach a receipt</h2>
        <div className="mt-3 grid gap-2">
          <select
            value={kind}
            onChange={(e) => setKind(e.target.value as (typeof RECEIPT_KINDS)[number]["id"])}
            className="rounded-md border border-border bg-transparent px-3 py-2 font-cond text-sm"
          >
            {RECEIPT_KINDS.map((k) => (
              <option key={k.id} value={k.id}>
                {k.label}
              </option>
            ))}
          </select>
          <input
            value={amount}
            inputMode="decimal"
            placeholder="Amount (optional)"
            onChange={(e) => setAmount(e.target.value)}
            className="rounded-md border border-border bg-transparent px-3 py-2 font-cond text-sm"
          />
          <input
            ref={fileInput}
            type="file"
            accept="image/*,application/pdf"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            className="rounded-md border border-border bg-transparent px-3 py-2 font-cond text-sm"
          />
          <button
            onClick={() => uploadMut.mutate()}
            disabled={uploadMut.isPending || !file}
            className="rounded-md border border-brand py-3 font-cond text-xs uppercase tracking-[0.3em] text-brand disabled:opacity-40"
          >
            {uploadMut.isPending ? "Uploading…" : "Send receipt"}
          </button>
        </div>

        {receipts.length > 0 && (
          <div className="mt-4 space-y-2">
            {receipts.map((r) => (
              <div
                key={r.id}
                className="flex items-baseline justify-between gap-3 rounded-md border border-border px-3 py-2"
              >
                <span className="font-cond text-[13px]">
                  {RECEIPT_KINDS.find((k) => k.id === r.kind)?.label ?? r.kind}
                </span>
                <span className="font-cond text-[12px] text-muted-foreground">
                  {Number(r.amount) > 0 ? `$${Number(r.amount).toFixed(2)} · ` : ""}Sent
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      <PayoutBox token={token} payout={payout} />
    </>
  );
}

const PAY_METHODS = [
  { id: "zelle", label: "Zelle" },
  { id: "ach", label: "ACH / bank transfer" },
  { id: "venmo", label: "Venmo" },
  { id: "cashapp", label: "Cash App" },
] as const;

function PayoutBox({ token, payout }: { token: string; payout: Payout }) {
  const qc = useQueryClient();
  const savePayout = useServerFn(saveGuestPayout);

  const [method, setMethod] = useState(payout.method || "zelle");
  const [handle, setHandle] = useState(payout.handle);
  const [bankName, setBankName] = useState(payout.bank_name);
  const [routing, setRouting] = useState(payout.routing_number);
  const [account, setAccount] = useState(payout.account_number);

  const mut = useMutation({
    mutationFn: () =>
      savePayout({
        data: {
          token,
          method: method as "zelle" | "ach" | "venmo" | "cashapp",
          handle,
          bank_name: bankName,
          routing_number: routing,
          account_number: account,
        },
      }),
    onSuccess: () => {
      toast.success("Payment details saved");
      qc.invalidateQueries({ queryKey: ["guest-trip", token] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const handleLabel =
    method === "venmo" ? "Venmo name" : method === "cashapp" ? "Cash App name ($cashtag)" : "Zelle name, phone or email";

  return (
    <div className="mt-4 rounded-lg border border-border bg-card p-5">
      <h2 className="font-display text-xl">Preferred method of payment</h2>
      <div className="mt-3 grid gap-2">
        <select
          value={method}
          onChange={(e) => setMethod(e.target.value)}
          className="rounded-md border border-border bg-transparent px-3 py-2 font-cond text-sm"
        >
          {PAY_METHODS.map((m) => (
            <option key={m.id} value={m.id}>
              {m.label}
            </option>
          ))}
        </select>

        {method === "ach" ? (
          <>
            <Field label="Bank name" value={bankName} onChange={setBankName} required />
            <Field label="Routing number" value={routing} onChange={setRouting} required />
            <Field label="Account number" value={account} onChange={setAccount} required />
          </>
        ) : (
          <Field label={handleLabel} value={handle} onChange={setHandle} required />
        )}

        <button
          onClick={() => mut.mutate()}
          disabled={mut.isPending}
          className="rounded-md bg-brand py-3 font-cond text-xs uppercase tracking-[0.3em] text-brand-foreground disabled:opacity-50"
        >
          {mut.isPending ? "Saving…" : "Save payment details"}
        </button>
      </div>
    </div>
  );
}




function Frame({ children }: { children: React.ReactNode }) {
  return (
    <main className="mx-auto w-full max-w-[720px] px-4 py-8">
      <div className="mb-4 flex items-center gap-3">
        <BrandLogo className="h-12 w-12" />
        <h1 className="font-display text-2xl uppercase tracking-widest">
          Blackwave Transportation
        </h1>
      </div>
      {children}
    </main>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
      {children}
    </div>
  );
}

function SpecTile({
  label,
  value,
  className,
}: {
  label: string;
  value?: string | null;
  className?: string | undefined;
}) {
  if (!value) return null;
  return (
    <div className={`rounded-md border border-border/60 bg-card px-3 py-2.5 ${className ?? ""}`}>
      <Label>{label}</Label>
      <div className="mt-0.5 break-words font-cond text-sm font-semibold leading-5 text-foreground">
        {value}
      </div>
    </div>
  );
}

function PlaneGlyph({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M21 16v-2l-8-5V3.5A1.5 1.5 0 0 0 11.5 2 1.5 1.5 0 0 0 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" />
    </svg>
  );
}

function Field({
  label,
  value,
  onChange,
  required,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
}) {
  return (
    <label className="block">
      <Label>{label}</Label>
      <input
        value={value}
        required={required}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-md border border-border bg-transparent px-3 py-2 font-cond text-sm"
      />
    </label>
  );
}
