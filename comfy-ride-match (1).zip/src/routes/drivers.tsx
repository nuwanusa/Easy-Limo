import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { initials } from "@/lib/auth";
import { createDriverLogin } from "@/lib/driver-account.functions";
import { sendDriverPaymentEmail } from "@/lib/driver-pay.functions";
import { driverPayout, driversQuery, groupStops, money, reservationsQuery, stopsQuery, vehiclesQuery, type Driver } from "@/lib/dispatch";
import { VEHICLE_MAKES, modelsForMake } from "@/lib/vehicle-catalog";
import { useRole } from "@/lib/roles";
import { Ban, CalendarDays, Car, CreditCard, Edit3, FileText, KeyRound, Mail, MoreHorizontal, Phone, Plus, RefreshCw, Search, UserCheck, Users } from "lucide-react";

type DriverReview = {
  id: string;
  rating: number;
  tags: string[];
  comment: string | null;
  created_at: string;
  reservation: { id: string; reference: string; driver_id: string | null } | null;
};

const driverReviewsQuery = (enabled: boolean) => ({
  queryKey: ["driver-reviews"],
  enabled,
  queryFn: async (): Promise<DriverReview[]> => {
    const { data, error } = await supabase
      .from("ride_reviews")
      .select("id, rating, tags, comment, created_at, reservation:reservations!inner(id, reference, driver_id)")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []) as unknown as DriverReview[];
  },
});

function Stars({ rating }: { rating: number }) {
  return (
    <span className="text-amber-400" aria-label={`${rating} out of 5 stars`}>
      {"★".repeat(rating)}
      <span className="text-muted-foreground/40">{"★".repeat(Math.max(0, 5 - rating))}</span>
    </span>
  );
}


export const Route = createFileRoute("/drivers")({
  head: () => ({
    meta: [
      { title: "Drivers — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Full chauffeur records: licence, TLC, insurance, pay, emergency contacts, shift status and live trip counts for Blackwave Transportation LLC.",
      },
      { property: "og:title", content: "Drivers — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Manage the chauffeur roster: full profiles, documents, availability and assigned trips.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <AppShell>
      <DriversPage />
    </AppShell>
  ),
});

const DRIVER_STATUSES = ["available", "on_trip", "off_duty"];

const blank = {
  full_name: "",
  phone: "",
  email: "",
  license_number: "",
  license_class: "",
  license_state: "",
  license_expiry: "",
  tlc_number: "",
  tlc_expiry: "",
  badge_number: "",
  date_of_birth: "",
  hire_date: "",
  address_line1: "",
  address_line2: "",
  city: "",
  state: "",
  postal_code: "",
  emergency_contact_name: "",
  emergency_contact_phone: "",
  insurance_provider: "",
  insurance_policy: "",
  insurance_expiry: "",
  default_vehicle_id: "",
  vehicle_make: "",
  vehicle_model: "",
  vehicle_color: "",
  vehicle_plate: "",
  pay_type: "percentage",
  pay_rate: "0",
  notes: "",
};

type Form = typeof blank;

const toPayload = (form: Form) => {
  const dateFields = [
    "license_expiry",
    "tlc_expiry",
    "date_of_birth",
    "hire_date",
    "insurance_expiry",
  ] as const;
  const payload: Record<string, unknown> = { ...form, pay_rate: Number(form.pay_rate) };
  for (const f of dateFields) if (!form[f]) payload[f] = null;
  payload['default_vehicle_id'] = form.default_vehicle_id || null;
  delete payload['vehicle_make'];
  delete payload['vehicle_model'];
  delete payload['vehicle_color'];
  delete payload['vehicle_plate'];
  return payload;
};

/** Creates or updates the chauffeur's vehicle from the form fields; returns its id or null. */
async function syncVehicle(form: Form, currentVehicleId: string | null) {
  const make = form.vehicle_make.trim();
  const model = form.vehicle_model.trim();
  const color = form.vehicle_color.trim();
  const plate = form.vehicle_plate.trim();
  if (!make && !model && !color && !plate) return currentVehicleId;
  const vehiclePayload: Record<string, unknown> = {
    make: make || null,
    model: model || null,
    color: color || null,
    plate: plate || null,
  };
  if (currentVehicleId) {
    const { error } = await supabase.from("vehicles").update(vehiclePayload as never).eq("id", currentVehicleId);
    if (error) throw error;
    return currentVehicleId;
  }
  const name = [make, model].filter(Boolean).join(" ") || plate || "Vehicle";
  const { data, error } = await supabase
    .from("vehicles")
    .insert({
      ...vehiclePayload,
      name,
      fleet_code: plate || name.toUpperCase().replace(/\s+/g, "-").slice(0, 12),
      vehicle_class: "sedan",
      capacity: 3,
      status: "ready",
    } as never)
    .select("id")
    .single();
  if (error) throw error;
  return (data as { id: string }).id;
}

function DriversPage() {
  const qc = useQueryClient();
  const { data: drivers = [] } = useQuery(driversQuery);
  const { data: reservations = [] } = useQuery(reservationsQuery);
  const { data: stops = [] } = useQuery(stopsQuery);
  const { data: vehicles = [] } = useQuery(vehiclesQuery);
  const { isStaff } = useRole();
  const { data: reviews = [] } = useQuery(driverReviewsQuery(isStaff));
  const [form, setForm] = useState<Form>(blank);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [open, setOpen] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [vehicleFilter, setVehicleFilter] = useState("");
  const [loginFor, setLoginFor] = useState<string | null>(null);
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const makeLogin = useServerFn(createDriverLogin);
  const payDriver = useServerFn(sendDriverPaymentEmail);
  const sendPay = useMutation({
    mutationFn: (driverId: string) => payDriver({ data: { driverId } }),
    onSuccess: (res: any) => {
      if (res?.sent) {
        toast.success(`Payment statement sent to ${res.email} — ${res.amount} for ${res.trips} trips.`);
        qc.invalidateQueries({ queryKey: ["reservations"] });
      } else if (res?.reason === "nothing_due") {
        toast.error("No completed unpaid rides for this chauffeur.");
      } else if (res?.reason === "no_driver_email") {
        toast.error("Add an email address for this chauffeur first.");
      } else {
        toast.error(`Payment email failed: ${res?.reason ?? "unknown error"}`);
      }
    },
    onError: (e: unknown) => toast.error(e instanceof Error ? e.message : "Payment email failed"),
  });


  const set = (k: keyof Form) => (v: string) => setForm((f) => ({ ...f, [k]: v }));

  const saveLogin = useMutation({
    mutationFn: async (driverId: string) =>
      makeLogin({ data: { driverId, email: loginEmail, password: loginPassword } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["drivers"] });
      toast.success("Driver login is ready — they can sign in at the main login page");
      setLoginFor(null);
      setLoginPassword("");
    },
    onError: (e: Error) => toast.error(e.message),
  });


  const save = useMutation({
    mutationFn: async () => {
      const payload = toPayload(form);
      const vehicleId = await syncVehicle(form, form.default_vehicle_id || null);
      if (vehicleId) payload['default_vehicle_id'] = vehicleId;
      if (editingId) {
        const { error } = await supabase.from("drivers").update(payload as never).eq("id", editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("drivers").insert(payload as never);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["drivers"] });
      qc.invalidateQueries({ queryKey: ["vehicles"] });
      toast.success(editingId ? "Driver updated" : "Driver added to roster");
      setForm(blank);
      setEditingId(null);
      setOpen(false);
    },
    onError: (e: Error) =>
      toast.error(
        e.message.includes("drivers_default_vehicle_unique")
          ? "That vehicle is already assigned to another chauffeur."
          : e.message,
      ),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("drivers").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["drivers"] });
      toast.success("Driver deleted");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const setStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("drivers").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["drivers"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const setActive = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) => {
      const { error } = await supabase.from("drivers").update({ is_active: active }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: (_d, v) => {
      qc.invalidateQueries({ queryKey: ["drivers"] });
      toast.success(v.active ? "Chauffeur activated" : "Chauffeur deactivated");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const tripsFor = (id: string) =>
    reservations.filter((r) => r.driver_id === id && r.status !== "cancelled").length;

  const startEdit = (d: Driver) => {
    setEditingId(d.id);
    setOpen(true);
    const val = (v: unknown) => (v == null ? "" : String(v));
    const veh = vehicles.find((x) => x.id === d.default_vehicle_id);
    setForm({
      full_name: d.full_name,
      phone: val(d.phone),
      email: val(d.email),
      license_number: val(d.license_number),
      license_class: val(d.license_class),
      license_state: val(d.license_state),
      license_expiry: val(d.license_expiry),
      tlc_number: val(d.tlc_number),
      tlc_expiry: val(d.tlc_expiry),
      badge_number: val(d.badge_number),
      date_of_birth: val(d.date_of_birth),
      hire_date: val(d.hire_date),
      address_line1: val(d.address_line1),
      address_line2: val(d.address_line2),
      city: val(d.city),
      state: val(d.state),
      postal_code: val(d.postal_code),
      emergency_contact_name: val(d.emergency_contact_name),
      emergency_contact_phone: val(d.emergency_contact_phone),
      insurance_provider: val(d.insurance_provider),
      insurance_policy: val(d.insurance_policy),
      insurance_expiry: val(d.insurance_expiry),
      default_vehicle_id: val(d.default_vehicle_id),
      vehicle_make: val(veh?.make),
      vehicle_model: val(veh?.model),
      vehicle_color: val(veh?.color),
      vehicle_plate: val(veh?.plate),
      pay_type: d.pay_type ?? "percentage",
      pay_rate: val(d.pay_rate ?? 0),
      notes: val(d.notes),
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const q = search.trim().toLowerCase();
  const shownDrivers = drivers.filter((d) => {
    const vehicle = vehicles.find((item) => item.id === d.default_vehicle_id);
    const matchesSearch = !q || [d.full_name, d.phone, d.email, d.license_number, d.tlc_number, d.status, vehicle?.name, vehicle?.make, vehicle?.model, vehicle?.plate]
      .filter(Boolean).some((value) => String(value).toLowerCase().includes(q));
    return matchesSearch && (!statusFilter || d.status === statusFilter) && (!vehicleFilter || d.default_vehicle_id === vehicleFilter);
  });
  const onlineCount = drivers.filter((driver) => driver.is_online).length;
  const offDutyCount = drivers.filter((driver) => driver.status === "off_duty").length;
  const availableCount = drivers.filter((driver) => driver.status === "available").length;
  const stopsByRide = groupStops(stops);
  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);
  const monthTripsFor = (id: string) => reservations.filter((ride) => ride.driver_id === id && new Date(ride.pickup_at) >= monthStart && ride.status !== "cancelled").length;
  const earningsFor = (driver: Driver) => reservations
    .filter((ride) => ride.driver_id === driver.id && ride.status === "completed")
    .reduce((sum, ride) => sum + driverPayout(ride, driver, (stopsByRide.get(ride.id) ?? []).length), 0);

  return (
    <div className="min-h-screen bg-dashboard-canvas px-3 pb-10 pt-5 font-admin-body sm:px-5">
      <header className="flex items-end justify-between gap-4 border-b border-dashboard-line pb-4">
        <div className="min-w-0">
          <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-dashboard-blue">Crew roster</p>
          <h1 className="font-admin-display text-3xl font-bold text-dashboard-navy sm:text-4xl">Drivers</h1>
          <p className="mt-1 text-sm text-dashboard-muted">Manage your chauffeurs, track status, assign trips, and handle payments.</p>
        </div>
        <Button
          onClick={() => {
            if (open) {
              setOpen(false);
              setEditingId(null);
              setForm(blank);
            } else setOpen(true);
          }}
          className="shrink-0 bg-dashboard-blue text-primary-foreground hover:bg-dashboard-sidebar"
        >
          <Plus /> <span className="hidden sm:inline">{open ? "Close" : "Add driver"}</span>
        </Button>
      </header>

      <section className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <RosterStat icon={<Users />} label="Total drivers" value={drivers.length} note="All drivers in your roster" tone="blue" />
        <RosterStat icon={<UserCheck />} label="Online" value={onlineCount} note={`${drivers.length ? Math.round(onlineCount / drivers.length * 100) : 0}% of drivers`} tone="green" />
        <RosterStat icon={<Ban />} label="Off duty" value={offDutyCount} note={`${drivers.length ? Math.round(offDutyCount / drivers.length * 100) : 0}% of drivers`} tone="muted" />
        <RosterStat icon={<Users />} label="Available" value={availableCount} note={`${drivers.length ? Math.round(availableCount / drivers.length * 100) : 0}% of drivers`} tone="amber" />
      </section>

      <section className="mt-4 grid gap-2 rounded-md border border-dashboard-line bg-card p-2 shadow-sm lg:grid-cols-[minmax(280px,1fr)_190px_190px_auto]">
        <div className="relative"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-dashboard-muted" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search drivers by name, phone, email, licence, vehicle, or status…" aria-label="Search drivers" className="h-10 w-full rounded-md border border-dashboard-line bg-background pl-9 pr-3 text-sm outline-none focus:border-dashboard-blue" /></div>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} aria-label="Filter by status" className="h-10 rounded-md border border-dashboard-line bg-background px-3 text-sm"><option value="">All statuses</option>{DRIVER_STATUSES.map((status) => <option key={status} value={status}>{status.replace(/_/g, " ")}</option>)}</select>
        <select value={vehicleFilter} onChange={(e) => setVehicleFilter(e.target.value)} aria-label="Filter by vehicle" className="h-10 rounded-md border border-dashboard-line bg-background px-3 text-sm"><option value="">All vehicles</option>{vehicles.map((vehicle) => <option key={vehicle.id} value={vehicle.id}>{vehicle.name}</option>)}</select>
        <Button variant="outline" onClick={() => { setSearch(""); setStatusFilter(""); setVehicleFilter(""); }}><RefreshCw /> Reset</Button>
      </section>

      {open && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            save.mutate();
          }}
          className="mt-4"
        >
          <div className="mb-5 flex flex-wrap items-center gap-3 rounded-xl border border-border bg-card px-5 py-4 shadow-sm">
            <div>
              <div className="font-display text-xl text-foreground">
                {editingId ? "Editing chauffeur file" : "New chauffeur file"}
              </div>
              <div className="font-cond text-[10px] uppercase tracking-[0.3em] text-brand">
                Licence, TLC, insurance, pay & vehicle on one page
              </div>
            </div>
            {editingId && (
              <span className="ml-auto rounded-full border border-brand/40 bg-brand/10 px-3 py-1 font-cond text-[10px] uppercase tracking-widest text-brand">
                Editing
              </span>
            )}
          </div>

          <div className="grid items-start gap-5 md:grid-cols-2 xl:grid-cols-3">
            <div className="min-w-0 space-y-5">
              <FormSection step="01" title="Personal">
                <Input label="Full name" value={form.full_name} onChange={set("full_name")} required />
                <Input label="Phone" value={form.phone} onChange={set("phone")} />
                <Input label="Login email" type="email" value={form.email} onChange={set("email")} />
                <Input label="Date of birth" type="date" value={form.date_of_birth} onChange={set("date_of_birth")} />
                <Input label="Address line 1" value={form.address_line1} onChange={set("address_line1")} />
                <Input label="Address line 2" value={form.address_line2} onChange={set("address_line2")} />
                <Input label="City" value={form.city} onChange={set("city")} />
                <div className="grid grid-cols-2 gap-3">
                  <Input label="State" value={form.state} onChange={set("state")} />
                  <Input label="ZIP" value={form.postal_code} onChange={set("postal_code")} />
                </div>
              </FormSection>
            </div>

            <div className="min-w-0 space-y-5">
              <FormSection step="02" title="Licensing">
                <Input label="Licence №" value={form.license_number} onChange={set("license_number")} />
                <Input label="Licence class" value={form.license_class} onChange={set("license_class")} />
                <Input label="Licence state" value={form.license_state} onChange={set("license_state")} />
                <Input label="Licence expiry" type="date" value={form.license_expiry} onChange={set("license_expiry")} />
                <Input label="TLC / chauffeur №" value={form.tlc_number} onChange={set("tlc_number")} />
                <Input label="TLC expiry" type="date" value={form.tlc_expiry} onChange={set("tlc_expiry")} />
                <Input label="Badge №" value={form.badge_number} onChange={set("badge_number")} />
                <Input label="Hire date" type="date" value={form.hire_date} onChange={set("hire_date")} />
              </FormSection>
              <FormSection step="03" title="Insurance & emergency" last>
                <Input label="Insurance provider" value={form.insurance_provider} onChange={set("insurance_provider")} />
                <Input label="Policy №" value={form.insurance_policy} onChange={set("insurance_policy")} />
                <Input label="Policy expiry" type="date" value={form.insurance_expiry} onChange={set("insurance_expiry")} />
                <div className="grid grid-cols-2 gap-3">
                  <Input label="Emergency contact" value={form.emergency_contact_name} onChange={set("emergency_contact_name")} />
                  <Input label="Emergency phone" value={form.emergency_contact_phone} onChange={set("emergency_contact_phone")} />
                </div>
              </FormSection>
            </div>

            <div className="min-w-0 space-y-5">
              <FormSection step="04" title="Vehicle assignment" last>
                <div>
                  <Label>Default vehicle</Label>
                  <select
                    value={form.default_vehicle_id}
                    onChange={(e) => set("default_vehicle_id")(e.target.value)}
                    className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
                  >
                    <option value="">None</option>
                    {vehicles
                      .filter(
                        (v) =>
                          !drivers.some((d) => d.default_vehicle_id === v.id && d.id !== editingId),
                      )
                      .map((v) => (
                      <option key={v.id} value={v.id} className="bg-popover">
                        {v.fleet_code} · {v.name}
                      </option>
                      ))}
                  </select>
                  <p className="mt-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                    Or enter the vehicle below — it will be created and assigned automatically
                  </p>
                </div>
                <Input
                  label="Vehicle make"
                  value={form.vehicle_make}
                  onChange={(v) => setForm((f) => ({ ...f, vehicle_make: v, vehicle_model: "" }))}
                  list="driver-vehicle-makes"
                  placeholder="e.g. Cadillac"
                />
                <Input
                  label="Vehicle model"
                  value={form.vehicle_model}
                  onChange={set("vehicle_model")}
                  list="driver-vehicle-models"
                  placeholder={form.vehicle_make ? "e.g. Escalade" : "Pick a make first"}
                />
                <div className="grid grid-cols-2 gap-3">
                  <Input label="Vehicle color" value={form.vehicle_color} onChange={set("vehicle_color")} placeholder="Black" />
                  <Input label="License plate" value={form.vehicle_plate} onChange={set("vehicle_plate")} />
                </div>
                <datalist id="driver-vehicle-makes">
                  {VEHICLE_MAKES.map((m) => (
                    <option key={m} value={m} />
                  ))}
                </datalist>
                <datalist id="driver-vehicle-models">
                  {modelsForMake(form.vehicle_make).map((m) => (
                    <option key={m} value={m} />
                  ))}
                </datalist>
              </FormSection>
              <FormSection step="05" title="Pay" last>
                <div>
                  <Label>Pay type</Label>
                  <select
                    value={form.pay_type}
                    onChange={(e) => set("pay_type")(e.target.value)}
                    className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
                  >
                    <option value="percentage">Percentage of fare</option>
                    <option value="hourly">Hourly</option>
                    <option value="per_trip">Per trip</option>
                  </select>
                </div>
                <Input label="Pay rate" type="number" value={form.pay_rate} onChange={set("pay_rate")} />
                <div>
                  <Label>Notes</Label>
                  <textarea
                    value={form.notes}
                    onChange={(e) => set("notes")(e.target.value)}
                    rows={2}
                    className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
                  />
                </div>
              </FormSection>
            </div>
          </div>

          <div className="mt-5 flex justify-end rounded-xl border border-border bg-card px-5 py-4 shadow-sm">
            <button
              type="submit"
              disabled={save.isPending}
              className="rounded-md bg-brand px-5 py-2.5 font-cond text-xs uppercase tracking-[0.3em] text-brand-foreground disabled:opacity-60"
            >
              {editingId ? "Update Driver" : "Add Driver"}
            </button>
          </div>
        </form>
      )}

      <div className="mt-3 space-y-3">
        {shownDrivers.length === 0 && (
          <div className="px-5 py-6 font-cond text-sm text-muted-foreground">No drivers match that search.</div>
        )}
        {shownDrivers.map((d) => (
          <article key={d.id} className="overflow-hidden rounded-md border border-dashboard-line bg-card px-4 py-3 shadow-sm">
            <div className="grid items-center gap-4 xl:grid-cols-[minmax(330px,1.35fr)_minmax(360px,0.9fr)_170px]">
              <div className="flex min-w-0 items-center gap-4">
              <div className="grid size-12 shrink-0 place-items-center rounded-full bg-dashboard-ice font-admin-display text-base font-bold uppercase text-dashboard-blue">
                {initials(d.full_name)}
              </div>
              <div className="min-w-0 break-words">

                <div className="flex flex-wrap items-center gap-2 font-admin-display text-base font-bold text-dashboard-navy">
                  <span>{d.full_name}</span>
                  <span
                    className={`size-2 rounded-full ${d.is_online ? "bg-dashboard-green" : "bg-dashboard-muted/50"}`}
                    title={d.is_online ? "Online" : "Offline"}
                  />
                  <span className="text-xs font-normal text-dashboard-muted">{d.is_online ? "Online" : "Offline"}</span>
                </div>
                <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-dashboard-muted">
                  <span className="inline-flex items-center gap-1.5"><Phone className="size-3.5" />{d.phone ?? "No phone"}</span>
                  <span className="inline-flex min-w-0 items-center gap-1.5"><Mail className="size-3.5" /><span className="truncate">{d.email ? (d.user_id ? `${d.email} (App linked)` : `${d.email} (Awaiting sign-up)`) : "No login email"}</span></span>
                </div>
                {(() => {
                  const v = vehicles.find((x) => x.id === d.default_vehicle_id);
                  if (!v) return null;
                  const parts = [v.make, v.model].filter(Boolean).join(" ");
                  const bits = [
                    parts || v.name,
                    v.year ? String(v.year) : "",
                    v.color ? v.color.charAt(0).toUpperCase() + v.color.slice(1) : "",
                    v.plate ? `Plate ${v.plate}` : "",
                  ].filter(Boolean);
                  return (
                    <div className="mt-1 text-[11px] text-dashboard-muted">
                      TLC: {d.tlc_number ?? "Not on file"} <span className="mx-2">|</span> Vehicle: {bits.join(" · ")}
                    </div>
                  );
                })()}
              </div>
              </div>
              <div className="grid grid-cols-3 divide-x divide-dashboard-line border-y border-dashboard-line py-2 xl:border-y-0 xl:py-0">
                <RosterMetric icon={<Car />} value={tripsFor(d.id)} label="Trips assigned" />
                <RosterMetric icon={<CalendarDays />} value={monthTripsFor(d.id)} label="This month" />
                <RosterMetric icon={<CreditCard />} value={money(earningsFor(d))} label="Total earnings" />
              </div>
              <select
                value={d.status}
                onChange={(e) => setStatus.mutate({ id: d.id, status: e.target.value })}
                className={`h-9 rounded-full border-0 px-4 text-xs font-bold uppercase ${d.status === "on_trip" ? "bg-success/15 text-success" : d.status === "off_duty" ? "bg-muted text-muted-foreground" : "bg-dashboard-ice text-dashboard-blue"}`}
              >
                {DRIVER_STATUSES.map((s) => (
                  <option key={s} value={s} className="bg-popover">
                    {s.replace(/_/g, " ")}
                  </option>
                ))}
              </select>
              <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5 xl:col-span-3 xl:grid-cols-[1fr_1fr_1fr_1fr_1fr_auto]">
                <Button variant="outline"
                  onClick={() => setExpanded(expanded === d.id ? null : d.id)}
                >
                  <FileText />
                  {expanded === d.id ? "Hide" : "Details"}
                </Button>
                <Button variant="outline"
                  onClick={() => {
                    if (loginFor === d.id) {
                      setLoginFor(null);
                      return;
                    }
                    setLoginFor(d.id);
                    setLoginEmail(d.email ?? "");
                    setLoginPassword("");
                  }}
                >
                  <KeyRound />
                  {d.user_id ? "Reset password" : "Create login"}
                </Button>
                <Button variant="outline"
                  onClick={() => {
                    if (sendPay.isPending) return;
                    if (confirm(`Email ${d.full_name} a payment statement and mark those rides paid?`))
                      sendPay.mutate(d.id);
                  }}
                  disabled={sendPay.isPending}
                  className="border-success/50 text-success"
                >
                  <CreditCard />
                  {sendPay.isPending ? "Sending…" : "Send payment"}
                </Button>
                <Button variant="outline"
                  onClick={() => startEdit(d)}
                  className="border-dashboard-blue/50 text-dashboard-blue"
                >
                  <Edit3 /> Edit
                </Button>
                <Button variant="outline"
                  onClick={() => setActive.mutate({ id: d.id, active: d.is_active === false })}
                  className={`${
                    d.is_active === false
                      ? "border-success/50 text-success"
                      : "border-destructive/50 text-destructive"
                  }`}
                >
                  <Ban />
                  {d.is_active === false ? "Activate" : "Deactivate"}
                </Button>
                <Button variant="outline" size="icon" aria-label={`Delete ${d.full_name}`}
                  onClick={() => {
                    if (tripsFor(d.id) > 0) {
                      toast.error("Reassign this driver's trips before deleting.");
                      return;
                    }
                    if (confirm(`Delete ${d.full_name}?`)) remove.mutate(d.id);
                  }}
                  className="border-dashboard-line text-dashboard-muted hover:text-destructive"
                >
                  <MoreHorizontal />
                </Button>
              </div>
            </div>

            {loginFor === d.id && (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  saveLogin.mutate(d.id);
                }}
                className="mt-4 grid gap-3 border-t border-border pt-4 md:grid-cols-4"
              >
                <Input label="Login email" type="email" value={loginEmail} onChange={setLoginEmail} required />
                <Input
                  label="Password (min 8 characters)"
                  type="text"
                  value={loginPassword}
                  onChange={setLoginPassword}
                  required
                />
                <div className="flex items-end">
                  <button
                    type="submit"
                    disabled={saveLogin.isPending}
                    className="rounded-md bg-brand px-5 py-2.5 font-cond text-xs uppercase tracking-[0.3em] text-brand-foreground disabled:opacity-60"
                  >
                    {d.user_id ? "Update login" : "Create login"}
                  </button>
                </div>
                <p className="self-end font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
                  Share these details with the driver — they sign in on the driver app.
                </p>
              </form>
            )}


            {expanded === d.id && (
              <dl className="mt-4 grid gap-3 border-t border-border pt-4 font-cond text-sm md:grid-cols-4">
                <Detail label="Address">
                  {[d.address_line1, d.address_line2, d.city, d.state, d.postal_code].filter(Boolean).join(", ") || "—"}
                </Detail>
                <Detail label="Date of birth">{d.date_of_birth ?? "—"}</Detail>
                <Detail label="Hired">{d.hire_date ?? "—"}</Detail>
                <Detail label="Badge №">{d.badge_number ?? "—"}</Detail>
                <Detail label="Licence">
                  {[d.license_number, d.license_class, d.license_state].filter(Boolean).join(" · ") || "—"}
                </Detail>
                <Detail label="Licence expiry">{d.license_expiry ?? "—"}</Detail>
                <Detail label="TLC №">{d.tlc_number ?? "—"}</Detail>
                <Detail label="TLC expiry">{d.tlc_expiry ?? "—"}</Detail>
                <Detail label="Insurance">
                  {[d.insurance_provider, d.insurance_policy].filter(Boolean).join(" · ") || "—"}
                </Detail>
                <Detail label="Insurance expiry">{d.insurance_expiry ?? "—"}</Detail>
                <Detail label="Emergency contact">
                  {[d.emergency_contact_name, d.emergency_contact_phone].filter(Boolean).join(" · ") || "—"}
                </Detail>
                <Detail label="Vehicle">
                  {(() => {
                    const v = vehicles.find((x) => x.id === d.default_vehicle_id);
                    if (!v) return "—";
                    return [v.year, [v.make, v.model].filter(Boolean).join(" ") || v.name]
                      .filter(Boolean)
                      .join(" ");
                  })()}
                </Detail>
                <Detail label="Vehicle class">
                  {(() => {
                    const v = vehicles.find((x) => x.id === d.default_vehicle_id);
                    return v ? (v.vehicle_class ?? "—") : "—";
                  })()}
                </Detail>
                <Detail label="Vehicle colour">
                  {(() => {
                    const v = vehicles.find((x) => x.id === d.default_vehicle_id);
                    if (!v?.color) return "—";
                    return v.color.charAt(0).toUpperCase() + v.color.slice(1);
                  })()}
                </Detail>
                <Detail label="Licence plate">
                  {vehicles.find((x) => x.id === d.default_vehicle_id)?.plate ?? "—"}
                </Detail>
                <Detail label="Pay">
                  {d.pay_rate ? `${d.pay_rate}${d.pay_type === "percentage" ? "%" : ""} (${(d.pay_type ?? "").replace(/_/g, " ")})` : "—"}
                </Detail>
                <Detail label="Last seen">
                  {d.last_seen_at ? new Date(d.last_seen_at).toLocaleString() : "—"}
                </Detail>
                <div className="md:col-span-4">
                  <Detail label="Notes">{d.notes ?? "—"}</Detail>
                </div>
                {isStaff && (() => {
                  const mine = reviews.filter((r) => r.reservation?.driver_id === d.id);
                  const avg = mine.length ? mine.reduce((s, r) => s + (r.rating || 0), 0) / mine.length : 0;
                  return (
                    <div className="md:col-span-4 border-t border-border pt-4">
                      <div className="mb-2 flex items-baseline gap-2">
                        <span className="font-cond text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                          Client reviews
                        </span>
                        {mine.length > 0 && (
                          <>
                            <span className="font-display text-lg">{avg.toFixed(1)}</span>
                            <Stars rating={Math.round(avg)} />
                            <span className="text-xs text-muted-foreground">
                              {mine.length} review{mine.length === 1 ? "" : "s"}
                            </span>
                          </>
                        )}
                      </div>
                      {mine.length === 0 ? (
                        <p className="text-sm text-muted-foreground">No client reviews yet.</p>
                      ) : (
                        <div className="grid gap-2">
                          {mine.map((r) => (
                            <div key={r.id} className="rounded-lg border border-border bg-surface-2 p-3">
                              <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                                <Stars rating={r.rating} />
                                <span className="font-cond text-xs uppercase tracking-widest text-brand">
                                  {r.reservation?.reference ?? "Ride"}
                                </span>
                                <span className="ml-auto text-xs text-muted-foreground">
                                  {new Date(r.created_at).toLocaleDateString("en-US", {
                                    month: "short",
                                    day: "numeric",
                                    year: "numeric",
                                  })}
                                </span>
                              </div>
                              {r.tags?.length > 0 && (
                                <div className="mt-2 flex flex-wrap gap-1.5">
                                  {r.tags.map((t) => (
                                    <span
                                      key={t}
                                      className="rounded-full border border-border px-2.5 py-0.5 text-xs text-foreground/80"
                                    >
                                      {t}
                                    </span>
                                  ))}
                                </div>
                              )}
                              {r.comment && <p className="mt-2 text-sm leading-relaxed">{r.comment}</p>}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })()}
              </dl>
            )}
          </article>
        ))}
      </div>
    </div>
  );
}

function RosterStat({ icon, label, value, note, tone }: { icon: React.ReactNode; label: string; value: number; note: string; tone: "blue" | "green" | "muted" | "amber" }) {
  const tones = { blue: "border-dashboard-blue/20 bg-dashboard-ice/60 text-dashboard-blue", green: "border-success/20 bg-success/5 text-success", muted: "border-dashboard-line bg-card text-dashboard-muted", amber: "border-warning/25 bg-warning/5 text-warning" };
  return <div className={`flex min-h-24 items-center gap-4 rounded-md border p-4 shadow-sm ${tones[tone]}`}><span className="grid size-12 shrink-0 place-items-center rounded-full bg-current/10 [&>svg]:size-6">{icon}</span><div><p className="text-[10px] font-bold uppercase text-dashboard-muted">{label}</p><p className="font-admin-display text-2xl font-bold text-dashboard-navy">{value}</p><p className="text-xs text-dashboard-muted">{note}</p></div></div>;
}

function RosterMetric({ icon, value, label }: { icon: React.ReactNode; value: React.ReactNode; label: string }) {
  return <div className="flex min-w-0 items-center justify-center gap-2 px-3"><span className="text-dashboard-navy [&>svg]:size-5">{icon}</span><span className="min-w-0"><b className="block truncate text-sm text-dashboard-navy">{value}</b><small className="block truncate text-[10px] text-dashboard-muted">{label}</small></span></div>;
}

function FormSection({
  step,
  title,
  last,
  children,
}: {
  step: string;
  title: string;
  last?: boolean;
  children: React.ReactNode;
}) {
  return (
    <section className="w-full rounded-xl border border-border bg-card p-5 shadow-sm">
      <div className="mb-4 flex items-center gap-2">
        <span className="flex h-6 w-6 items-center justify-center rounded bg-brand/10 font-cond text-[10px] font-bold text-brand">
          {step}
        </span>
        <h3 className="font-cond text-[11px] uppercase tracking-[0.2em] text-foreground">{title}</h3>
      </div>
      <div className="grid gap-3">{children}</div>
    </section>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">{children}</div>
  );
}

function Detail({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <dt className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">{label}</dt>
      <dd className="mt-0.5">{children}</dd>
    </div>
  );
}

function Input({
  label,
  value,
  onChange,
  required,
  type = "text",
  list,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
  type?: string;
  list?: string;
  placeholder?: string;
}) {
  return (
    <div>
      <Label>{label}</Label>
      <input
        type={type}
        value={value}
        required={required}
        list={list}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground outline-none focus:border-brand/60"
      />
    </div>
  );
}
