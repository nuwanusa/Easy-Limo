import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getPortalByToken, type PortalRide } from "@/lib/client-portal.functions";
import { passengerNames } from "@/lib/dispatch";
import { PayByCardLink } from "@/components/PayByCardLink";

export const Route = createFileRoute("/i/$token/$id")({
  head: () => ({
    meta: [
      { title: "Billing Statement PDF — Blackwave Transportation LLC" },
      {
        name: "description",
        content: "Printable Blackwave Transportation invoice with full ride and fare detail.",
      },
      { property: "og:title", content: "Billing Statement PDF — Blackwave Transportation LLC" },
      { property: "og:description", content: "Printable invoice with full ride and fare detail." },
      { property: "og:type", content: "website" },
      { name: "robots", content: "noindex" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PrintableInvoicePage,
});

const money = (v: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 2 }).format(v || 0);

const day = (v: string | null | undefined) =>
  v
    ? new Date(v).toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
        timeZone: "America/New_York",
      })
    : "—";

const shortDate = (v: string | null | undefined) =>
  v
    ? new Date(/^\d{4}-\d{2}-\d{2}$/.test(v) ? `${v}T12:00:00Z` : v).toLocaleDateString("en-US", {
        month: "numeric",
        day: "numeric",
        year: "numeric",
        timeZone: "America/New_York",
      })
    : "—";

const periodLabel = (start?: string | null, end?: string | null) => {
  if (!start && !end) return "—";
  const from = shortDate(start ?? end);
  const to = shortDate(end ?? start);
  return from === to ? from : `${from} – ${to}`;
};

const clock = (v: string | null | undefined) =>
  v
    ? new Date(v).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZone: "America/New_York" })
    : "—";

const others = (r: PortalRide) =>
  (r.booking_type === "hourly" ? r.hourly_rate * r.hours : 0) +
  r.tolls +
  r.airport_fee +
  r.parking_fee +
  r.meet_greet_fee +
  (r.waiting_minutes / 60) * r.waiting_rate +
  r.gratuity +
  r.stop_fee * (r.stops?.length ?? 0) +
  r.car_seat_count * r.car_seat_fee;

const otherRows = (r: PortalRide) => {
  const rows: { label: string; amount: number }[] = [];
  const push = (label: string, v: number) => {
    if (v > 0) rows.push({ label, amount: v });
  };
  if (r.booking_type === "hourly" && r.hourly_rate * r.hours > 0)
    push(
      `Other - ${money(r.hourly_rate)} / hour X ${r.hours} hours = ${money(r.hourly_rate * r.hours)}`,
      r.hourly_rate * r.hours,
    );
  const named: { label: string; amount: number }[] = [];
  for (const leg of r.tolls_breakdown ?? []) {
    for (const t of leg.tolls ?? []) {
      const amount = Number(t.amount ?? 0);
      if (!amount) continue;
      named.push({ label: [t.name ?? leg.label ?? "Toll", t.agency, t.payment].filter(Boolean).join(" · "), amount });
    }
  }
  const namedTotal = named.reduce((s, t) => s + t.amount, 0);
  if (named.length && Math.abs(namedTotal - r.tolls) < 0.02) {
    for (const t of named) rows.push({ label: `Toll — ${t.label}`, amount: t.amount });
  } else {
    push("Tolls", r.tolls);
    for (const t of named) rows.push({ label: t.label, amount: t.amount });
  }
  push("Airport fee", r.airport_fee);
  push("Parking", r.parking_fee);
  push("Meet & greet", r.meet_greet_fee);
  if (r.waiting_minutes > 0)
    rows.push({
      label: `Waiting time (${r.waiting_minutes} min)`,
      amount: (r.waiting_minutes / 60) * r.waiting_rate,
    });
  push("Gratuity", r.gratuity);
  if ((r.stops?.length ?? 0) > 0)
    push(`Extra stops (${r.stops.length})`, r.stop_fee * r.stops.length);
  if (r.car_seat_count > 0)
    push(`Car seats (${r.car_seat_count})`, r.car_seat_count * r.car_seat_fee);
  return rows;
};

const rideTotal = (r: PortalRide) =>
  (r.base_rate ?? 0) +
  (r.booking_type === "hourly" ? r.hourly_rate * r.hours : r.base_fare) +
  (r.waiting_minutes / 60) * r.waiting_rate +
  r.airport_fee +
  r.meet_greet_fee +
  r.parking_fee +
  r.tolls +
  r.gratuity +
  r.stop_fee * (r.stops?.length ?? 0) +
  r.car_seat_count * r.car_seat_fee;

function PrintableInvoicePage() {
  const { token, id } = Route.useParams();
  const fetchPortal = useServerFn(getPortalByToken);

  const query = useQuery({
    queryKey: ["client-portal", token],
    queryFn: () => fetchPortal({ data: { token } }),
  });

  if (query.isLoading) {
    return <p className="py-20 text-center text-sm text-muted-foreground">Loading invoice…</p>;
  }
  if (query.error || !query.data) {
    return <p className="py-20 text-center text-sm text-destructive">This invoice link is no longer valid.</p>;
  }

  const data = query.data;
  const invoice = data.invoices.find((i) => i.id === id) ?? null;
  const rides = invoice
    ? data.rides.filter((r) => r.invoice_id === invoice.id)
    : data.rides.filter((r) => r.id === id);

  if (!rides.length) {
    return <p className="py-20 text-center text-sm text-destructive">That invoice could not be found.</p>;
  }

  const subtotal = rides.reduce((s, r) => s + rideTotal(r), 0);
  const discount = invoice?.discount ?? 0;
  const payments = invoice?.payments ?? 0;
  const paid = Boolean(invoice?.paid_at ?? rides[0]?.invoice_paid_at);
  const due = Math.max(subtotal - discount - payments, 0);
  const number = invoice?.invoice_number ?? rides[0]?.invoice_number ?? `INV-${rides[0]?.reference ?? ""}`;

  return (
    <div className="min-h-screen overflow-x-auto bg-slate-100 py-8 print:overflow-visible print:bg-white print:py-0">
      <style>{`
        @media print {
          .no-print { display: none !important; }
          @page { size: letter landscape; margin: 8mm; }
          .portal-invoice-sheet { width: 100% !important; max-width: none !important; padding: 0 !important; box-shadow: none !important; }
          .portal-invoice-table { font-size: 9px !important; }
          .portal-invoice-table tr { break-inside: avoid; page-break-inside: avoid; }
        }
      `}</style>

      <div className="mx-auto mb-4 flex max-w-4xl justify-end px-4 no-print">
        <button
          type="button"
          onClick={() => window.print()}
          className="rounded-md bg-[#0b3a75] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#1665d8]"
        >
          Download PDF Billing Statement
        </button>
      </div>

      <div className="portal-invoice-sheet mx-auto w-full max-w-[1800px] bg-white p-4 text-[#132132] shadow sm:p-8 print:w-full">
        <div className="flex flex-wrap items-start justify-between gap-6 border-b-4 border-[#4d9bff] bg-[#0b3a75] p-6 text-white">
          <div>
            <h1 className="text-xl font-bold text-white">Blackwave Transportation LLC</h1>
            <p className="text-sm text-blue-100">52 Meredith Avenue, Staten Island, NY 10314</p>
            <p className="text-sm text-blue-100">(917) 325-3211 · info@rideblackwave.com</p>
            <p className="text-sm text-blue-100">www.rideblackwave.com</p>
          </div>
          <div className="text-right">
            <p className="text-xl font-bold uppercase tracking-[0.2em] text-white">Billing Statement</p>
            <p className="text-sm text-blue-100">Statement #{number}</p>
            <p className="text-sm text-blue-100">Issued: {day(invoice?.issued_at ?? rides[0]?.invoice_issued_at)}</p>
            <p className="text-sm font-semibold">{paid ? "Paid" : "Balance due"}</p>
          </div>
        </div>

        <div className="mt-5 grid gap-4 sm:grid-cols-3">
          <div className="rounded-md border-l-4 border-[#1665d8] bg-[#eef4fd] p-4">
            <p className="text-[11px] font-bold uppercase tracking-widest text-[#1665d8]">Bill to</p>
            <p className="font-semibold">{data.client.name}</p>
            {data.client.address_line1 ? <p className="text-sm text-slate-600">{data.client.address_line1}</p> : null}
            {data.client.address_line2 ? <p className="text-sm text-slate-600">{data.client.address_line2}</p> : null}
            {data.client.email ? <p className="text-sm text-slate-600">{data.client.email}</p> : null}
          </div>
          <div className="rounded-md border border-[#d7e4f7] bg-[#f7faff] p-4">
            <p className="text-[11px] font-bold uppercase tracking-widest text-[#1665d8]">Account #</p>
            <p className="font-semibold">{data.client.account_number}</p>
            <p className="mt-3 text-[11px] font-bold uppercase tracking-widest text-[#1665d8]">Billing period</p>
            <p className="text-sm text-slate-600">{periodLabel(invoice?.period_start ?? rides[rides.length - 1]?.pickup_at, invoice?.period_end ?? rides[0]?.pickup_at)}</p>
          </div>
          <div className="rounded-md border border-[#d7e4f7] bg-[#f7faff] p-4">
            <p className="text-[11px] font-bold uppercase tracking-widest text-[#1665d8]">Trips</p>
            <p className="text-3xl font-bold text-[#0b3a75]">{rides.length}</p>
          </div>
        </div>

        <div className="mt-6 overflow-x-auto">
        <table className="portal-invoice-table w-full min-w-[1100px] table-fixed border-collapse text-left text-[12px]">
          <colgroup>
            <col className="w-[8%]" />
            <col className="w-[10%]" />
            <col className="w-[10%]" />
            <col className="w-[29%]" />
            <col className="w-[8%]" />
            <col className="w-[7%]" />
            <col className="w-[7%]" />
            <col className="w-[14%]" />
            <col className="w-[7%]" />
          </colgroup>
          <thead>
            <tr className="bg-[#0b3a75] text-white">
              <th className="p-2 font-semibold">Date</th>
              <th className="p-2 font-semibold">Pickup / Drop-off</th>
              <th className="p-2 font-semibold">Passenger</th>
              <th className="p-2 font-semibold">Route</th>
              <th className="p-2 font-semibold">Vehicle</th>
              <th className="p-2 text-right font-semibold">Base rate</th>
              <th className="p-2 text-right font-semibold">Flat rate</th>
              <th className="p-2 text-right font-semibold">Others</th>
              <th className="p-2 text-right font-semibold">Total</th>
            </tr>
          </thead>
          <tbody>
            {rides.map((r, i) => (
              <tr key={r.id} className={i % 2 ? "bg-[#f7faff]" : ""}>
                <td className="border-b border-[#d7e4f7] p-2 align-top whitespace-nowrap">{day(r.pickup_at)}</td>
                <td className="border-b border-[#d7e4f7] p-2 align-top whitespace-nowrap">
                  {clock(r.pickup_at)} – {clock(r.dropoff_at)}
                </td>
                <td className="border-b border-[#d7e4f7] p-2 align-top">
                  {passengerNames(r)}
                  <div className="text-[11px] text-[#5a6b84]">
                    Notes: {r.passenger_count ?? 0} passenger{(r.passenger_count ?? 0) === 1 ? "" : "s"} ·{" "}
                    {r.luggage_count ?? 0} luggage
                  </div>
                </td>
                <td className="border-b border-[#d7e4f7] p-2 align-top">
                  {[`PU: ${r.pickup_address}`, ...(r.stops ?? []).map((s) => s.address), `DO: ${r.dropoff_address}`].join(" → ")}
                  <div className="text-[11px] text-slate-500">
                    {r.booking_type === "hourly"
                      ? `${r.hours} hr @ ${money(r.hourly_rate)}/hr`
                      : `Flat rate ${money(r.base_fare)}`}
                    {r.waiting_minutes > 0 ? ` · Waiting ${r.waiting_minutes} min` : ""}
                    {r.distance_miles > 0 ? ` · ${r.distance_miles} mi` : ""}
                  </div>
                </td>
                <td className="border-b border-[#d7e4f7] p-2 align-top">{r.vehicle_class}</td>
                <td className="border-b border-[#d7e4f7] p-2 text-right align-top tabular-nums whitespace-nowrap">{money(r.base_rate ?? 0)}</td>
                <td className="border-b border-[#d7e4f7] p-2 text-right align-top tabular-nums whitespace-nowrap">
                  {r.booking_type === "hourly" ? "—" : money(r.base_fare)}
                </td>
                <td className="border-b border-[#d7e4f7] p-2 align-top">
                  <div className="text-right font-semibold tabular-nums whitespace-nowrap">{money(others(r))}</div>
                  {otherRows(r).length > 0 ? (
                    <div className="mt-1.5 border-t border-[#d7e4f7] pt-1.5 text-[10px] leading-4 text-slate-500">
                      <p className="text-left font-semibold uppercase tracking-wider">Breakdown</p>
                      {otherRows(r).map((row) => (
                        <div key={row.label} className="grid grid-cols-[minmax(0,1fr)_auto] gap-2">
                          <span className="min-w-0 text-left">{row.label}</span>
                          <span className="text-right tabular-nums whitespace-nowrap">{money(row.amount)}</span>
                        </div>
                      ))}
                    </div>
                  ) : null}
                </td>
                <td className="border-b border-[#d7e4f7] p-2 text-right align-top font-semibold tabular-nums whitespace-nowrap">{money(rideTotal(r))}</td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>

        <div className="mt-6 flex flex-wrap justify-between gap-6">
          <div className="min-w-[280px] rounded-md bg-[#eef4fd] p-4 text-sm">
            <p className="mb-2 text-[11px] font-bold uppercase tracking-widest text-[#1665d8]">Payment methods</p>
            <dl className="divide-y divide-[#d7e4f7]">
              <div className="grid grid-cols-[72px_minmax(0,1fr)] gap-3 py-2">
                <dt className="font-semibold text-slate-500">Zelle</dt>
                <dd className="text-right font-semibold">
                  <a href="tel:+19173253211" className="text-[#1665d8] underline">917-325-3211</a>
                </dd>
              </div>
              <div className="grid grid-cols-[72px_minmax(0,1fr)] gap-3 py-2">
                <dt className="font-semibold text-slate-500">ACH</dt>
                <dd className="text-right font-semibold">
                  <span className="block">Chase Bank</span>
                  <span className="block text-xs font-normal text-slate-500">Account # 507675562</span>
                  <span className="block text-xs font-normal text-slate-500">Routing # 021000021</span>
                </dd>
              </div>
              <div className="grid grid-cols-[72px_minmax(0,1fr)] gap-3 py-2">
                <dt className="font-semibold text-slate-500">Venmo</dt>
                <dd className="text-right font-semibold">@nuwanusa</dd>
              </div>
              <div className="grid grid-cols-[72px_minmax(0,1fr)] gap-3 py-2">
                <dt className="font-semibold text-slate-500">Cash App</dt>
                <dd className="text-right font-semibold">$blackwavelimo</dd>
              </div>
            </dl>
          </div>
          <div className="min-w-[260px] flex-1 text-sm">
            <div className="flex justify-between border-b border-[#d7e4f7] py-1">
              <span>Subtotal</span>
              <span>{money(subtotal)}</span>
            </div>
            <div className="flex justify-between border-b border-[#d7e4f7] py-1">
              <span>Discount</span>
              <span>{money(discount)}</span>
            </div>
            <div className="flex justify-between border-b border-[#d7e4f7] py-1">
              <span>Payments</span>
              <span>{money(payments)}</span>
            </div>
            <div className="mt-3 flex items-center justify-between rounded-md bg-[#0b3a75] px-4 py-3 text-white">
              <span className="text-xs uppercase tracking-widest">Total due</span>
              <span className="text-xl font-bold">{money(paid ? 0 : due)}</span>
            </div>
          </div>
        </div>

        {invoice?.notes ? <p className="mt-5 text-sm">{invoice.notes}</p> : null}
        <p className="mt-6 text-center text-[11px] uppercase tracking-widest text-slate-500">
          Thank you for choosing Blackwave Transportation.
        </p>
        <PayByCardLink
          target={invoice ? "invoice" : "reservation"}
          id={invoice ? invoice.id : (rides[0]?.id ?? "")}
          amount={due}
          paid={paid}
          tone="navy"
        />
      </div>
    </div>
  );
}
