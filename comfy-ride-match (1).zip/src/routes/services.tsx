import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — Blackwave Transportation" },
      {
        name: "description",
        content:
          "Airport transfers, executive hourly hire, weddings, road shows, and discreet personal protection logistics.",
      },
      { property: "og:title", content: "Services — Blackwave Transportation" },
      { property: "og:description", content: "Airport transfers, executive hourly, weddings, road shows." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ServicesPage,
});

const services = [
  {
    n: "01",
    t: "Airport Transfer",
    d: "Flight tracked from wheels-up. Greeter at baggage claim. Cabin pre-cooled to your preference. Curb-to-door, on time, every time.",
  },
  {
    n: "02",
    t: "Hourly Executive",
    d: "A car and chauffeur held at your disposal — for the duration of a meeting, a day of appointments, or a city you've never seen.",
  },
  {
    n: "03",
    t: "Road Shows",
    d: "Multi-leg, multi-city itineraries managed by a dedicated coordinator. Private aviation handoffs, hotel arrivals, and contingency routing.",
  },
  {
    n: "04",
    t: "Weddings & Events",
    d: "Choreographed arrivals and departures for the bridal party, principals, and guests. Coordinated with planners and venues.",
  },
  {
    n: "05",
    t: "Corporate Accounts",
    d: "Billed accounts with monthly consolidated invoicing, saved passengers, agreed rates, and a private portal for every ride and invoice.",
  },
  {
    n: "06",
    t: "Long Distance",
    d: "Intercity transfers with route reconnaissance, refreshment provisioning, and an alternate vehicle on standby for your peace of mind.",
  },
];

function ServicesPage() {
  return (
    <SiteLayout>
      <section className="pb-20 pt-40 lg:pt-48">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <p className="eyebrow mb-6">Services</p>
          <h1 className="max-w-4xl font-display text-5xl leading-[1.05] md:text-7xl">
            Six ways we move you. <span className="gold-text italic">All of them quietly.</span>
          </h1>
        </div>
      </section>

      <section className="pb-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <div className="grid border-t border-border md:grid-cols-2">
            {services.map((s, i) => (
              <div
                key={s.n}
                className={`group border-b border-border p-10 transition-colors hover:bg-card md:p-14 ${
                  i % 2 === 0 ? "md:border-r" : ""
                }`}
              >
                <div className="mb-6 flex items-start justify-between">
                  <span className="font-mono text-xs tracking-[0.3em] text-gold">{s.n}</span>
                  <span className="text-gold transition-transform group-hover:translate-x-1">→</span>
                </div>
                <h3 className="font-display text-3xl md:text-4xl">{s.t}</h3>
                <p className="mt-6 text-base leading-relaxed text-muted-foreground">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="border-t border-border bg-card py-32">
        <div className="mx-auto max-w-3xl px-6 text-center lg:px-10">
          <h2 className="font-display text-4xl leading-tight md:text-5xl">
            Don&apos;t see your itinerary above?
          </h2>
          <p className="mt-6 text-lg text-muted-foreground">
            Most of our work is bespoke. Call our concierge and we&apos;ll build it.
          </p>
          <Link
            to="/contact"
            className="mt-10 inline-block border border-gold px-8 py-4 font-mono text-xs uppercase tracking-[0.25em] text-gold transition hover:bg-gold hover:text-primary-foreground"
          >
            Speak with Concierge
          </Link>
        </div>
      </section>
    </SiteLayout>
  );
}
