import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AppShell, PageHeading } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { vehiclesQuery, VEHICLE_CLASSES } from "@/lib/dispatch";
import { VEHICLE_MAKES, modelsForMake } from "@/lib/vehicle-catalog";

export const Route = createFileRoute("/fleet")({
  head: () => ({
    meta: [
      { title: "Fleet — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Fleet roster for Blackwave Transportation LLC: sedans, SUVs, sprinters and stretches with plates, capacity and readiness.",
      },
      { property: "og:title", content: "Fleet — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Track vehicle readiness, capacity and plates across the chauffeur fleet.",
      },
    ],
  }),
  component: () => (
    <AppShell>
      <FleetPage />
    </AppShell>
  ),
});

const VEHICLE_STATUSES = ["ready", "on_road", "maintenance", "retired"];

function FleetPage() {
  const qc = useQueryClient();
  const { data: vehicles = [] } = useQuery(vehiclesQuery);
  const blank = {
    fleet_code: "",
    name: "",
    vehicle_class: "sedan",
    make: "",
    model: "",
    year: "" as string,
    plate: "",
    color: "",
    capacity: 3,
  };
  const [form, setForm] = useState(blank);
  const [editingId, setEditingId] = useState<string | null>(null);

  const save = useMutation({
    mutationFn: async () => {
      const payload = { ...form, year: form.year ? Number(form.year) : null };
      if (editingId) {
        const { error } = await supabase.from("vehicles").update(payload).eq("id", editingId);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("vehicles").insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["vehicles"] });
      toast.success(editingId ? "Vehicle updated" : "Vehicle added to fleet");
      setForm(blank);
      setEditingId(null);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("vehicles").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["vehicles"] });
      toast.success("Vehicle deleted");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const setStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("vehicles").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["vehicles"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <>
      <PageHeading eyebrow="Rolling Stock" title="Fleet" />

      <form
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate();
        }}
        className="plate m-6 grid gap-3 rounded-lg border border-border p-5 md:grid-cols-6"
      >
        <Input label="Fleet code" value={form.fleet_code} onChange={(v) => setForm({ ...form, fleet_code: v })} required />
        <Input label="Vehicle" value={form.name} onChange={(v) => setForm({ ...form, name: v })} required />
        <div>
          <Label>Class</Label>
          <select
            value={form.vehicle_class}
            onChange={(e) => setForm({ ...form, vehicle_class: e.target.value })}
            className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
          >
            {VEHICLE_CLASSES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
        <Input
          label="Make"
          value={form.make}
          onChange={(v) => setForm({ ...form, make: v, model: "" })}
          list="vehicle-makes"
          placeholder="Search make"
        />
        <Input
          label="Model"
          value={form.model}
          onChange={(v) => setForm({ ...form, model: v })}
          list="vehicle-models"
          placeholder={form.make ? "Search model" : "Pick a make first"}
        />
        <datalist id="vehicle-makes">
          {VEHICLE_MAKES.map((m) => (
            <option key={m} value={m} />
          ))}
        </datalist>
        <datalist id="vehicle-models">
          {modelsForMake(form.make).map((m) => (
            <option key={m} value={m} />
          ))}
        </datalist>
        <Input
          label="Year"
          type="number"
          value={form.year}
          onChange={(v) => setForm({ ...form, year: v })}
          placeholder="2026"
        />
        <Input label="Color" value={form.color} onChange={(v) => setForm({ ...form, color: v })} />
        <Input label="Plate" value={form.plate} onChange={(v) => setForm({ ...form, plate: v })} />
        <Input label="Capacity" type="number" value={String(form.capacity)} onChange={(v) => setForm({ ...form, capacity: Number(v) })} />
        <button
          type="submit"
          disabled={save.isPending}
          className="self-end rounded-md bg-brand px-5 py-2.5 font-cond text-xs uppercase tracking-[0.3em] text-brand-foreground disabled:opacity-60"
        >
          {editingId ? "Update" : "Add"}
        </button>
        {editingId && (
          <button
            type="button"
            onClick={() => {
              setEditingId(null);
              setForm(blank);
            }}
            className="self-end rounded-md border border-border px-5 py-2.5 font-cond text-xs uppercase tracking-[0.3em] text-muted-foreground"
          >
            Cancel
          </button>
        )}
      </form>

      <div className="mx-6 mb-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {vehicles.map((v) => (
          <div key={v.id} className="rounded-lg border border-border bg-card p-5">
            <div className="flex items-start justify-between">
              <div>
                <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                  {v.fleet_code} · {v.plate ?? "no plate"}
                </div>
                <div className="font-display text-2xl uppercase leading-tight">{v.name}</div>
              </div>
              <div className="grid size-12 place-items-center rounded-md bg-surface-2 font-display text-xl text-brand">
                {v.vehicle_class[0]?.toUpperCase()}
              </div>
            </div>
            <div className="mt-3 font-cond text-sm text-muted-foreground">
              {[v.year, v.make, v.model, v.color].filter(Boolean).join(" ") || v.vehicle_class} · {v.vehicle_class} · seats {v.capacity}
            </div>
            <select
              value={v.status}
              onChange={(e) => setStatus.mutate({ id: v.id, status: e.target.value })}
              className="mt-4 w-full rounded-md border border-border bg-transparent px-2 py-1.5 font-cond text-[11px] uppercase tracking-widest"
            >
              {VEHICLE_STATUSES.map((s) => (
                <option key={s} value={s} className="bg-popover">
                  {s.replace(/_/g, " ")}
                </option>
              ))}
            </select>
            <div className="mt-3 flex gap-2">
              <button
                onClick={() => {
                  setEditingId(v.id);
                  setForm({
                    fleet_code: v.fleet_code,
                    name: v.name,
                    vehicle_class: v.vehicle_class,
                    make: v.make ?? "",
                    model: v.model ?? "",
                    year: v.year ? String(v.year) : "",
                    plate: v.plate ?? "",
                    color: v.color ?? "",
                    capacity: v.capacity,
                  });
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className="flex-1 rounded-md border border-brand/50 py-1.5 font-cond text-[11px] uppercase tracking-widest text-brand"
              >
                Edit
              </button>
              <button
                onClick={() => {
                  if (confirm(`Delete ${v.name}?`)) remove.mutate(v.id);
                }}
                className="flex-1 rounded-md border border-destructive/50 py-1.5 font-cond text-[11px] uppercase tracking-widest text-destructive"
              >
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
      {children}
    </div>
  );
}

function Input({
  label,
  value,
  onChange,
  type = "text",
  required,
  list,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
  list?: string;
  placeholder?: string;
}) {
  return (
    <div>
      <Label>{label}</Label>
      <input
        type={type}
        value={value}
        required={required}
        list={list}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground outline-none focus:border-brand/60"
      />
    </div>
  );
}
