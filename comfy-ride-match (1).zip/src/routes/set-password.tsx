import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company";
import { resolveLanding } from "@/lib/post-login";
import { BrandLogo } from "@/components/BrandLogo";

export const Route = createFileRoute("/set-password")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Choose Your Password — Blackwave Platform" },
      {
        name: "description",
        content: "Set a new password for your company administrator account before using the dispatch board.",
      },
      { property: "og:title", content: "Choose Your Password — Blackwave Platform" },
      { property: "og:description", content: "Set a new password for your company administrator account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SetPasswordPage,
});

function SetPasswordPage() {
  const navigate = useNavigate();
  const { company } = useCompany();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 8) {
      toast.error("Use at least 8 characters");
      return;
    }
    if (password !== confirm) {
      toast.error("The two passwords do not match");
      return;
    }
    setBusy(true);
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
      const { data: sessionData } = await supabase.auth.getSession();
      const userId = sessionData.session?.user?.id;
      if (userId) {
        await supabase
          .from("company_users")
          .update({ must_change_password: false })
          .eq("user_id", userId);
      }
      toast.success("Password updated");
      navigate({ to: await resolveLanding() });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not update the password");
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-4 py-12">
      <form
        onSubmit={submit}
        className="w-full max-w-md space-y-5 rounded-2xl border border-border bg-card p-8 shadow-sm"
      >
        <div className="flex flex-col items-center gap-3 text-center">
          <BrandLogo className="h-12 w-auto" />
          <h1 className="font-cond text-lg uppercase tracking-[0.2em] text-foreground">
            Choose your password
          </h1>
          <p className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
            {company?.name ? company.name : "Welcome"} · first sign-in
          </p>
        </div>

        <label className="block">
          <span className="font-cond text-xs uppercase tracking-[0.15em] text-foreground">New password</span>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="mt-2 w-full rounded-xl border border-input bg-surface-2 px-4 py-4 font-cond text-base text-foreground outline-none focus:border-brand"
          />
        </label>
        <label className="block">
          <span className="font-cond text-xs uppercase tracking-[0.15em] text-foreground">Confirm password</span>
          <input
            type="password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            required
            className="mt-2 w-full rounded-xl border border-input bg-surface-2 px-4 py-4 font-cond text-base text-foreground outline-none focus:border-brand"
          />
        </label>

        <button
          type="submit"
          disabled={busy}
          className="w-full rounded-xl bg-brand py-3.5 font-cond text-xs uppercase tracking-[0.3em] text-brand-foreground disabled:opacity-60"
        >
          {busy ? "Saving…" : "Save password"}
        </button>
      </form>
    </main>
  );
}
