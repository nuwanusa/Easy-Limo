import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import sedan from "@/assets/fleet-sedan.jpg";
import suv from "@/assets/fleet-suv.jpg";

export const Route = createFileRoute("/our-fleet")({
  head: () => ({
    meta: [
      { title: "The Fleet — Blackwave Transportation" },
      {
        name: "description",
        content:
          "Executive sedans and luxury SUVs — every vehicle immaculately maintained and discreetly appointed.",
      },
      { property: "og:title", content: "The Fleet — Blackwave Transportation" },
      { property: "og:description", content: "Executive sedans and luxury SUVs." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FleetPublicPage,
});

const fleet = [
  {
    img: sedan,
    name: "Executive Sedan",
    sub: "Mercedes-Benz S-Class · BMW 7 Series",
    caps: "1–3 passengers · 3 cases",
    desc: "The standard for the daily commute, airport transfer, and discreet evening engagement. Massaging rear seats, climate-zoned cabin, refreshments on request.",
    rate: "from $100 / hr",
  },
  {
    img: suv,
    name: "Luxury SUV",
    sub: "Cadillac Escalade Premium · Lincoln Navigator",
    caps: "1–6 passengers · 6 cases",
    desc: "Stately presence with cathedral-quiet cabins. Preferred for family travel, principal protection, and protracted ground itineraries.",
    rate: "from $150 / hr",
  },
];

function FleetPublicPage() {
  return (
    <SiteLayout>
      <section className="pb-20 pt-40 lg:pt-48">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <p className="eyebrow mb-6">The Fleet</p>
          <h1 className="max-w-4xl font-display text-5xl leading-[1.05] md:text-7xl">
            Two vehicles. <span className="gold-text italic">One standard.</span>
          </h1>
          <p className="mt-8 max-w-2xl text-lg text-muted-foreground">
            Every car in our fleet is fewer than two years old, detailed before and after each
            engagement, and outfitted to the same uncompromising specification.
          </p>
        </div>
      </section>

      <section className="pb-32">
        <div className="mx-auto max-w-7xl space-y-32 px-6 lg:px-10">
          {fleet.map((v, i) => (
            <article
              key={v.name}
              className={`grid gap-12 lg:grid-cols-2 lg:items-center ${
                i % 2 === 1 ? "lg:[&>div:first-child]:order-2" : ""
              }`}
            >
              <div className="relative overflow-hidden bg-card">
                <img
                  src={v.img}
                  alt={v.name}
                  width={1280}
                  height={960}
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              </div>
              <div>
                <p className="font-mono text-xs uppercase tracking-[0.3em] text-gold">0{i + 1} / 02</p>
                <h2 className="mt-4 font-display text-4xl md:text-5xl">{v.name}</h2>
                <p className="mt-2 font-mono text-sm uppercase tracking-[0.15em] text-muted-foreground">
                  {v.sub}
                </p>
                <div className="hairline my-8 max-w-[100px]" />
                <p className="text-lg leading-relaxed text-muted-foreground">{v.desc}</p>
                <div className="mt-10 grid grid-cols-2 gap-6 border-y border-border py-6">
                  <div>
                    <div className="font-mono text-[0.65rem] uppercase tracking-[0.25em] text-muted-foreground">
                      Capacity
                    </div>
                    <div className="mt-2 font-display text-xl">{v.caps}</div>
                  </div>
                  <div>
                    <div className="font-mono text-[0.65rem] uppercase tracking-[0.25em] text-muted-foreground">
                      Rate
                    </div>
                    <div className="mt-2 font-display text-xl text-gold">{v.rate}</div>
                  </div>
                </div>
                <Link
                  to="/contact"
                  className="mt-10 inline-block border border-gold px-8 py-4 font-mono text-xs uppercase tracking-[0.25em] text-gold transition hover:bg-gold hover:text-primary-foreground"
                >
                  Reserve This Vehicle
                </Link>
              </div>
            </article>
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}
