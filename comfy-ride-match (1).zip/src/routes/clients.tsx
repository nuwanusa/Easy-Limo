import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CreditCard, DollarSign, ExternalLink, FileText, Mail, MapPin, Pencil, Phone, Plus, Search, Tag, Trash2, UserRound, UsersRound } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { PriceMap } from "@/components/PriceMap";
import { AddressField } from "@/components/AddressAutocomplete";
import { PhoneField } from "@/components/PhoneField";
import { clientPassengersQuery, clientRatesQuery, clientsQuery, reservationsQuery, stopsQuery, invoicesQuery, fareTotal, money, VEHICLE_CLASSES } from "@/lib/dispatch";
import { ClientPortalAccess } from "@/components/ClientPortalAccess";
import { CardsOnFile } from "@/components/CardsOnFile";

export const Route = createFileRoute("/clients")({
  head: () => ({
    meta: [
      { title: "Client Accounts — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Corporate and personal client accounts with billing address, contact, terms and total rides booked with Blackwave Transportation LLC.",
      },
      { property: "og:title", content: "Client Accounts — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Manage account numbers, billing contacts and payment terms for recurring chauffeur clients.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AppShell>
      <ClientsPage />
    </AppShell>
  ),
});

const emptyRate = {
  label: "",
  rate_type: "flat",
  amount: "0",
  vehicle_class: "sedan",
  minimum_hours: "3",
  notes: "",
};

const emptyPassenger = { full_name: "", phone: "", email: "", notes: "" };

const empty = {
  account_number: "",
  name: "",
  contact_name: "",
  billing_contact_phone: "",
  billing_contact_email: "",
  booking_contact_name: "",
  booking_contact_phone: "",
  booking_contact_email: "",
  email: "",
  phone: "",
  address_line1: "",
  address_line2: "",
  terms: "Due upon receipt",
  notify_reservation: true,
  notify_driver_accepted: true,
  notify_ride_reminder: true,
  notify_invoice: true,
  notify_payment: true,
};

const NOTIFY_OPTIONS = [
  { key: "notify_reservation", label: "New reservation is created" },
  { key: "notify_driver_accepted", label: "Chauffeur accepts the ride (with chauffeur & vehicle details)" },
  { key: "notify_ride_reminder", label: "Ride reminder 24 hours before pickup" },
  { key: "notify_invoice", label: "New invoice is created" },
  { key: "notify_payment", label: "Payment received" },
] as const;

function ClientsPage() {
  const qc = useQueryClient();
  const { data: clients = [] } = useQuery(clientsQuery);
  const { data: reservations = [] } = useQuery(reservationsQuery);
  const { data: stops = [] } = useQuery(stopsQuery);
  const { data: rates = [] } = useQuery(clientRatesQuery);
  const { data: invoices = [] } = useQuery(invoicesQuery);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive">("all");
  const [sortOrder, setSortOrder] = useState<"name" | "account">("name");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [portalFor, setPortalFor] = useState<string | null>(null);
  const [cardsFor, setCardsFor] = useState<string | null>(null);
  const [rateFor, setRateFor] = useState<string | null>(null);
  const [rateForm, setRateForm] = useState(emptyRate);
  const { data: passengers = [] } = useQuery(clientPassengersQuery);
  const [passengerFor, setPassengerFor] = useState<string | null>(null);
  const [passengerForm, setPassengerForm] = useState(emptyPassenger);
  const [editingPassengerId, setEditingPassengerId] = useState<string | null>(null);
  const [draftPassenger, setDraftPassenger] = useState(emptyPassenger);
  const [draftPassengers, setDraftPassengers] = useState<(typeof emptyPassenger)[]>([]);


  const savePassenger = useMutation({
    mutationFn: async (clientId: string) => {
      const { error } = await supabase.from("client_passengers").insert({
        client_id: clientId,
        full_name: passengerForm.full_name,
        phone: passengerForm.phone || null,
        email: passengerForm.email || null,
        notes: passengerForm.notes || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["client_passengers"] });
      setPassengerForm(emptyPassenger);
      toast.success("Passenger saved");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const updatePassenger = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("client_passengers")
        .update({
          full_name: passengerForm.full_name,
          phone: passengerForm.phone || null,
          email: passengerForm.email || null,
          notes: passengerForm.notes || null,
        })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["client_passengers"] });
      setPassengerForm(emptyPassenger);
      setEditingPassengerId(null);
      toast.success("Passenger updated");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const removePassenger = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("client_passengers").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["client_passengers"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const saveRate = useMutation({
    mutationFn: async (clientId: string) => {
      const { error } = await supabase.from("client_rates").insert({
        client_id: clientId,
        label: rateForm.label,
        rate_type: rateForm.rate_type,
        amount: Number(rateForm.amount),
        vehicle_class: rateForm.vehicle_class,
        minimum_hours: Number(rateForm.minimum_hours),
        notes: rateForm.notes || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["client_rates"] });
      setRateForm(emptyRate);
      toast.success("Price added to the list");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const removeRate = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("client_rates").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["client_rates"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const create = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase
        .from("clients")
        .insert({
          ...form,
          account_number: form.account_number || String(30000 + clients.length + 1),
        })
        .select("id")
        .single();
      if (error) throw error;
      const id = data.id as string;
      if (draftPassengers.length > 0) {
        const { error: pErr } = await supabase.from("client_passengers").insert(
          draftPassengers.map((p) => ({
            client_id: id,
            full_name: p.full_name,
            phone: p.phone || null,
            email: p.email || null,
            notes: p.notes || null,
          })),
        );
        if (pErr) throw pErr;
      }
      return id;
    },
    onSuccess: (id) => {
      qc.invalidateQueries({ queryKey: ["clients"] });
      qc.invalidateQueries({ queryKey: ["client_passengers"] });
      setForm(empty);
      setOpen(false);
      setEditingPassengerId(null);
      setPassengerForm(emptyPassenger);
      setDraftPassenger(emptyPassenger);
      setDraftPassengers([]);
      setPassengerFor(id);
      toast.success("Client account created");
    },

    onError: (e: Error) => toast.error(e.message),
  });


  const update = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("clients").update({ ...form }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["clients"] });
      setForm(empty);
      setEditingId(null);
      setOpen(false);
      toast.success("Client updated");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("clients").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["clients"] });
      toast.success("Client deleted");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const startEdit = (c: (typeof clients)[number]) => {
    setEditingId(c.id);
    setOpen(true);
    setForm({
      account_number: c.account_number ?? "",
      name: c.name ?? "",
      contact_name: c.contact_name ?? "",
      billing_contact_phone: c.billing_contact_phone ?? "",
      billing_contact_email: c.billing_contact_email ?? "",
      booking_contact_name: c.booking_contact_name ?? "",
      booking_contact_phone: c.booking_contact_phone ?? "",
      booking_contact_email: c.booking_contact_email ?? "",
      email: c.email ?? "",
      phone: c.phone ?? "",
      address_line1: c.address_line1 ?? "",
      address_line2: c.address_line2 ?? "",
      terms: c.terms ?? "Due upon receipt",
      notify_reservation: c.notify_reservation ?? true,
      notify_driver_accepted: c.notify_driver_accepted ?? true,
      notify_ride_reminder: c.notify_ride_reminder ?? true,
      notify_invoice: c.notify_invoice ?? true,
      notify_payment: c.notify_payment ?? true,
    });
  };

  const closeForm = () => {
    setOpen(false);
    setEditingId(null);
    setForm(empty);
  };

  // Client records have no disabled state; every saved account is active.
  const clientIsActive = () => true;
  const q = search.trim().toLowerCase();
  const shownClients = clients
    .filter((c) =>
      !q ||
        [
          c.account_number,
          c.name,
          c.email,
          c.phone,
          c.contact_name,
          c.booking_contact_name,
          c.address_line1,
          c.address_line2,
        ]
          .filter(Boolean)
          .join(" ")
          .toLowerCase()
          .includes(q),
      )
    .filter(() => statusFilter === "all" || statusFilter === "active")
    .sort((a, b) => sortOrder === "account" ? (a.account_number ?? "").localeCompare(b.account_number ?? "", undefined, { numeric: true }) : a.name.localeCompare(b.name));

  const openInvoices = invoices.filter((invoice) => !invoice.paid_at);
  const outstandingBalance = openInvoices.reduce((total, invoice) => {
    const invoiceRides = reservations.filter((reservation) => reservation.invoice_id === invoice.id);
    const gross = invoiceRides.reduce(
      (sum, reservation) => sum + fareTotal(reservation, stops.filter((stop) => stop.reservation_id === reservation.id).length),
      0,
    );
    return total + Math.max(0, gross - Number(invoice.discount ?? 0) - Number(invoice.payments ?? 0));
  }, 0);
  const activeClients = clients.length;

  const frequentAddresses = (() => {
    if (!editingId) return [] as { address: string; count: number }[];
    const ids = new Set(reservations.filter((r) => r.client_id === editingId).map((r) => r.id));
    const counts = new Map<string, { address: string; count: number }>();
    const add = (raw: string | null | undefined) => {
      const address = (raw ?? "").trim();
      if (address.length < 4) return;
      const key = address.toLowerCase();
      const row = counts.get(key) ?? { address, count: 0 };
      row.count += 1;
      counts.set(key, row);
    };
    for (const r of reservations) {
      if (r.client_id !== editingId) continue;
      add(r.pickup_address);
      add(r.dropoff_address);
    }
    for (const s of stops) if (ids.has(s.reservation_id)) add(s.address);
    return [...counts.values()].filter((a) => a.count > 2).sort((a, b) => b.count - a.count);
  })();


  return (
    <div className="min-h-screen bg-dashboard-canvas px-3 py-5 font-admin-body sm:px-5 lg:px-7">
      <header className="mb-4 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="mb-1 text-xs font-bold uppercase tracking-[0.22em] text-dashboard-blue">Account book</p>
          <h1 className="font-admin-display text-3xl font-bold text-dashboard-navy sm:text-4xl">Clients</h1>
          <p className="mt-1 text-sm text-dashboard-muted">Group rides under an account to bill several trips on one invoice.</p>
        </div>
        <Button type="button" className="self-start sm:self-auto" onClick={() => (open ? closeForm() : setOpen(true))}>
          <Plus className="size-4" />{open ? "Close" : "New client"}
        </Button>
      </header>

      <section className="mb-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4" aria-label="Client account summary">
        <ClientStat icon={UsersRound} value={String(clients.length)} label="Total clients" tone="blue" />
        <ClientStat icon={UserRound} value={String(activeClients)} label="Active accounts" tone="green" />
        <ClientStat icon={FileText} value={String(openInvoices.length)} label="Open invoices" tone="amber" />
        <ClientStat icon={DollarSign} value={money(outstandingBalance)} label="Outstanding balance" tone="red" />
      </section>


      {open && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (editingId) update.mutate(editingId);
            else create.mutate();
          }}
          className="mb-4"
        >
          <div className="mb-5 flex flex-wrap items-center gap-3 rounded-xl border border-border bg-card p-5 shadow-sm">
            <div>
              <div className="font-cond text-[10px] uppercase tracking-[0.3em] text-brand">
                {editingId ? "Editing client" : "New client account"}
              </div>
              <div className="mt-1 font-cond text-lg text-foreground">
                {form.name || (editingId ? "Client" : "Blackwave account book")}
              </div>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <button
                type="button"
                onClick={closeForm}
                className="rounded-md border border-border px-4 py-2.5 font-cond text-xs uppercase tracking-[0.3em] text-muted-foreground"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={create.isPending || update.isPending}
                className="rounded-md bg-brand px-5 py-2.5 font-cond text-xs uppercase tracking-[0.3em] text-brand-foreground disabled:opacity-60"
              >
                {editingId ? "Save Changes" : "Save Client"}
              </button>
            </div>
          </div>

          <div className="grid items-start gap-5 md:grid-cols-2 xl:grid-cols-3">
            <div className="min-w-0 space-y-5">
              <FormSection index="01" title="Account">
                <Field label="Account #" value={form.account_number} placeholder="Auto" onChange={(v) => setForm({ ...form, account_number: v })} />
                <Field label="Client / company" value={form.name} required onChange={(v) => setForm({ ...form, name: v })} />
                <div>
                  <Field label="Account email" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} />
                  {form.email && (
                    <Link to="/inbox" search={{ client: form.email, folder: undefined, compose: undefined, open: undefined }} className="mt-1 inline-block text-xs text-primary underline">
                      View emails with this client
                    </Link>
                  )}
                </div>
                <PhoneField value={form.phone} onChange={(v) => setForm({ ...form, phone: v })} />
                <div>
                  <div className="mb-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">Terms</div>
                  <select
                    value={form.terms}
                    onChange={(e) => setForm({ ...form, terms: e.target.value })}
                    className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
                  >
                    {["Due upon receipt", "30 days", "60 days", "90 days", "180 days"].map((t) => (
                      <option key={t} value={t} className="bg-popover">
                        {t}
                      </option>
                    ))}
                  </select>
                </div>
              </FormSection>

              <FormSection index="02" title="Booking contact">
                <Field label="Booking contact name" value={form.booking_contact_name} onChange={(v) => setForm({ ...form, booking_contact_name: v })} />
                <Field label="Booking contact email" type="email" value={form.booking_contact_email} onChange={(v) => setForm({ ...form, booking_contact_email: v })} />
                <PhoneField value={form.booking_contact_phone} onChange={(v) => setForm({ ...form, booking_contact_phone: v })} />
              </FormSection>

              <FormSection index="03" title="Billing contact">
                <Field label="Billing contact name" value={form.contact_name} onChange={(v) => setForm({ ...form, contact_name: v })} />
                <Field label="Billing contact email" type="email" value={form.billing_contact_email} onChange={(v) => setForm({ ...form, billing_contact_email: v })} />
                <PhoneField value={form.billing_contact_phone} onChange={(v) => setForm({ ...form, billing_contact_phone: v })} />
              </FormSection>
            </div>

            <div className="min-w-0 space-y-5">
              <FormSection index="04" title="Billing address">
                <AddressField label="Address line 1" value={form.address_line1} placeholder="Search address" onChange={(v) => setForm({ ...form, address_line1: v })} />
                <Field label="Address line 2" value={form.address_line2} onChange={(v) => setForm({ ...form, address_line2: v })} />
              </FormSection>

              <FormSection index="05" title="Frequently used addresses">
                {!editingId && (
                  <p className="font-cond text-xs text-muted-foreground">
                    Addresses used on three or more rides are collected here automatically once this client starts booking.
                  </p>
                )}
                {editingId && (
                  <>
                    {frequentAddresses.length === 0 ? (
                      <p className="font-cond text-xs text-muted-foreground">
                        No address has been used three times yet for this client.
                      </p>
                    ) : (
                      <div className="divide-y divide-border">
                        {frequentAddresses.map((a) => (
                          <div key={a.address} className="flex items-start gap-3 py-2">
                            <span className="min-w-0 flex-1 break-words font-cond text-sm text-foreground">{a.address}</span>
                            <span className="shrink-0 rounded-full bg-brand/10 px-2 py-0.5 font-cond text-[10px] uppercase tracking-widest text-brand">
                              {a.count}×
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                void navigator.clipboard?.writeText(a.address);
                                toast.success("Address copied");
                              }}
                              className="shrink-0 rounded-md border border-border px-2 py-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground hover:text-foreground"
                            >
                              Copy
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                    <p className="font-cond text-xs text-muted-foreground">
                      Saved automatically from this client&apos;s pickups, stops and drop-offs.
                    </p>
                  </>
                )}
              </FormSection>

              <FormSection index="06" title="Email confirmations">
                <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                  Send this client an email when
                </div>
                <div className="grid gap-2">
                  {NOTIFY_OPTIONS.map((o) => (
                    <label key={o.key} className="flex items-start gap-2 font-cond text-sm text-foreground">
                      <input
                        type="checkbox"
                        checked={form[o.key]}
                        onChange={(e) => setForm({ ...form, [o.key]: e.target.checked })}
                        className="mt-1 h-4 w-4 accent-brand"
                      />
                      <span>{o.label}</span>
                    </label>
                  ))}
                </div>
              </FormSection>
            </div>

            <div className="min-w-0 space-y-5">
              <FormSection index="07" title="Frequent passengers">
                {editingId && (
                  <>
                    <div className="divide-y divide-border">
                      {passengers
                        .filter((p) => p.client_id === editingId)
                        .map((p) => (
                          <div key={p.id} className="flex flex-wrap items-center gap-2 py-2 font-cond text-sm">
                            <span className="min-w-32">{p.full_name}</span>
                            <span className="text-muted-foreground">{p.phone || "—"}</span>
                            <span className="text-muted-foreground">{p.email || "—"}</span>
                            <button
                              type="button"
                              onClick={() => {
                                setEditingPassengerId(p.id);
                                setPassengerForm({
                                  full_name: p.full_name,
                                  phone: p.phone ?? "",
                                  email: p.email ?? "",
                                  notes: p.notes ?? "",
                                });
                              }}
                              className="ml-auto rounded-md border border-border px-3 py-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground hover:text-foreground"
                            >
                              Edit
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                if (editingPassengerId === p.id) {
                                  setEditingPassengerId(null);
                                  setPassengerForm(emptyPassenger);
                                }
                                removePassenger.mutate(p.id);
                              }}
                              className="rounded-md border border-destructive/50 px-3 py-1 font-cond text-[10px] uppercase tracking-widest text-destructive"
                            >
                              Remove
                            </button>
                          </div>
                        ))}
                      {passengers.filter((p) => p.client_id === editingId).length === 0 && (
                        <div className="py-2 font-cond text-sm text-muted-foreground">
                          No passengers saved for this client yet.
                        </div>
                      )}
                    </div>
                    <Field label="Passenger name" value={passengerForm.full_name} onChange={(v) => setPassengerForm({ ...passengerForm, full_name: v })} />
                    <PhoneField value={passengerForm.phone} onChange={(v) => setPassengerForm({ ...passengerForm, phone: v })} />
                    <Field label="Email" type="email" value={passengerForm.email} onChange={(v) => setPassengerForm({ ...passengerForm, email: v })} />
                    <Field label="Notes" value={passengerForm.notes} placeholder="Preferences" onChange={(v) => setPassengerForm({ ...passengerForm, notes: v })} />
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        disabled={savePassenger.isPending || updatePassenger.isPending}
                        onClick={() => {
                          if (!passengerForm.full_name.trim()) {
                            toast.error("Passenger name is required");
                            return;
                          }
                          if (editingPassengerId) updatePassenger.mutate(editingPassengerId);
                          else savePassenger.mutate(editingId);
                        }}
                        className="rounded-md bg-brand px-5 py-2.5 font-cond text-xs uppercase tracking-[0.3em] text-brand-foreground disabled:opacity-60"
                      >
                        {editingPassengerId ? "Save passenger" : "Add passenger"}
                      </button>
                      {editingPassengerId && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditingPassengerId(null);
                            setPassengerForm(emptyPassenger);
                          }}
                          className="rounded-md border border-border px-4 py-2.5 font-cond text-xs uppercase tracking-[0.3em] text-muted-foreground"
                        >
                          Cancel
                        </button>
                      )}
                    </div>
                  </>
                )}

                {!editingId && (
                  <>
                    {draftPassengers.length > 0 && (
                      <div className="divide-y divide-border">
                        {draftPassengers.map((p, i) => (
                          <div key={i} className="flex flex-wrap items-center gap-2 py-2 font-cond text-sm">
                            <span className="min-w-32">{p.full_name}</span>
                            <span className="text-muted-foreground">{p.phone || "—"}</span>
                            <span className="text-muted-foreground">{p.email || "—"}</span>
                            <button
                              type="button"
                              onClick={() => setDraftPassengers(draftPassengers.filter((_, j) => j !== i))}
                              className="ml-auto rounded-md border border-destructive/50 px-3 py-1 font-cond text-[10px] uppercase tracking-widest text-destructive"
                            >
                              Remove
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                    <Field label="Passenger name" value={draftPassenger.full_name} onChange={(v) => setDraftPassenger({ ...draftPassenger, full_name: v })} />
                    <PhoneField value={draftPassenger.phone} onChange={(v) => setDraftPassenger({ ...draftPassenger, phone: v })} />
                    <Field label="Email" type="email" value={draftPassenger.email} onChange={(v) => setDraftPassenger({ ...draftPassenger, email: v })} />
                    <Field label="Notes" value={draftPassenger.notes} placeholder="Preferences" onChange={(v) => setDraftPassenger({ ...draftPassenger, notes: v })} />
                    <button
                      type="button"
                      onClick={() => {
                        if (!draftPassenger.full_name.trim()) {
                          toast.error("Passenger name is required");
                          return;
                        }
                        setDraftPassengers([...draftPassengers, draftPassenger]);
                        setDraftPassenger(emptyPassenger);
                      }}
                      className="rounded-md border border-border px-4 py-2.5 font-cond text-xs uppercase tracking-[0.3em] text-foreground"
                    >
                      Add passenger
                    </button>
                    <p className="font-cond text-xs text-muted-foreground">
                      Add as many passengers as you need — they are saved with the client.
                    </p>
                  </>
                )}
              </FormSection>

              {editingId && (
                <FormSection index="08" title="Billing history">
                  {(() => {
                    const clientInvoices = (invoices as any[]).filter((i) => i.client_id === editingId);
                    if (clientInvoices.length === 0)
                      return (
                        <p className="font-cond text-sm text-muted-foreground">No invoices yet for this client.</p>
                      );
                    return (
                      <div className="overflow-x-auto rounded-md border border-border">
                        <table className="w-full">
                          <thead>
                            <tr className="border-b border-border font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                              <th className="px-3 py-2 text-left">Statement #</th>
                              <th className="px-3 py-2 text-left">Created</th>
                              <th className="px-3 py-2 text-right">Amount</th>
                              <th className="px-3 py-2 text-right">Status</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-border font-cond text-sm">
                            {clientInvoices.map((inv) => {
                              const rides = (reservations as any[]).filter((r) => r.invoice_id === inv.id);
                              const gross = rides.reduce(
                                (sum, r) =>
                                  sum + fareTotal(r, (stops as any[]).filter((s) => s.reservation_id === r.id).length),
                                0,
                              );
                              const amount = gross - Number(inv.discount ?? 0);
                              const paid = Boolean(inv.paid_at);
                              return (
                                <tr key={inv.id}>
                                  <td className="px-3 py-2 tabular-nums">
                                    <a href={`/invoices/${inv.id}`} className="text-brand underline-offset-2 hover:underline">
                                      {inv.invoice_number}
                                    </a>
                                  </td>
                                  <td className="px-3 py-2 text-muted-foreground">
                                    {new Date(inv.created_at).toLocaleDateString("en-US", {
                                      month: "short",
                                      day: "numeric",
                                      year: "numeric",
                                    })}
                                  </td>
                                  <td className="px-3 py-2 text-right tabular-nums">{money(amount)}</td>
                                  <td className="px-3 py-2 text-right">
                                    <span
                                      className={`rounded-full px-2 py-0.5 font-cond text-[10px] uppercase tracking-widest ${
                                        paid ? "bg-green-500/15 text-green-500" : "bg-amber-500/15 text-amber-500"
                                      }`}
                                    >
                                      {paid ? "Paid" : "Unpaid"}
                                    </span>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    );
                  })()}
                </FormSection>
              )}
            </div>
          </div>
        </form>
      )}


      <section className="mb-4 rounded-md border border-dashboard-line bg-background p-3 shadow-sm">
        <div className="mb-3 grid gap-2 md:grid-cols-[minmax(280px,1fr)_180px_180px]">
          <div className="relative"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-dashboard-muted" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search clients by account #, name, email, phone or address…" className="h-10 w-full rounded-md border border-dashboard-line bg-background pl-9 pr-3 text-sm text-dashboard-navy outline-none focus:border-dashboard-blue" /></div>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)} className="h-10 rounded-md border border-dashboard-line bg-background px-3 text-sm text-dashboard-navy"><option value="all">All statuses</option><option value="active">Active</option><option value="inactive">Inactive</option></select>
          <select value={sortOrder} onChange={(e) => setSortOrder(e.target.value as typeof sortOrder)} className="h-10 rounded-md border border-dashboard-line bg-background px-3 text-sm text-dashboard-navy"><option value="name">Name (A–Z)</option><option value="account">Account number</option></select>
        </div>
        <div className="overflow-x-auto">
        <table className="w-full min-w-[920px] table-fixed">
          <thead>
            <tr className="bg-dashboard-ice text-[10px] font-bold uppercase text-dashboard-muted">
              <th className="w-[9%] px-3 py-3 text-left">Acct #</th>
              <th className="w-[19%] px-3 py-3 text-left">Client</th>
              <th className="w-[22%] px-3 py-3 text-left">Address</th>
              <th className="w-[20%] px-3 py-3 text-left">Contact</th>
              <th className="w-[10%] px-3 py-3 text-left">Status</th>
              <th className="w-[20%] px-3 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-dashboard-line text-sm">
            {shownClients.map((c) => {
              const active = clientIsActive();
              const initials = c.name.split(/\s+/).slice(0, 2).map((word) => word[0]).join("").toUpperCase();
              return (
              <tr key={c.id} className="transition-colors hover:bg-dashboard-canvas/60">
                <td className="px-3 py-3 tabular-nums">
                  <Button
                    type="button"
                    variant="link"
                    onClick={() => {
                      startEdit(c);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    className="h-auto p-0 font-semibold tabular-nums text-dashboard-blue underline"
                  >
                    {c.account_number}
                  </Button>
                </td>
                <td className="px-3 py-3"><div className="flex items-center gap-2"><span className="grid size-9 shrink-0 place-items-center rounded-full bg-dashboard-soft text-xs font-bold text-dashboard-navy">{initials || "—"}</span><span className="font-semibold text-dashboard-navy">{c.name}</span></div></td>
                <td className="px-3 py-3 text-dashboard-muted">
                  <div className="flex max-w-72 items-start gap-2"><MapPin className="mt-0.5 size-4 shrink-0 text-dashboard-navy" /><span>{[c.address_line1, c.address_line2].filter(Boolean).join(", ") || "—"}</span></div>
                </td>
                <td className="px-3 py-3 text-dashboard-muted"><div className="space-y-1 break-words">{c.phone && <div className="flex items-center gap-2"><Phone className="size-4 shrink-0 text-dashboard-navy" />{c.phone}</div>}{c.email && <div className="flex items-center gap-2"><Mail className="size-4 shrink-0 text-dashboard-navy" />{c.email}</div>}{!c.phone && !c.email && "—"}</div></td>
                <td className="px-3 py-3"><span className={`rounded-md px-2.5 py-1 text-xs font-semibold ${active ? "bg-dashboard-green/12 text-dashboard-green" : "bg-dashboard-soft text-dashboard-muted"}`}>{active ? "Active" : "Inactive"}</span></td>
                <td className="px-3 py-3">
                  <div className="ml-auto grid w-full max-w-52 grid-cols-2 gap-1.5">
                    <Button type="button" variant="outline" size="sm"
                      onClick={() => {
                        setPassengerForm(emptyPassenger);
                        setPassengerFor(passengerFor === c.id ? null : c.id);
                      }}
                      className="text-dashboard-blue"><UsersRound />Passengers</Button>
                    <Button type="button" variant="outline" size="sm" onClick={() => startEdit(c)}><Pencil />Edit</Button>
                    <Button type="button" variant="outline" size="sm"
                      onClick={() => { setRateForm(emptyRate); setRateFor(rateFor === c.id ? null : c.id); }} className="text-dashboard-blue"><Tag />Prices</Button>
                    <Button type="button" variant="outline" size="sm" onClick={() => setPortalFor(portalFor === c.id ? null : c.id)} className="text-dashboard-blue"><ExternalLink />Portal</Button>
                    <Button type="button" variant="outline" size="sm" onClick={() => setCardsFor(cardsFor === c.id ? null : c.id)} className="text-dashboard-blue"><CreditCard />Cards</Button>
                    <Button type="button" variant="outline" size="sm"
                      onClick={() => {
                        const rides = reservations.filter((r) => r.client_id === c.id).length;
                        if (rides > 0) {
                          toast.error(`${c.name} has ${rides} ride(s) booked — remove or reassign them first.`);
                          return;
                        }
                        if (window.confirm(`Delete ${c.name}? This cannot be undone.`)) remove.mutate(c.id);
                      }}
                      disabled={remove.isPending}
                      className="border-destructive/40 text-destructive"><Trash2 />Delete</Button>
                  </div>
                </td>
              </tr>
            );})}
            {shownClients.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-dashboard-muted">No client accounts match these filters.</td>
              </tr>
            )}
          </tbody>
        </table>
        </div>
        <div className="flex items-center justify-between border-t border-dashboard-line px-2 pt-3 text-xs text-dashboard-muted"><span>Showing {shownClients.length} of {clients.length} clients</span><span>Page 1</span></div>
      </section>

      {portalFor && (
        <div className="mx-6 mb-10">
          <ClientPortalAccess
            clientId={portalFor}
            clientName={clients.find((c) => c.id === portalFor)?.name ?? ""}
          />
        </div>
      )}

      {cardsFor && (
        <div className="mx-6 mb-10">
          <div className="mb-2 font-cond text-[11px] uppercase tracking-[0.3em] text-brand">
            Cards on file — {clients.find((c) => c.id === cardsFor)?.name}
          </div>
          <CardsOnFile clientId={cardsFor} staff />
        </div>
      )}

      {passengerFor && (
        <div id="passenger-panel" className="plate mx-6 mb-10 rounded-lg border border-border p-5">
          <div className="font-cond text-[11px] uppercase tracking-[0.3em] text-brand">

            Frequent passengers — {clients.find((c) => c.id === passengerFor)?.name}
          </div>
          <div className="mt-4 divide-y divide-border">
            {passengers
              .filter((p) => p.client_id === passengerFor)
              .map((p) => (
                <div key={p.id} className="flex flex-wrap items-center gap-3 py-2 font-cond text-sm">
                  <span className="min-w-40">{p.full_name}</span>
                  <span className="text-muted-foreground">{p.phone || "—"}</span>
                  <span className="text-muted-foreground">{p.email || "—"}</span>
                  {p.notes && <span className="text-muted-foreground">{p.notes}</span>}
                  <button
                    onClick={() => {
                      setEditingPassengerId(p.id);
                      setPassengerForm({
                        full_name: p.full_name,
                        phone: p.phone ?? "",
                        email: p.email ?? "",
                        notes: p.notes ?? "",
                      });
                    }}
                    className="ml-auto rounded-md border border-border px-3 py-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground hover:text-foreground"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => {
                      if (editingPassengerId === p.id) {
                        setEditingPassengerId(null);
                        setPassengerForm(emptyPassenger);
                      }
                      removePassenger.mutate(p.id);
                    }}
                    className="rounded-md border border-destructive/50 px-3 py-1 font-cond text-[10px] uppercase tracking-widest text-destructive"
                  >
                    Remove
                  </button>
                </div>
              ))}
            {passengers.filter((p) => p.client_id === passengerFor).length === 0 && (
              <div className="py-2 font-cond text-sm text-muted-foreground">No passengers saved for this client yet.</div>
            )}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (editingPassengerId) updatePassenger.mutate(editingPassengerId);
              else savePassenger.mutate(passengerFor);
            }}
            className="mt-4 grid gap-3 md:grid-cols-5"
          >
            <Field label="Passenger name" value={passengerForm.full_name} required onChange={(v) => setPassengerForm({ ...passengerForm, full_name: v })} />
            <PhoneField value={passengerForm.phone} onChange={(v) => setPassengerForm({ ...passengerForm, phone: v })} />
            <Field label="Email" type="email" value={passengerForm.email} onChange={(v) => setPassengerForm({ ...passengerForm, email: v })} />
            <Field label="Notes" value={passengerForm.notes} onChange={(v) => setPassengerForm({ ...passengerForm, notes: v })} placeholder="Preferences" />
            <button
              type="submit"
              disabled={savePassenger.isPending || updatePassenger.isPending}
              className="self-end rounded-md bg-brand px-5 py-2.5 font-cond text-xs uppercase tracking-[0.3em] text-brand-foreground disabled:opacity-60"
            >
              {editingPassengerId ? "Save passenger" : "Add passenger"}
            </button>
            {editingPassengerId && (
              <button
                type="button"
                onClick={() => {
                  setEditingPassengerId(null);
                  setPassengerForm(emptyPassenger);
                }}
                className="self-end rounded-md border border-border px-4 py-2.5 font-cond text-xs uppercase tracking-[0.3em] text-muted-foreground"
              >
                Cancel
              </button>
            )}
          </form>
        </div>
      )}

      {rateFor && (
        <div className="plate mx-6 mb-10 rounded-lg border border-border p-5">
          <div className="font-cond text-[11px] uppercase tracking-[0.3em] text-brand">
            Price list — {clients.find((c) => c.id === rateFor)?.name}
          </div>
          <div className="mt-4 divide-y divide-border">
            {rates
              .filter((r) => r.client_id === rateFor)
              .map((r) => (
                <div key={r.id} className="flex flex-wrap items-center gap-3 py-2 font-cond text-sm">
                  <span className="min-w-40">{r.label}</span>
                  <span className="text-muted-foreground">{r.vehicle_class}</span>
                  <span className="text-muted-foreground">
                    {r.rate_type === "hourly" ? `${money(Number(r.amount))} / hr (min ${r.minimum_hours}h)` : money(Number(r.amount))}
                  </span>
                  {r.notes && <span className="text-muted-foreground">{r.notes}</span>}
                  <button
                    onClick={() => removeRate.mutate(r.id)}
                    className="ml-auto rounded-md border border-destructive/50 px-3 py-1 font-cond text-[10px] uppercase tracking-widest text-destructive"
                  >
                    Remove
                  </button>
                </div>
              ))}
            {rates.filter((r) => r.client_id === rateFor).length === 0 && (
              <div className="py-2 font-cond text-sm text-muted-foreground">No prices saved for this client yet.</div>
            )}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              saveRate.mutate(rateFor);
            }}
            className="mt-4 grid gap-3 md:grid-cols-6"
          >
            <Field label="Name" value={rateForm.label} required onChange={(v) => setRateForm({ ...rateForm, label: v })} placeholder="JFK transfer" />
            <div>
              <div className="mb-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">Type</div>
              <select
                value={rateForm.rate_type}
                onChange={(e) => setRateForm({ ...rateForm, rate_type: e.target.value })}
                className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
              >
                <option value="flat">Flat rate</option>
                <option value="hourly">Hourly</option>
              </select>
            </div>
            <Field label="Amount" type="number" value={rateForm.amount} onChange={(v) => setRateForm({ ...rateForm, amount: v })} />
            <div>
              <div className="mb-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">Vehicle</div>
              <select
                value={rateForm.vehicle_class}
                onChange={(e) => setRateForm({ ...rateForm, vehicle_class: e.target.value })}
                className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
              >
                {VEHICLE_CLASSES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <Field label="Min hours" type="number" value={rateForm.minimum_hours} onChange={(v) => setRateForm({ ...rateForm, minimum_hours: v })} />
            <button
              type="submit"
              disabled={saveRate.isPending}
              className="self-end rounded-md bg-brand px-5 py-2.5 font-cond text-xs uppercase tracking-[0.3em] text-brand-foreground disabled:opacity-60"
            >
              Add price
            </button>
          </form>

          <PriceMap key={rateFor} clientId={rateFor} clientName={clients.find((c) => c.id === rateFor)?.name ?? ""} />
        </div>
      )}
    </div>
  );
}

function ClientStat({ icon: Icon, value, label, tone }: { icon: typeof UsersRound; value: string; label: string; tone: "blue" | "green" | "amber" | "red" }) {
  const colors = tone === "green" ? "bg-dashboard-green/10 text-dashboard-green" : tone === "amber" ? "bg-dashboard-amber/12 text-dashboard-amber" : tone === "red" ? "bg-dashboard-red/10 text-dashboard-red" : "bg-dashboard-ice text-dashboard-blue";
  return <div className="flex min-h-20 items-center gap-4 rounded-md border border-dashboard-line bg-background p-4 shadow-sm"><div className={`grid size-11 shrink-0 place-items-center rounded-full ${colors}`}><Icon className="size-5" /></div><div><p className="font-admin-display text-2xl font-bold text-dashboard-navy">{value}</p><p className={`text-sm font-medium ${colors.split(" ").at(-1)}`}>{label}</p></div></div>;
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
  placeholder?: string;
}) {
  return (
    <div>
      <div className="mb-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <input
        type={type}
        value={value}
        required={required}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground outline-none placeholder:text-muted-foreground focus:border-brand/60"
      />
    </div>
  );
}

function FormSection({
  index,
  title,
  children,
}: {
  index: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="w-full rounded-xl border border-border bg-card p-5 shadow-sm">
      <div className="mb-4 flex items-center gap-2">
        <span className="inline-flex h-6 w-6 items-center justify-center rounded bg-brand/10 font-cond text-[10px] text-brand">
          {index}
        </span>
        <h3 className="font-cond text-[11px] uppercase tracking-[0.3em] text-foreground">{title}</h3>
      </div>
      <div className="grid gap-3">{children}</div>
    </section>
  );
}
