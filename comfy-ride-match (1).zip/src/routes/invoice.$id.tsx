import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { InvoiceShare } from "@/components/InvoiceShare";
import { PayOptions } from "@/components/PayOptions";
import { PayByCardLink } from "@/components/PayByCardLink";
import { SendReceiptButton } from "@/components/SendReceiptButton";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { sendDriverAssignmentEmail } from "@/lib/driver-notify.functions";
import { sendRideInvoiceEmail } from "@/lib/invoice-notify.functions";

import {
  billableHours,
  clockTime,
  dayLabel,
  fareTotal,
  money,
  passengerNames,
  reservationsQuery,
  rideCharge,
  stopCharge,
  stopsQuery,
  waitingCharge,
  driversQuery,
  vehiclesQuery,
  type Reservation,
} from "@/lib/dispatch";

export const Route = createFileRoute("/invoice/$id")({
  head: () => ({
    meta: [
      { title: "Billing Statement — Blackwave Transportation LLC" },
      {
        name: "description",
        content: "Printable chauffeur service invoice with route, vehicle class and full fare breakdown.",
      },
      { property: "og:title", content: "Billing Statement — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Issue, print and email a branded invoice for any chauffeur reservation.",
      },
    ],
  }),
  component: () => (
    <AppShell>
      <InvoicePage />
    </AppShell>
  ),
});

const COMPANY = {
  name: "Blackwave Transportation LLC",
  line1: "52 Meredith Avenue",
  line2: "Staten Island, NY 10314",
  contact: "Tel: (917) 325-3211",
  email: "info@rideblackwave.com",
  website: "www.rideblackwave.com",
};

function InvoicePage() {
  const { id } = Route.useParams();
  const qc = useQueryClient();
  const { data: reservations = [], isLoading } = useQuery(reservationsQuery);
  const { data: drivers = [] } = useQuery(driversQuery);
  const { data: vehicles = [] } = useQuery(vehiclesQuery);
  const { data: stops = [] } = useQuery(stopsQuery);
  const reservation = reservations.find((r) => r.id === id);

  const notifyDriver = useServerFn(sendDriverAssignmentEmail);
  const emailInvoiceFn = useServerFn(sendRideInvoiceEmail);

  const emailInvoice = useMutation({
    mutationFn: async () => emailInvoiceFn({ data: { reservationId: id } }),
    onSuccess: (res) => {
      qc.invalidateQueries({ queryKey: ["reservations"] });
      if (res?.sent) toast.success("Invoice emailed to the client");
      else if (res?.reason === "no_client_email") toast.error("No email address on file for this client");
      else toast.error("Invoice could not be emailed", { description: res?.reason });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const patch = useMutation({
    mutationFn: async (values: Partial<Reservation>) => {
      const { error } = await supabase.from("reservations").update(values).eq("id", id);
      if (error) throw error;
      if (!("driver_id" in values) || !values.driver_id) return { notified: null as null | { sent: boolean; reason?: string } };
      return { notified: await notifyDriver({ data: { reservationId: id } }) };
    },
    onSuccess: (res) => {
      qc.invalidateQueries({ queryKey: ["reservations"] });
      const n = res?.notified;
      if (n?.sent) toast.success("Chauffeur assigned — confirmation email sent");
      else if (n && n.reason === "no_driver_email") toast.success("Chauffeur assigned (no email on file)");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (isLoading) {
    return (
      <div className="px-6 py-16 font-cond text-xs uppercase tracking-[0.4em] text-muted-foreground">
        Loading invoice
      </div>
    );
  }

  if (!reservation) {
    return (
      <div className="px-6 py-16">
        <h1 className="font-display text-4xl uppercase">Billing statement not found</h1>
        <Link to="/reservations" className="mt-4 inline-block font-cond text-xs uppercase tracking-widest text-brand">
          Back to reservations
        </Link>
      </div>
    );
  }

  const r = reservation;
  const number = r.invoice_number ?? `INV-${r.reference}`;
  const issued = r.invoice_issued_at ?? new Date().toISOString();
  const driver = drivers.find((d) => d.id === r.driver_id);
  const vehicle = vehicles.find((v) => v.id === r.vehicle_id);
  const rideStops = stops.filter((s) => s.reservation_id === r.id);
  const total = fareTotal(r, rideStops.length);

  const lines = [
    { label: "Base rate", amount: Number((r as any).base_rate ?? 0) },
    {
      label:
        r.booking_type === "hourly"
          ? `Hourly chauffeur service — ${r.vehicle_class} · ${billableHours(r)} hr @ ${money(Number(r.hourly_rate))}/hr`
          : `Flat rate — chauffeur service · ${r.vehicle_class}`,
      amount: rideCharge(r),
    },
    {
      label: `Waiting time (${Number(r.waiting_minutes ?? 0)} min @ ${money(Number(r.waiting_rate ?? 0))}/hr)`,
      amount: waitingCharge(r),
    },
    { label: `Extra stops (${rideStops.length})`, amount: stopCharge(r, rideStops.length) },
    { label: "Airport fee", amount: Number(r.airport_fee) },
    { label: "Meet & greet", amount: Number(r.meet_greet_fee ?? 0) },
    { label: "Parking fee", amount: Number(r.parking_fee ?? 0) },
    { label: "Tolls", amount: Number(r.tolls) },
    { label: "Gratuity", amount: Number(r.gratuity) },
  ].filter((l, i) => i <= 1 || l.amount > 0);

  return (
    <>
      <div className="no-print flex flex-wrap items-center gap-3 border-b border-border px-6 py-4">
        <Link to="/reservations" className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground hover:text-brand">
          ← Ledger
        </Link>
        <Link
          to="/reservations"
          search={{ edit: r.id }}
          className="rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest hover:border-brand hover:text-brand"
        >
          Edit ride
        </Link>
        <label className="flex items-center gap-2 font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
          Chauffeur
          <select
            value={r.driver_id ?? ""}
            onChange={(e) => patch.mutate({ driver_id: e.target.value || null })}
            className="rounded-md border border-border bg-background px-2 py-1.5 font-cond text-xs"
          >
            <option value="">Unassigned</option>
            {drivers.map((d) => (
              <option key={d.id} value={d.id}>
                {d.full_name}
              </option>
            ))}
          </select>
        </label>
        {r.driver_id && (
          <button
            onClick={() => patch.mutate({ driver_id: null })}
            className="font-cond text-[11px] uppercase tracking-widest text-destructive underline underline-offset-4 hover:opacity-80"
          >
            Remove driver
          </button>
        )}


        <div className="ml-auto flex flex-wrap items-center gap-2">
          {!r.invoice_issued_at && (
            <button
              onClick={() =>
                patch.mutate({ invoice_number: number, invoice_issued_at: new Date().toISOString() })
              }
              className="rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-foreground hover:border-brand hover:text-brand"
            >
              Issue invoice
            </button>
          )}
          {!r.invoice_paid_at ? (
            <button
              onClick={() => patch.mutate({ invoice_paid_at: new Date().toISOString() })}
              className="rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-foreground hover:border-brand hover:text-brand"
            >
              Mark paid
            </button>
          ) : (
            <button
              onClick={() => patch.mutate({ invoice_paid_at: null })}
              className="rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-muted-foreground"
            >
              Undo paid
            </button>
          )}
          <button
            onClick={() => emailInvoice.mutate()}
            disabled={emailInvoice.isPending}
            className="rounded-md border border-border px-4 py-2 font-cond text-[11px] uppercase tracking-widest hover:border-brand hover:text-brand disabled:opacity-50"
          >
            {emailInvoice.isPending ? "Sending…" : "Email client"}
          </button>
          <PayOptions
            target="reservation"
            id={r.id}
            amount={total}
            paid={Boolean(r.invoice_paid_at)}
            label="Pay"
          />
          <SendReceiptButton target="reservation" id={r.id} paid={Boolean(r.invoice_paid_at)} />
          <InvoiceShare number={number} />
          <button
            onClick={() => window.print()}
            className="rounded-md bg-brand px-5 py-2 font-cond text-[11px] uppercase tracking-widest text-brand-foreground"
          >
            Print / Save PDF
          </button>
        </div>
      </div>

      <article className="invoice-sheet tpl-azure mx-auto my-8 w-full max-w-[1400px] rounded-lg border border-border bg-card p-10">
        <header className="invoice-head flex items-start justify-between border-b border-border pb-6">
          <div>
            <div className="font-display text-3xl uppercase leading-none tracking-wider">{COMPANY.name}</div>
            <div className="mt-3 font-cond text-base leading-relaxed tracking-wide text-foreground">
              {COMPANY.line1}
              <br />
              {COMPANY.line2}
              <br />
              {COMPANY.contact}
              <br />
              {COMPANY.email}
              <br />
              {COMPANY.website}
            </div>
          </div>
          <div className="text-right">
            <div className="font-display text-3xl uppercase leading-none text-brand">Billing Statement</div>
            <div className="mt-2 font-cond text-sm tracking-wide text-foreground">
              <div>Statement #{number}</div>
              <div className="text-muted-foreground">Issued {dayLabel(issued)}</div>
              <div>Due date: {r.invoice_paid_at ? `Paid ${dayLabel(r.invoice_paid_at)}` : dayLabel(issued)}</div>
            </div>
          </div>
        </header>
        {r.invoice_paid_at && (
          <div className="mt-6 rounded-md border border-emerald-600/40 bg-emerald-50 px-5 py-3 text-center">
            <div className="font-display text-2xl uppercase tracking-wider text-emerald-700">Paid in full</div>
            <div className="font-cond text-sm text-emerald-800">Thank you for your payment.</div>
          </div>
        )}


        <section className="grid gap-6 border-b border-border py-6 sm:grid-cols-3">
          <div className="invoice-billto">
            <Label>Bill to</Label>
            <div className="font-cond text-sm">{r.passenger_name}</div>
            {r.passenger_email && <div className="font-cond text-sm text-muted-foreground">{r.passenger_email}</div>}
            {r.passenger_phone && <div className="font-cond text-sm text-muted-foreground">{r.passenger_phone}</div>}
          </div>
          <div className="invoice-card">
            <Label>Statement #</Label>
            <div className="font-cond text-sm font-semibold">{number}</div>
            <Label>Issued</Label>
            <div className="font-cond text-sm text-muted-foreground">{dayLabel(issued)}</div>
          </div>
          <div className="invoice-card">
            <Label>Trips</Label>
            <div className="font-display text-3xl leading-none">1</div>
          </div>
        </section>

        <section className="py-6">
          <Label>Trip details</Label>
          <div className="invoice-detail-grid grid grid-cols-2 md:grid-cols-4">
            <Detail label="Date" value={dayLabel(r.pickup_at)} />
            <Detail label="Pickup time" value={clockTime(r.pickup_at)} />
            <Detail label="Drop-off time" value={r.dropoff_at ? clockTime(r.dropoff_at) : "—"} />
            <Detail label="Passenger" value={passengerNames(r)} />
            <div className="invoice-route md:col-span-4">
              <Label>Full route</Label>
              <div className="font-cond text-sm">
                {[r.pickup_address, ...rideStops.map((s) => s.address), r.dropoff_address].join(" → ")}
              </div>
            </div>
          </div>

          <div className="mt-6">
            <Label>Charges</Label>
            <div className="invoice-charge-grid grid grid-cols-2 md:grid-cols-4">
              {lines.filter((line) => line.amount > 0).map((line) => (
                <Detail key={line.label} label={line.label} value={money(line.amount)} />
              ))}
            </div>
          </div>
        </section>

        <section className="mt-8 grid gap-6 md:grid-cols-2">
          <div className="invoice-card font-cond text-sm">
            <Label>Payment methods</Label>
            <Row label="Zelle" value="917-325-3211" />
            <Row label="ACH" value="Chase Bank · Account # 507675562 · Routing # 021000021" />
            <Row label="Venmo" value="@nuwanusa" />
            <Row label="Cash App" value="$blackwavelimo" />
          </div>
          <div className="invoice-summary font-cond text-sm">
            <Row label="Subtotal" value={money(total)} />
            <Row label="Discount" value={money(0)} />
            <Row label="Payments" value={money(r.invoice_paid_at ? total : 0)} />
            <div className="invoice-total mt-3 flex items-center justify-between">
              <span className="font-cond text-xs uppercase tracking-widest">Total due</span>
              <span className="font-display text-3xl tabular-nums">{money(r.invoice_paid_at ? 0 : total)}</span>
            </div>
          </div>
        </section>

        {r.notes && (
          <p className="border-t border-border pt-6 font-cond text-sm text-muted-foreground">{r.notes}</p>
        )}
        <div className="mt-6 border-t border-border pt-4 text-center font-cond text-sm text-muted-foreground">
          <p>Thank you for choosing BlackWave Transportation. We appreciate your business and look forward to serving you again.</p>
          <p className="mt-1">For reservations or inquiries, please contact us at info@rideblackwave.com.</p>
        </div>
        <PayByCardLink target="reservation" id={r.id} amount={total} paid={Boolean(r.invoice_paid_at)} />

      </article>
    </>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-6 border-b border-border py-2 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="max-w-[70%] text-right font-semibold tabular-nums">{value}</span>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div className="invoice-detail-cell">
      <Label>{label}</Label>
      <div className="font-cond text-sm font-semibold">{value}</div>
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-1 font-cond text-[10px] uppercase tracking-widest text-brand">{children}</div>
  );
}
