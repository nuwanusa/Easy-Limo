import { useMemo, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AppShell, PageHeading } from "@/components/AppShell";
import { MoneyTabs } from "@/components/MoneyTabs";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { sendClientInvoiceEmail } from "@/lib/invoice-notify.functions";
import {
  clientsQuery,
  clockTime,
  dayLabel,
  fareTotal,
  groupStops,
  invoicesQuery,
  money,
  reservationsQuery,
  stopsQuery,
} from "@/lib/dispatch";

export const Route = createFileRoute("/invoices/")({
  head: () => ({
    meta: [
      { title: "Billing Statements — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Consolidated chauffeur invoices: bundle every ride a client took in a billing period onto one numbered invoice with a grand total.",
      },
      { property: "og:title", content: "Billing Statements — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Build multi-trip invoices per client account, then issue, print and mark them paid.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AppShell>
      <InvoicesPage />
    </AppShell>
  ),
});

function InvoicesPage() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { data: invoices = [] } = useQuery(invoicesQuery);
  const { data: clients = [] } = useQuery(clientsQuery);
  const { data: reservations = [] } = useQuery(reservationsQuery);
  const { data: stops = [] } = useQuery(stopsQuery);
  const stopsByRide = groupStops(stops);
  const stopCountOf = (id: string) => (stopsByRide.get(id) ?? []).length;

  const [open, setOpen] = useState(false);
  const [clientId, setClientId] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [picked, setPicked] = useState<string[]>([]);

  const billable = useMemo(
    () =>
      reservations.filter((r) => {
        if (!clientId || r.client_id !== clientId) return false;
        if (r.invoice_id) return false;
        const t = new Date(r.pickup_at).getTime();
        if (from && t < new Date(from).getTime()) return false;
        if (to && t > new Date(to).getTime() + 86_400_000) return false;
        return true;
      }),
    [reservations, clientId, from, to],
  );

  const selectedTotal = billable
    .filter((r) => picked.includes(r.id))
    .reduce((sum, r) => sum + fareTotal(r, stopCountOf(r.id)), 0);

  const emailInvoice = useServerFn(sendClientInvoiceEmail);

  const create = useMutation({
    mutationFn: async () => {
      if (!clientId) throw new Error("Pick a client account");
      if (picked.length === 0) throw new Error("Select at least one ride");
      const missing = billable.filter((r) => picked.includes(r.id) && !r.dropoff_at);
      if (missing.length)
        throw new Error(
          `Add a drop-off time to ${missing.map((r) => r.reference).join(", ")} before billing.`,
        );
      const { data, error } = await supabase
        .from("invoices")
        .insert({
          client_id: clientId,
          period_start: from || null,
          period_end: to || null,
        })
        .select("id")
        .single();
      if (error) throw error;
      const { error: linkError } = await supabase
        .from("reservations")
        .update({ invoice_id: data.id })
        .in("id", picked);
      if (linkError) throw linkError;

      // Email the client automatically when their account asks for it.
      const client = clients.find((c) => c.id === clientId);
      let emailed = false;
      if (client?.notify_invoice !== false) {
        try {
          const res = await emailInvoice({ data: { invoiceId: data.id as string } });
          emailed = !!res?.sent;
        } catch (err) {
          console.error("invoice email failed", err);
        }
      }
      return { id: data.id as string, emailed };
    },
    onSuccess: ({ id, emailed }) => {
      qc.invalidateQueries({ queryKey: ["invoices"] });
      qc.invalidateQueries({ queryKey: ["reservations"] });
      setPicked([]);
      setOpen(false);
      toast.success(emailed ? "Billing statement created and emailed to the client" : "Billing statement created");
      navigate({ to: "/invoices/$id", params: { id } });
    },
    onError: (e: Error) => toast.error(e.message),
  });




  const removeInvoice = useMutation({
    mutationFn: async (invoiceId: string) => {
      const { error: unlinkError } = await supabase
        .from("reservations")
        .update({ invoice_id: null })
        .eq("invoice_id", invoiceId);
      if (unlinkError) throw unlinkError;
      const { error } = await supabase.from("invoices").delete().eq("id", invoiceId);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["invoices"] });
      qc.invalidateQueries({ queryKey: ["reservations"] });
      toast.success("Billing statement deleted");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <>
      <PageHeading eyebrow="Accounts Receivable" title="Billing Statements" />
      <MoneyTabs />

      <div className="flex items-center px-6 py-4">
        <p className="font-cond text-xs uppercase tracking-widest text-muted-foreground">
          Bundle multiple rides from one client onto a single invoice
        </p>
        <button
          onClick={() => setOpen((v) => !v)}
          className="ml-auto rounded-md bg-brand px-5 py-2 font-cond text-xs uppercase tracking-widest text-brand-foreground"
        >
          {open ? "Close" : "New Statement"}
        </button>
      </div>

      {open && (
        <div className="plate mx-6 mb-4 rounded-lg border border-border p-5">
          <div className="grid gap-3 md:grid-cols-3">
            <div>
              <Label>Client account</Label>
              <select
                value={clientId}
                onChange={(e) => {
                  setClientId(e.target.value);
                  setPicked([]);
                }}
                className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
              >
                <option value="">Select client…</option>
                {clients.map((c) => (
                  <option key={c.id} value={c.id} className="bg-popover">
                    {c.account_number} · {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label>Billing period from</Label>
              <input
                type="date"
                value={from}
                onChange={(e) => setFrom(e.target.value)}
                className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
              />
            </div>
            <div>
              <Label>Billing period to</Label>
              <input
                type="date"
                value={to}
                onChange={(e) => setTo(e.target.value)}
                className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
              />
            </div>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
              Billing period
            </span>
            {[
              { label: "This month", offset: 0 },
              { label: "Last month", offset: -1 },
            ].map((p) => (
              <button
                key={p.label}
                onClick={() => {
                  const now = new Date();
                  const start = new Date(now.getFullYear(), now.getMonth() + p.offset, 1);
                  const end = new Date(now.getFullYear(), now.getMonth() + p.offset + 1, 0);
                  const iso = (d: Date) =>
                    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
                  setFrom(iso(start));
                  setTo(iso(end));
                }}
                className="rounded-md border border-border px-3 py-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground hover:text-brand"
              >
                {p.label}
              </button>
            ))}
            <span className="font-cond text-xs text-muted-foreground">
              {from || to
                ? `${from || "—"} to ${to || "—"}`
                : "No billing period selected — all unbilled rides shown"}
            </span>
          </div>


          {clientId && (
            <div className="mt-5">
              <div className="mb-2 flex items-center gap-3">
                <Label>Unbilled rides ({billable.length})</Label>
                <button
                  onClick={() => setPicked(billable.map((r) => r.id))}
                  className="ml-auto font-cond text-[10px] uppercase tracking-widest text-muted-foreground hover:text-brand"
                >
                  Select all
                </button>
                <button
                  onClick={() => setPicked([])}
                  className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground hover:text-brand"
                >
                  Clear
                </button>
              </div>
              <div className="max-h-72 overflow-y-auto rounded-md border border-border">
                {billable.map((r) => (
                  <label
                    key={r.id}
                    className="flex cursor-pointer items-center gap-3 border-b border-border px-3 py-2 font-cond text-sm last:border-0 hover:bg-surface-2/40"
                  >
                    <input
                      type="checkbox"
                      checked={picked.includes(r.id)}
                      onChange={(e) =>
                        setPicked((prev) =>
                          e.target.checked ? [...prev, r.id] : prev.filter((x) => x !== r.id),
                        )
                      }
                      className="accent-[oklch(var(--brand))]"
                    />
                    <span className="w-40 text-muted-foreground">
                      {dayLabel(r.pickup_at)} · {clockTime(r.pickup_at)}
                    </span>
                    <span className="w-24">{r.reference}</span>
                    <span className="flex-1 truncate">{r.passenger_name}</span>
                    <span className="tabular-nums text-brand">{money(fareTotal(r, stopCountOf(r.id)))}</span>
                  </label>
                ))}
                {billable.length === 0 && (
                  <div className="px-3 py-6 text-center font-cond text-sm text-muted-foreground">
                    No unbilled rides for this client in that range.
                  </div>
                )}
              </div>
              <div className="mt-4 flex items-center gap-4">
                <span className="font-cond text-xs uppercase tracking-widest text-muted-foreground">
                  {picked.length} rides selected
                </span>
                <span className="font-display text-2xl text-brand">{money(selectedTotal)}</span>
                <button
                  onClick={() => create.mutate()}
                  disabled={create.isPending}
                  className="ml-auto rounded-md bg-brand px-5 py-2.5 font-cond text-xs uppercase tracking-[0.3em] text-brand-foreground disabled:opacity-60"
                >
                  Create Statement
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      <div className="mx-6 mb-8 overflow-x-auto rounded-lg border border-border bg-card">
        <table className="w-full min-w-[600px]">
          <thead>
            <tr className="border-b border-border font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
              <th className="px-4 py-3 text-left">Statement #</th>
              <th className="px-4 py-3 text-left">Client</th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-right"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border font-cond text-sm">
            {invoices.map((inv) => {
              const client = clients.find((c) => c.id === inv.client_id);
              return (
                <tr key={inv.id} className="transition-colors hover:bg-surface-2/40">
                  <td className="px-4 py-3 tabular-nums">
                    <Link
                      to="/invoices/$id"
                      params={{ id: inv.id }}
                      className="text-brand underline underline-offset-4 hover:opacity-80"
                    >
                      {inv.invoice_number}
                    </Link>
                  </td>
                  <td className="px-4 py-3">{client?.name ?? "—"}</td>
                  <td className="px-4 py-3 text-muted-foreground">
                    {inv.paid_at ? "Paid" : inv.issued_at ? "Issued" : "Draft"}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Link
                      to="/invoices/$id"
                      params={{ id: inv.id }}
                      className="inline-block rounded-md border border-brand px-3 py-1.5 font-cond text-[11px] uppercase tracking-widest text-brand hover:bg-brand hover:text-brand-foreground"
                    >
                      View invoice
                    </Link>
                    {!inv.paid_at && (
                      <Link
                        to="/paycard/$target/$id"
                        params={{ target: "invoice", id: inv.id }}
                        target="_blank"
                        className="ml-2 inline-block rounded-md border border-brand bg-brand/10 px-3 py-1.5 font-cond text-[11px] uppercase tracking-widest text-brand hover:bg-brand hover:text-brand-foreground"
                      >
                        Card payment page
                      </Link>
                    )}
                    <button
                      onClick={() => {
                        if (window.confirm(`Delete invoice ${inv.invoice_number}? The rides become unbilled.`))
                          removeInvoice.mutate(inv.id);
                      }}
                      className="ml-2 inline-block rounded-md border border-destructive/60 px-3 py-1.5 font-cond text-[11px] uppercase tracking-widest text-destructive hover:bg-destructive hover:text-white"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              );
            })}
            {invoices.length === 0 && (
              <tr>
                <td colSpan={4} className="px-4 py-6 text-center text-muted-foreground">
                  No invoices yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

    </>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">{children}</div>
  );
}
