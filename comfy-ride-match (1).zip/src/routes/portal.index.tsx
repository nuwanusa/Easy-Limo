import { useEffect } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/auth";
import { getMyPortal } from "@/lib/client-portal.functions";
import { PortalView } from "@/components/PortalView";
import { BrandLogo } from "@/components/BrandLogo";
import { Button } from "@/components/ui/button";
import { MessengerPopup } from "@/components/MessengerPopup";

export const Route = createFileRoute("/portal/")({
  head: () => ({
    meta: [
      { title: "My Billing Statements — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Client portal: every Blackwave Transportation invoice, paid and unpaid, with the full fare breakdown for each ride.",
      },
      { property: "og:title", content: "My Billing Statements — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Review ride details, fees and outstanding balances, and pay online.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PortalPage,
});

function PortalPage() {
  const { session, loading } = useSession();
  const navigate = useNavigate();
  const fetchPortal = useServerFn(getMyPortal);

  useEffect(() => {
    if (!loading && !session) navigate({ to: "/auth" });
  }, [loading, session, navigate]);

  const query = useQuery({
    queryKey: ["client-portal"],
    queryFn: () => fetchPortal(),
    enabled: Boolean(session),
  });

  return (
    <div className="min-h-screen bg-portal-mist text-portal-ink">
      <header className="relative z-[700] h-[65px] border-b border-portal-line bg-portal-panel">
        <div className="flex h-full items-center gap-3 px-4 sm:px-6">
          <BrandLogo className="size-10" />
          <div className="flex-1">
            <div className="font-portal-display text-base font-bold leading-none text-portal-ink">Blackwave Transportation</div>
            <div className="mt-1 font-portal-body text-[9px] font-bold uppercase tracking-widest text-portal-muted">Live client portal</div>
          </div>
          <Button
            variant="ghost"
            onClick={async () => {
              await supabase.auth.signOut();
              navigate({ to: "/auth", replace: true });
            }}
            className="font-portal-body text-[10px] font-bold uppercase tracking-wider text-portal-muted hover:text-portal-blue"
          >
            Sign out
          </Button>
        </div>
      </header>

      {loading || query.isLoading ? (
        <p className="py-20 text-center font-cond text-xs uppercase tracking-[0.4em] text-muted-foreground">
          Loading invoices
        </p>
      ) : query.error ? (
        <p className="py-20 text-center text-sm text-destructive">
          {query.error instanceof Error ? query.error.message : "Could not load your invoices"}
        </p>
      ) : query.data ? (
        <>
          <PortalView data={query.data} />
          <MessengerPopup mode="client" companyId={query.data.companyId} clientId={query.data.client.id} />
        </>
      ) : null}
    </div>
  );
}
