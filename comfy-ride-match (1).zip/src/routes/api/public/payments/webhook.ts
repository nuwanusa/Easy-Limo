import { createFileRoute } from "@tanstack/react-router";
import { type StripeEnv, verifyWebhook } from "@/lib/stripe.server";

const DISPATCH_EMAIL = "info@rideblackwave.com";
const OWNER_EMAIL = "nuwanusa@gmail.com";

const money = (v: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(v);

const dayLabel = (d: Date) =>
  d.toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
    timeZone: "America/New_York",
  });

async function notify(
  audience: "client" | "dispatch",
  to: string,
  data: Record<string, unknown>,
  key: string,
) {
  try {
    const { sendTemplateEmail } = await import("@/lib/email-templates/send-email");
    await sendTemplateEmail("payment-receipt", to, {
      templateData: { audience, ...data },
      idempotencyKey: key,
    });
  } catch (e) {
    console.error("payment receipt email failed", e);
  }
}

async function fulfil(session: any) {
  const target = session?.metadata?.target as "invoice" | "reservation" | undefined;
  const targetId = session?.metadata?.targetId as string | undefined;
  if (!target || !targetId) return;

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const paidAt = new Date();
  const amount = (session.amount_total ?? 0) / 100;
  const card = session.payment_method_details?.card ?? null;

  let reference = "";
  let clientName: string | undefined;
  let description = "";
  let paymentStatus: "full" | "partial" = "full";
  let balanceDue: string | undefined;
  let email: string | undefined;

  if (target === "invoice") {
    const { data: invoice } = await supabaseAdmin
      .from("invoices")
      .select("*")
      .eq("id", targetId)
      .maybeSingle();
    if (!invoice) return;
    if (invoice.paid_at) return;

    // The balance at checkout time travels on the session, so a part payment
    // only records the money and leaves the invoice open. The 3% card fee is
    // charged on top and never counts toward the invoice balance.
    const dueCents = Number(session?.metadata?.dueCents ?? 0);
    const paidCents = Number(session?.metadata?.paidCents ?? 0) || Math.round(amount * 100);
    const appliedAmount = paidCents / 100;
    const settled = !dueCents || paidCents >= dueCents - 1;
    paymentStatus = settled ? "full" : "partial";
    if (!settled) balanceDue = money((dueCents - paidCents) / 100);

    await supabaseAdmin
      .from("invoices")
      .update({
        ...(settled ? { paid_at: paidAt.toISOString() } : {}),
        payments: Number(invoice.payments ?? 0) + appliedAmount,
      })
      .eq("id", targetId);

    if (settled) {
      await supabaseAdmin
        .from("reservations")
        .update({ invoice_paid_at: paidAt.toISOString() })
        .eq("invoice_id", targetId);
    }


    reference = invoice.invoice_number;
    const { data: invoiceRides = [] } = await supabaseAdmin
      .from("reservations")
      .select("billing_contact_email")
      .eq("invoice_id", targetId)
      .order("pickup_at", { ascending: true });
    email = (invoiceRides ?? [])
      .map((ride: any) => typeof ride.billing_contact_email === "string" ? ride.billing_contact_email.trim() : "")
      .find(Boolean) || undefined;
    if (invoice.client_id) {
      const { data: client } = await supabaseAdmin
        .from("clients")
        .select("name, email, billing_contact_email")
        .eq("id", invoice.client_id)
        .maybeSingle();
      clientName = client?.name ?? undefined;
      email = email ?? client?.billing_contact_email ?? client?.email ?? undefined;
    }
    email = email ?? session.customer_details?.email ?? session.customer_email ?? undefined;
    description = `Statement ${reference}${clientName ? ` — ${clientName}` : ""}`;
  } else {
    const { data: ride } = await supabaseAdmin
      .from("reservations")
      .select("*")
      .eq("id", targetId)
      .maybeSingle();
    if (!ride || ride.invoice_paid_at) return;

    await supabaseAdmin
      .from("reservations")
      .update({ invoice_paid_at: paidAt.toISOString() })
      .eq("id", targetId);

    reference = ride.reference;
    clientName = ride.passenger_name ?? undefined;
    email = ride.billing_contact_email ?? ride.passenger_email ?? session.customer_details?.email ?? session.customer_email ?? undefined;
    description = `Ride ${reference}${clientName ? ` — ${clientName}` : ""}`;
  }

  const { buildPaymentInvoiceDetails } = await import("@/lib/payment-receipt-data");
  const details = await buildPaymentInvoiceDetails(supabaseAdmin, target, targetId, amount);

  const payload = {
    ...(details ?? {}),
    clientName,
    reference,
    description,
    amount: money(amount),
    paidOn: dayLabel(paidAt),
    cardBrand: card?.brand ? String(card.brand).toUpperCase() : undefined,
    last4: card?.last4 ?? undefined,
    paymentStatus,
    balanceDue,
  };

  if (email) await notify("client", email, payload, `receipt-${session.id}-client`);
  await notify("dispatch", DISPATCH_EMAIL, payload, `receipt-${session.id}-dispatch`);
  await notify("dispatch", OWNER_EMAIL, payload, `receipt-${session.id}-owner`);
}

async function handleWebhook(req: Request, env: StripeEnv) {
  const event = await verifyWebhook(req, env);

  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object;
      if (session.payment_status !== "unpaid") await fulfil(session);
      break;
    }
    case "checkout.session.async_payment_succeeded":
      await fulfil(event.data.object);
      break;
    default:
      console.log("Unhandled payment event:", event.type);
  }
}

export const Route = createFileRoute("/api/public/payments/webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const rawEnv = new URL(request.url).searchParams.get("env");
        if (rawEnv !== "sandbox" && rawEnv !== "live") {
          console.error("Webhook received with invalid env:", rawEnv);
          return Response.json({ received: true, ignored: "invalid env" });
        }
        try {
          await handleWebhook(request, rawEnv);
          return Response.json({ received: true });
        } catch (e) {
          console.error("Webhook error:", e);
          return new Response("Webhook error", { status: 400 });
        }
      },
    },
  },
});
