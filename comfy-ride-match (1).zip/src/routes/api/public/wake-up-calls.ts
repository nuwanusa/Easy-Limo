import { createFileRoute } from "@tanstack/react-router";

/** Places due chauffeur wake-up calls. Runs every 5 minutes from the scheduler. */
async function run(request: Request) {
  const provided = request.headers.get("x-cron-secret") ?? "";
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { runWakeUpCalls } = await import("@/lib/wake-up.server");

  const envSecret = process.env["LOVABLE_CRON_SECRET"];
  let allowed = !!envSecret && provided === envSecret;
  if (!allowed && provided) {
    const { data: token } = await supabaseAdmin.rpc("cron_token_matches", { _token: provided });
    allowed = token === true;
  }
  if (!allowed) return new Response("Unauthorized", { status: 401 });

  try {
    const result = await runWakeUpCalls(supabaseAdmin);
    return Response.json(result);
  } catch (e) {
    console.error("wake-up run failed", e);
    return new Response(e instanceof Error ? e.message : "failed", { status: 500 });
  }
}

export const Route = createFileRoute("/api/public/wake-up-calls")({
  server: { handlers: { POST: ({ request }) => run(request), GET: ({ request }) => run(request) } },
});
