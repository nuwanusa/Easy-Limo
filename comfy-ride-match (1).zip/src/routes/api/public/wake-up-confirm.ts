import { createFileRoute } from "@tanstack/react-router";

/** Twilio posts here when the chauffeur presses a key during the wake-up call. */
async function run(request: Request) {
  const url = new URL(request.url);
  const id = url.searchParams.get("id") ?? "";
  let digit = "";
  try {
    const form = await request.formData();
    digit = String(form.get("Digits") ?? "");
  } catch {
    digit = "";
  }

  const xml = (say: string) =>
    new Response(
      `<?xml version="1.0" encoding="UTF-8"?><Response><Say voice="Polly.Joanna">${say}</Say></Response>`,
      { headers: { "Content-Type": "text/xml" } },
    );

  if (!id || digit !== "1") return xml("No confirmation received. Goodbye.");

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { confirmWakeUpCall } = await import("@/lib/wake-up.server");
  await confirmWakeUpCall(supabaseAdmin, id);
  return xml("Thank you. Your ride is confirmed. Drive safely.");
}

export const Route = createFileRoute("/api/public/wake-up-confirm")({
  server: { handlers: { POST: ({ request }) => run(request), GET: ({ request }) => run(request) } },
});
