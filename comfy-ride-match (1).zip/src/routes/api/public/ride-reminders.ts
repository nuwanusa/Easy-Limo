import { createFileRoute } from "@tanstack/react-router";

/**
 * Sends the 24-hour ride reminder to clients who opted in.
 * Called hourly by the scheduled job; the shared secret guards the endpoint.
 */
async function run(request: Request) {
  const provided = request.headers.get("x-cron-secret") ?? "";
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { sendClientTripNotice } = await import("@/lib/client-notify.server");

  const envSecret = process.env["LOVABLE_CRON_SECRET"];
  let allowed = !!envSecret && provided === envSecret;
  if (!allowed && provided) {
    const { data: token } = await supabaseAdmin.rpc("cron_token_matches", { _token: provided });
    allowed = token === true;
  }
  if (!allowed) return new Response("Unauthorized", { status: 401 });


  const now = new Date();
  const until = new Date(now.getTime() + 24 * 60 * 60 * 1000);

  const { data: rides, error } = await supabaseAdmin
    .from("reservations")
    .select("id")
    .is("reminder_sent_at", null)
    .neq("status", "cancelled")
    .gte("pickup_at", now.toISOString())
    .lte("pickup_at", until.toISOString())
    .limit(100);
  if (error) return new Response(error.message, { status: 500 });

  let sent = 0;
  for (const ride of rides ?? []) {
    try {
      const result = await sendClientTripNotice(supabaseAdmin, ride.id, "reminder");
      if (result.sent) sent += 1;
    } catch (e) {
      console.error("ride reminder failed", ride.id, e);
    }
    await supabaseAdmin
      .from("reservations")
      .update({ reminder_sent_at: new Date().toISOString() })
      .eq("id", ride.id);
  }

  return Response.json({ checked: rides?.length ?? 0, sent });
}

export const Route = createFileRoute("/api/public/ride-reminders")({
  server: { handlers: { POST: ({ request }) => run(request), GET: ({ request }) => run(request) } },
});
