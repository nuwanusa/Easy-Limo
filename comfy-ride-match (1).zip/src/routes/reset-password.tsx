import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Reset Password — Blackwave Transportation LLC" },
      {
        name: "description",
        content: "Set a new password for your Blackwave Transportation LLC dispatch or driver account.",
      },
      { property: "og:title", content: "Reset Password — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Set a new password for your Blackwave Transportation LLC account.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const navigate = useNavigate();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Password updated");
    navigate({ to: "/auth" });
  };

  return (
    <div className="cine flex min-h-screen items-center justify-center px-4">
      <form onSubmit={submit} className="plate w-full max-w-sm rounded-lg border border-border p-7">
        <h1 className="font-display text-3xl uppercase leading-[0.9]">New Password</h1>
        <p className="mt-2 font-cond text-sm text-muted-foreground">
          Choose a new password for your account.
        </p>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="New password"
          autoComplete="new-password"
          required
          minLength={6}
          className="mt-6 w-full rounded-md border border-input bg-surface px-3 py-3 font-cond text-sm text-foreground outline-none placeholder:text-muted-foreground focus:border-brand/60"
        />
        <button
          type="submit"
          disabled={busy}
          className="mt-3 w-full rounded-md bg-brand py-3 font-cond text-xs uppercase tracking-[0.3em] text-brand-foreground disabled:opacity-60"
        >
          {busy ? "Saving" : "Update password"}
        </button>
      </form>
    </div>
  );
}
