import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { AppShell, PageHeading } from "@/components/AppShell";
import { CompanyProfile } from "@/components/CompanyProfile";
import { Building2, Eye, EyeOff, Lock, Mail, Plus, Search, UserCog, UserPlus, Users } from "lucide-react";
import { useRole } from "@/lib/roles";
import { supabase } from "@/integrations/supabase/client";
import {
  createStaffAccount,
  listStaffAccounts,
  removeStaffAccount,
} from "@/lib/staff-account.functions";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Main admin area for Blackwave Transportation LLC: create dispatch logins, manage staff access and driver accounts.",
      },
      { property: "og:title", content: "Admin — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Create dispatch and driver logins and manage staff access.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <AppShell>
      <AdminPage />
    </AppShell>
  ),
});

function AdminPage() {
  const { isAdmin, loading } = useRole();
  const qc = useQueryClient();
  const list = useServerFn(listStaffAccounts);
  const create = useServerFn(createStaffAccount);
  const remove = useServerFn(removeStaffAccount);

  const [myUserId, setMyUserId] = useState<string | null>(null);
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setMyUserId(data.session?.user?.id ?? null));
  }, []);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [staffSearch, setStaffSearch] = useState("");
  const company = useQuery({
    queryKey: ["admin-company-code"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data: s } = await supabase.auth.getSession();
      const uid = s.session?.user?.id;
      if (!uid) return null;
      const { data: m } = await supabase.from("company_users").select("company_id").eq("user_id", uid).maybeSingle();
      if (!m) return null;
      const { data } = await supabase.from("companies").select("code").eq("id", m.company_id).maybeSingle();
      return data?.code ?? null;
    },
  });
  const [role, setRole] = useState<"admin" | "dispatcher">("dispatcher");

  const staff = useQuery({
    queryKey: ["staff-accounts"],
    queryFn: () => list(),
    enabled: isAdmin,
  });

  const createMutation = useMutation({
    mutationFn: () => create({ data: { email, password, role } }),
    onSuccess: () => {
      toast.success("Account ready");
      setEmail("");
      setPassword("");
      qc.invalidateQueries({ queryKey: ["staff-accounts"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const removeMutation = useMutation({
    mutationFn: (userId: string) => remove({ data: { userId } }),
    onSuccess: () => {
      toast.success("Access removed");
      qc.invalidateQueries({ queryKey: ["staff-accounts"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (loading) {
    return <div className="px-6 py-10 text-sm text-muted-foreground">Loading…</div>;
  }

  if (!isAdmin) {
    return (
      <div className="px-6 py-10">
        <PageHeading eyebrow="Restricted" title="Admin only" />
        <p className="mt-6 text-sm text-muted-foreground">
          This section is available to the main admin account only.
        </p>
      </div>
    );
  }

  const q = staffSearch.trim().toLowerCase();
  const staffRows = (staff.data ?? []).filter((s) => !q || (s.email ?? "").toLowerCase().includes(q));

  return (
    <div className="min-h-full bg-dashboard-canvas px-4 py-6 sm:px-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <div className="text-xs font-semibold uppercase tracking-[0.3em] text-dashboard-blue">Accounts</div>
          <h1 className="font-display text-4xl font-bold text-dashboard-navy">Admin</h1>
          <p className="mt-1 text-sm text-dashboard-muted">
            Manage your company information, logo, and staff accounts. These details appear on invoices, quotes, and client communications.
          </p>
        </div>
        {company.data && (
          <div className="flex items-center gap-3 rounded-xl border border-dashboard-line bg-dashboard-ice px-5 py-3">
            <Building2 className="h-8 w-8 text-dashboard-blue" />
            <div>
              <div className="text-xs text-dashboard-muted">Company ID</div>
              <div className="font-display text-base font-bold tracking-widest text-dashboard-navy">{company.data}</div>
            </div>
          </div>
        )}
      </div>

      <div className="mt-5">
        <CompanyProfile />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <section className="rounded-xl border border-dashboard-line bg-card p-5 shadow-sm">
          <div className="flex items-start gap-4">
            <UserPlus className="mt-1 h-8 w-8 text-dashboard-blue" />
            <div>
              <h2 className="font-display text-xl font-semibold text-dashboard-navy">New Staff Login</h2>
              <p className="text-sm text-dashboard-muted">
                Dispatchers can run the board and create driver logins, but cannot open Accounting.
              </p>
            </div>
          </div>
          <form
            className="mt-4 grid gap-3"
            onSubmit={(e) => {
              e.preventDefault();
              createMutation.mutate();
            }}
          >
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="grid gap-1.5">
                <span className="text-sm font-medium text-dashboard-navy">Email <span className="text-dashboard-red">*</span></span>
                <span className="flex overflow-hidden rounded-md border border-dashboard-line bg-card focus-within:ring-2 focus-within:ring-dashboard-blue/30">
                  <span className="grid w-10 shrink-0 place-items-center border-r border-dashboard-line text-dashboard-muted"><Mail className="h-4 w-4" /></span>
                  <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@company.com" className="h-10 min-w-0 flex-1 bg-transparent px-3 text-sm text-dashboard-navy outline-none placeholder:text-dashboard-muted/70" />
                </span>
              </label>
              <label className="grid gap-1.5">
                <span className="text-sm font-medium text-dashboard-navy">Password <span className="text-dashboard-red">*</span></span>
                <span className="flex overflow-hidden rounded-md border border-dashboard-line bg-card focus-within:ring-2 focus-within:ring-dashboard-blue/30">
                  <span className="grid w-10 shrink-0 place-items-center border-r border-dashboard-line text-dashboard-muted"><Lock className="h-4 w-4" /></span>
                  <input type={showPw ? "text" : "password"} required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Minimum 8 characters" className="h-10 min-w-0 flex-1 bg-transparent px-3 text-sm text-dashboard-navy outline-none placeholder:text-dashboard-muted/70" />
                  <button type="button" onClick={() => setShowPw((v) => !v)} aria-label={showPw ? "Hide password" : "Show password"} className="px-3 text-dashboard-muted">
                    {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </span>
              </label>
            </div>
            <label className="grid gap-1.5">
              <span className="text-sm font-medium text-dashboard-navy">Role <span className="text-dashboard-red">*</span></span>
              <span className="flex overflow-hidden rounded-md border border-dashboard-line bg-card focus-within:ring-2 focus-within:ring-dashboard-blue/30">
                <span className="grid w-10 shrink-0 place-items-center border-r border-dashboard-line text-dashboard-muted"><UserCog className="h-4 w-4" /></span>
                <select value={role} onChange={(e) => setRole(e.target.value as "admin" | "dispatcher")} className="h-10 min-w-0 flex-1 bg-transparent px-3 text-sm text-dashboard-navy outline-none placeholder:text-dashboard-muted/70">
                  <option value="dispatcher">Dispatch</option>
                  <option value="admin">Main admin</option>
                </select>
              </span>
            </label>
            <button type="submit" disabled={createMutation.isPending} className="inline-flex h-11 items-center justify-center gap-2 rounded-md bg-dashboard-blue px-4 text-sm font-semibold text-primary-foreground disabled:opacity-60">
              <Plus className="h-4 w-4" /> {createMutation.isPending ? "Saving…" : "Create Account"}
            </button>
          </form>
          <div className="mt-4 text-sm text-dashboard-navy">
            Driver logins are created on the{" "}
            <Link to="/drivers" className="text-dashboard-blue underline">Drivers</Link> page.
          </div>
        </section>

        <section className="rounded-xl border border-dashboard-line bg-card p-5 shadow-sm">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="flex items-start gap-4">
              <Users className="mt-1 h-8 w-8 text-dashboard-blue" />
              <div>
                <h2 className="font-display text-xl font-semibold text-dashboard-navy">Staff Accounts</h2>
                <p className="text-sm text-dashboard-muted">Manage existing staff accounts and their roles.</p>
              </div>
            </div>
            <label className="flex h-10 w-full items-center gap-2 rounded-md border border-dashboard-line px-3 sm:w-56">
              <Search className="h-4 w-4 text-dashboard-muted" />
              <input value={staffSearch} onChange={(e) => setStaffSearch(e.target.value)} placeholder="Search staff..." className="min-w-0 flex-1 bg-transparent text-sm outline-none" />
            </label>
          </div>
          <div className="mt-4 grid gap-2">
            {staffRows.map((s) => (
              <div key={s.userId} className="flex items-center justify-between gap-3 rounded-lg border border-dashboard-line bg-dashboard-canvas px-3 py-3">
                <div className="flex min-w-0 items-center gap-3">
                  <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-dashboard-ice text-sm font-bold text-dashboard-blue">
                    {(s.email || "?").slice(0, 2).toUpperCase()}
                  </span>
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="truncate text-sm font-medium text-dashboard-navy">{s.email || s.userId}</span>
                      <span className="rounded bg-dashboard-ice px-2 py-0.5 text-xs text-dashboard-blue">
                        {s.role === "admin" ? "Main Admin" : "Dispatch"}
                      </span>
                    </div>
                  </div>
                </div>
                {s.userId === myUserId ? (
                  <span className="rounded bg-dashboard-ice px-2 py-1 text-xs font-semibold text-dashboard-blue">YOU</span>
                ) : (
                  <button onClick={() => removeMutation.mutate(s.userId)} className="text-xs font-semibold text-destructive">
                    Remove
                  </button>
                )}
              </div>
            ))}
            {staff.data && staffRows.length === 0 && (
              <div className="text-sm text-dashboard-muted">No staff accounts found.</div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
