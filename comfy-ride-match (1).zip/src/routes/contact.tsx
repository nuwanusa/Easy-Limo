import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { z } from "zod";
import { Phone, Mail, MapPin, Clock } from "lucide-react";
import { SiteLayout, PageHeader, COMPANY } from "@/components/SiteLayout";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact & Quote Request — Blackwave Transportation" },
      {
        name: "description",
        content:
          "Request a flat-rate quote for airport transfers, corporate travel, hourly charters or events. Call (917) 325-3211 or send your trip details 24/7.",
      },
      { property: "og:title", content: "Contact & Quote Request — Blackwave Transportation" },
      { property: "og:description", content: "Tell us your trip and we'll come back with an all-in price." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ContactPage,
});

const schema = z.object({
  full_name: z.string().trim().min(2, "Please enter your name").max(100),
  email: z.string().trim().email("Please enter a valid email").max(255),
  phone: z.string().trim().max(40).optional(),
  company: z.string().trim().max(120).optional(),
  service_type: z.enum(["transfer", "airport", "hourly", "event", "corporate"]),
  pickup_address: z.string().trim().max(300).optional(),
  dropoff_address: z.string().trim().max(300).optional(),
  pickup_at: z.string().trim().max(40).optional(),
  passenger_count: z.number().int().min(1).max(60),
  vehicle_class: z.string().trim().max(60).optional(),
  luggage_count: z.number().int().min(0).max(60),
  round_trip: z.boolean(),
  notes: z.string().trim().max(1000).optional(),
});

const SERVICE_OPTIONS = [
  { value: "airport", label: "Airport transfer" },
  { value: "transfer", label: "Point to point" },
  { value: "hourly", label: "Hourly / as-directed" },
  { value: "corporate", label: "Corporate account" },
  { value: "event", label: "Wedding or event" },
] as const;

const VEHICLES = ["Executive sedan", "Luxury SUV", "Passenger van", "Not sure"];

const empty = {
  full_name: "",
  email: "",
  phone: "",
  company: "",
  service_type: "airport",
  pickup_address: "",
  dropoff_address: "",
  pickup_at: "",
  passenger_count: "1",
  luggage_count: "0",
  vehicle_class: "",
  notes: "",
};

const field =
  "mt-3 w-full border border-border bg-transparent px-4 py-3 text-sm text-foreground outline-none transition-colors focus:border-gold";
const label = "font-mono text-[0.65rem] uppercase tracking-[0.25em] text-muted-foreground";

function ContactPage() {
  const [form, setForm] = useState(empty);
  const [stops, setStops] = useState<string[]>([]);
  const [roundTrip, setRoundTrip] = useState(false);
  const [done, setDone] = useState(false);

  const set = (k: keyof typeof empty, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const submit = useMutation({
    mutationFn: async () => {
      const parsed = schema.parse({
        ...form,
        passenger_count: Number(form.passenger_count) || 1,
        luggage_count: Number(form.luggage_count) || 0,
        round_trip: roundTrip,
        pickup_at: form.pickup_at || undefined,
        phone: form.phone || undefined,
        company: form.company || undefined,
        pickup_address: form.pickup_address || undefined,
        dropoff_address: form.dropoff_address || undefined,
        vehicle_class: form.vehicle_class || undefined,
        notes: form.notes || undefined,
      });
      const { error } = await supabase.from("quote_requests").insert({
        full_name: parsed.full_name,
        email: parsed.email,
        phone: parsed.phone ?? null,
        company: parsed.company ?? null,
        service_type: parsed.service_type,
        pickup_address: parsed.pickup_address ?? null,
        dropoff_address: parsed.dropoff_address ?? null,
        passenger_count: parsed.passenger_count,
        luggage_count: parsed.luggage_count,
        round_trip: parsed.round_trip,
        stops: stops.map((s2) => s2.trim()).filter(Boolean),
        vehicle_class: parsed.vehicle_class ?? null,
        notes: parsed.notes ?? null,
        pickup_at: parsed.pickup_at ? new Date(parsed.pickup_at).toISOString() : null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setForm(empty);
      setStops([]);
      setRoundTrip(false);
      setDone(true);
      toast.success("Thanks — we'll be in touch shortly.");
    },
    onError: (e: unknown) => {
      if (e instanceof z.ZodError) {
        toast.error(e.issues[0]?.message ?? "Please check the form");
        return;
      }
      toast.error(e instanceof Error ? e.message : "Could not send your request");
    },
  });

  return (
    <SiteLayout>
      <PageHeader
        kicker="Concierge"
        title="Request a reservation."
        blurb="Send us the itinerary and we'll reply with a flat, all-in price. Prefer to speak? Our line is open 24 hours."
      />

      <section className="mx-auto grid max-w-7xl gap-12 px-6 pb-32 lg:grid-cols-[1fr_22rem] lg:px-10">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit.mutate();
          }}
          className="border border-border bg-card p-8 md:p-12"
        >
          {done && (
            <div className="mb-8 border border-gold/40 bg-gold/5 px-4 py-3 text-sm">
              Your request is in. We'll confirm by email or phone shortly.
            </div>
          )}

          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className={label}>Full name *</span>
              <input required value={form.full_name} onChange={(e) => set("full_name", e.target.value)} className={field} />
            </label>
            <label className="block">
              <span className={label}>Email *</span>
              <input required type="email" value={form.email} onChange={(e) => set("email", e.target.value)} className={field} />
            </label>
            <label className="block">
              <span className={label}>Phone</span>
              <input value={form.phone} onChange={(e) => set("phone", e.target.value)} className={field} />
            </label>
            <label className="block">
              <span className={label}>Company</span>
              <input value={form.company} onChange={(e) => set("company", e.target.value)} className={field} />
            </label>
            <label className="block">
              <span className={label}>Service</span>
              <select value={form.service_type} onChange={(e) => set("service_type", e.target.value)} className={field}>
                {SERVICE_OPTIONS.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className={label}>Date & time</span>
              <input type="datetime-local" value={form.pickup_at} onChange={(e) => set("pickup_at", e.target.value)} className={field} />
            </label>
            <label className="block">
              <span className={label}>Pickup location</span>
              <input value={form.pickup_address} onChange={(e) => set("pickup_address", e.target.value)} className={field} />
            </label>
            <label className="block">
              <span className={label}>Drop-off location</span>
              <input value={form.dropoff_address} onChange={(e) => set("dropoff_address", e.target.value)} className={field} />
            </label>
            <label className="block">
              <span className={label}>Passengers</span>
              <input
                type="number"
                min={1}
                max={60}
                value={form.passenger_count}
                onChange={(e) => set("passenger_count", e.target.value)}
                className={field}
              />
            </label>
            <label className="block">
              <span className={label}>Luggage</span>
              <input
                type="number"
                min={0}
                max={60}
                value={form.luggage_count}
                onChange={(e) => set("luggage_count", e.target.value)}
                className={field}
              />
            </label>
            <label className="block">
              <span className={label}>Vehicle preference</span>
              <select value={form.vehicle_class} onChange={(e) => set("vehicle_class", e.target.value)} className={field}>
                <option value="">Select…</option>
                {VEHICLES.map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <div className="mt-6">
            <span className={label}>Additional stops</span>
            <div className="mt-3 grid gap-3">
              {stops.map((stop, i) => (
                <div key={i} className="flex gap-3">
                  <input
                    value={stop}
                    placeholder={`Stop ${i + 1}`}
                    onChange={(e) => setStops((prev) => prev.map((v, j) => (j === i ? e.target.value : v)))}
                    className="w-full border border-border bg-transparent px-4 py-3 text-sm text-foreground outline-none transition-colors focus:border-gold"
                  />
                  <button
                    type="button"
                    onClick={() => setStops((prev) => prev.filter((_, j) => j !== i))}
                    className="border border-border px-4 font-mono text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground hover:border-gold hover:text-gold"
                  >
                    Remove
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={() => setStops((prev) => [...prev, ""])}
                className="justify-self-start border border-border px-5 py-3 font-mono text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground transition hover:border-gold hover:text-gold"
              >
                + Add stop
              </button>
            </div>
          </div>

          <label className="mt-6 flex items-center gap-3 text-sm">
            <input type="checkbox" checked={roundTrip} onChange={(e) => setRoundTrip(e.target.checked)} className="size-4 accent-[color:var(--gold,#d8b45a)]" />
            <span>Round trip / return needed</span>
          </label>

          <label className="mt-4 block">
            <span className={label}>Anything else?</span>
            <textarea
              rows={4}
              maxLength={1000}
              value={form.notes}
              onChange={(e) => set("notes", e.target.value)}
              className={field}
              placeholder="Flight number, extra stops, child seats, return trip…"
            />
          </label>

          <button
            type="submit"
            disabled={submit.isPending}
            className="mt-10 border border-gold bg-gold px-8 py-4 font-mono text-xs uppercase tracking-[0.25em] text-primary-foreground transition hover:bg-transparent hover:text-gold disabled:opacity-60"
          >
            {submit.isPending ? "Sending…" : "Send request"}
          </button>
        </form>

        <aside className="h-max border border-border bg-card p-8">
          <div className="eyebrow">Reach us</div>
          <div className="mt-6 grid gap-5 text-sm">
            <a href={COMPANY.phoneHref} className="flex items-start gap-3 hover:text-gold">
              <Phone className="mt-0.5 size-4 text-gold" /> {COMPANY.phone}
            </a>
            <a href={`mailto:${COMPANY.email}`} className="flex items-start gap-3 hover:text-gold">
              <Mail className="mt-0.5 size-4 text-gold" /> {COMPANY.email}
            </a>
            <div className="flex items-start gap-3 text-muted-foreground">
              <MapPin className="mt-0.5 size-4 text-gold" /> {COMPANY.address}
            </div>
            <div className="flex items-start gap-3 text-muted-foreground">
              <Clock className="mt-0.5 size-4 text-gold" /> Concierge open 24/7, 365 days
            </div>
          </div>
        </aside>
      </section>
    </SiteLayout>
  );
}
