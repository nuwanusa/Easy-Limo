import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/driver/login")({
  beforeLoad: () => {
    throw redirect({ to: "/auth" });
  },
  component: () => null,
});
