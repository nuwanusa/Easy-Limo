import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout, COMPANY } from "@/components/SiteLayout";
import heroCar from "@/assets/hero-car.jpg";
import heroChauffeurDoor from "@/assets/hero-chauffeur-door.jpg";
import heroAirportEscalade from "@/assets/hero-airport-escalade.jpg";
import chauffeur from "@/assets/chauffeur.jpg";
import sedan from "@/assets/fleet-sedan.jpg";
import suv from "@/assets/fleet-suv.jpg";

const heroSlides = [
  { src: heroCar, alt: "Black luxury sedan at a hotel entrance at night" },
  { src: heroChauffeurDoor, alt: "A chauffeur in white gloves opening the door of a black luxury sedan" },
  { src: heroAirportEscalade, alt: "An executive stepping out of a black Cadillac Escalade at an airport terminal" },
];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Blackwave Transportation — Private Chauffeur & Black Car Service" },
      {
        name: "description",
        content:
          "Private chauffeur service serving New York, Connecticut, New Jersey, Washington DC, and Philadelphia. Discreet, on-time, immaculately appointed.",
      },
      { property: "og:title", content: "Blackwave Transportation — Private Chauffeur Service" },
      {
        property: "og:description",
        content: "Discreet, on-time chauffeur service for executives and discerning travelers.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const [slide, setSlide] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setSlide((s) => (s + 1) % heroSlides.length), 5500);
    return () => clearInterval(id);
  }, []);

  return (
    <SiteLayout>
      {/* HERO */}
      <section className="relative h-screen min-h-[720px] w-full overflow-hidden">
        {heroSlides.map((s, i) => (
          <img
            key={s.src}
            src={s.src}
            alt={s.alt}
            width={1920}
            height={1080}
            className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-[1500ms] ease-in-out ${
              i === slide ? "opacity-100" : "opacity-0"
            }`}
          />
        ))}
        <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/40 to-background" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/80 to-transparent" />

        <div className="relative z-10 mx-auto flex h-full max-w-7xl flex-col justify-end px-6 pb-24 lg:px-10 lg:pb-32">
          <p className="eyebrow mb-6">Est. 2023 · New York</p>
          <h1 className="max-w-4xl font-display text-5xl leading-[1.05] sm:text-6xl md:text-7xl lg:text-8xl">
            Arrive
            <span className="gold-text italic"> quietly.</span>
            <br />
            Depart
            <span className="gold-text italic"> precisely.</span>
          </h1>
          <p className="mt-8 max-w-xl text-base leading-relaxed text-muted-foreground md:text-lg">
            A private chauffeur service for those who measure luxury in seconds saved, doors held, and
            questions never asked.
          </p>
          <div className="mt-10 flex flex-wrap gap-4">
            <Link
              to="/contact"
              className="border border-gold bg-gold px-8 py-4 font-mono text-xs uppercase tracking-[0.25em] text-primary-foreground transition hover:bg-transparent hover:text-gold"
            >
              Reserve a Vehicle
            </Link>
            <Link
              to="/our-fleet"
              className="border border-border px-8 py-4 font-mono text-xs uppercase tracking-[0.25em] text-foreground transition hover:border-gold hover:text-gold"
            >
              View the Fleet
            </Link>
          </div>
        </div>

        <div className="absolute bottom-8 right-6 z-10 flex gap-3 lg:right-10">
          {heroSlides.map((s, i) => (
            <button
              key={s.src}
              onClick={() => setSlide(i)}
              aria-label={`Go to slide ${i + 1}`}
              className={`h-[2px] w-10 transition-all duration-500 ${
                i === slide ? "bg-gold" : "bg-foreground/30 hover:bg-foreground/60"
              }`}
            />
          ))}
        </div>
      </section>

      {/* PHILOSOPHY */}
      <section className="mx-auto max-w-7xl px-6 py-32 lg:px-10 lg:py-40">
        <div className="grid gap-16 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <p className="eyebrow mb-6">The Standard</p>
            <h2 className="font-display text-4xl leading-tight md:text-5xl lg:text-6xl">
              Service so quiet, you&apos;ll forget we&apos;re here.
            </h2>
          </div>
          <div className="lg:col-span-6 lg:col-start-7">
            <p className="text-lg leading-relaxed text-muted-foreground">
              Every chauffeur in our service is trained for fifty hours before they ever open a door for
              a client. They learn the geography of select cities, the protocols of seven embassies, and
              the difference between a seventy-degree cabin and one set, precisely, to sixty-eight.
            </p>
            <p className="mt-6 text-lg leading-relaxed text-muted-foreground">
              We do not advertise. Our roster grows by introduction.
            </p>
            <div className="mt-12 grid grid-cols-3 gap-6">
              {[
                { n: "2", l: "Years" },
                { n: "5", l: "Regions" },
                { n: "98%", l: "Retention" },
              ].map((s) => (
                <div key={s.l}>
                  <div className="font-display text-4xl text-gold md:text-5xl">{s.n}</div>
                  <div className="mt-2 font-mono text-[0.65rem] uppercase tracking-[0.25em] text-muted-foreground">
                    {s.l}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* SPLIT IMAGE */}
      <section className="relative">
        <div className="grid lg:grid-cols-2">
          <div className="relative h-[600px] overflow-hidden">
            <img
              src={chauffeur}
              alt="Chauffeur opening the door of a black sedan"
              width={1280}
              height={1600}
              loading="lazy"
              className="h-full w-full object-cover"
            />
          </div>
          <div className="flex items-center bg-card px-6 py-20 lg:px-20">
            <div className="max-w-lg">
              <p className="eyebrow mb-6">A Standing Door</p>
              <h2 className="font-display text-4xl leading-tight md:text-5xl">
                Your chauffeur is waiting before you finish your coffee.
              </h2>
              <p className="mt-6 text-lg leading-relaxed text-muted-foreground">
                Flight delayed? We watch it. Meeting moved? We&apos;ll be there. Rain? Your chauffeur is
                at the curb with an umbrella.
              </p>
              <Link
                to="/services"
                className="mt-10 inline-block border-b border-gold pb-1 font-mono text-xs uppercase tracking-[0.25em] text-gold transition hover:tracking-[0.35em]"
              >
                See What We Do →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* FLEET PREVIEW */}
      <section className="mx-auto max-w-7xl px-6 py-32 lg:px-10">
        <div className="mb-16 flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="eyebrow mb-4">The Fleet</p>
            <h2 className="font-display text-4xl md:text-5xl">A discreet selection.</h2>
          </div>
          <Link
            to="/our-fleet"
            className="font-mono text-xs uppercase tracking-[0.25em] text-gold transition-all hover:tracking-[0.35em]"
          >
            All Vehicles →
          </Link>
        </div>

        <div className="grid gap-8 md:grid-cols-2">
          {[
            { img: sedan, name: "Executive Sedan", sub: "Mercedes-Benz S-Class", caps: "1–3 passengers" },
            { img: suv, name: "Luxury SUV", sub: "Cadillac Escalade Premium", caps: "1–6 passengers" },
          ].map((v) => (
            <div key={v.name} className="group relative overflow-hidden bg-card">
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={v.img}
                  alt={v.name}
                  width={1280}
                  height={960}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
              </div>
              <div className="flex items-end justify-between p-8">
                <div>
                  <h3 className="font-display text-2xl">{v.name}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{v.sub}</p>
                </div>
                <p className="font-mono text-[0.65rem] uppercase tracking-[0.2em] text-gold">{v.caps}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="relative overflow-hidden border-y border-border bg-card py-32">
        <div className="mx-auto max-w-4xl px-6 text-center lg:px-10">
          <p className="eyebrow mb-6">Concierge</p>
          <h2 className="font-display text-4xl leading-tight md:text-6xl">
            Some things should not be booked through an app.
          </h2>
          <p className="mx-auto mt-8 max-w-xl text-lg text-muted-foreground">Call our 24-hour concierge.</p>
          <div className="mt-12 flex flex-wrap justify-center gap-4">
            <a
              href={COMPANY.phoneHref}
              className="border border-gold bg-gold px-8 py-4 text-xs uppercase tracking-[0.25em] text-primary-foreground transition hover:bg-transparent hover:text-gold"
            >
              {COMPANY.phone}
            </a>
            <Link
              to="/contact"
              className="border border-border px-8 py-4 font-mono text-xs uppercase tracking-[0.25em] hover:border-gold hover:text-gold"
            >
              Request Account
            </Link>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
