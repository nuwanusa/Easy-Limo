import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { sendQuoteToClient } from "@/lib/quotes.functions";

export const Route = createFileRoute("/quotes")({
  head: () => ({
    meta: [
      { title: "Quote Requests — Blackwave Dispatch" },
      { name: "description", content: "Website quote requests submitted by prospective clients." },
      { property: "og:title", content: "Quote Requests — Blackwave Dispatch" },
      { property: "og:description", content: "Review and action incoming website quote requests." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: QuotesPage,
});

const STATUSES = ["new", "contacted", "quoted", "booked", "closed"] as const;

const usd = (n: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(n);

function QuoteComposer({ q }: { q: any }) {
  const qc = useQueryClient();
  const send = useServerFn(sendQuoteToClient);
  const [amount, setAmount] = useState(q.quote_amount ? String(q.quote_amount) : "");
  const [message, setMessage] = useState(q.quote_message ?? "");
  const [validUntil, setValidUntil] = useState(q.quote_valid_until ?? "");

  const mut = useMutation({
    mutationFn: async () =>
      send({
        data: {
          id: q.id,
          amount: Number(amount),
          message: message || undefined,
          validUntil: validUntil || undefined,
        },
      }),
    onSuccess: (res: any) => {
      if (res?.sent) toast.success(`Quote emailed to ${res.to}`);
      else toast.error(res?.reason ?? "Email not sent");
      qc.invalidateQueries({ queryKey: ["quote_requests"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const input = "mt-1 w-full rounded-md border border-input bg-surface-2 px-3 py-2 text-sm";

  return (
    <div className="mt-4 rounded-md border border-border bg-surface-2 p-4">
      <div className="font-cond text-[11px] uppercase tracking-[0.25em] text-brand">Send a quote</div>
      {q.quote_sent_at && (
        <div className="mt-2 text-xs text-muted-foreground">
          Last sent {fmt(q.quote_sent_at)} · {usd(Number(q.quote_amount || 0))}
        </div>
      )}
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <label className="block text-xs uppercase text-muted-foreground">
          Quote amount (USD)
          <input type="number" min="0" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} className={input} />
        </label>
        <label className="block text-xs uppercase text-muted-foreground">
          Valid until
          <input type="date" value={validUntil} onChange={(e) => setValidUntil(e.target.value)} className={input} />
        </label>
      </div>
      <label className="mt-3 block text-xs uppercase text-muted-foreground">
        Message to the client
        <textarea
          rows={3}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="What the price includes, wait time, tolls, gratuity…"
          className={input}
        />
      </label>
      <button
        onClick={() => mut.mutate()}
        disabled={mut.isPending || !amount}
        className="mt-3 rounded-md bg-brand px-4 py-2 font-cond text-[11px] uppercase tracking-[0.2em] text-primary-foreground disabled:opacity-50"
      >
        {mut.isPending ? "Sending…" : q.quote_sent_at ? "Resend quote" : "Send quote by email"}
      </button>
    </div>
  );
}

function fmt(v: string | null) {
  if (!v) return "—";
  return new Date(v).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" });
}

function QuotesPage() {
  const qc = useQueryClient();
  const { data = [], isLoading } = useQuery({
    queryKey: ["quote_requests"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("quote_requests")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const update = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("quote_requests").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["quote_requests"] });
      toast.success("Updated");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <AppShell>
      <div className="mx-auto max-w-[1800px] px-4 py-8">
        <h1 className="font-display text-2xl uppercase">Quote requests</h1>
        <p className="mt-1 text-sm text-muted-foreground">Submitted from the public website contact page.</p>

        {isLoading && <div className="mt-8 text-sm text-muted-foreground">Loading…</div>}
        {!isLoading && data.length === 0 && (
          <div className="mt-8 rounded-lg border border-border bg-card p-8 text-center text-sm text-muted-foreground">
            No quote requests yet.
          </div>
        )}

        <div className="mt-6 grid gap-4 lg:grid-cols-2">
          {data.map((q) => (
            <article key={q.id} className="rounded-lg border border-border bg-card p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="font-display text-lg uppercase">{q.full_name}</div>
                  <div className="text-sm text-muted-foreground">
                    {q.company ? `${q.company} · ` : ""}
                    {q.email}
                    {q.phone ? ` · ${q.phone}` : ""}
                  </div>
                </div>
                <select
                  value={q.status ?? "new"}
                  onChange={(e) => update.mutate({ id: q.id, status: e.target.value })}
                  className="rounded-md border border-input bg-surface-2 px-2 py-1.5 text-xs uppercase"
                >
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              <dl className="mt-4 grid gap-2 text-sm sm:grid-cols-2">
                <div>
                  <dt className="text-xs uppercase text-muted-foreground">Service</dt>
                  <dd>{q.service_type ?? "—"}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase text-muted-foreground">Pickup time</dt>
                  <dd>{fmt(q.pickup_at)}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase text-muted-foreground">From</dt>
                  <dd>{q.pickup_address ?? "—"}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase text-muted-foreground">To</dt>
                  <dd>{q.dropoff_address ?? "—"}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase text-muted-foreground">Passengers</dt>
                  <dd>{q.passenger_count ?? "—"}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase text-muted-foreground">Luggage</dt>
                  <dd>{q.luggage_count ?? 0}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase text-muted-foreground">Vehicle</dt>
                  <dd>{q.vehicle_class ?? "—"}</dd>
                </div>
                <div>
                  <dt className="text-xs uppercase text-muted-foreground">Trip</dt>
                  <dd>{q.round_trip ? "Round trip" : "One way"}</dd>
                </div>
                <div className="sm:col-span-2">
                  <dt className="text-xs uppercase text-muted-foreground">Stops</dt>
                  <dd>
                    {Array.isArray(q.stops) && q.stops.length > 0
                      ? (q.stops as string[]).join(" → ")
                      : "—"}
                  </dd>
                </div>
              </dl>

              {q.notes && <p className="mt-4 rounded-md bg-surface-2 p-3 text-sm">{q.notes}</p>}
              <QuoteComposer q={q} />
              <div className="mt-3 text-xs text-muted-foreground">Received {fmt(q.created_at)}</div>
            </article>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
