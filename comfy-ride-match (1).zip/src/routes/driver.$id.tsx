import { driverContact } from "@/lib/ride-contact";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { DriverShell } from "@/components/DriverShell";
import { TripEta } from "@/components/TripEta";
import { FlightStatusCard } from "@/components/FlightStatusCard";
import { RideSummary } from "@/components/RideSummary";
import { WaitingClock } from "@/components/WaitingClock";


import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { useRideTrail } from "@/hooks/useRideTrail";
import {
  useDriverAccount,
  driverTripsQuery,
  driverStopsQuery,
  driverFlowFor,
} from "@/lib/driver";
import { mapsUrl, wazeUrl } from "@/lib/nav-links";
import { autoWaitingMinutes, waitingExempt } from "@/lib/waiting-time";
import { useServerFn } from "@tanstack/react-start";

import { submitRideTolls } from "@/lib/tolls.functions";
import { submitRideReport } from "@/lib/ride-report.functions";

import {
  bookingTypeLabel,
  clockTime,
  driverPayout,
  fareTotal,
  groupStops,
  money,
  statusLabel,
} from "@/lib/dispatch";


export const Route = createFileRoute("/driver/$id")({
  head: () => ({
    meta: [
      { title: "Trip Details — Blackwave Driver" },
      {
        name: "description",
        content:
          "Trip sheet for Blackwave chauffeurs: passenger contact, pickup, stops, drop-off and status updates.",
      },
      { property: "og:title", content: "Trip Details — Blackwave Driver" },
      {
        property: "og:description",
        content: "Passenger contact, full itinerary and one-tap status updates for your trip.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: DriverTripPage,
});

function splitTerminalLevel(v: string | null): { terminal: string | null; level: string | null } {
  if (!v) return { terminal: null, level: null };
  const parts = v.split("/");
  if (parts.length >= 2) {
    return { terminal: (parts[0] ?? "").trim() || null, level: parts.slice(1).join("/").trim() || null };
  }
  return { terminal: v.trim() || null, level: null };
}

function DriverTripPage() {
  const { id } = Route.useParams();
  const qc = useQueryClient();
  const { data: driver, isLoading } = useDriverAccount();
  const { data: trips = [] } = useQuery(driverTripsQuery(driver?.id));
  const { data: stops = [] } = useQuery(driverStopsQuery(driver?.id));
  const sendTolls = useServerFn(submitRideTolls);
  const sendReport = useServerFn(submitRideReport);



  const trip = trips.find((t) => t.id === id);
  const tripStops = trip ? (groupStops(stops).get(trip.id) ?? []) : [];
  // Breadcrumbs for the road actually driven, used to charge real tolls.
  useRideTrail(id, driver?.id, trip?.status);

  // Moment the chauffeur reported standing at the pickup point — the free
  // 15-minute wait starts here, not at the scheduled pickup time.
  const { data: arrivedAt = null } = useQuery({
    queryKey: ["trip-arrival", id],
    enabled: Boolean(id),
    refetchInterval: 60_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("reservation_status_events")
        .select("occurred_at")
        .eq("reservation_id", id)
        .eq("status", "on_location")
        .order("occurred_at", { ascending: false })
        .limit(1);
      if (error) throw error;
      return data?.[0]?.occurred_at ?? null;
    },
  });

  const setStatus = useMutation({
    mutationFn: async (status: string) => {
      const now = new Date();
      const patch: {
        status: string;
        dropoff_at?: string | null;
        pickup_at?: string;
        waiting_minutes?: number;
      } =
        status === "completed" && !trip?.dropoff_at
          ? { status, dropoff_at: now.toISOString() }
          : { status };
      // Non-airport rides bill waiting time automatically: everything past the
      // 15-minute grace after the chauffeur arrives until the passenger boards.
      if (
        status === "passenger_on_board" &&
        trip &&
        !waitingExempt(
          trip as {
            airport_name?: string | null;
            flight_number?: string | null;
            booking_type?: string | null;
          },
        )
      ) {
        const { data: arrivedRows } = await supabase
          .from("reservation_status_events")
          .select("occurred_at")
          .eq("reservation_id", id)
          .eq("status", "on_location")
          .order("occurred_at", { ascending: false })
          .limit(1);
        patch.waiting_minutes = autoWaitingMinutes(arrivedRows?.[0]?.occurred_at ?? null, now);
      }
      // Correcting a mistaken status: leaving "completed" clears the drop-off time.
      if (status !== "completed" && trip?.status === "completed") patch.dropoff_at = null;
      // The pickup time can never be later than the drop-off time. If the ride
      // finishes before its scheduled pickup, the schedule was late: record the
      // actual on-board time (or the completion time) as the pickup instead.
      if (patch.dropoff_at && trip?.pickup_at && now.getTime() < new Date(trip.pickup_at).getTime()) {
        const { data: boarded } = await supabase
          .from("reservation_status_events")
          .select("occurred_at")
          .eq("reservation_id", id)
          .eq("status", "passenger_on_board")
          .order("occurred_at", { ascending: false })
          .limit(1);
        const boardedAt = boarded?.[0]?.occurred_at ? new Date(boarded[0].occurred_at) : null;
        patch.pickup_at = (
          boardedAt && boardedAt.getTime() <= now.getTime() ? boardedAt : now
        ).toISOString();
      }
      const { error } = await supabase.from("reservations").update(patch).eq("id", id);
      if (error) throw error;
      await supabase
        .from("reservation_status_events")
        .insert({ reservation_id: id, status, occurred_at: new Date().toISOString() });
      // Once the passenger is dropped off, file the route's tolls with dispatch.
      if (status === "completed" && trip?.status !== "completed") {
        await sendTolls({ data: { reservation_id: id } }).catch(() => undefined);
        // File the full ride report (milestone times, stop times, distance driven).
        await sendReport({ data: { reservation_id: id } }).catch(() => undefined);
      }
    },
    onSuccess: (_d, status) => {
      qc.invalidateQueries({ queryKey: ["driver-trips"] });
      qc.invalidateQueries({ queryKey: ["trip-events", id] });
      toast.success(`Trip marked ${statusLabel(status)}`);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <DriverShell driver={driver ?? null} loading={isLoading}>
      {!trip ? (
        <div className="mt-10 rounded-lg border border-border bg-card p-6 text-center font-cond text-sm text-muted-foreground">
          Trip not found or no longer assigned to you.
          <div>
            <Link to="/driver" className="mt-4 inline-block text-brand">
              Back to my trips
            </Link>
          </div>
        </div>
      ) : (
        <>
          <Link
            to="/driver"
            className="mt-4 inline-block font-cond text-[11px] uppercase tracking-widest text-muted-foreground hover:text-brand"
          >
            ← My trips
          </Link>

          <div className="mt-3 rounded-lg border border-border bg-card p-5">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                  Trip {trip.reference}
                </div>
                <div className="mt-1 flex items-baseline gap-x-2 font-display text-xl uppercase leading-none sm:text-4xl sm:gap-x-3">
                  <span className="whitespace-nowrap">
                    {new Date(trip.pickup_at).toLocaleDateString("en-US", {
                      weekday: "short",
                      month: "short",
                      day: "numeric",
                    })}
                  </span>
                  <span className="whitespace-nowrap">
                    {new Date(trip.pickup_at).toLocaleTimeString("en-US", {
                      hour: "numeric",
                      minute: "2-digit",
                      hour12: true,
                    })}
                  </span>
                </div>
              </div>
              <span className="shrink-0 rounded-full border border-success/30 bg-success/10 px-3 py-1 font-cond text-[10px] uppercase tracking-widest text-success">
                {statusLabel(trip.status)}
              </span>
            </div>
            <div className="mt-2 font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
              {bookingTypeLabel(trip.booking_type)}
            </div>

            <div className="mt-5 space-y-4">
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                    Passenger
                  </div>
                  <div className="mt-0.5 truncate font-cond text-lg font-semibold">
                    {trip.passenger_name}
                  </div>
                </div>
                <span className="shrink-0 rounded-full border border-brand/30 bg-brand/10 px-3 py-1 font-cond text-[11px] uppercase tracking-widest text-brand">
                  {trip.passenger_count} pax
                </span>
              </div>
              {(() => {
                const contact = driverContact(trip as never);
                if (!contact.phone) return null;
                return (
                  <div>
                    <div className="mb-1.5 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                      Contact · {contact.label}
                      {contact.name ? ` · ${contact.name}` : ""}
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <a
                        href={`tel:${contact.phone}`}
                        className="rounded-md border border-success bg-success px-3 py-2.5 text-center font-cond text-[11px] uppercase tracking-widest text-brand-foreground transition-opacity hover:opacity-90"
                      >
                        Call
                      </a>
                      <a
                        href={`sms:${contact.phone}`}
                        className="rounded-md border border-success bg-success px-3 py-2.5 text-center font-cond text-[11px] uppercase tracking-widest text-brand-foreground transition-opacity hover:opacity-90"
                      >
                        Text
                      </a>
                      <a
                        href={`https://wa.me/${contact.phone.replace(/\D/g, "")}`}
                        target="_blank"
                        rel="noreferrer"
                        className="rounded-md border border-success bg-success px-3 py-2.5 text-center font-cond text-[11px] uppercase tracking-widest text-brand-foreground transition-opacity hover:opacity-90"
                      >
                        WhatsApp
                      </a>
                    </div>
                  </div>
                );
              })()}
            </div>
          </div>

          <div className="mt-4 rounded-lg border border-border bg-card p-5">
            <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
              Itinerary
            </div>
            <Leg
              label="Pickup"
              address={trip.pickup_address}
              time={clockTime(trip.pickup_at)}
            />
            {tripStops.map((s, i) => (
              <Leg
                key={s.id}
                label={`Stop ${i + 1}`}
                address={s.address}
                time={s.stop_at ? clockTime(s.stop_at) : undefined}
                note={s.note}
              />
            ))}
            <Leg
              label="Drop-off"
              address={trip.dropoff_address}
              time={trip.dropoff_at ? clockTime(trip.dropoff_at) : undefined}
            />
          </div>

          {(trip.flight_number ||
            trip.airport_name ||
            trip.terminal_level ||
            trip.door_number ||
            trip.flight_direction !== "none") && (
            <div className="mt-4 rounded-lg border border-border bg-card p-5">
              <div className="rounded-lg bg-muted/50 p-4">
                {trip.airport_name && (
                  <div className="flex items-start gap-2.5">
                    <PlaneGlyph className="mt-0.5 h-4 w-4 shrink-0 text-brand" />
                    <div className="min-w-0">
                      <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                        Airport
                      </div>
                      <div className="mt-0.5 break-words font-cond text-[15px] font-semibold leading-snug text-foreground">
                        {trip.airport_name}
                      </div>
                    </div>
                  </div>
                )}
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <SpecTile label="Flight" value={trip.flight_number} />
                  <SpecTile
                    label="Type"
                    value={
                      trip.flight_direction === "arrival"
                        ? "Arrival"
                        : trip.flight_direction === "departure"
                          ? "Departure"
                          : null
                    }
                  />
                  <SpecTile label="Terminal" value={splitTerminalLevel(trip.terminal_level).terminal} />
                  <SpecTile label="Level" value={splitTerminalLevel(trip.terminal_level).level} />
                  <SpecTile label="Door #" value={trip.door_number} />
                  <SpecTile label="Passengers" value={String(trip.passenger_count)} />
                </div>
              </div>
            </div>
          )}

          <div className="mt-4 rounded-lg border border-brand/40 bg-brand/5 p-5">
            <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
              Estimated pay for this ride
            </div>
            <div className="mt-1 font-display text-3xl uppercase leading-none">
              {money(driverPayout(trip, driver, tripStops.length))}
            </div>
            <div className="mt-1 font-cond text-[11px] text-muted-foreground">
              Estimate only — final payout may change with tolls, waiting time or route changes.
            </div>
          </div>

          {!waitingExempt(
            trip as {
              airport_name?: string | null;
              flight_number?: string | null;
              booking_type?: string | null;
            },
          ) && (
            <WaitingClock
              arrivedAt={arrivedAt}
              status={trip.status}
              waitingMinutes={
                (trip as { waiting_minutes?: number | null }).waiting_minutes ?? null
              }
              airport={false}
            />
          )}

          {trip.flight_number && trip.status !== "completed" && trip.status !== "cancelled" && (
            <FlightStatusCard flightNumber={trip.flight_number} pickupAt={trip.pickup_at} />
          )}

          {trip.status !== "completed" && trip.status !== "cancelled" && (
            <TripEta
              pickup={trip.pickup_address}
              stops={tripStops}
              dropoff={trip.dropoff_address}
            />
          )}
          {trip.notes && (
            <div className="mt-4 rounded-lg border border-brand/40 bg-brand/5 p-5">
              <div className="font-cond text-[10px] uppercase tracking-widest text-brand">
                Notes from dispatch
              </div>
              <p className="mt-2 whitespace-pre-wrap font-cond text-[14px] leading-relaxed text-foreground">
                {trip.notes}
              </p>
            </div>
          )}



          <p className="mt-4 font-cond text-[11px] text-muted-foreground">
            Tapped the wrong status by mistake? Tap the correct step to change it back — or undo
            "On my way" if the trip hasn't started.
          </p>
          <div className="mt-2 grid gap-2">
            {(() => {
              const flow = driverFlowFor(tripStops.length);
              const currentIndex = flow.findIndex((f) => f.status === trip.status);
              return flow.map((step, i) => (
                <button
                  key={step.status}
                  disabled={setStatus.isPending || trip.status === step.status}
                  onClick={() => {
                    if (
                      currentIndex >= 0 &&
                      i < currentIndex &&
                      !window.confirm(`Change the status back to "${step.label}"?`)
                    )
                      return;
                    setStatus.mutate(step.status);
                  }}
                  className={`rounded-md py-3 font-cond text-xs uppercase tracking-[0.3em] transition-opacity hover:opacity-90 disabled:opacity-40 ${
                    trip.status === step.status
                      ? "bg-success text-brand-foreground"
                      : currentIndex >= 0 && i < currentIndex
                        ? "border border-border text-muted-foreground"
                        : "bg-success text-brand-foreground"
                  }`}
                >
                  {step.label}
                </button>
              ));
            })()}
            {trip.status === "en_route" && (
              <button
                disabled={setStatus.isPending}
                onClick={() => {
                  if (!window.confirm('Undo "On my way"? The trip goes back to "not started".')) return;
                  setStatus.mutate("confirmed");
                }}
                className="rounded-md border border-border py-3 font-cond text-xs uppercase tracking-[0.3em] text-muted-foreground transition-opacity hover:opacity-90"
              >
                Undo — not on my way yet
              </button>
            )}
          </div>

          {trip.status === "completed" && (
            <RideSummary reservationId={trip.id} initialNote={trip.driver_note ?? null} />
          )}

        </>
      )}
    </DriverShell>
  );
}

function Leg({
  label,
  address,
  time,
  note,
}: {
  label: string;
  address: string;
  time?: string | undefined;
  note?: string | null | undefined;
}) {
  return (
    <div className="mt-3 border-l-2 border-brand/50 pl-3">
      <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
        {label}
        {time ? ` · ${time}` : ""}
      </div>
      <div className="font-cond text-[14px] leading-snug">{address}</div>
      {note && <div className="font-cond text-[12px] text-muted-foreground">{note}</div>}
      <div className="mt-2 grid grid-cols-2 gap-2">
        <a
          href={mapsUrl(address)}
          target="_blank"
          rel="noreferrer"
          className="rounded-md border border-border px-3 py-2 text-center font-cond text-[11px] uppercase tracking-widest text-brand"
        >
          Google Maps
        </a>
        <a
          href={wazeUrl(address)}
          target="_blank"
          rel="noreferrer"
          className="rounded-md border border-border px-3 py-2 text-center font-cond text-[11px] uppercase tracking-widest text-brand"
        >
          Waze
        </a>
      </div>
    </div>
  );
}

function SpecTile({
  label,
  value,
  className,
}: {
  label: string;
  value?: string | null;
  className?: string | undefined;
}) {
  if (!value) return null;
  return (
    <div className={`rounded-md border border-border/60 bg-card px-3 py-2.5 ${className ?? ""}`}>
      <div className="font-cond text-[9px] uppercase tracking-widest text-muted-foreground">
        {label}
      </div>
      <div className="mt-0.5 break-words font-cond text-sm font-semibold leading-5 text-foreground">
        {value}
      </div>
    </div>
  );
}

function PlaneGlyph({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M21 16v-2l-8-5V3.5A1.5 1.5 0 0 0 11.5 2 1.5 1.5 0 0 0 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z" />
    </svg>
  );
}
