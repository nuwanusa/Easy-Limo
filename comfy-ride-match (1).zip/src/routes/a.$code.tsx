import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  affiliateRespondToRide,
  affiliateSubmitDriver,
  getAffiliatePortal,
  type AffiliatePortalRide,
} from "@/lib/affiliates.functions";

export const Route = createFileRoute("/a/$code")({
  head: () => ({
    meta: [
      { title: "Partner Portal — Blackwave Transportation LLC" },
      { name: "description", content: "Accept assigned rides, submit your chauffeur and vehicle, and view your statements." },
      { property: "og:title", content: "Partner Portal — Blackwave Transportation LLC" },
      { property: "og:description", content: "Assigned rides, chauffeur submission and payout statements for Blackwave partners." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AffiliatePortalPage,
});

const money = (v: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(v);
const when = (iso: string | null) =>
  iso ? new Date(iso).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" }) : "—";
const input = "mt-1 w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900";

function AffiliatePortalPage() {
  const { code } = Route.useParams();
  const load = useServerFn(getAffiliatePortal);

  const portal = useQuery({
    queryKey: ["affiliate-portal", code],
    queryFn: () => load({ data: { code } }),
    refetchInterval: 60_000,
    retry: false,
  });

  if (portal.isLoading) {
    return <Shell><p className="text-slate-600">Loading your partner portal…</p></Shell>;
  }
  if (portal.error || !portal.data) {
    return (
      <Shell>
        <p className="text-slate-700">This partner link is not valid. Please ask Blackwave dispatch for a new one.</p>
      </Shell>
    );
  }

  const { affiliate, rides, statements, earnings } = portal.data;
  const unbilled = earnings.filter((e) => !e.statement_id).reduce((s, e) => s + e.amount, 0);
  const upcoming = rides.filter((r) => r.status !== "completed" && r.status !== "cancelled");
  const past = rides.filter((r) => r.status === "completed" || r.status === "cancelled");

  return (
    <Shell>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[11px] uppercase tracking-[0.3em] text-slate-500">Partner portal</p>
          <h1 className="text-2xl font-semibold text-slate-900">{affiliate.name}</h1>
          <p className="text-sm text-slate-600">
            {[affiliate.contact_name, affiliate.phone, affiliate.email].filter(Boolean).join(" · ")}
          </p>
        </div>
        <div className="rounded-lg border border-slate-200 bg-white px-4 py-3 text-right">
          <div className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Unbilled earnings</div>
          <div className="text-xl font-semibold text-slate-900">{money(unbilled)}</div>
        </div>
      </div>

      <section className="mt-6 space-y-3">
        <h2 className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">Assigned rides</h2>
        {!upcoming.length && <Card>No rides assigned to you right now.</Card>}
        {upcoming.map((ride) => (
          <RideCard key={ride.id} ride={ride} code={code} />
        ))}
      </section>

      <section className="mt-8 space-y-3">
        <h2 className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">Statements</h2>
        {!statements.length && <Card>No statements yet.</Card>}
        {statements.map((s) => (
          <Card key={s.id}>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="font-semibold text-slate-900">{s.statement_number}</div>
                <div className="text-xs text-slate-500">
                  {s.period_start} – {s.period_end} · {s.status}
                </div>
              </div>
              <div className="text-lg font-semibold text-slate-900">{money(s.total)}</div>
            </div>
          </Card>
        ))}
      </section>

      {past.length > 0 && (
        <section className="mt-8 space-y-3">
          <h2 className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">Completed rides</h2>
          {past.slice(0, 20).map((r) => (
            <Card key={r.id}>
              <div className="flex flex-wrap items-center justify-between gap-2 text-sm">
                <div>
                  <div className="font-semibold text-slate-900">{r.reference}</div>
                  <div className="text-xs text-slate-600">{when(r.pickup_at)}</div>
                  <div className="text-xs text-slate-600">
                    {r.pickup_address} → {r.dropoff_address}
                  </div>
                </div>
                <div className="font-semibold text-slate-900">{money(r.affiliate_payout)}</div>
              </div>
            </Card>
          ))}
        </section>
      )}
    </Shell>
  );
}

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-slate-100 px-4 py-8">
      <div className="mx-auto max-w-4xl">
        <div className="mb-6 text-[11px] uppercase tracking-[0.3em] text-slate-500">
          Blackwave Transportation LLC
        </div>
        {children}
      </div>
    </div>
  );
}

function Card({ children }: { children: React.ReactNode }) {
  return <div className="rounded-lg border border-slate-200 bg-white p-4 text-sm text-slate-700">{children}</div>;
}

function RideCard({ ride, code }: { ride: AffiliatePortalRide; code: string }) {
  const qc = useQueryClient();
  const respond = useServerFn(affiliateRespondToRide);
  const submit = useServerFn(affiliateSubmitDriver);
  const [driverName, setDriverName] = useState(ride.affiliate_driver_name ?? "");
  const [driverPhone, setDriverPhone] = useState(ride.affiliate_driver_phone ?? "");
  const [vehicle, setVehicle] = useState(ride.affiliate_vehicle ?? "");
  const [notes, setNotes] = useState(ride.affiliate_notes ?? "");

  const refresh = () => qc.invalidateQueries({ queryKey: ["affiliate-portal", code] });

  const answer = useMutation({
    mutationFn: (action: "accept" | "decline") => respond({ data: { code, reservationId: ride.id, action } }),
    onSuccess: (_d, action) => {
      toast.success(action === "accept" ? "Ride accepted" : "Ride declined");
      refresh();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const saveDriver = useMutation({
    mutationFn: () => submit({ data: { code, reservationId: ride.id, driverName, driverPhone, vehicle, notes } }),
    onSuccess: () => {
      toast.success("Chauffeur details sent to dispatch");
      refresh();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Card>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <div className="text-base font-semibold text-slate-900">{when(ride.pickup_at)}</div>
          <div className="text-xs uppercase tracking-[0.2em] text-slate-500">
            {ride.reference} · {ride.vehicle_class}
            {ride.booking_type === "hourly" ? ` · ${ride.hours} hrs` : ""}
          </div>
        </div>
        <div className="text-right">
          <div className="text-lg font-semibold text-slate-900">{money(ride.affiliate_payout)}</div>
          <div className="text-[11px] uppercase tracking-[0.2em] text-slate-500">{ride.affiliate_status ?? "offered"}</div>
        </div>
      </div>

      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        <div>
          <div className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Pickup</div>
          <div className="text-slate-900">{ride.pickup_address}</div>
        </div>
        <div>
          <div className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Drop-off</div>
          <div className="text-slate-900">{ride.dropoff_address}</div>
        </div>
        <div>
          <div className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Passenger</div>
          <div className="text-slate-900">
            {ride.passenger_name} · {ride.passenger_count} pax · {ride.luggage_count} bags
          </div>
        </div>
        {(ride.airport_name || ride.flight_number) && (
          <div>
            <div className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Flight</div>
            <div className="text-slate-900">
              {[ride.airport_name, ride.airline, ride.flight_number].filter(Boolean).join(" · ")}
            </div>
          </div>
        )}
        {ride.notes && (
          <div className="sm:col-span-2">
            <div className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Notes</div>
            <div className="text-slate-900">{ride.notes}</div>
          </div>
        )}
      </div>

      {ride.affiliate_status !== "accepted" && (
        <div className="mt-3 flex gap-2">
          <button
            disabled={answer.isPending}
            onClick={() => answer.mutate("accept")}
            className="rounded-md bg-emerald-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
          >
            Accept ride
          </button>
          <button
            disabled={answer.isPending}
            onClick={() => answer.mutate("decline")}
            className="rounded-md border border-slate-300 px-4 py-2 text-sm text-slate-700 disabled:opacity-60"
          >
            Decline
          </button>
        </div>
      )}

      <div className="mt-4 rounded-md border border-slate-200 bg-slate-50 p-3">
        <div className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Your chauffeur &amp; vehicle</div>
        <div className="mt-2 grid gap-2 sm:grid-cols-2">
          <label className="text-xs text-slate-600">
            Chauffeur name
            <input className={input} value={driverName} onChange={(e) => setDriverName(e.target.value)} />
          </label>
          <label className="text-xs text-slate-600">
            Chauffeur phone
            <input className={input} value={driverPhone} onChange={(e) => setDriverPhone(e.target.value)} />
          </label>
          <label className="text-xs text-slate-600 sm:col-span-2">
            Vehicle (color, make, model, plate)
            <input className={input} value={vehicle} onChange={(e) => setVehicle(e.target.value)} />
          </label>
          <label className="text-xs text-slate-600 sm:col-span-2">
            Notes for dispatch
            <textarea className={input} rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
          </label>
        </div>
        <button
          disabled={saveDriver.isPending}
          onClick={() => saveDriver.mutate()}
          className="mt-2 rounded-md bg-slate-900 px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
        >
          Send to dispatch
        </button>
      </div>
    </Card>
  );
}
