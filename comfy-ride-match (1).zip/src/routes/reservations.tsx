import { Fragment, useEffect, useRef, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AppShell, PageHeading, StatusChip } from "@/components/AppShell";
import { ReservationRequests } from "@/components/ReservationRequests";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { sendDriverAssignmentEmail } from "@/lib/driver-notify.functions";
import { sendClientRideNotice } from "@/lib/client-notify.functions";
import { AddressAutocomplete, AddressField } from "@/components/AddressAutocomplete";
import { ReservationCalendar } from "@/components/ReservationCalendar";
import { useRole } from "@/lib/roles";
import { ActiveRides } from "@/components/ActiveRides";
import { GuestLinkShare } from "@/components/GuestLinkShare";
import { DriverInfoShare } from "@/components/DriverInfoShare";
import { RideEmailShare } from "@/components/RideEmailShare";
import { AirlineField } from "@/components/AirlineField";
import { CardsOnFile } from "@/components/CardsOnFile";
import type { Reservation } from "@/lib/dispatch";
import { isActiveStatus } from "@/lib/trip-status";
import { DRIVER_CONTACT_OPTIONS } from "@/lib/ride-contact";
import { ArrowLeft, CalendarDays, Copy, ExternalLink, Filter, Plus, Save, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  BOOKING_TYPES,
  bookingTypeLabel,
  clientPassengersQuery,
  type ClientPassenger,
  clientRatesQuery,
  clientsQuery,
  clockTime,
  dayLabel,
  driversQuery,
  driverPayEstimate,
  driverPayout,
  fareTotal,
  groupStops,
  money,
  reservationsQuery,
  stopsQuery,
  vehiclesQuery,
  waitingCharge,
  zoneRatesQuery,


  RESERVATION_STATUSES,
  VEHICLE_CLASSES,
} from "@/lib/dispatch";

export const Route = createFileRoute("/reservations")({
  validateSearch: (search: Record<string, unknown>): { edit?: string; new?: string } => ({
    ...(typeof search['edit'] === "string" ? { edit: search['edit'].replace(/^"|"$/g, "") } : {}),
    ...(typeof search['new'] === "string"
      ? { new: search['new'].replace(/^"|"$/g, "") }
      : search['new'] === 1 || search['new'] === true
        ? { new: "1" }
        : {}),
  }),
  head: () => ({
    meta: [
      { title: "Reservations — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Every chauffeur reservation in one ledger: passenger, route, vehicle class, assigned crew, status and fare.",
      },
      { property: "og:title", content: "Reservations — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Create and track limousine reservations with fares, flights and crew assignment.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <AppShell>
      <ReservationsPage />
    </AppShell>
  ),
});

const PAYMENT_METHODS = [
  "Credit card",
  "Zelle",
  "Venmo",
  "Cash App",
  "ACH transfer",
  "Cash",
  "Bill to account",
];

type ExtraPassenger = { name: string; phone: string; email: string };

function parseExtraPassengers(value: unknown): ExtraPassenger[] {
  if (!Array.isArray(value)) return [];
  return value.map((p) => {
    const row = (p ?? {}) as Record<string, unknown>;
    return {
      name: typeof row['name'] === "string" ? row['name'] : "",
      phone: typeof row['phone'] === "string" ? row['phone'] : "",
      email: typeof row['email'] === "string" ? row['email'] : "",
    };
  });
}

const emptyForm = {
  reference: "",

  client_id: "",
  booked_by_name: "",
  booked_by_phone: "",
  booked_by_email: "",
  billing_contact_name: "",
  billing_contact_phone: "",
  billing_contact_email: "",
  driver_contact_role: "passenger",
  passenger_name: "",
  passenger_phone: "",
  passenger_email: "",
  passenger_count: 1,
  luggage_count: 0,
  car_seat_count: 0,
  car_seat_fee: 0,
  extra_passengers: [] as ExtraPassenger[],
  pickup_address: "",
  pickup_at: "",
  dropoff_address: "",
  dropoff_at: "",
  flight_number: "",
  airline: "",
  payment_method: "",
  airport_name: "",
  flight_direction: "none",
  terminal_level: "",
  door_number: "",
  vehicle_class: "sedan",
  booking_type: "point_to_point",
  hourly_rate: 0,
  hours: 0,
  minimum_hours: 3,
  stop_fee: 15,
  base_rate: 0,
  base_fare: 0,
  airport_fee: 0,
  meet_greet_fee: 0,
  parking_fee: 0,
  tolls: 0,
  gratuity: 0,
  waiting_minutes: 0,
  waiting_rate: 0,
  distance_miles: 0,
  driver_pay: 0,
  driver_hourly_pay: 0,
  driver_minimum_hours: 0,
  driver_total_hours: 0,
  driver_airport_fee: 0,
  driver_parking_fee: 0,
  driver_waiting_pay: 0,
  driver_waiting_hours: 0,
  driver_tolls: 0,
  notes: "",
};

type StopDraft = { address: string; stop_at: string; note: string };

function ReservationsPage() {
  const qc = useQueryClient();
  const { data: reservations = [] } = useQuery(reservationsQuery);
  const { data: drivers = [] } = useQuery(driversQuery);
  const { data: vehicles = [] } = useQuery(vehiclesQuery);
  const { data: clients = [] } = useQuery(clientsQuery);
  const { data: clientRates = [] } = useQuery(clientRatesQuery);
  const { data: zoneRates = [] } = useQuery(zoneRatesQuery);
  const { data: stops = [] } = useQuery(stopsQuery);
  const stopsByRide = groupStops(stops);

  const [filter, setFilter] = useState<string>("all");
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [stopDrafts, setStopDrafts] = useState<StopDraft[]>([]);
  const [payDriverId, setPayDriverId] = useState("");
  const [showPay, setShowPay] = useState(false);
  const [hourlyMode, setHourlyMode] = useState<"hourly" | "as_directed">("hourly");

  const { data: savedPassengers = [] } = useQuery(clientPassengersQuery);
  const passengerPool = form.client_id
    ? savedPassengers.filter((p) => p.client_id === form.client_id)
    : savedPassengers;

  const accountRates = clientRates.filter((r) => r.client_id === form.client_id);
  const accountZones = zoneRates.filter((z) => !!form.client_id && z.client_id === form.client_id);
  const globalZones = zoneRates.filter((z) => !z.client_id);



  const resetForm = () => {
    setForm(emptyForm);
    setStopDrafts([]);
    setEditingId(null);
    setHourlyMode("hourly");
    setOpen(false);
  };

  const localInput = (iso: string | null) => {
    if (!iso) return "";
    const d = new Date(iso);
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };

  const startEdit = (id: string) => {
    const r = reservations.find((x) => x.id === id);
    if (!r) return;
    setEditingId(id);
    setOpen(true);
    setForm({
      reference: r.reference,
      client_id: r.client_id ?? "",
      booked_by_name: (r as any).booked_by_name ?? "",
      booked_by_phone: (r as any).booked_by_phone ?? "",
      booked_by_email: (r as any).booked_by_email ?? "",
      billing_contact_name: (r as any).billing_contact_name ?? "",
      billing_contact_phone: (r as any).billing_contact_phone ?? "",
      billing_contact_email: (r as any).billing_contact_email ?? "",
      driver_contact_role: (r as any).driver_contact_role ?? "passenger",
      passenger_name: r.passenger_name,
      passenger_phone: r.passenger_phone ?? "",
      passenger_email: r.passenger_email ?? "",
      passenger_count: r.passenger_count,
      luggage_count: Number((r as any).luggage_count ?? 0),
      car_seat_count: Number((r as any).car_seat_count ?? 0),
      car_seat_fee: Number((r as any).car_seat_fee ?? 0),
      extra_passengers: parseExtraPassengers((r as { extra_passengers?: unknown }).extra_passengers),
      pickup_address: r.pickup_address,
      pickup_at: localInput(r.pickup_at),
      dropoff_address: r.dropoff_address,
      dropoff_at: localInput(r.dropoff_at),
      flight_number: r.flight_number ?? "",
      airline: r.airline ?? "",
      payment_method: r.payment_method ?? "",
      airport_name: r.airport_name ?? "",
      flight_direction: r.flight_direction ?? "none",
      terminal_level: r.terminal_level ?? "",
      door_number: r.door_number ?? "",
      vehicle_class: r.vehicle_class,
      booking_type: r.booking_type,
      hourly_rate: Number(r.hourly_rate),
      hours: Number(r.hours),
      minimum_hours: Number(r.minimum_hours),
      stop_fee: Number(r.stop_fee),
      base_rate: Number((r as any).base_rate ?? 0),
      base_fare: Number(r.base_fare),
      airport_fee: Number(r.airport_fee),
      meet_greet_fee: Number(r.meet_greet_fee ?? 0),
      parking_fee: Number(r.parking_fee ?? 0),
      tolls: Number(r.tolls),
      gratuity: Number(r.gratuity),
      waiting_minutes: Number(r.waiting_minutes ?? 0),
      waiting_rate: Number(r.waiting_rate ?? 0),
      distance_miles: Number(r.distance_miles ?? 0),
      driver_pay: Number(r.driver_pay ?? 0),
      driver_hourly_pay: Number(r.driver_hourly_pay ?? 0),
      driver_minimum_hours: Number(r.driver_minimum_hours ?? 0),
      driver_total_hours: Number(r.driver_total_hours ?? 0),
      driver_airport_fee: Number(r.driver_airport_fee ?? 0),
      driver_parking_fee: Number(r.driver_parking_fee ?? 0),
      driver_waiting_pay: Number(r.driver_waiting_pay ?? 0),
      driver_waiting_hours: Number(r.driver_waiting_hours ?? 0),
      driver_tolls: Number((r as { driver_tolls?: number }).driver_tolls ?? 0),
      notes: r.notes ?? "",
    });
    setStopDrafts(
      (stopsByRide.get(id) ?? []).map((s) => ({
        address: s.address,
        stop_at: localInput(s.stop_at),
        note: s.note ?? "",
      })),
    );
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const { edit: editParam, new: newParam } = Route.useSearch();
  const handledEdit = useRef<string | null>(null);
  const handledNew = useRef(false);
  useEffect(() => {
    if (editParam && reservations.length > 0 && handledEdit.current !== editParam) {
      handledEdit.current = editParam;
      startEdit(editParam);
    }
    if (newParam === "1" && !handledNew.current) {
      handledNew.current = true;
      setOpen(true);
      if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, [editParam, newParam, reservations.length]);

  const stopRows = (reservationId: string) =>
    stopDrafts
      .filter((s) => s.address.trim())
      .map((s, i) => ({
        reservation_id: reservationId,
        position: i + 1,
        address: s.address.trim(),
        stop_at: s.stop_at ? new Date(s.stop_at).toISOString() : null,
        note: s.note || null,
      }));

  const notifyClient = useServerFn(sendClientRideNotice);

  const basePayload = () => {
    const extras = form.extra_passengers
      .map((p) => ({ name: p.name.trim(), phone: p.phone.trim(), email: p.email.trim() }))
      .filter((p) => p.name || p.phone || p.email);
    return {
      ...form,
      extra_passengers: extras,
      passenger_count: Math.max(form.passenger_count, extras.length + 1),
      client_id: form.client_id || null,
      pickup_at: new Date(form.pickup_at).toISOString(),
      dropoff_at: form.dropoff_at ? new Date(form.dropoff_at).toISOString() : null,
    };
  };

  const create = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase
        .from("reservations")
        .insert({
          ...basePayload(),
          reference: form.reference || `AUR-${Math.floor(1000 + Math.random() * 9000)}`,
          status: "unassigned",
        })
        .select("id")
        .single();
      if (error) throw error;
      const rows = stopRows(data.id as string);
      if (rows.length) {
        const { error: stopError } = await supabase.from("reservation_stops").insert(rows);
        if (stopError) throw stopError;
      }
      try {
        await notifyClient({ data: { reservationId: data.id as string, kind: "reservation" } });
      } catch (err) {
        console.error("client confirmation email failed", err);
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["reservations"] });
      qc.invalidateQueries({ queryKey: ["reservation_stops"] });
      resetForm();
      toast.success("Reservation booked");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const update = useMutation({
    mutationFn: async (id: string) => {
      const { data: updated, error } = await supabase
        .from("reservations")
        .update(basePayload())
        .eq("id", id)
        .select("id");
      if (error) throw error;
      if (!updated || updated.length === 0)
        throw new Error("This reservation could not be saved — you may not have permission to edit it.");

      const { error: delError } = await supabase.from("reservation_stops").delete().eq("reservation_id", id);
      if (delError) throw delError;
      const rows = stopRows(id);
      if (rows.length) {
        const { error: stopError } = await supabase.from("reservation_stops").insert(rows);
        if (stopError) throw stopError;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["reservations"] });
      qc.invalidateQueries({ queryKey: ["reservation_stops"] });
      resetForm();
      toast.success("Reservation updated");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error: delStops } = await supabase.from("reservation_stops").delete().eq("reservation_id", id);
      if (delStops) throw delStops;
      const { error } = await supabase.from("reservations").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: (_d, id) => {
      qc.invalidateQueries({ queryKey: ["reservations"] });
      qc.invalidateQueries({ queryKey: ["reservation_stops"] });
      if (editingId === id) resetForm();
      toast.success("Reservation deleted");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const setStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      if (status === "completed") {
        const ride = reservations.find((r) => r.id === id);
        if (ride && !ride.dropoff_at)
          throw new Error("Add a drop-off time to this reservation before closing it.");
      }
      const { error } = await supabase.from("reservations").update({ status }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["reservations"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const notifyDriver = useServerFn(sendDriverAssignmentEmail);

  const setDriver = useMutation({
    mutationFn: async ({ id, driver_id }: { id: string; driver_id: string | null }) => {
      const { error } = await supabase.from("reservations").update({ driver_id, driver_confirmed_at: null }).eq("id", id);
      if (error) throw error;
      if (!driver_id) return { notified: null as null | { sent: boolean; reason?: string } };
      const notified = await notifyDriver({ data: { reservationId: id } });
      return { notified };
    },
    onSuccess: (res) => {
      qc.invalidateQueries({ queryKey: ["reservations"] });
      const n = res?.notified;
      if (!n) toast.success("Driver updated");
      else if (n.sent) toast.success("Driver assigned — confirmation email sent");
      else if (n.reason === "no_driver_email") toast.success("Driver assigned (no email on file, so no notification sent)");
      else toast.success("Driver assigned — email could not be sent yet");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const resendDriverEmail = useMutation({
    mutationFn: async (id: string) => await notifyDriver({ data: { reservationId: id } }),
    onSuccess: (n: { sent: boolean; reason?: string }) => {
      if (n?.sent) toast.success("Assignment email sent to the chauffeur");
      else if (n?.reason === "no_driver_email") toast.error("This chauffeur has no email on file");
      else toast.error(`Email could not be sent${n?.reason ? `: ${n.reason}` : ""}`);
    },
    onError: (e: Error) => toast.error(e.message),
  });


  const { isStaff, isAdmin } = useRole();
  const isAssigned = (r: { driver_confirmed_at?: string | null; status: string }) =>
    !!r.driver_confirmed_at && r.status !== "completed" && r.status !== "cancelled";
  const assignedCount = reservations.filter(isAssigned).length;
  const rows = reservations.filter((r) =>
    filter === "all" ? true : filter === "assigned" ? isAssigned(r) : r.status === filter,
  );
  // Below the calendar we only list rides still ahead of us. Once a chauffeur is
  // rolling ("on my way" onwards) the trip moves to the Active rides board.
  const isUpcoming = (r: { pickup_at: string; status: string }) =>
    r.status !== "completed" &&
    r.status !== "cancelled" &&
    !isActiveStatus(r.status) &&
    new Date(r.pickup_at).getTime() >= Date.now() - 2 * 60 * 60 * 1000;
  const tableRows = (filter === "all" || filter === "assigned"
    ? rows.filter(isUpcoming)
    : rows
  ).sort((a, b) => new Date(a.pickup_at).getTime() - new Date(b.pickup_at).getTime());
  // Completed list stays short: rides finished in the past 24 hours, recent
  // past-pickup rides that never started, plus completed rides not yet invoiced.
  const completedRows = reservations
    .filter((r) => {
      if (r.status === "cancelled" || isActiveStatus(r.status)) return false;
      const isCompleted = r.status === "completed";
      const pickupAt = new Date(r.pickup_at).getTime();
      const isPastUnstarted = !isCompleted && Number.isFinite(pickupAt) && pickupAt < Date.now();
      if (!isCompleted && !isPastUnstarted) return false;
      const finishedAt = new Date(isCompleted ? (r.dropoff_at ?? r.pickup_at) : r.pickup_at).getTime();
      const recent = Number.isFinite(finishedAt) && Date.now() - finishedAt <= 24 * 60 * 60 * 1000;
      const uninvoiced = isCompleted && !r.invoice_id && !r.invoice_number;
      return recent || uninvoiced;
    })
    .sort((a, b) => new Date(b.pickup_at).getTime() - new Date(a.pickup_at).getTime());
  const nameOf = (id: string | null, list: { id: string; label: string }[]) =>
    list.find((x) => x.id === id)?.label ?? "—";
  const vehicleList = vehicles.map((v) => ({ id: v.id, label: v.fleet_code }));
  const editingRide = editingId ? reservations.find((ride) => ride.id === editingId) : undefined;

  return (
    <>
      <div className="bg-dashboard-canvas px-3 pb-8 pt-5 sm:px-5">
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-4 border-b border-dashboard-line pb-4 sm:flex sm:justify-between">
        <div className="min-w-0">
          {open && <p className="mb-1 text-[10px] font-semibold text-dashboard-muted">Reservations <span className="px-1">›</span> {editingId ? "Edit reservation" : "New reservation"}</p>}
          <div className="flex min-w-0 flex-wrap items-center gap-2">
            <h1 className="truncate font-admin-display text-3xl font-bold text-dashboard-navy">
              {open ? (editingId ? `Reservation ${form.reference}` : "New reservation") : "Reservations"}
            </h1>
            {editingId && <span className="rounded border border-dashboard-blue/30 bg-dashboard-ice px-2 py-1 text-[10px] font-semibold text-dashboard-blue">Editing</span>}
          </div>
          <p className="mt-1 text-sm text-dashboard-muted">{open ? "Blackwave Booking Desk" : "View, manage and schedule all reservations"}</p>
        </div>
        <div className="flex items-center gap-2">
          {editingId && (
            <Button type="button" variant="outline" onClick={() => { setEditingId(null); setForm({ ...form, reference: "" }); }}>
              <Copy className="size-4" /> <span className="hidden sm:inline">Duplicate</span>
            </Button>
          )}
          <Button onClick={() => (open ? resetForm() : setOpen(true))} className="shrink-0 bg-dashboard-sidebar text-primary-foreground hover:bg-dashboard-blue">
            {open ? <ArrowLeft className="size-4" /> : <Plus className="size-4" />} <span className="hidden sm:inline">{open ? "Back" : "New reservation"}</span>
          </Button>
        </div>
      </header>

      <div className="mt-4">
        <ReservationRequests />
      </div>


      <div className="grid grid-cols-1 items-center gap-3 py-4 sm:flex sm:flex-wrap">
        <div className="flex min-w-0 flex-1 gap-2 overflow-x-auto pb-1">
          {["all", "assigned", ...RESERVATION_STATUSES].map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={`flex h-9 shrink-0 items-center justify-center gap-2 rounded-md border px-3 text-[10px] font-bold uppercase ${
                filter === s ? "border-dashboard-blue bg-dashboard-ice text-dashboard-blue" : "border-dashboard-line bg-card text-dashboard-muted"
              }`}
            >
              <span className={`size-2 rounded-full ${s === "completed" ? "bg-dashboard-green" : s === "cancelled" ? "bg-dashboard-red" : s === "unassigned" ? "bg-dashboard-amber" : "bg-dashboard-blue"}`} />
              {s.replace(/_/g, " ")} <span className="rounded bg-dashboard-soft px-1.5 py-0.5">{s === "all" ? reservations.length : s === "assigned" ? assignedCount : reservations.filter((ride) => ride.status === s).length}</span>
            </button>
          ))}
        </div>
        <div className="relative w-full sm:w-64"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-dashboard-muted" /><input aria-label="Search reservations" placeholder="Search reservations…" className="h-9 w-full rounded-md border border-dashboard-line bg-card pl-9 pr-3 text-xs" /></div>
        <Button variant="outline" size="sm"><Filter /> Filter</Button>
      </div>


      {open && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (
              form.pickup_at &&
              form.dropoff_at &&
              new Date(form.dropoff_at).getTime() <= new Date(form.pickup_at).getTime()
            ) {
              toast.error("Drop-off must be after the pickup date and time.");
              return;
            }
            if (editingId) update.mutate(editingId);
            else create.mutate();
          }}

          className="mb-6"
        >
          <div className="grid gap-3">
            <div className="min-w-0">
              <div className="grid gap-3 lg:grid-cols-3">
                <div className="flex min-w-0 flex-col gap-3">
                  <FormSection step="01" title="Client & passenger" grow>
                <Field label="Reference" value={form.reference} onChange={(v) => setForm({ ...form, reference: v })} placeholder="Auto" />
                <div>
                  <FieldLabel>Client account</FieldLabel>
                  <select
                    value={form.client_id}
                    onChange={(e) => {
                      const id = e.target.value;
                      const c = clients.find((x) => x.id === id);
                      setForm({
                        ...form,
                        client_id: id,
                        booked_by_name: c?.booking_contact_name || form.booked_by_name,
                        booked_by_phone: c?.booking_contact_phone || form.booked_by_phone,
                        booked_by_email: c?.booking_contact_email || form.booked_by_email,
                        billing_contact_name: c?.contact_name || form.billing_contact_name,
                        billing_contact_phone: c?.billing_contact_phone || form.billing_contact_phone,
                        billing_contact_email: c?.billing_contact_email || form.billing_contact_email,
                      });
                    }}
                    className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
                  >
                    <option value="">None (bill this ride alone)</option>
                    {clients.map((c) => (
                      <option key={c.id} value={c.id} className="bg-popover">
                        {c.account_number} · {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <FieldLabel>Price list</FieldLabel>
                  <select
                    value=""
                    onChange={(e) => {
                      const [kind, id] = e.target.value.split(":");
                      if (kind === "rate") {
                        const rate = clientRates.find((r) => r.id === id);
                        if (!rate) return;
                        setForm((f) => ({
                          ...f,
                          vehicle_class: rate.vehicle_class,
                          booking_type: rate.rate_type === "hourly" ? "hourly" : "point_to_point",
                          hourly_rate: rate.rate_type === "hourly" ? Number(rate.amount) : f.hourly_rate,
                          minimum_hours: rate.rate_type === "hourly" ? Number(rate.minimum_hours) : f.minimum_hours,
                          base_fare: rate.rate_type === "hourly" ? f.base_fare : Number(rate.amount),
                        }));
                        toast.success(`Applied "${rate.label}"`);
                        return;
                      }
                      const zone = zoneRates.find((z) => z.id === id);
                      if (!zone) return;
                      setForm((f) => ({
                        ...f,
                        vehicle_class: zone.vehicle_class,
                        booking_type: "point_to_point",
                        base_fare: Number(zone.amount),
                      }));
                      toast.success(`Applied ${zone.from_label} → ${zone.to_label}`);
                    }}
                    className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
                  >
                    <option value="">Choose a saved price…</option>
                    {accountRates.length > 0 && (
                      <optgroup label="Account rates">
                        {accountRates.map((r) => (
                          <option key={r.id} value={`rate:${r.id}`} className="bg-popover">
                            {r.label} · {r.rate_type === "hourly" ? `$${r.amount}/hr` : `$${r.amount}`} · {r.vehicle_class}
                          </option>
                        ))}
                      </optgroup>
                    )}
                    {accountZones.length > 0 && (
                      <optgroup label="Client route prices">
                        {accountZones.map((z) => (
                          <option key={z.id} value={`zone:${z.id}`} className="bg-popover">
                            {z.from_label} → {z.to_label} · ${z.amount} · {z.vehicle_class}
                          </option>
                        ))}
                      </optgroup>
                    )}
                    {globalZones.length > 0 && (
                      <optgroup label="Standard route prices">
                        {globalZones.map((z) => (
                          <option key={z.id} value={`zone:${z.id}`} className="bg-popover">
                            {z.from_label} → {z.to_label} · ${z.amount} · {z.vehicle_class}
                          </option>
                        ))}
                      </optgroup>
                    )}
                  </select>
                  {accountRates.length + accountZones.length + globalZones.length === 0 && (
                    <p className="mt-1 font-cond text-[11px] text-muted-foreground">
                      No saved prices yet — add them on the Clients page.
                    </p>
                  )}
                </div>

                <div className="font-cond text-[10px] uppercase tracking-[0.3em] text-brand">Booked by</div>
                <Field label="Booked by name" value={form.booked_by_name} onChange={(v) => setForm({ ...form, booked_by_name: v })} />
                <Field label="Booked by phone" value={form.booked_by_phone} onChange={(v) => setForm({ ...form, booked_by_phone: v })} />
                <Field label="Booked by email" type="email" value={form.booked_by_email} onChange={(v) => setForm({ ...form, booked_by_email: v })} />

                <div className="font-cond text-[10px] uppercase tracking-[0.3em] text-brand">Billing contact</div>
                <Field label="Billing contact name" value={form.billing_contact_name} onChange={(v) => setForm({ ...form, billing_contact_name: v })} />
                <Field label="Billing contact phone" value={form.billing_contact_phone} onChange={(v) => setForm({ ...form, billing_contact_phone: v })} />
                <Field label="Billing contact email" type="email" value={form.billing_contact_email} onChange={(v) => setForm({ ...form, billing_contact_email: v })} />

                <div>
                  <label className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                    Chauffeur should contact
                  </label>
                  <select
                    value={form.driver_contact_role}
                    onChange={(e) => setForm({ ...form, driver_contact_role: e.target.value })}
                    className="mt-1 w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
                  >
                    {DRIVER_CONTACT_OPTIONS.map((o) => (
                      <option key={o.value} value={o.value} className="bg-popover">
                        {o.label}
                      </option>
                    ))}
                  </select>
                  <p className="mt-1 font-cond text-[11px] text-muted-foreground">
                    This is the name and number shown on the chauffeur's trip screen.
                  </p>
                </div>



                  </FormSection>

                  <FormSection step="02" title="Passenger details" grow>
                <PassengerNameField
                  value={form.passenger_name}
                  options={passengerPool}
                  onChange={(v) => setForm({ ...form, passenger_name: v })}
                  onPick={(p) =>
                    setForm({
                      ...form,
                      passenger_name: p.full_name,
                      passenger_phone: p.phone || form.passenger_phone,
                      passenger_email: p.email || form.passenger_email,
                      client_id: form.client_id || p.client_id,
                    })
                  }
                />
                <Field label="Phone" value={form.passenger_phone} onChange={(v) => setForm({ ...form, passenger_phone: v })} />
                <Field label="Email" type="email" value={form.passenger_email} onChange={(v) => setForm({ ...form, passenger_email: v })} />
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Passengers" type="number" value={String(form.passenger_count)} onChange={(v) => setForm({ ...form, passenger_count: Number(v) })} />
                  <Field label="Luggage" type="number" value={String(form.luggage_count)} onChange={(v) => setForm({ ...form, luggage_count: Number(v) || 0 })} />
                  <Field label="Car seats" type="number" value={String(form.car_seat_count)} onChange={(v) => setForm({ ...form, car_seat_count: Number(v) || 0 })} />
                </div>
                <div>
                  <div className="mb-2 flex items-center justify-between gap-2">
                    <FieldLabel>
                      <span className="block min-w-0">Additional passengers</span>
                    </FieldLabel>
                    <button
                      type="button"
                      onClick={() =>
                        setForm({
                          ...form,
                          extra_passengers: [...form.extra_passengers, { name: "", phone: "", email: "" }],
                        })
                      }
                      className="shrink-0 whitespace-nowrap rounded-md border border-input px-3 py-1.5 font-cond text-xs text-foreground hover:bg-muted"
                    >
                      + Add passenger
                    </button>
                  </div>
                  {form.extra_passengers.length === 0 ? (
                    <p className="font-cond text-[11px] text-muted-foreground">
                      Only the main passenger so far. Add everyone else riding along.
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {form.extra_passengers.map((p, i) => (
                        <div key={i} className="space-y-2 rounded-lg border border-border/60 p-2.5">
                          <PassengerNameField
                            value={p.name}
                            options={passengerPool}
                            onChange={(v) => {
                              const next = [...form.extra_passengers];
                              next[i] = { ...p, name: v };
                              setForm({ ...form, extra_passengers: next });
                            }}
                            onPick={(sp) => {
                              const next = [...form.extra_passengers];
                              next[i] = {
                                name: sp.full_name,
                                phone: sp.phone || p.phone,
                                email: sp.email || p.email,
                              };
                              setForm({ ...form, extra_passengers: next });
                            }}
                          />
                          <Field
                            label="Phone"
                            value={p.phone}
                            onChange={(v) => {
                              const next = [...form.extra_passengers];
                              next[i] = { ...p, phone: v };
                              setForm({ ...form, extra_passengers: next });
                            }}
                          />
                          <Field
                            label="Email"
                            type="email"
                            value={p.email}
                            onChange={(v) => {
                              const next = [...form.extra_passengers];
                              next[i] = { ...p, email: v };
                              setForm({ ...form, extra_passengers: next });
                            }}
                          />
                          <div className="flex justify-end">
                            <button
                              type="button"
                              onClick={() =>
                                setForm({
                                  ...form,
                                  extra_passengers: form.extra_passengers.filter((_, j) => j !== i),
                                })
                              }
                              className="rounded-md border border-input px-3 py-1.5 font-cond text-xs text-muted-foreground hover:bg-muted"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                  </FormSection>

                  <FormSection step="07" title="Chauffeur & vehicle" last grow>
                    <div>
                      <FieldLabel>Chauffeur</FieldLabel>
                      <select
                        value={editingRide?.driver_id ?? payDriverId}
                        onChange={(e) => {
                          const id = e.target.value;
                          setPayDriverId(id);
                          if (editingId) setDriver.mutate({ id: editingId, driver_id: id || null });
                          else if (id) toast.message("The chauffeur will be assigned after the reservation is saved.");
                        }}
                        className="h-9 w-full rounded-md border border-dashboard-line bg-card px-3 text-xs text-foreground"
                      >
                        <option value="">Choose a chauffeur…</option>
                        {drivers.filter((d) => d.is_active !== false || d.id === editingRide?.driver_id).map((driver) => (
                          <option key={driver.id} value={driver.id}>{driver.full_name}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <FieldLabel>Vehicle class</FieldLabel>
                      <select value={form.vehicle_class} onChange={(e) => setForm({ ...form, vehicle_class: e.target.value })} className="h-9 w-full rounded-md border border-dashboard-line bg-card px-3 text-xs text-foreground">
                        {VEHICLE_CLASSES.map((vehicleClass) => <option key={vehicleClass} value={vehicleClass}>{vehicleClass}</option>)}
                      </select>
                    </div>
                    <div>
                      <textarea
                        value={form.notes}
                        onChange={(e) => setForm({ ...form, notes: e.target.value })}
                        rows={3}
                        placeholder="Gate code, meet-and-greet sign, car seat, luggage, VIP handling…"
                        className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground placeholder:text-muted-foreground focus:border-brand/60"
                      />
                      <p className="mt-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                        Shown only in the assigned chauffeur's app — never on invoices or to the client.
                      </p>
                    </div>
                  </FormSection>
                </div>

                <div className="flex min-w-0 flex-col gap-3">
                  <FormSection step="03" title="Trip details" grow>
                <div>
                  <FieldLabel>Trip type</FieldLabel>
                  <div className="grid grid-cols-3 overflow-hidden rounded-md border border-dashboard-line">
                    {(["point_to_point", "hourly", "as_directed"] as const).map((type) => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => {
                          if (type === "point_to_point") setForm({ ...form, booking_type: "point_to_point" });
                          else {
                            setHourlyMode(type);
                            setForm({ ...form, booking_type: "hourly" });
                          }
                        }}
                        className={`h-9 border-r border-dashboard-line px-2 text-[10px] font-semibold last:border-r-0 ${
                          (type === "point_to_point" && form.booking_type === "point_to_point") ||
                          (type !== "point_to_point" && form.booking_type === "hourly" && hourlyMode === type)
                            ? "bg-dashboard-blue text-primary-foreground"
                            : "bg-card text-dashboard-muted hover:bg-dashboard-canvas"
                        }`}
                      >
                        {type === "point_to_point" ? "Point to point / One way" : type === "hourly" ? "Hourly" : "As directed"}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <AddressField label="Pickup address" value={form.pickup_address} onChange={(v) => setForm({ ...form, pickup_address: v })} required />
                </div>
                <Field
                  label="Pickup time"
                  type="datetime-local"
                  value={form.pickup_at}
                  onChange={(v) => {
                    // Keep drop-off on/after pickup: shift its date to match when it falls earlier.
                    const next = { ...form, pickup_at: v };
                    if (v && form.dropoff_at && new Date(form.dropoff_at).getTime() < new Date(v).getTime()) {
                      next.dropoff_at = `${v.slice(0, 10)}T${form.dropoff_at.slice(11, 16)}`;
                      if (new Date(next.dropoff_at).getTime() < new Date(v).getTime()) next.dropoff_at = v;
                    }
                    setForm(next);
                  }}
                  required
                />
                <div>
                  <AddressField label="Drop-off address" value={form.dropoff_address} onChange={(v) => setForm({ ...form, dropoff_address: v })} required={form.booking_type !== "hourly"} />
                </div>
                <Field
                  label="Drop-off time (optional)"
                  type="datetime-local"
                  value={form.dropoff_at}
                  min={form.pickup_at}
                  onChange={(v) => setForm({ ...form, dropoff_at: v })}
                />

                <Field label="Distance (miles)" type="number" value={String(form.distance_miles)} onChange={(v) => setForm({ ...form, distance_miles: Number(v) })} />
                {(form.pickup_address || form.dropoff_address) && (
                  <a
                    href={`https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(form.pickup_address)}&destination=${encodeURIComponent(form.dropoff_address)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex h-9 items-center justify-center gap-2 rounded-md border border-dashboard-line bg-card px-3 text-xs font-semibold text-dashboard-blue hover:bg-dashboard-ice"
                  >
                    <ExternalLink className="size-3.5" /> Route preview
                  </a>
                )}

                <div className="rounded-lg border border-dashed border-border p-3">
                  <div className="mb-2 flex items-center justify-between gap-2">
                    <FieldLabel>
                      <span className="block min-w-0">Extra stops (optional)</span>
                    </FieldLabel>
                    <button
                      type="button"
                      onClick={() => setStopDrafts((s) => [...s, { address: "", stop_at: "", note: "" }])}
                      className="shrink-0 whitespace-nowrap rounded-md border border-border px-3 py-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground hover:text-brand"
                    >
                      Add stop
                    </button>
                  </div>
                  {stopDrafts.map((s, i) => (
                    <div key={i} className="mb-2 space-y-2 rounded-lg border border-border/60 p-2.5">
                      <AddressAutocomplete
                        value={s.address}
                        placeholder={`Stop ${i + 1} address`}
                        onChange={(v) =>
                          setStopDrafts((prev) => prev.map((x, j) => (j === i ? { ...x, address: v } : x)))
                        }
                      />
                      <input
                        type="datetime-local"
                        value={s.stop_at}
                        onChange={(e) =>
                          setStopDrafts((prev) => prev.map((x, j) => (j === i ? { ...x, stop_at: e.target.value } : x)))
                        }
                        className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
                      />
                      <input
                        value={s.note}
                        placeholder="Note (optional)"
                        onChange={(e) =>
                          setStopDrafts((prev) => prev.map((x, j) => (j === i ? { ...x, note: e.target.value } : x)))
                        }
                        className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground placeholder:text-muted-foreground focus:border-brand/60"
                      />
                      <div className="flex items-center justify-between">
                        {stopDrafts.length > 1 && (
                          <button
                            type="button"
                            onClick={() => setStopDrafts((prev) => prev.filter((_, j) => j !== i))}
                            className="rounded-md border border-border px-3 py-1.5 font-cond text-[10px] uppercase tracking-widest text-muted-foreground hover:text-destructive"
                          >
                            Remove
                          </button>
                        )}
                        <span className="ml-auto font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                          Stop {i + 1} · {money(form.stop_fee)} fee
                        </span>
                      </div>
                    </div>
                  ))}
                  {stopDrafts.length > 0 && (
                    <p className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
                      {stopDrafts.length} extra stop{stopDrafts.length > 1 ? "s" : ""} · {money(stopDrafts.length * form.stop_fee)} in stop fees
                    </p>
                  )}
                </div>
                  </FormSection>

                  <FormSection step="04" title="Airport & flight" grow>
                <Field label="Flight" value={form.flight_number} onChange={(v) => setForm({ ...form, flight_number: v })} />
                <AirlineField value={form.airline} onChange={(v) => setForm({ ...form, airline: v })} />
                <AddressField
                  label="Airport"
                  value={form.airport_name}
                  onChange={(v) => setForm({ ...form, airport_name: v })}
                  placeholder="Search airport"
                />
                <div>
                  <FieldLabel>Arrival / departure</FieldLabel>
                  <select
                    value={form.flight_direction}
                    onChange={(e) => setForm({ ...form, flight_direction: e.target.value })}
                    className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
                  >
                    <option value="none">Not a flight</option>
                    <option value="arrival">Arrival</option>
                    <option value="departure">Departure</option>
                  </select>
                </div>
                <Field label="Terminal / level" value={form.terminal_level} onChange={(v) => setForm({ ...form, terminal_level: v })} />
                <Field label="Door #" value={form.door_number} onChange={(v) => setForm({ ...form, door_number: v })} />
                  </FormSection>

                  <FormSection step="06" title="Chauffeur pay" grow>
                {form.booking_type === "hourly" ? (
                  <>
                    <Field label="Hourly pay" type="number" value={String(form.driver_hourly_pay)} onChange={(v) => setForm({ ...form, driver_hourly_pay: Number(v) })} />
                    <Field label="Minimum hours" type="number" value={String(form.driver_minimum_hours)} onChange={(v) => setForm({ ...form, driver_minimum_hours: Number(v) })} />
                    <Field label="Total hours" type="number" value={String(form.driver_total_hours)} onChange={(v) => setForm({ ...form, driver_total_hours: Number(v) })} />
                  </>
                ) : (
                  <Field label="Driver pay (ride)" type="number" value={String(form.driver_pay)} onChange={(v) => setForm({ ...form, driver_pay: Number(v) })} />
                )}
                <Field label="Driver airport fee" type="number" value={String(form.driver_airport_fee)} onChange={(v) => setForm({ ...form, driver_airport_fee: Number(v) })} />
                <Field label="Driver parking fee" type="number" value={String(form.driver_parking_fee)} onChange={(v) => setForm({ ...form, driver_parking_fee: Number(v) })} />
                <Field label="Tolls" type="number" value={String(form.driver_tolls)} onChange={(v) => setForm({ ...form, driver_tolls: Number(v) })} />
                <Field label="Total waiting hours" type="number" value={String(form.driver_waiting_hours)} onChange={(v) => setForm({ ...form, driver_waiting_hours: Number(v) })} />
                <Field label="Driver waiting rate per hour" type="number" value={String(form.driver_waiting_pay)} onChange={(v) => setForm({ ...form, driver_waiting_pay: Number(v) })} />
                <div className="border-t border-border pt-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
                      Driver total
                    </span>
                    <span className="font-cond text-sm font-semibold text-foreground">
                      {money(
                        (form.booking_type === "hourly"
                          ? Number(form.driver_hourly_pay) * Math.max(Number(form.driver_minimum_hours), Number(form.driver_total_hours))
                          : Number(form.driver_pay)) +
                          Number(form.driver_airport_fee) +
                          Number(form.driver_parking_fee) +
                          (Number(form.driver_waiting_hours) > 0
                            ? Number(form.driver_waiting_pay) * Number(form.driver_waiting_hours)
                            : Number(form.driver_waiting_pay)) +
                          Number(form.driver_tolls),
                      )}
                    </span>
                  </div>
                  <p className="mt-1 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                    {form.booking_type === "hourly"
                      ? "Hourly pay uses the greater of minimum hours or total hours."
                      : "Leave at 0 to use the chauffeur's default pay rate."}
                  </p>
                </div>
                  </FormSection>
                </div>

                <div className="flex min-w-0 flex-col gap-3">
                  <FormSection step="05" title="Pricing & summary" grow>
                <div>
                  <FieldLabel>Booking type</FieldLabel>
                  <select
                    value={form.booking_type}
                    onChange={(e) => setForm({ ...form, booking_type: e.target.value })}
                    className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
                  >
                    {BOOKING_TYPES.map((t) => (
                      <option key={t} value={t} className="bg-popover">
                        {bookingTypeLabel(t)}
                      </option>
                    ))}
                  </select>
                </div>
                <Field label="Base rate" type="number" value={String(form.base_rate)} onChange={(v) => setForm({ ...form, base_rate: Number(v) })} />
                {form.booking_type === "hourly" ? (
                  <>
                    <Field label="Hourly rate" type="number" value={String(form.hourly_rate)} onChange={(v) => setForm({ ...form, hourly_rate: Number(v) })} />
                    <Field label="Hours booked" type="number" value={String(form.hours)} onChange={(v) => setForm({ ...form, hours: Number(v) })} />
                    <Field label="Minimum hours" type="number" value={String(form.minimum_hours)} onChange={(v) => setForm({ ...form, minimum_hours: Number(v) })} />
                  </>
                ) : (
                  <Field label="Flat fare" type="number" value={String(form.base_fare)} onChange={(v) => setForm({ ...form, base_fare: Number(v) })} />
                )}
                <Field label="Airport fee" type="number" value={String(form.airport_fee)} onChange={(v) => setForm({ ...form, airport_fee: Number(v) })} />
                <Field label="Meet & greet fee" type="number" value={String(form.meet_greet_fee)} onChange={(v) => setForm({ ...form, meet_greet_fee: Number(v) })} />
                <Field label="Parking fee" type="number" value={String(form.parking_fee)} onChange={(v) => setForm({ ...form, parking_fee: Number(v) })} />
                <Field label="Car seats" type="number" value={String(form.car_seat_count)} onChange={(v) => setForm({ ...form, car_seat_count: Number(v) || 0 })} />
                <Field label="Fee per car seat" type="number" value={String(form.car_seat_fee)} onChange={(v) => setForm({ ...form, car_seat_fee: Number(v) })} />
                <Field label="Tolls" type="number" value={String(form.tolls)} onChange={(v) => setForm({ ...form, tolls: Number(v) })} />
                <Field label="Gratuity" type="number" value={String(form.gratuity)} onChange={(v) => setForm({ ...form, gratuity: Number(v) })} />
                <Field label="Fee per extra stop" type="number" value={String(form.stop_fee)} onChange={(v) => setForm({ ...form, stop_fee: Number(v) })} />
                <Field label="Waiting time (min)" type="number" value={String(form.waiting_minutes)} onChange={(v) => setForm({ ...form, waiting_minutes: Number(v) })} />
                <Field label="Waiting rate ($/hr)" type="number" value={String(form.waiting_rate)} onChange={(v) => setForm({ ...form, waiting_rate: Number(v) })} />
                  </FormSection>
                  <FormSection step="08" title="Payment" grow>
                    <div>
                      <FieldLabel>Payment method</FieldLabel>
                      <select
                        value={form.payment_method}
                        onChange={(e) => setForm({ ...form, payment_method: e.target.value })}
                        className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground"
                      >
                        <option value="">Not selected</option>
                        {PAYMENT_METHODS.map((m) => (
                          <option key={m} value={m} className="bg-popover">
                            {m}
                          </option>
                        ))}
                      </select>
                    </div>
                    {form.payment_method === "Credit card" && (
                      <div className="border-t border-border pt-3">
                        {!form.client_id && (
                          <div className="mb-3 rounded-md border border-brand/30 bg-brand/5 px-3 py-2 font-cond text-xs text-muted-foreground">
                            Choose a client account above before saving the card to that account.
                          </div>
                        )}
                        <CardsOnFile clientId={form.client_id} staff embedded defaultOpen />
                      </div>
                    )}
                    <div className="border-t border-dashboard-line pt-3">
                      <FieldLabel>Ride status</FieldLabel>
                      <select
                        value={editingRide?.status ?? "unassigned"}
                        disabled={!editingId}
                        onChange={(e) => editingId && setStatus.mutate({ id: editingId, status: e.target.value })}
                        className="h-9 w-full rounded-md border border-dashboard-line bg-card px-3 text-xs text-foreground disabled:bg-dashboard-canvas disabled:text-dashboard-muted"
                      >
                        {RESERVATION_STATUSES.map((status) => <option key={status} value={status}>{status.replace(/_/g, " ")}</option>)}
                      </select>
                      {!editingId && <p className="mt-1 text-[10px] text-dashboard-muted">New reservations begin as unassigned.</p>}
                    </div>
                  </FormSection>
          <aside className="flex grow flex-col gap-3 rounded-md border border-dashboard-line bg-card p-4 shadow-sm">
            <div className="text-[10px] font-bold uppercase text-dashboard-muted">
              Ride summary
            </div>
            <SummaryRow label="Passenger" value={form.passenger_name || "—"} />
            <SummaryRow label="Pickup" value={form.pickup_address || "—"} />
            {stopDrafts
              .map((s, i) => ({ ...s, num: i + 1 }))
              .filter((s) => s.address.trim())
              .map((s) => (
                <SummaryRow key={s.num} label={`Stop ${s.num}`} value={s.address.trim()} />
              ))}
            <SummaryRow label="Drop-off" value={form.dropoff_address || "—"} />
            <SummaryRow label="Vehicle" value={form.vehicle_class} />
            <div className="mt-2 rounded-md border border-dashboard-line bg-dashboard-ice px-4 py-3">
              <div className="text-[10px] font-bold uppercase text-dashboard-muted">
                Estimated total
              </div>
              <div className="font-admin-display text-3xl font-bold text-dashboard-blue">
                {money(fareTotal(form, stopDrafts.filter((s) => s.address.trim()).length))}
              </div>
            </div>

            <div className="mt-2 rounded-md border border-dashboard-line bg-dashboard-canvas px-4 py-3">
              <button
                type="button"
                onClick={() => setShowPay((v) => !v)}
                className="w-full text-left text-[10px] font-bold uppercase text-dashboard-muted hover:text-dashboard-blue"
              >
                {showPay ? "Hide chauffeur pay" : "Show chauffeur pay"}
              </button>
              {showPay && (
                <div className="mt-3 space-y-2">
                  <select
                    value={payDriverId}
                    onChange={(e) => {
                      const id = e.target.value;
                      setPayDriverId(id);
                      if (editingId) setDriver.mutate({ id: editingId, driver_id: id || null });
                      else if (id) toast.message("Book the ride first — the chauffeur will be asked to confirm once it is saved.");
                    }}
                    className="w-full rounded-md border border-dashboard-line bg-card px-3 py-2 text-sm text-foreground"
                  >
                    <option value="">Choose a chauffeur…</option>
                    {drivers.filter((d) => d.is_active !== false).map((d) => (
                      <option key={d.id} value={d.id} className="bg-popover">
                        {d.full_name}
                      </option>
                    ))}
                  </select>
                  {(() => {
                    const driver = drivers.find((d) => d.id === payDriverId);
                    const stopCount = stopDrafts.filter((s) => s.address.trim()).length;
                    const fare = fareTotal(form, stopCount);
                    const hourly = form.booking_type === "hourly";
                    const payHours = Math.max(Number(form.driver_minimum_hours) || 0, Number(form.driver_total_hours) || 0);
                    const base = hourly
                      ? (Number(form.driver_hourly_pay) || 0) * payHours ||
                        Number(form.driver_pay) ||
                        driverPayEstimate(fare, driver)
                      : Number(form.driver_pay) || driverPayEstimate(fare, driver);
                    const wait = Number(form.driver_waiting_hours) > 0
                      ? Number(form.driver_waiting_pay) * Number(form.driver_waiting_hours)
                      : Number(form.driver_waiting_pay) || waitingCharge(form);
                    const airport = Number(form.driver_airport_fee) || Number(form.airport_fee ?? 0);
                    const parking = Number(form.driver_parking_fee) || Number(form.parking_fee ?? 0);
                    const tollsD = Number(form.driver_tolls) || Number(form.tolls ?? 0);
                    return (
                      <>
                        {hourly ? (
                          <>
                            <SummaryRow label="Hourly rate" value={`${money(Number(form.driver_hourly_pay) || 0)} / hr`} />
                            <SummaryRow label="Minimum hours" value={String(Number(form.driver_minimum_hours) || 0)} />
                            <SummaryRow label="Total hours" value={String(Number(form.driver_total_hours) || 0)} />
                            <SummaryRow label={`Hourly pay (${payHours} hr)`} value={money(base)} />
                          </>
                        ) : (
                          <SummaryRow
                            label={
                              driver
                                ? driver.pay_type === "percentage"
                                  ? `Flat rate (${driver.pay_rate ?? 0}%)`
                                  : "Flat rate"
                                : "Flat rate"
                            }
                            value={money(base)}
                          />
                        )}
                        <SummaryRow label="Airport fee" value={money(airport)} />
                        <SummaryRow label="Parking fee" value={money(parking)} />
                        <SummaryRow label="Tolls" value={money(tollsD)} />
                        <SummaryRow
                          label={`Wait time (${form.waiting_minutes || 0} min)`}
                          value={money(wait)}
                        />
                        <div className="mt-2 flex items-baseline justify-between border-t border-dashboard-line pt-2">
                          <span className="text-[10px] font-bold uppercase text-dashboard-muted">
                            Driver total
                          </span>
                          <span className="font-admin-display text-xl font-bold text-dashboard-blue">
                            {money(base + airport + parking + wait + tollsD)}
                          </span>
                        </div>
                        <p className="text-[10px] uppercase text-dashboard-muted">
                          Estimate only — not saved with the ride.
                        </p>
                      </>
                    );
                  })()}
                </div>
              )}
            </div>

            <Button
              type="submit"
              disabled={create.isPending || update.isPending}
              className="mt-auto w-full bg-dashboard-blue text-primary-foreground hover:bg-dashboard-sidebar"
            >
              <Save className="size-4" />
              {editingId ? "Save Changes" : "Book Ride"}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={resetForm}
              className="w-full"
            >
              Cancel
            </Button>
          </aside>
                </div>
              </div>
            </div>
          </div>
        </form>
      )}


      {isStaff && <div className="mb-3 overflow-x-auto"><ReservationCalendar reservations={rows} /></div>}
      {isStaff && <div className="[&>section]:mx-0 [&>section]:mb-3"><ActiveRides reservations={reservations} drivers={drivers} /></div>}

      <div className="mb-3 overflow-x-auto rounded-md border border-dashboard-line bg-card shadow-sm">
        <div className="flex items-center gap-2 border-b border-dashboard-line px-4 py-3">
          <CalendarDays className="size-4 text-dashboard-blue" /><span className="font-admin-display text-base font-bold text-dashboard-navy">Upcoming reservations</span>
        </div>
        <table className="w-full min-w-[900px]">
          <thead>
            <tr className="border-b border-border font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
              <th className="px-4 py-3 text-left">When</th>
              <th className="px-4 py-3 text-left">Ref</th>
              <th className="px-4 py-3 text-left">Passenger</th>
              <th className="px-4 py-3 text-left">Route</th>
              <th className="px-4 py-3 text-left">Driver</th>
              <th className="px-4 py-3 text-left">Vehicle</th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-right">Fare</th>
              <th className="px-4 py-3 text-right">Statement</th>
              <th className="px-4 py-3 text-right">Manage</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border font-cond text-sm">
            {tableRows.map((r) => (
              <Fragment key={r.id}>
              <tr className="transition-colors hover:bg-surface-2/40">
                <td className="whitespace-nowrap px-4 py-3 text-muted-foreground">
                  {dayLabel(r.pickup_at)} · {clockTime(r.pickup_at)}
                </td>
                <td className="px-4 py-3">
                  <Link
                    to="/rides/$id"
                    params={{ id: r.id }}
                    className="text-brand hover:underline"
                  >
                    {r.reference}
                  </Link>
                </td>
                <td className="px-4 py-3">{r.passenger_name}</td>
                <td className="px-4 py-3 text-muted-foreground">
                  {[r.pickup_address, ...(stopsByRide.get(r.id) ?? []).map((s) => s.address), r.dropoff_address].join(" → ")}
                  {r.booking_type === "hourly" && (
                    <span className="ml-2 text-brand">· hourly</span>
                  )}
                </td>
                <td className="px-4 py-3 text-muted-foreground">
                  <select
                    value={r.driver_id ?? ""}
                    onChange={(e) => setDriver.mutate({ id: r.id, driver_id: e.target.value || null })}
                    className={`rounded-md border border-border bg-transparent px-2 py-1 font-cond text-[11px] ${
                      r.driver_id ? "" : "text-brand"
                    }`}
                  >
                    <option value="" className="bg-popover">
                      {r.driver_id ? "Remove driver" : "Assign driver"}
                    </option>
                    {drivers.filter((d) => d.is_active !== false || d.id === r?.driver_id).map((d) => (
                      <option key={d.id} value={d.id} className="bg-popover">
                        {d.full_name}
                      </option>
                    ))}
                  </select>
                  {r.driver_id && (
                    <button
                      type="button"
                      onClick={() => resendDriverEmail.mutate(r.id)}
                      disabled={resendDriverEmail.isPending}
                      className="mt-1 block font-cond text-[10px] uppercase tracking-widest text-brand hover:underline disabled:opacity-50"
                    >
                      Resend driver email
                    </button>
                  )}

                  <GuestLinkShare
                    reservationId={r.id}
                    token={(r as Reservation & { guest_link_token?: string | null }).guest_link_token}
                    passenger={r.passenger_name}
                    pickup={r.pickup_address}
                    pickupAt={r.pickup_at}
                    onCreated={() => qc.invalidateQueries({ queryKey: ["reservations"] })}
                  />
                  <DriverInfoShare
                    driverId={r.driver_id}
                    vehicleId={r.vehicle_id}
                    passenger={r.passenger_name}
                    pickupAt={r.pickup_at}
                    reference={r.reference}
                  />
                  <RideEmailShare reservationId={r.id} />

                </td>
                <td className="px-4 py-3 text-muted-foreground">{nameOf(r.vehicle_id, vehicleList)}</td>
                <td className="px-4 py-3">
                  <select
                    value={r.status}
                    onChange={(e) => setStatus.mutate({ id: r.id, status: e.target.value })}
                    className="rounded-md border border-border bg-transparent px-2 py-1 font-cond text-[11px] uppercase tracking-widest"
                  >
                    {RESERVATION_STATUSES.map((s) => (
                      <option key={s} value={s} className="bg-popover">
                        {s.replace(/_/g, " ")}
                      </option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-3 text-right tabular-nums text-brand">
                  {money(fareTotal(r, (stopsByRide.get(r.id) ?? []).length))}
                  {r.driver_id && (
                    <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                      Driver est.{" "}
                      {money(
                        driverPayout(
                          r,
                          drivers.find((d) => d.id === r.driver_id),
                          (stopsByRide.get(r.id) ?? []).length,
                        ),
                      )}
                    </div>
                  )}
                </td>
                <td className="px-4 py-3 text-right">
                  {r.invoice_id ? (
                    <Link
                      to="/invoices/$id"
                      params={{ id: r.invoice_id }}
                      className="font-cond text-[11px] uppercase tracking-widest text-brand"
                    >
                      On invoice
                    </Link>
                  ) : (
                    <Link
                      to="/invoice/$id"
                      params={{ id: r.id }}
                      className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground transition-colors hover:text-brand"
                    >
                      {r.invoice_paid_at ? "Paid" : r.invoice_issued_at ? "View" : "Bill"}
                    </Link>
                  )}
                </td>
                <td className="whitespace-nowrap px-4 py-3 text-right">
                  <button
                    onClick={() => startEdit(r.id)}
                    className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground transition-colors hover:text-brand"
                  >
                    Edit
                  </button>
                  {(r.status !== "completed" || isAdmin) && (
                    <button
                      disabled={remove.isPending}
                      onClick={() => {
                        if (r.invoice_id) {
                          toast.error("Remove this ride from its invoice before deleting it");
                          return;
                        }
                        if (window.confirm(`Delete reservation ${r.reference}? This cannot be undone.`)) {
                          remove.mutate(r.id);
                        }
                      }}
                      className="ml-3 font-cond text-[11px] uppercase tracking-widest text-muted-foreground transition-colors hover:text-destructive disabled:opacity-50"
                    >
                      Delete
                    </button>
                  )}
                </td>
              </tr>
              </Fragment>
            ))}
            {tableRows.length === 0 && (
              <tr>
                <td colSpan={10} className="px-4 py-6 text-center text-muted-foreground">
                  No upcoming reservations.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {isStaff && (
        <div className="mb-3 overflow-x-auto rounded-md border border-dashboard-line bg-card shadow-sm">
          <div className="flex items-center gap-2 border-b border-dashboard-line px-4 py-3">
            <CalendarDays className="size-4 text-dashboard-green" /><span className="font-admin-display text-base font-bold text-dashboard-navy">Completed reservations</span>
          </div>
          <table className="w-full min-w-[760px]">
            <thead>
              <tr className="border-b border-border font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                <th className="px-4 py-3 text-left">When</th>
                <th className="px-4 py-3 text-left">Ref</th>
                <th className="px-4 py-3 text-left">Passenger</th>
                <th className="px-4 py-3 text-left">Route</th>
                <th className="px-4 py-3 text-left">Driver</th>
                <th className="px-4 py-3 text-right">Fare</th>
                <th className="px-4 py-3 text-right">Statement</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border font-cond text-sm">
              {completedRows.map((r) => (
                <tr key={r.id} className="transition-colors hover:bg-surface-2/40">
                  <td className="whitespace-nowrap px-4 py-3 text-muted-foreground">
                    {dayLabel(r.pickup_at)} · {clockTime(r.pickup_at)}
                  </td>
                  <td className="px-4 py-3">
                    <Link to="/rides/$id" params={{ id: r.id }} className="text-brand hover:underline">
                      {r.reference}
                    </Link>
                  </td>
                  <td className="px-4 py-3">{r.passenger_name}</td>
                  <td className="px-4 py-3 text-muted-foreground">
                    {[r.pickup_address, ...(stopsByRide.get(r.id) ?? []).map((s) => s.address), r.dropoff_address].join(
                      " → ",
                    )}
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">
                    <select
                      value={r.driver_id ?? ""}
                      onChange={(e) => setDriver.mutate({ id: r.id, driver_id: e.target.value || null })}
                      className={`rounded-md border border-border bg-transparent px-2 py-1 font-cond text-[11px] ${
                        r.driver_id ? "" : "text-brand"
                      }`}
                    >
                      <option value="" className="bg-popover">
                        {r.driver_id ? "Remove driver" : "Assign driver"}
                      </option>
                      {drivers.filter((d) => d.is_active !== false || d.id === r?.driver_id).map((d) => (
                        <option key={d.id} value={d.id} className="bg-popover">
                          {d.full_name}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-3 text-right tabular-nums text-brand">
                    {money(fareTotal(r, (stopsByRide.get(r.id) ?? []).length))}
                  </td>
                  <td className="px-4 py-3 text-right">
                    {r.invoice_id ? (
                      <Link
                        to="/invoices/$id"
                        params={{ id: r.invoice_id }}
                        className="font-cond text-[11px] uppercase tracking-widest text-brand"
                      >
                        On invoice
                      </Link>
                    ) : (
                      <Link
                        to="/invoice/$id"
                        params={{ id: r.id }}
                        className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground transition-colors hover:text-brand"
                      >
                        {r.invoice_paid_at ? "Paid" : r.invoice_issued_at ? "View" : "Bill"}
                      </Link>
                    )}
                  </td>
                  <td className="whitespace-nowrap px-4 py-3 text-right">
                    {(r.status !== "completed" || isAdmin) && (
                      <button
                        type="button"
                        disabled={remove.isPending}
                        onClick={() => {
                          if (r.invoice_id) {
                            toast.error("Remove this ride from its invoice before deleting it");
                            return;
                          }
                          if (window.confirm(`Delete reservation ${r.reference}? This cannot be undone.`)) {
                            remove.mutate(r.id);
                          }
                        }}
                        className="font-cond text-[11px] uppercase tracking-widest text-destructive transition-colors hover:underline disabled:opacity-50"
                      >
                        Delete
                      </button>
                    )}
                  </td>
                </tr>
              ))}
              {completedRows.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-6 text-center text-muted-foreground">
                    No completed reservations yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
      </div>
    </>
  );
}

function PassengerNameField({
  value,
  options,
  onChange,
  onPick,
}: {
  value: string;
  options: ClientPassenger[];
  onChange: (v: string) => void;
  onPick: (p: ClientPassenger) => void;
}) {
  const [focused, setFocused] = useState(false);
  const term = value.trim().toLowerCase();
  const matches = term
    ? options.filter((p) => p.full_name.toLowerCase().includes(term)).slice(0, 8)
    : options.slice(0, 8);
  const showList = focused && matches.length > 0 && !(matches.length === 1 && matches[0]!.full_name.toLowerCase() === term);

  return (
    <div className="relative z-30">
      <FieldLabel>Passenger</FieldLabel>
      <input
        value={value}
        required
        autoComplete="off"
        placeholder="Start typing a name"
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => window.setTimeout(() => setFocused(false), 150)}
        className="w-full rounded-md border border-input bg-surface px-3 py-2 font-cond text-sm text-foreground outline-none placeholder:text-muted-foreground focus:border-brand/60"
      />
      {showList && (
        <ul className="absolute left-0 right-0 top-full z-[70] mt-1 max-h-60 overflow-auto rounded-md border border-border bg-popover shadow-lg">
          {matches.map((p) => (
            <li key={p.id}>
              <button
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => onPick(p)}
                className="block w-full px-3 py-2 text-left font-cond text-sm text-foreground hover:bg-surface-2/60"
              >
                {p.full_name}
                {p.phone || p.email ? (
                  <span className="block text-[11px] text-muted-foreground">
                    {[p.phone, p.email].filter(Boolean).join(" · ")}
                  </span>
                ) : null}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="mb-1 text-[10px] font-semibold text-dashboard-muted">
      {children}
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required,
  placeholder,
  min,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
  placeholder?: string;
  min?: string | undefined;
}) {
  return (
    <div>
      <FieldLabel>{label}</FieldLabel>
      <input
        type={type}
        value={value}
        required={required}
        placeholder={placeholder}
        min={min}
        onChange={(e) => onChange(e.target.value)}
        className="h-9 w-full rounded-md border border-dashboard-line bg-card px-3 text-xs text-foreground outline-none placeholder:text-muted-foreground focus:border-dashboard-blue"
      />
    </div>
  );
}


function FormSection({
  step,
  title,
  last,
  grow,
  children,
}: {
  step: string;
  title: string;
  last?: boolean;
  grow?: boolean;
  children: React.ReactNode;
}) {
  return (
    <section
      className={`flex w-full flex-col rounded-md border border-dashboard-line bg-card p-4 shadow-sm${
        grow ? " grow" : ""
      }`}
    >
      <div className="mb-3 flex items-center gap-2 border-b border-dashboard-line pb-3">
        <span className="flex h-7 w-7 items-center justify-center rounded bg-dashboard-blue text-[10px] font-bold text-primary-foreground">
          {step}
        </span>
        <h3 className="font-admin-display text-sm font-bold text-dashboard-navy">{title}</h3>
      </div>
      <div className="grid gap-2.5">{children}</div>
    </section>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-dashboard-line pb-2">
      <span className="text-[10px] font-semibold text-dashboard-muted">{label}</span>
      <span className="max-w-[60%] text-right text-xs font-medium text-dashboard-navy">{value}</span>
    </div>
  );
}
