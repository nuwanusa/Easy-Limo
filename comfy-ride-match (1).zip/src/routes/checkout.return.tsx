import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { getCheckoutResult } from "@/lib/payments.functions";
import { finishClientCardSetup } from "@/lib/client-cards.functions";
import { getStripeEnvironment } from "@/lib/stripe";

export const Route = createFileRoute("/checkout/return")({
  head: () => ({
    meta: [
      { title: "Payment result — Blackwave Transportation LLC" },
      { name: "description", content: "Confirmation page for a card payment made to Blackwave Transportation." },
      { property: "og:title", content: "Payment result — Blackwave Transportation LLC" },
      { property: "og:description", content: "See whether a card payment for a ride or account invoice went through." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  validateSearch: (search: Record<string, unknown>): { session_id?: string | undefined; card?: string | undefined } => ({
    session_id: typeof search["session_id"] === "string" ? search["session_id"] : undefined,
    card: typeof search["card"] === "string" ? search["card"] : undefined,
  }),
  component: () => (
    <AppShell>
      <CheckoutReturn />
    </AppShell>
  ),
});

const money = (v: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(v);

function CheckoutReturn() {
  const { session_id: sessionId, card } = Route.useSearch();
  const savingCard = card === "1";

  const cardResult = useQuery({
    queryKey: ["card-setup-result", sessionId],
    enabled: Boolean(sessionId) && savingCard,
    queryFn: async () =>
      finishClientCardSetup({ data: { sessionId: sessionId as string, environment: getStripeEnvironment() } }),
  });

  const { data, isLoading } = useQuery({
    queryKey: ["checkout-result", sessionId],
    enabled: Boolean(sessionId) && !savingCard,
    queryFn: async () =>
      getCheckoutResult({ data: { sessionId: sessionId as string, environment: getStripeEnvironment() } }),
  });

  const paid = data && !("error" in data) && data.paymentStatus === "paid";

  return (
    <section className="mx-auto my-16 w-full max-w-xl rounded-lg border border-border bg-card p-8 text-center">
      {savingCard ? (
        cardResult.isLoading ? (
          <p className="text-sm text-muted-foreground">Saving your card…</p>
        ) : cardResult.data && "error" in cardResult.data ? (
          <p className="text-sm text-destructive">{cardResult.data.error as string}</p>
        ) : (
          <>
            <h1 className="font-cond text-2xl uppercase tracking-widest text-brand">Card saved</h1>
            <p className="mt-3 text-sm text-muted-foreground">
              The card is now on file for this account. Only the brand, last four digits and expiry are kept here.
            </p>
          </>
        )
      ) : !sessionId ? (
        <p className="text-sm text-muted-foreground">No payment information found.</p>
      ) : isLoading ? (
        <p className="text-sm text-muted-foreground">Checking your payment…</p>
      ) : data && "error" in data ? (
        <p className="text-sm text-destructive">{data.error}</p>
      ) : paid ? (
        <>
          <h1 className="font-cond text-2xl uppercase tracking-widest text-brand">Payment received</h1>
          <p className="mt-3 text-lg">{money(data?.amountTotal ?? 0)}</p>
          <p className="mt-2 text-sm text-muted-foreground">
            A receipt has been emailed and the account has been marked paid.
          </p>
        </>
      ) : (
        <>
          <h1 className="font-cond text-2xl uppercase tracking-widest">Payment pending</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            We have not received confirmation yet. If your bank completes it later, the invoice updates automatically.
          </p>
        </>
      )}
      <div className="mt-6 flex justify-center gap-4">
        <Link to="/invoices" className="font-cond text-xs uppercase tracking-widest text-brand">
          Back to invoices
        </Link>
        <Link to="/reservations" className="font-cond text-xs uppercase tracking-widest text-muted-foreground">
          Reservations
        </Link>
      </div>
    </section>
  );
}
