import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { AppShell, PageHeading } from "@/components/AppShell";
import { CompanyPlanControl } from "@/components/CompanyPlanControl";
import { useIsPlatformOwner } from "@/lib/company";
import {
  createCompany,
  listCompanies,
  resetCompanyAdminPassword,
  setCompanyStatus,
} from "@/lib/platform.functions";

export const Route = createFileRoute("/platform")({
  head: () => ({
    meta: [
      { title: "Platform — Company Accounts" },
      {
        name: "description",
        content: "Platform owner console: create transportation company accounts with an admin login and temporary password.",
      },
      { property: "og:title", content: "Platform — Company Accounts" },
      {
        property: "og:description",
        content: "Create and manage transportation company accounts on the platform.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <AppShell>
      <PlatformPage />
    </AppShell>
  ),
});

function PlatformPage() {
  const { isPlatformOwner, loading } = useIsPlatformOwner();
  const qc = useQueryClient();
  const list = useServerFn(listCompanies);
  const create = useServerFn(createCompany);
  const status = useServerFn(setCompanyStatus);
  const reset = useServerFn(resetCompanyAdminPassword);

  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [adminEmail, setAdminEmail] = useState("");
  const [issued, setIssued] = useState<{ email: string; code: string; password: string } | null>(
    null,
  );

  const companies = useQuery({
    queryKey: ["companies"],
    queryFn: () => list(),
    enabled: isPlatformOwner,
  });

  const createMutation = useMutation({
    mutationFn: () => create({ data: { name, code, adminEmail } }),
    onSuccess: (res) => {
      setIssued({ email: res.adminEmail, code: res.code, password: res.temporaryPassword });
      setName("");
      setCode("");
      setAdminEmail("");
      toast.success("Company created");
      qc.invalidateQueries({ queryKey: ["companies"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const statusMutation = useMutation({
    mutationFn: (input: { companyId: string; status: "active" | "suspended" }) =>
      status({ data: input }),
    onSuccess: () => {
      toast.success("Company updated");
      qc.invalidateQueries({ queryKey: ["companies"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const resetMutation = useMutation({
    mutationFn: (input: { userId: string; email: string; code: string }) =>
      reset({ data: { userId: input.userId } }).then((res) => ({ ...res, ...input })),
    onSuccess: (res) => {
      setIssued({ email: res.email, code: res.code, password: res.temporaryPassword });
      toast.success("Temporary password issued");
      qc.invalidateQueries({ queryKey: ["companies"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (loading) return <p className="p-6 text-sm text-muted-foreground">Loading…</p>;
  if (!isPlatformOwner)
    return (
      <p className="p-6 text-sm text-muted-foreground">
        This area is only available to the platform owner.
      </p>
    );

  return (
    <div className="space-y-6 p-4 md:p-6">
      <PageHeading eyebrow="Company accounts" title="Platform" />

      <section className="rounded-xl border border-border bg-card p-5 shadow-sm">
        <h2 className="font-cond text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
          Add a company
        </h2>
        <form
          className="mt-4 grid gap-3 md:grid-cols-4"
          onSubmit={(e) => {
            e.preventDefault();
            createMutation.mutate();
          }}
        >
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Company name"
            required
            className="rounded-lg border border-input bg-surface-2 px-3 py-2.5 text-sm text-foreground outline-none focus:border-brand"
          />
          <input
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="Company ID (e.g. LUXERIDE)"
            required
            className="rounded-lg border border-input bg-surface-2 px-3 py-2.5 text-sm uppercase tracking-widest text-foreground outline-none focus:border-brand"
          />
          <input
            value={adminEmail}
            onChange={(e) => setAdminEmail(e.target.value)}
            type="email"
            placeholder="Admin email"
            required
            className="rounded-lg border border-input bg-surface-2 px-3 py-2.5 text-sm text-foreground outline-none focus:border-brand"
          />
          <button
            type="submit"
            disabled={createMutation.isPending}
            className="rounded-lg bg-brand px-4 py-2.5 font-cond text-[11px] uppercase tracking-[0.2em] text-brand-foreground disabled:opacity-60"
          >
            {createMutation.isPending ? "Creating…" : "Create company"}
          </button>
        </form>

        {issued ? (
          <div className="mt-4 rounded-lg border border-brand/40 bg-brand/5 p-4">
            <p className="font-cond text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
              Send these details once — the password is shown only now
            </p>
            <dl className="mt-2 grid gap-1 text-sm text-foreground">
              <div className="flex gap-2">
                <dt className="w-40 text-muted-foreground">Company ID</dt>
                <dd className="font-mono">{issued.code}</dd>
              </div>
              <div className="flex gap-2">
                <dt className="w-40 text-muted-foreground">Admin email</dt>
                <dd className="font-mono">{issued.email}</dd>
              </div>
              <div className="flex gap-2">
                <dt className="w-40 text-muted-foreground">Temporary password</dt>
                <dd className="font-mono">{issued.password}</dd>
              </div>
            </dl>
            <button
              type="button"
              onClick={() => {
                void navigator.clipboard.writeText(
                  `Company ID: ${issued.code}\nEmail: ${issued.email}\nTemporary password: ${issued.password}`,
                );
                toast.success("Copied");
              }}
              className="mt-3 rounded-lg border border-border px-3 py-2 font-cond text-[11px] uppercase tracking-[0.2em] text-foreground hover:border-brand hover:text-brand"
            >
              Copy details
            </button>
          </div>
        ) : null}
      </section>

      <section className="space-y-3">
        {(companies.data ?? []).map((c) => (
          <article key={c.id} className="rounded-xl border border-border bg-card p-5 shadow-sm">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h3 className="font-cond text-base text-foreground">{c.name}</h3>
                <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
                  {c.code} · {c.status} · {c.members} user{c.members === 1 ? "" : "s"}
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  statusMutation.mutate({
                    companyId: c.id,
                    status: c.status === "active" ? "suspended" : "active",
                  })
                }
                className="rounded-lg border border-border px-3 py-2 font-cond text-[11px] uppercase tracking-[0.2em] text-foreground hover:border-brand hover:text-brand"
              >
                {c.status === "active" ? "Suspend" : "Reactivate"}
              </button>
            </div>
            <CompanyPlanControl companyId={c.id} />
            <ul className="mt-3 space-y-2">
              {c.admins.map((a) => (
                <li
                  key={a.userId}
                  className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border/70 px-3 py-2 text-sm"
                >
                  <span className="text-foreground">
                    {a.email}
                    {a.mustChangePassword ? (
                      <span className="ml-2 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                        temporary password
                      </span>
                    ) : null}
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      resetMutation.mutate({ userId: a.userId, email: a.email, code: c.code })
                    }
                    className="font-cond text-[11px] uppercase tracking-[0.2em] text-muted-foreground hover:text-brand"
                  >
                    Reset password
                  </button>
                </li>
              ))}
            </ul>
          </article>
        ))}
      </section>
    </div>
  );
}
