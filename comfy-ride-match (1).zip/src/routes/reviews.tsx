import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell, PageHeading } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reviews")({
  head: () => ({
    meta: [
      { title: "Ride Reviews — Blackwave Dispatch" },
      { name: "description", content: "Client ratings and comments for completed rides." },
      { property: "og:title", content: "Ride Reviews — Blackwave Dispatch" },
      { property: "og:description", content: "Client ratings and comments for completed rides." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => (
    <AppShell>
      <ReviewsPage />
    </AppShell>
  ),
});

const usdDate = (s: string) =>
  new Date(s).toLocaleString("en-US", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" });

function Stars({ rating }: { rating: number }) {
  return (
    <span className="text-amber-400" aria-label={`${rating} out of 5 stars`}>
      {"★".repeat(rating)}
      <span className="text-muted-foreground/40">{"★".repeat(5 - rating)}</span>
    </span>
  );
}

function ReviewsPage() {
  const reviews = useQuery({
    queryKey: ["ride_reviews", "staff"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ride_reviews")
        .select(
          `id, rating, tags, comment, created_at,
           reservation:reservations(id, reference, passenger_name, status),
           client:clients(name)`
        )
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as Array<{
        id: string;
        rating: number;
        tags: string[];
        comment: string | null;
        created_at: string;
        reservation: { id: string; reference: string; passenger_name: string; status: string } | null;
        client: { name: string } | null;
      }>;
    },
  });

  const rows = reviews.data ?? [];
  const avg = rows.length ? rows.reduce((s, r) => s + (r.rating || 0), 0) / rows.length : 0;

  return (
    <div className="pb-10">
      <PageHeading eyebrow="Feedback" title="Ride Reviews" />

      <div className="px-6">
        {reviews.isLoading ? (
          <div className="py-10 text-sm text-muted-foreground">Loading reviews…</div>
        ) : reviews.error ? (
          <div className="py-10 text-sm text-destructive">Could not load reviews. Try refreshing.</div>
        ) : rows.length === 0 ? (
          <div className="plate rounded-lg border border-border p-6 text-sm text-muted-foreground">
            No client reviews yet. Clients can rate a ride from their invoice portal after a trip.
          </div>
        ) : (
          <>
            <div className="mb-4 flex items-baseline gap-3">
              <span className="font-display text-4xl">{avg.toFixed(1)}</span>
              <span className="text-amber-400 text-lg">{"★".repeat(Math.round(avg))}</span>
              <span className="text-sm text-muted-foreground">
                average from {rows.length} review{rows.length === 1 ? "" : "s"}
              </span>
            </div>
            <div className="grid gap-3">
              {rows.map((r) => (
                <div key={r.id} className="plate rounded-lg border border-border p-4">
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                    <Stars rating={r.rating} />
                    <Link
                      to="/rides/$id"
                      params={{ id: r.reservation?.id ?? "" }}
                      className="font-cond text-xs uppercase tracking-widest text-brand hover:underline"
                    >
                      {r.reservation?.reference ?? "Ride"}
                    </Link>
                    {r.reservation?.passenger_name && (
                      <span className="text-sm text-muted-foreground">{r.reservation.passenger_name}</span>
                    )}
                    {r.client?.name && (
                      <span className="text-sm text-muted-foreground">· {r.client.name}</span>
                    )}
                    <span className="ml-auto text-xs text-muted-foreground">{usdDate(r.created_at)}</span>
                  </div>
                  {r.tags?.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {r.tags.map((t) => (
                        <span
                          key={t}
                          className="rounded-full border border-border bg-surface-2 px-2.5 py-0.5 text-xs text-foreground/80"
                        >
                          {t}
                        </span>
                      ))}
                    </div>
                  )}
                  {r.comment && <p className="mt-2 text-sm leading-relaxed">{r.comment}</p>}
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
