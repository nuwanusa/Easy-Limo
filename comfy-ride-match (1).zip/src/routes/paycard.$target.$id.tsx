import { useCallback, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { EmbeddedCheckoutProvider, EmbeddedCheckout } from "@stripe/react-stripe-js";
import { BrandLogo } from "@/components/BrandLogo";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";
import { getStripe, getStripeEnvironment, paymentsConfigured } from "@/lib/stripe";
import { cardFee, createPaymentCheckout, getPaySummary, type PaymentTarget } from "@/lib/payments.functions";
import { PaymentShare } from "@/components/PaymentShare";

export const Route = createFileRoute("/paycard/$target/$id")({
  head: () => ({
    meta: [
      { title: "Pay by Credit Card — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Secure card payment page for Blackwave Transportation invoices and rides. Pay the full balance or part of it by credit or debit card.",
      },
      { property: "og:title", content: "Pay by Credit Card — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Settle your Blackwave Transportation invoice securely by credit or debit card.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: PayCardPage,
});

const percent = (part: number, whole: number) =>
  whole > 0 ? Math.round((part / whole) * 1000) / 10 : 0;

function PayCardPage() {

  const { target, id } = Route.useParams();
  const kind: PaymentTarget = target === "reservation" ? "reservation" : "invoice";
  const loadSummary = useServerFn(getPaySummary);

  const [partial, setPartial] = useState(false);
  const [entered, setEntered] = useState("");
  const [charge, setCharge] = useState<number | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [tipPct, setTipPct] = useState<number | null>(null);
  const [tipTyped, setTipTyped] = useState("");
  const [tipCustom, setTipCustom] = useState(false);
  const [tipLocked, setTipLocked] = useState(0);

  const summary = useQuery({
    queryKey: ["pay-summary", kind, id],
    queryFn: () => loadSummary({ data: { target: kind, id } }),
  });

  const data = summary.data && !("error" in summary.data) ? summary.data : null;
  const amount = data?.amount ?? 0;

  // What the payer has chosen so far: a confirmed charge, a typed partial, or the full balance.
  const typed = Number(entered);
  const payNow =
    charge != null
      ? charge
      : partial && Number.isFinite(typed) && typed > 0
        ? Math.min(typed, amount)
        : amount;

  // Gratuity is optional, sits on top of the balance and carries no card fee.
  const typedTip = Number(tipTyped);
  const liveTip = tipCustom
    ? Number.isFinite(typedTip) && typedTip > 0
      ? Math.round(typedTip * 100) / 100
      : 0
    : tipPct != null
      ? Math.round(payNow * tipPct) / 100
      : 0;
  const tip = charge != null ? tipLocked : liveTip;

  const fetchClientSecret = useCallback(async (): Promise<string> => {
    const result = await createPaymentCheckout({
      data: {
        target: kind,
        id,
        returnUrl: `${window.location.origin}/checkout/return?session_id={CHECKOUT_SESSION_ID}`,
        environment: getStripeEnvironment(),
        ...(charge != null ? { amount: charge } : {}),
        ...(tipLocked > 0 ? { tip: tipLocked } : {}),
      },
    });
    if ("error" in result) throw new Error(result.error);
    if (!result.clientSecret) throw new Error("Checkout could not be started");
    return result.clientSecret;
  }, [kind, id, charge, tipLocked]);

  const options = useMemo(() => ({ fetchClientSecret }), [fetchClientSecret]);

  const start = () => {
    if (tipCustom && tipTyped.trim() !== "" && (!Number.isFinite(typedTip) || typedTip < 0)) {
      setNotice("Enter a valid gratuity amount.");
      return;
    }
    if (!partial) {
      setNotice(null);
      setTipLocked(liveTip);
      setCharge(amount);
      return;
    }
    const value = Number(entered);
    if (!Number.isFinite(value) || value < 0.5) {
      setNotice("Enter an amount of at least $0.50.");
      return;
    }
    if (value > amount) {
      setNotice(`That is more than the balance of $${amount.toFixed(2)}.`);
      return;
    }
    setNotice(null);
    setTipLocked(liveTip);
    setCharge(Number(value.toFixed(2)));
  };

  const tipOptions = [15, 18, 20, 25];

  return (
    <div className="min-h-screen bg-[#0b1220] text-white">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-80 bg-[radial-gradient(60%_100%_at_50%_0%,rgba(22,101,216,0.35),transparent)]" />

      <header className="relative border-b border-white/10">
        <div className="mx-auto flex max-w-5xl items-center gap-3 px-5 py-5">
          <BrandLogo className="size-10" />
          <div>
            <div className="text-base font-bold leading-none">Blackwave Transportation LLC</div>
            <div className="mt-1 text-[10px] font-semibold uppercase tracking-[0.3em] text-white/50">
              Secure card payment
            </div>
          </div>
        </div>
      </header>

      <main className="relative mx-auto w-full max-w-5xl px-5 py-10">
        {summary.isLoading ? (
          <p className="py-24 text-center text-sm uppercase tracking-[0.3em] text-white/50">Loading</p>
        ) : !data ? (
          <div className="mx-auto max-w-lg rounded-2xl border border-white/10 bg-white/5 p-8 text-center">
            <h1 className="text-xl font-semibold">This payment link is not available</h1>
            <p className="mt-2 text-sm text-white/60">
              {(summary.data && "error" in summary.data && summary.data.error) ||
                "Please contact us at info@rideblackwave.com and we will help you settle the balance."}
            </p>
          </div>
        ) : data.paid || amount <= 0 ? (
          <div className="mx-auto max-w-lg rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-8 text-center">
            <h1 className="text-2xl font-bold text-emerald-300">Paid in full</h1>
            <p className="mt-2 text-sm text-white/70">
              {data.number ? `${data.number} — ` : ""}nothing is outstanding. Thank you.
            </p>
          </div>
        ) : (
          <div className="grid gap-6 lg:grid-cols-[minmax(0,320px)_minmax(0,1fr)]">
            <aside className="h-fit rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur">
              <div className="text-[10px] font-semibold uppercase tracking-[0.3em] text-white/50">
                {kind === "invoice" ? "Invoice" : "Reservation"}
              </div>
              <div className="mt-1 text-2xl font-bold">{data.number}</div>
              {data.name ? <div className="mt-1 text-sm text-white/60">{data.name}</div> : null}
              {data.details ? <PayDetailsBlock details={data.details} /> : null}

              <div className="mt-6 rounded-xl bg-[linear-gradient(135deg,#0b3a75,#1665d8)] px-5 py-4">
                <div className="text-[10px] font-semibold uppercase tracking-[0.25em] text-white/70">
                  Balance due
                </div>
                <div className="mt-1 text-3xl font-bold">${amount.toFixed(2)}</div>
              </div>

              <dl className="mt-4 space-y-1.5 text-sm text-white/70">
                <div className="flex justify-between">
                  <dt>Statement total</dt>
                  <dd>${(data.subtotal || amount).toFixed(2)}</dd>
                </div>
                {data.discount > 0 && (
                  <div className="flex justify-between">
                    <dt>Discount</dt>
                    <dd>−${data.discount.toFixed(2)}</dd>
                  </div>
                )}
                {data.credited > 0 && (
                  <div className="flex justify-between">
                    <dt>Payments received</dt>
                    <dd>−${data.credited.toFixed(2)}</dd>
                  </div>
                )}
                <div className="flex justify-between border-t border-white/10 pt-1.5">
                  <dt>Balance due</dt>
                  <dd>${amount.toFixed(2)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt>
                    Paying now
                    {amount > 0 && (
                      <span className="ml-1 text-white/40">({percent(payNow, amount)}% of balance)</span>
                    )}
                  </dt>
                  <dd>${payNow.toFixed(2)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt>Card processing fee (3%)</dt>
                  <dd>${cardFee(payNow).toFixed(2)}</dd>
                </div>
                {tip > 0 && (
                  <div className="flex justify-between">
                    <dt>Gratuity</dt>
                    <dd>${tip.toFixed(2)}</dd>
                  </div>
                )}
                <div className="flex justify-between border-t border-white/10 pt-1.5 text-base font-semibold text-white">
                  <dt>Charged to card</dt>
                  <dd>${(payNow + cardFee(payNow) + tip).toFixed(2)}</dd>
                </div>
                {payNow < amount && (
                  <div className="flex justify-between text-amber-300">
                    <dt>Remaining after payment</dt>
                    <dd>${(amount - payNow).toFixed(2)}</dd>
                  </div>
                )}
              </dl>

              <ul className="mt-6 space-y-2 text-xs text-white/60">
                <li>Visa · Mastercard · American Express · Discover</li>
                <li>A 3% fee applies to card payments only.</li>
                <li>Card details are entered on our processor's secure form.</li>
                <li>A receipt is emailed as soon as the payment clears.</li>
              </ul>


              <p className="mt-6 text-xs text-white/50">
                Questions? info@rideblackwave.com · (917) 325-3211
              </p>
            </aside>

            <section className="rounded-2xl border border-white/10 bg-white p-6 text-[#132132] shadow-2xl">
              {!paymentsConfigured() ? (
                <p className="text-sm text-red-600">Card payments are not available right now.</p>
              ) : charge == null ? (
                <>
                  <h1 className="text-xl font-bold">How much would you like to pay?</h1>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setPartial(false);
                        setNotice(null);
                      }}
                      className={`rounded-lg border px-5 py-3 text-sm font-semibold transition ${
                        !partial
                          ? "border-[#1665d8] bg-[#eef4fd] text-[#0b3a75]"
                          : "border-slate-200 text-slate-600 hover:border-[#1665d8]"
                      }`}
                    >
                      Full balance ${amount.toFixed(2)}
                    </button>
                    {kind === "invoice" && (
                      <button
                        type="button"
                        onClick={() => {
                          setPartial(true);
                          setNotice(null);
                        }}
                        className={`rounded-lg border px-5 py-3 text-sm font-semibold transition ${
                          partial
                            ? "border-[#1665d8] bg-[#eef4fd] text-[#0b3a75]"
                            : "border-slate-200 text-slate-600 hover:border-[#1665d8]"
                        }`}
                      >
                        Part payment
                      </button>
                    )}
                  </div>

                  {partial && (
                    <div className="mt-4">
                      <label htmlFor="pay-amount" className="text-xs font-semibold uppercase tracking-widest text-slate-500">
                        Amount to pay now
                      </label>
                      <div className="mt-2 flex items-center gap-2">
                        <span className="text-lg font-semibold text-slate-500">$</span>
                        <input
                          id="pay-amount"
                          inputMode="decimal"
                          value={entered}
                          onChange={(e) => setEntered(e.target.value)}
                          placeholder={amount.toFixed(2)}
                          className="w-40 rounded-lg border border-slate-300 px-3 py-2 text-lg outline-none focus:border-[#1665d8]"
                        />
                        <span className="text-xs text-slate-500">of ${amount.toFixed(2)} balance</span>
                      </div>
                      {payNow > 0 && payNow < amount && (
                        <p className="mt-2 text-xs font-semibold text-[#0b3a75]">
                          {percent(payNow, amount)}% of the balance now — ${(amount - payNow).toFixed(2)} stays open
                          on this invoice.
                        </p>
                      )}
                    </div>
                  )}

                  {/* Optional gratuity for the chauffeur — no card fee on this */}
                  <div className="mt-6 rounded-xl border border-slate-200 p-4">
                    <div className="text-sm font-bold text-[#0b3a75]">Add a gratuity for your chauffeur</div>
                    <p className="mt-1 text-xs text-slate-500">Optional. No processing fee is added to a gratuity.</p>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {tipOptions.map((pct) => {
                        const active = !tipCustom && tipPct === pct;
                        return (
                          <button
                            key={pct}
                            type="button"
                            onClick={() => {
                              setTipCustom(false);
                              setTipPct(active ? null : pct);
                            }}
                            className={`rounded-lg border px-4 py-2 text-sm font-semibold transition ${
                              active
                                ? "border-[#1665d8] bg-[#eef4fd] text-[#0b3a75]"
                                : "border-slate-200 text-slate-600 hover:border-[#1665d8]"
                            }`}
                          >
                            {pct}%
                            <span className="ml-1 text-xs font-normal text-slate-400">
                              ${((payNow * pct) / 100).toFixed(2)}
                            </span>
                          </button>
                        );
                      })}
                      <button
                        type="button"
                        onClick={() => {
                          setTipCustom(true);
                          setTipPct(null);
                        }}
                        className={`rounded-lg border px-4 py-2 text-sm font-semibold transition ${
                          tipCustom
                            ? "border-[#1665d8] bg-[#eef4fd] text-[#0b3a75]"
                            : "border-slate-200 text-slate-600 hover:border-[#1665d8]"
                        }`}
                      >
                        Other amount
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setTipCustom(false);
                          setTipPct(null);
                          setTipTyped("");
                        }}
                        className={`rounded-lg border px-4 py-2 text-sm font-semibold transition ${
                          !tipCustom && tipPct === null
                            ? "border-[#1665d8] bg-[#eef4fd] text-[#0b3a75]"
                            : "border-slate-200 text-slate-600 hover:border-[#1665d8]"
                        }`}
                      >
                        No gratuity
                      </button>
                    </div>
                    {tipCustom && (
                      <div className="mt-3 flex items-center gap-2">
                        <span className="text-lg font-semibold text-slate-500">$</span>
                        <input
                          id="tip-amount"
                          aria-label="Gratuity amount"
                          inputMode="decimal"
                          value={tipTyped}
                          onChange={(e) => setTipTyped(e.target.value)}
                          placeholder="0.00"
                          className="w-32 rounded-lg border border-slate-300 px-3 py-2 text-lg outline-none focus:border-[#1665d8]"
                        />
                      </div>
                    )}
                  </div>

                  {/* Live breakdown of what the card will actually be charged */}
                  <dl className="mt-5 rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm">
                    <div className="flex justify-between py-1 text-slate-600">
                      <dt>Statement total</dt>
                      <dd>${(data.subtotal || amount).toFixed(2)}</dd>
                    </div>
                    {data.discount > 0 && (
                      <div className="flex justify-between py-1 text-slate-600">
                        <dt>Discount</dt>
                        <dd>−${data.discount.toFixed(2)}</dd>
                      </div>
                    )}
                    {data.credited > 0 && (
                      <div className="flex justify-between py-1 text-slate-600">
                        <dt>Payments received</dt>
                        <dd>−${data.credited.toFixed(2)}</dd>
                      </div>
                    )}
                    <div className="flex justify-between border-t border-slate-200 py-1 pt-2 text-slate-600">
                      <dt>Balance due</dt>
                      <dd>${amount.toFixed(2)}</dd>
                    </div>
                    <div className="flex justify-between py-1 text-slate-800">
                      <dt>
                        Paying now{" "}
                        <span className="text-slate-400">({percent(payNow, amount)}%)</span>
                      </dt>
                      <dd>${payNow.toFixed(2)}</dd>
                    </div>
                    <div className="flex justify-between py-1 text-slate-600">
                      <dt>Card processing fee (3%)</dt>
                      <dd>${cardFee(payNow).toFixed(2)}</dd>
                    </div>
                    {tip > 0 && (
                      <div className="flex justify-between py-1 text-slate-600">
                        <dt>Gratuity</dt>
                        <dd>${tip.toFixed(2)}</dd>
                      </div>
                    )}
                    <div className="flex justify-between border-t border-slate-300 pt-2 text-base font-bold text-[#0b3a75]">
                      <dt>Total charged to card</dt>
                      <dd>${(payNow + cardFee(payNow) + tip).toFixed(2)}</dd>
                    </div>
                  </dl>


                  {notice && <p className="mt-3 text-sm text-red-600">{notice}</p>}

                  <button
                    type="button"
                    onClick={start}
                    className="mt-6 w-full rounded-lg bg-[#0b3a75] px-6 py-3.5 text-sm font-semibold text-white transition hover:bg-[#1665d8] sm:w-auto"
                  >
                    Continue to card details
                  </button>
                </>
              ) : (
                <>
                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <div className="text-xs font-semibold uppercase tracking-widest text-slate-500">
                          Total charged to card
                        </div>
                        <div className="text-3xl font-bold text-[#0b3a75]">
                          ${(charge + cardFee(charge) + tipLocked).toFixed(2)}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setCharge(null)}
                        className="text-xs font-semibold uppercase tracking-widest text-[#1665d8]"
                      >
                        Change amount
                      </button>
                    </div>
                    <dl className="mt-3 space-y-1 border-t border-slate-200 pt-3 text-sm">
                      <div className="flex justify-between text-slate-600">
                        <dt>Balance due</dt>
                        <dd>${amount.toFixed(2)}</dd>
                      </div>
                      <div className="flex justify-between text-slate-800">
                        <dt>
                          Payment amount{" "}
                          <span className="text-slate-400">
                            ({percent(charge, amount)}% {charge < amount ? "part payment" : "in full"})
                          </span>
                        </dt>
                        <dd>${charge.toFixed(2)}</dd>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <dt>Card processing fee (3%)</dt>
                        <dd>${cardFee(charge).toFixed(2)}</dd>
                      </div>
                      {tipLocked > 0 && (
                        <div className="flex justify-between text-slate-600">
                          <dt>Gratuity</dt>
                          <dd>${tipLocked.toFixed(2)}</dd>
                        </div>
                      )}
                      {charge < amount && (
                        <div className="flex justify-between font-semibold text-amber-700">
                          <dt>Remaining balance after payment</dt>
                          <dd>${(amount - charge).toFixed(2)}</dd>
                        </div>
                      )}
                    </dl>
                  </div>

                  <div className="mt-3">
                    <PaymentTestModeBanner />
                  </div>
                  <div className="mt-4">
                    <EmbeddedCheckoutProvider key={charge} stripe={getStripe()} options={options}>
                      <EmbeddedCheckout />
                    </EmbeddedCheckoutProvider>
                  </div>
                </>
              )}

              <div className="mt-8 border-t border-slate-200 pt-5">
                <PaymentShare target={kind} id={id} reference={data.number} />
              </div>
            </section>
          </div>
        )}
      </main>
    </div>
  );
}

function fmtTime(iso: string | null) {
  if (!iso) return null;
  return new Date(iso).toLocaleString("en-US", {
    month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit",
    timeZone: "America/New_York",
  });
}

function PayDetailsBlock({ details }: { details: NonNullable<Extract<Awaited<ReturnType<typeof getPaySummary>>, { number: string }>["details"]> }) {
  const bill = [details.company, details.address, details.billingContact, details.billingEmail, details.billingPhone].some(Boolean);
  return (
    <div className="mt-5 space-y-4 text-sm">
      {bill ? (
        <div className="rounded-xl border border-white/10 bg-white/5 p-4">
          <div className="text-[10px] font-semibold uppercase tracking-[0.25em] text-white/50">Bill to</div>
          {details.company ? <div className="mt-1 font-semibold">{details.company}</div> : null}
          {details.address ? <div className="text-white/70">{details.address}</div> : null}
          {details.billingContact ? <div className="mt-2 text-white/80">Attn: {details.billingContact}</div> : null}
          {details.billingEmail ? <div className="text-white/60">{details.billingEmail}</div> : null}
          {details.billingPhone ? <div className="text-white/60">{details.billingPhone}</div> : null}
        </div>
      ) : null}
      {details.rides.map((r) => {
        const p = fmtTime(r.pickupAt);
        const d = fmtTime(r.dropoffAt);
        const rows: Array<[string, string]> = [];
        for (const i of r.items) rows.push([i.label, i.value]);
        return (
          <div key={r.reference} className="rounded-xl border border-white/10 bg-white/5 p-4">
            <div className="text-[10px] font-semibold uppercase tracking-[0.25em] text-white/50">Ride {r.reference}</div>
            {p || r.pickup ? (
              <div className="mt-3">
                <div className="text-xs font-semibold uppercase tracking-widest text-white/90">Pickup</div>
                {p ? <div className="mt-0.5 text-white">{p}</div> : null}
                {r.pickup ? <div className="text-white/70">{r.pickup}</div> : null}
              </div>
            ) : null}
            {d || r.dropoff ? (
              <div className={p || r.pickup ? "mt-3" : "mt-3"}>
                <div className="text-xs font-semibold uppercase tracking-widest text-white/90">Drop off</div>
                {d ? <div className="mt-0.5 text-white">{d}</div> : null}
                {r.dropoff ? <div className="text-white/70">{r.dropoff}</div> : null}
              </div>
            ) : null}
            {rows.length ? (
              <dl className="mt-3 space-y-1 border-t border-white/10 pt-3 text-white/70">
                {rows.map(([k, v]) => (
                  <div key={k} className="flex justify-between gap-3">
                    <dt>{k}</dt>
                    <dd className="text-right text-white">{v}</dd>
                  </div>
                ))}
              </dl>
            ) : null}
          </div>
        );
      })}
    </div>
  );
}
