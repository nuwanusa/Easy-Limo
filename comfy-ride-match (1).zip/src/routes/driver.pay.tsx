import { useMemo } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { DriverShell } from "@/components/DriverShell";
import { useDriverAccount, driverTripsQuery, driverStopsQuery, isFinishedTrip } from "@/lib/driver";
import {
  clockTime,
  dayLabel,
  driverPayout,
  fareTotal,
  groupStops,
  money,
  type Reservation,
} from "@/lib/dispatch";

export const Route = createFileRoute("/driver/pay")({
  head: () => ({
    meta: [
      { title: "Driver Pay — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Blackwave chauffeurs: see payments already settled and amounts still due for completed trips.",
      },
      { property: "og:title", content: "Driver Pay — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Settled and outstanding chauffeur payments for completed Blackwave trips.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: DriverPayPage,
});

function DriverPayPage() {
  const { data: driver, isLoading } = useDriverAccount();
  const { data: trips = [] } = useQuery(driverTripsQuery(driver?.id));
  const { data: stops = [] } = useQuery(driverStopsQuery(driver?.id));
  const stopsByRide = useMemo(() => groupStops(stops), [stops]);

  const totalOf = (t: Reservation) => fareTotal(t, (stopsByRide.get(t.id) ?? []).length);
  const payOf = (t: Reservation) => driverPayout(t, driver ?? null, (stopsByRide.get(t.id) ?? []).length);


  const completed = trips.filter(isFinishedTrip);
  const paid = completed.filter((t) => t.driver_paid_at);
  const due = completed.filter((t) => !t.driver_paid_at);
  const sum = (list: Reservation[]) => list.reduce((n, t) => n + payOf(t), 0);

  return (
    <DriverShell driver={driver ?? null} loading={isLoading}>
      <div className="mt-4 grid grid-cols-2 gap-3">
        <div className="rounded-lg border border-border bg-card p-4">
          <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
            Paid out
          </div>
          <div className="mt-1 font-display text-3xl">{money(sum(paid))}</div>
          <div className="font-cond text-[11px] text-muted-foreground">{paid.length} trips</div>
        </div>
        <div className="rounded-lg border border-brand/40 bg-brand/5 p-4">
          <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
            Payment due
          </div>
          <div className="mt-1 font-display text-3xl text-brand">{money(sum(due))}</div>
          <div className="font-cond text-[11px] text-muted-foreground">{due.length} trips</div>
        </div>
      </div>

      <PaySection title="Due" trips={due} payOf={payOf} totalOf={totalOf} />
      <PaySection title="Completed payments" trips={paid} payOf={payOf} totalOf={totalOf} />
    </DriverShell>
  );
}

function PaySection({
  title,
  trips,
  payOf,
  totalOf,
}: {
  title: string;
  trips: Reservation[];
  payOf: (t: Reservation) => number;
  totalOf: (t: Reservation) => number;
}) {
  return (
    <section className="mt-6">
      <h2 className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
        {title}
      </h2>
      {trips.length === 0 ? (
        <p className="mt-3 font-cond text-sm text-muted-foreground">Nothing here yet.</p>
      ) : (
        <div className="mt-3 space-y-3">
          {trips.map((t) => (
            <Link
              key={t.id}
              to="/driver/$id"
              params={{ id: t.id }}
              className="block rounded-lg border border-border bg-card p-4 transition-colors hover:border-brand/50"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
                    Reservation
                  </div>
                  <div className="font-cond text-sm font-semibold">{t.reference}</div>
                </div>
                <div className="text-right">
                  <div className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
                    Date
                  </div>
                  <div className="font-cond text-sm">
                    {dayLabel(t.pickup_at)} · {clockTime(t.pickup_at)}
                  </div>
                </div>
              </div>
              <div className="mt-2 font-cond text-sm">{t.passenger_name}</div>
              <div className="font-cond text-[12px] leading-snug text-muted-foreground">
                {t.pickup_address} → {t.dropoff_address}
              </div>
              <div className="mt-3 flex items-end justify-end gap-3 border-t border-border pt-3">
                <div className="text-right">
                  <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                    Your pay
                  </div>
                  <div className="whitespace-nowrap font-display text-xl text-brand">
                    {money(payOf(t))}
                  </div>
                </div>
              </div>
            </Link>
          ))}

        </div>
      )}
    </section>
  );
}
