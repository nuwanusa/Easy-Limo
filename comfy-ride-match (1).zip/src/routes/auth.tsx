import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useSession } from "@/lib/auth";
import { resolveLanding } from "@/lib/post-login";
import { LoginCard } from "@/components/LoginCard";
import { ClientCodeLogin } from "@/components/ClientCodeLogin";
import { rememberedCompanyCode, rememberCompanyCode, verifyCompanyCode } from "@/lib/company";

const REMEMBER_KEY = "blackwave.remember-admin-email";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Secure Sign In — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Secure sign-in for Blackwave Transportation staff, chauffeurs and client portal accounts.",
      },
      { property: "og:title", content: "Secure Sign In — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Secure account access for Blackwave Transportation staff, chauffeurs and clients.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const [audience, setAudience] = useState<"staff" | "client">("staff");
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [companyCode, setCompanyCode] = useState("");
  const [show, setShow] = useState(false);
  const [remember, setRemember] = useState(true);
  const [busy, setBusy] = useState(false);
  const [resetting, setResetting] = useState(false);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { session, loading } = useSession();

  useEffect(() => {
    const saved = localStorage.getItem(REMEMBER_KEY);
    if (saved) setEmail(saved);
    setCompanyCode(rememberedCompanyCode());
  }, []);

  useEffect(() => {
    if (loading || !session) return;
    queryClient.clear();
    void resolveLanding().then((to) => navigate({ to }));
  }, [loading, session, navigate, queryClient]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin, data: { full_name: fullName } },
        });
        if (error) throw error;
        toast.success("Account created. Check your email if confirmation is required.");
      }
      queryClient.clear();
      await verifyCompanyCode(companyCode);
      if (companyCode) rememberCompanyCode(companyCode);
      if (remember) localStorage.setItem(REMEMBER_KEY, email);
      else localStorage.removeItem(REMEMBER_KEY);
      navigate({ to: await resolveLanding() });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setBusy(false);
    }
  };

  const resetPassword = async () => {
    if (!email) {
      toast.error("Enter your email first");
      return;
    }
    setResetting(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setResetting(false);
    if (error) toast.error(error.message);
    else toast.success("Reset link sent to your email");
  };

  const google = async () => {
    // Clear the app session and force Google to perform a fresh account
    // selection instead of silently reusing a cached identity.
    queryClient.clear();
    await supabase.auth.signOut({ scope: "local" }).catch(() => undefined);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: `${window.location.origin}/auth`,
      extraParams: {
        prompt: "select_account consent",
        max_age: "0",
      },
    });
    if (result.error) {
      toast.error("Google sign-in failed");
      return;
    }
    if (result.redirected) return;
    navigate({ to: await resolveLanding() });
  };

  if (audience === "client") {
    return <ClientCodeLogin onSwitchToStaff={() => setAudience("staff")} />;
  }

  return (
    <LoginCard
      kicker={audience === "staff" ? "Staff Sign In" : "Client Sign In"}
      email={email}
      setEmail={setEmail}
      password={password}
      setPassword={setPassword}
      show={show}
      setShow={setShow}
      remember={remember}
      setRemember={setRemember}
      busy={busy}
      submit={submit}
      cta={mode === "signin" ? "Login" : "Create account"}
      extraTop={
        <>
          <div className="grid grid-cols-2 gap-2 rounded-xl border border-border bg-surface-2 p-1">
            {(
              [
                { key: "staff", label: "Staff / Admin" },
                { key: "client", label: "Client" },
              ] as const
            ).map((t) => (
              <button
                key={t.key}
                type="button"
                onClick={() => {
                  setAudience(t.key);
                  setMode("signin");
                }}
                className={`rounded-lg py-2.5 font-cond text-[11px] uppercase tracking-[0.2em] transition-colors ${
                  audience === t.key
                    ? "bg-brand text-brand-foreground"
                    : "text-muted-foreground hover:text-brand"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
          <p className="text-center font-cond text-[11px] tracking-wide text-muted-foreground">
            {audience === "staff"
              ? "Admins, dispatchers and chauffeurs sign in here."
              : "Clients sign in to view invoices and make payments."}
          </p>
          <label className="block">
            <span className="font-cond text-xs uppercase tracking-[0.15em] text-foreground">
              Company ID
            </span>
            <input
              value={companyCode}
              onChange={(e) => setCompanyCode(e.target.value.toUpperCase())}
              placeholder="BLACKWAVE"
              autoCapitalize="characters"
              className="mt-2 w-full rounded-xl border border-input bg-surface-2 px-4 py-4 font-cond text-base uppercase tracking-[0.2em] text-foreground outline-none focus:border-brand"
            />
          </label>
          {audience === "staff" && mode === "signup" ? (
            <label className="block">
              <span className="font-cond text-xs uppercase tracking-[0.15em] text-foreground">Full name</span>
              <input
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
                className="mt-2 w-full rounded-xl border border-input bg-surface-2 px-4 py-4 font-cond text-base text-foreground outline-none focus:border-brand"
              />
            </label>
          ) : null}
        </>
      }
      footer={
        <>
          <button
            onClick={google}
            className="w-full rounded-xl border border-border py-3.5 font-cond text-xs uppercase tracking-[0.3em] text-foreground transition-colors hover:border-brand hover:text-brand"
          >
            Continue with Google
          </button>
          {audience === "staff" ? (
            <>
              <button
                onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
                className="mt-5 w-full font-cond text-[11px] uppercase tracking-widest text-muted-foreground transition-colors hover:text-brand"
              >
                {mode === "signin" ? "Need an operator account?" : "Already have access? Sign in"}
              </button>
              <Link
                to="/admin"
                className="mt-3 block w-full text-center font-cond text-[11px] uppercase tracking-widest text-muted-foreground transition-colors hover:text-brand"
              >
                Accounts
              </Link>
            </>
          ) : (
            <p className="mt-5 text-center font-cond text-[11px] uppercase tracking-widest text-muted-foreground">
              No client login yet? Ask your account manager.
            </p>
          )}
          <button
            onClick={resetPassword}
            disabled={resetting}
            className="mt-3 w-full font-cond text-[11px] uppercase tracking-widest text-muted-foreground transition-colors hover:text-brand disabled:opacity-60"
          >
            Forgot password?
          </button>
        </>
      }
    />
  );
}
