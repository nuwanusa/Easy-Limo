import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getPortalByCode } from "@/lib/client-portal.functions";
import { PortalView } from "@/components/PortalView";

export const Route = createFileRoute("/c/$code")({
  head: () => ({
    meta: [
      { title: "Client Portal — Blackwave Transportation LLC" },
      { name: "description", content: "Your Blackwave invoices, ride details and online payment." },
      { property: "og:title", content: "Client Portal — Blackwave Transportation LLC" },
      { property: "og:description", content: "Your invoices, ride details and online payment." },
      { property: "og:type", content: "website" },
      { name: "robots", content: "noindex" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ShortCodePage,
});

function ShortCodePage() {
  const { code } = Route.useParams();
  const navigate = useNavigate();
  const fetchByCode = useServerFn(getPortalByCode);
  const valid = /^\d{6}$/.test(code);

  const portal = useQuery({
    queryKey: ["portal-short", code],
    queryFn: () => fetchByCode({ data: { code } }),
    enabled: valid,
    retry: false,
  });

  if (!valid || portal.error) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 px-4 text-center">
        <h1 className="font-display text-3xl uppercase">Link not valid</h1>
        <p className="text-sm text-muted-foreground">
          This client link is no longer valid. Contact Blackwave Transportation for a new one.
        </p>
        <button
          onClick={() => navigate({ to: "/" })}
          className="rounded-md bg-brand px-4 py-2 font-cond text-[11px] uppercase tracking-widest text-brand-foreground"
        >
          Go to Blackwave
        </button>
      </div>
    );
  }

  if (portal.isLoading || !portal.data) {
    return (
      <p className="py-24 text-center font-cond text-xs uppercase tracking-[0.4em] text-muted-foreground">
        Opening your portal
      </p>
    );
  }

  return (
    <div className="cine min-h-screen text-foreground">
      <header className="border-b border-border bg-nav">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3 sm:px-6">
          <span className="grid size-10 place-items-center bg-brand font-display text-lg text-brand-foreground">B</span>
          <div className="flex-1">
            <div className="font-display text-lg uppercase leading-none">{portal.data.client.name}</div>
            <div className="font-cond text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
              Blackwave client portal
          </div>
          <button
            onClick={() => navigate({ to: "/", replace: true })}
            className="rounded-md border border-border px-3 py-2 font-cond text-[11px] uppercase tracking-widest text-foreground hover:border-brand hover:text-brand"
          >
            Close
          </button>
        </div>
        </div>
      </header>
      <PortalView data={portal.data} auth={{ code }} />
    </div>
  );
}
