import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Archive, Mail, MailOpen, PenSquare, Reply, ReplyAll, Search, X } from "lucide-react";
import { AppShell, PageHeading } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { getInboxMessage, listInbox, replyInboxMessage, sendInboxEmail, updateInboxMessage } from "@/lib/inbox.functions";

type Folder = "inbox" | "sentitems" | "archive";

const cleanParam = (v: unknown) =>
  typeof v === "string" ? v.replace(/^"([\s\S]*)"$/, "$1") : undefined;

export const Route = createFileRoute("/inbox")({
  validateSearch: (s: Record<string, unknown>) => {
    const folderValue = cleanParam(s["folder"]);
    const composeValue = cleanParam(s["compose"]);
    return {
      client: cleanParam(s["client"]),
      folder: folderValue === "sentitems" || folderValue === "archive" ? (folderValue as "sentitems" | "archive") : undefined,
      compose: (composeValue === "1" || s["compose"] === true) ? ("1" as const) : undefined,
      open: cleanParam(s["open"]),
    };
  },
  head: () => ({
    meta: [
      { title: "Email Inbox — Blackwave Dispatch" },
      { name: "description", content: "Read, reply to, and send company emails from Outlook." },
      { property: "og:title", content: "Email Inbox — Blackwave Dispatch" },
      { property: "og:description", content: "Read, reply to, and send company emails from Outlook." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => (
    <AppShell>
      <InboxPage />
    </AppShell>
  ),
});

const fmt = (s: string) => {
  const d = new Date(s);
  const today = new Date().toDateString() === d.toDateString();
  return today
    ? d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })
    : d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
};

function InboxPage() {
  const { client, folder: folderParam, compose, open } = Route.useSearch();
  const qc = useQueryClient();
  const [folder, setFolder] = useState<Folder>(folderParam ?? "inbox");
  const [search, setSearch] = useState("");
  const [term, setTerm] = useState("");
  const [selected, setSelected] = useState<string | null>(open ?? null);
  const [composeTo, setComposeTo] = useState<string | null>(compose ? (client ?? "") : null);

  const listFn = useServerFn(listInbox);
  const getFn = useServerFn(getInboxMessage);
  const updateFn = useServerFn(updateInboxMessage);

  const list = useQuery({
    queryKey: ["inbox", folder, term, client],
    queryFn: () => listFn({ data: { folder, search: term || undefined, clientEmail: client } }),
    refetchInterval: 60000,
  });
  const msg = useQuery({
    queryKey: ["inbox-msg", selected],
    queryFn: () => getFn({ data: { id: selected! } }),
    enabled: !!selected,
  });

  const update = useMutation({
    mutationFn: (v: { id: string; action: "archive" | "read" | "unread" }) => updateFn({ data: v }),
    onSuccess: (_d, v) => {
      if (v.action === "archive") {
        setSelected(null);
        toast.success("Archived");
      }
      qc.invalidateQueries({ queryKey: ["inbox"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <>
      <PageHeading eyebrow="Outlook" title="Inbox" />
      <div className="mx-auto max-w-[1800px] p-4 md:p-6">
        <div className="mb-4 flex flex-wrap items-center gap-2">
          {(["inbox", "sentitems", "archive"] as Folder[]).map((f) => (
            <Button key={f} size="sm" variant={folder === f && !client ? "default" : "outline"} onClick={() => { setFolder(f); setSelected(null); }} asChild={!!client}>
              {client ? <Link to="/inbox" search={{ client: undefined, folder: undefined, compose: undefined, open: undefined }} onClick={() => setFolder(f)}>{f === "sentitems" ? "Sent" : f[0]!.toUpperCase() + f.slice(1)}</Link> : <span>{f === "sentitems" ? "Sent" : f[0]!.toUpperCase() + f.slice(1)}</span>}
            </Button>
          ))}
          <form className="flex flex-1 items-center gap-2 min-w-[200px]" onSubmit={(e) => { e.preventDefault(); setTerm(search); }}>
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
              <Input className="pl-8" placeholder="Search emails" value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
          </form>
          <Button size="sm" onClick={() => setComposeTo(client ?? "")}>
            <PenSquare className="mr-1 size-4" /> New email
          </Button>
        </div>
        {client && (
          <div className="mb-3 flex items-center gap-2 rounded-md border border-border bg-muted/40 px-3 py-2 text-sm">
            Showing emails with <b>{client}</b>
            <Link to="/inbox" search={{ client: undefined, folder: undefined, compose: undefined, open: undefined }} className="ml-auto text-muted-foreground hover:text-foreground"><X className="size-4" /></Link>
          </div>
        )}

        <div className="grid gap-4 lg:grid-cols-[minmax(320px,420px)_1fr]">
          <div className={`rounded-lg border border-border bg-card ${selected ? "hidden lg:block" : ""}`}>
            {list.isLoading && <p className="p-4 text-sm text-muted-foreground">Loading emails…</p>}
            {list.error && <p className="p-4 text-sm text-destructive">{(list.error as Error).message}</p>}
            {list.data?.messages.length === 0 && <p className="p-4 text-sm text-muted-foreground">No emails here.</p>}
            <ul className="max-h-[75vh] divide-y divide-border overflow-y-auto">
              {list.data?.messages.map((m) => (
                <li key={m.id}>
                  <button
                    onClick={() => setSelected(m.id)}
                    className={`w-full px-4 py-3 text-left hover:bg-muted/50 ${selected === m.id ? "bg-muted" : ""}`}
                  >
                    <div className="flex items-center gap-2">
                      {!m.isRead && <span className="size-2 shrink-0 rounded-full bg-primary" />}
                      <span className={`truncate text-sm ${m.isRead ? "" : "font-semibold"}`}>{m.fromName || m.fromEmail}</span>
                      <span className="ml-auto shrink-0 text-xs text-muted-foreground">{fmt(m.receivedAt)}</span>
                    </div>
                    <div className={`truncate text-sm ${m.isRead ? "text-muted-foreground" : "font-medium"}`}>{m.subject}</div>
                    <div className="truncate text-xs text-muted-foreground">{m.preview}</div>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className={`rounded-lg border border-border bg-card ${selected ? "" : "hidden lg:block"}`}>
            {!selected && (
              <div className="flex h-full min-h-[300px] flex-col items-center justify-center gap-2 text-muted-foreground">
                <Mail className="size-8" /> Select an email to read
              </div>
            )}
            {selected && msg.isLoading && <p className="p-4 text-sm text-muted-foreground">Opening…</p>}
            {selected && msg.error && <p className="p-4 text-sm text-destructive">{(msg.error as Error).message}</p>}
            {selected && msg.data && (
              <MessageView
                key={msg.data.id}
                m={msg.data}
                onBack={() => setSelected(null)}
                onArchive={() => update.mutate({ id: msg.data!.id, action: "archive" })}
                onUnread={() => { update.mutate({ id: msg.data!.id, action: "unread" }); setSelected(null); }}
              />
            )}
          </div>
        </div>
      </div>
      {composeTo !== null && <Compose to={composeTo} onClose={() => setComposeTo(null)} />}
    </>
  );
}

type Msg = Awaited<ReturnType<typeof getInboxMessage>>;

function MessageView({ m, onBack, onArchive, onUnread }: { m: Msg; onBack: () => void; onArchive: () => void; onUnread: () => void }) {
  const qc = useQueryClient();
  const replyFn = useServerFn(replyInboxMessage);
  const [mode, setMode] = useState<null | "reply" | "replyAll">(null);
  const [text, setText] = useState("");
  const send = useMutation({
    mutationFn: () => replyFn({ data: { id: m.id, comment: text, replyAll: mode === "replyAll" } }),
    onSuccess: () => {
      toast.success("Reply sent");
      setMode(null);
      setText("");
      qc.invalidateQueries({ queryKey: ["inbox"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="flex flex-col">
      <div className="flex flex-wrap items-center gap-2 border-b border-border p-3">
        <Button size="sm" variant="ghost" className="lg:hidden" onClick={onBack}>← Back</Button>
        <Button size="sm" variant="outline" onClick={() => setMode("reply")}><Reply className="mr-1 size-4" />Reply</Button>
        <Button size="sm" variant="outline" onClick={() => setMode("replyAll")}><ReplyAll className="mr-1 size-4" />Reply all</Button>
        <Button size="sm" variant="outline" onClick={onArchive}><Archive className="mr-1 size-4" />Archive</Button>
        <Button size="sm" variant="ghost" onClick={onUnread}><MailOpen className="mr-1 size-4" />Mark unread</Button>
      </div>
      <div className="space-y-1 border-b border-border p-4">
        <h2 className="font-display text-2xl">{m.subject}</h2>
        <div className="text-sm">
          <b>{m.fromName}</b> <span className="text-muted-foreground">&lt;{m.fromEmail}&gt;</span>
        </div>
        <div className="text-xs text-muted-foreground">
          To: {m.to.join(", ")}{m.cc.length ? ` · Cc: ${m.cc.join(", ")}` : ""} · {new Date(m.receivedAt).toLocaleString()}
        </div>
        {m.client ? (
          <Link to="/clients" className="inline-block rounded bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
            Client: {m.client.name}
          </Link>
        ) : (
          <span className="inline-block rounded bg-muted px-2 py-0.5 text-xs text-muted-foreground">Not a saved client</span>
        )}
      </div>
      {mode && (
        <div className="space-y-2 border-b border-border bg-muted/30 p-4">
          <div className="text-xs text-muted-foreground">{mode === "replyAll" ? "Reply all" : `Reply to ${m.fromEmail}`}</div>
          <Textarea rows={6} autoFocus value={text} onChange={(e) => setText(e.target.value)} placeholder="Write your reply…" />
          <div className="flex gap-2">
            <Button size="sm" disabled={!text.trim() || send.isPending} onClick={() => send.mutate()}>
              {send.isPending ? "Sending…" : "Send"}
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setMode(null)}>Cancel</Button>
          </div>
        </div>
      )}
      <pre className="max-h-[60vh] overflow-y-auto whitespace-pre-wrap break-words p-4 font-sans text-sm">{m.body}</pre>
    </div>
  );
}

function Compose({ to: initialTo, onClose }: { to: string; onClose: () => void }) {
  const sendFn = useServerFn(sendInboxEmail);
  const qc = useQueryClient();
  const [to, setTo] = useState(initialTo);
  const [cc, setCc] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const send = useMutation({
    mutationFn: () => sendFn({ data: { to, cc, subject, body } }),
    onSuccess: () => {
      toast.success("Email sent");
      qc.invalidateQueries({ queryKey: ["inbox"] });
      onClose();
    },
    onError: (e: Error) => toast.error(e.message),
  });
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-background/60 p-4 sm:items-center">
      <div className="w-full max-w-xl space-y-3 rounded-lg border border-border bg-card p-4 shadow-xl">
        <div className="flex items-center">
          <h3 className="font-display text-xl">New email</h3>
          <button className="ml-auto text-muted-foreground" onClick={onClose} aria-label="Close"><X className="size-5" /></button>
        </div>
        <Input placeholder="To" type="email" value={to} onChange={(e) => setTo(e.target.value)} />
        <Input placeholder="Cc (optional)" type="email" value={cc} onChange={(e) => setCc(e.target.value)} />
        <Input placeholder="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} />
        <Textarea rows={8} placeholder="Message" value={body} onChange={(e) => setBody(e.target.value)} />
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button disabled={!to || !subject || !body || send.isPending} onClick={() => send.mutate()}>
            {send.isPending ? "Sending…" : "Send"}
          </Button>
        </div>
      </div>
    </div>
  );
}
