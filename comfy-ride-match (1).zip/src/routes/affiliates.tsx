import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { AppShell, PageHeading } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/lib/company";
import { fareTotal, money } from "@/lib/dispatch";
import {
  assignRideToAffiliate,
  createAffiliateStatement,
  markAffiliateStatementPaid,
  sendAffiliateStatement,
  syncReferralCommissions,
} from "@/lib/affiliates.functions";

export const Route = createFileRoute("/affiliates")({
  head: () => ({
    meta: [
      { title: "Affiliates — Blackwave Dispatch" },
      { name: "description", content: "Partner operators, referral partners, farmed-out rides and payout statements." },
      { property: "og:title", content: "Affiliates — Blackwave Dispatch" },
      { property: "og:description", content: "Manage partner operators, referral commissions and payout statements." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: () => (
    <AppShell>
      <AffiliatesPage />
    </AppShell>
  ),
});

const input = "mt-1 w-full rounded-md border border-input bg-surface-2 px-3 py-2 text-sm";
const card = "rounded-lg border border-border bg-surface-1 p-4";
const KINDS = [
  { value: "operator", label: "Ride partner (farm-out)" },
  { value: "referral", label: "Referral partner" },
  { value: "both", label: "Both" },
] as const;

const emptyForm = {
  id: "",
  name: "",
  kind: "operator",
  contact_name: "",
  email: "",
  phone: "",
  address_line1: "",
  city: "",
  state: "",
  postal_code: "",
  default_percent: "70",
  referral_percent: "10",
  status: "active",
  notes: "",
};

function AffiliatesPage() {
  const qc = useQueryClient();
  const { company } = useCompany();
  const [tab, setTab] = useState<"partners" | "farmout" | "statements">("partners");
  const [form, setForm] = useState({ ...emptyForm });

  const affiliatesQuery = useQuery({
    queryKey: ["affiliates"],
    queryFn: async () => {
      const { data, error } = await supabase.from("affiliates").select("*").order("name");
      if (error) throw error;
      return data ?? [];
    },
  });

  const save = useMutation({
    mutationFn: async () => {
      if (!form.name.trim()) throw new Error("Enter the partner name");
      const payload = {
        name: form.name.trim(),
        kind: form.kind,
        contact_name: form.contact_name || null,
        email: form.email || null,
        phone: form.phone || null,
        address_line1: form.address_line1 || null,
        city: form.city || null,
        state: form.state || null,
        postal_code: form.postal_code || null,
        default_percent: Number(form.default_percent) || 0,
        referral_percent: Number(form.referral_percent) || 0,
        status: form.status,
        notes: form.notes || null,
      };
      if (form.id) {
        const { data, error } = await supabase.from("affiliates").update(payload).eq("id", form.id).select("id");
        if (error) throw error;
        if (!data?.length) throw new Error("This partner could not be saved — you may not have permission");
      } else {
        if (!company?.companyId) throw new Error("Your account is not linked to a company");
        const { error } = await supabase.from("affiliates").insert({ ...payload, company_id: company.companyId });
        if (error) throw error;
      }
    },
    onSuccess: () => {
      toast.success("Partner saved");
      setForm({ ...emptyForm });
      qc.invalidateQueries({ queryKey: ["affiliates"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const affiliates = (affiliatesQuery.data ?? []) as any[];

  return (
    <div className="space-y-6">
      <PageHeading eyebrow="Partners" title="Affiliates" />

      <div className="flex flex-wrap gap-2">
        {([
          ["partners", "Partners"],
          ["farmout", "Farm-out rides"],
          ["statements", "Statements"],
        ] as const).map(([key, label]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`rounded-md border px-3 py-1.5 text-sm ${
              tab === key ? "border-brand bg-brand/10 text-brand" : "border-border bg-surface-1 text-muted-foreground"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "partners" && (
        <div className="grid gap-4 lg:grid-cols-[minmax(0,360px)_minmax(0,1fr)]">
          <div className={card}>
            <div className="font-cond text-[11px] uppercase tracking-[0.25em] text-brand">
              {form.id ? "Edit partner" : "New partner"}
            </div>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <label className="text-xs sm:col-span-2">
                Partner name
                <input className={input} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </label>
              <label className="text-xs sm:col-span-2">
                Partner type
                <select className={input} value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
                  {KINDS.map((k) => (
                    <option key={k.value} value={k.value}>
                      {k.label}
                    </option>
                  ))}
                </select>
              </label>
              <label className="text-xs">
                Contact name
                <input className={input} value={form.contact_name} onChange={(e) => setForm({ ...form, contact_name: e.target.value })} />
              </label>
              <label className="text-xs">
                Phone
                <input className={input} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              </label>
              <label className="text-xs sm:col-span-2">
                Email
                <input className={input} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </label>
              <label className="text-xs sm:col-span-2">
                Address
                <input className={input} value={form.address_line1} onChange={(e) => setForm({ ...form, address_line1: e.target.value })} />
              </label>
              <label className="text-xs">
                City
                <input className={input} value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
              </label>
              <label className="text-xs">
                State / ZIP
                <div className="mt-1 flex gap-2">
                  <input className="w-1/2 rounded-md border border-input bg-surface-2 px-3 py-2 text-sm" value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} />
                  <input className="w-1/2 rounded-md border border-input bg-surface-2 px-3 py-2 text-sm" value={form.postal_code} onChange={(e) => setForm({ ...form, postal_code: e.target.value })} />
                </div>
              </label>
              <label className="text-xs">
                Farm-out share %
                <input className={input} value={form.default_percent} onChange={(e) => setForm({ ...form, default_percent: e.target.value })} />
              </label>
              <label className="text-xs">
                Referral commission %
                <input className={input} value={form.referral_percent} onChange={(e) => setForm({ ...form, referral_percent: e.target.value })} />
              </label>
              <label className="text-xs sm:col-span-2">
                Status
                <select className={input} value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                  <option value="active">Active</option>
                  <option value="suspended">Suspended</option>
                </select>
              </label>
              <label className="text-xs sm:col-span-2">
                Notes
                <textarea className={input} rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
              </label>
            </div>
            <div className="mt-3 flex gap-2">
              <button
                onClick={() => save.mutate()}
                disabled={save.isPending}
                className="rounded-md bg-brand px-4 py-2 text-sm font-medium text-brand-foreground disabled:opacity-60"
              >
                {form.id ? "Save partner" : "Add partner"}
              </button>
              {form.id && (
                <button onClick={() => setForm({ ...emptyForm })} className="rounded-md border border-border px-4 py-2 text-sm">
                  Cancel
                </button>
              )}
            </div>
          </div>

          <div className="space-y-3">
            {affiliatesQuery.isLoading && <div className="text-sm text-muted-foreground">Loading partners…</div>}
            {!affiliatesQuery.isLoading && !affiliates.length && (
              <div className={card}>No partners yet. Add your first partner on the left.</div>
            )}
            {affiliates.map((a) => (
              <div key={a.id} className={card}>
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <div className="text-base font-semibold">{a.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {KINDS.find((k) => k.value === a.kind)?.label} · {a.status}
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">
                      {[a.contact_name, a.phone, a.email].filter(Boolean).join(" · ")}
                    </div>
                  </div>
                  <div className="text-right text-xs">
                    <div>Farm-out {Number(a.default_percent)}%</div>
                    <div>Referral {Number(a.referral_percent)}%</div>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
                  <span className="rounded-md border border-border bg-surface-2 px-2 py-1">
                    Portal code <strong className="tracking-[0.2em]">{a.portal_code}</strong>
                  </span>
                  <button
                    className="rounded-md border border-border px-2 py-1"
                    onClick={() => {
                      navigator.clipboard.writeText(`${window.location.origin}/a/${a.portal_code}`);
                      toast.success("Partner portal link copied");
                    }}
                  >
                    Copy portal link
                  </button>
                  <button
                    className="rounded-md border border-border px-2 py-1"
                    onClick={() =>
                      setForm({
                        id: a.id,
                        name: a.name ?? "",
                        kind: a.kind ?? "operator",
                        contact_name: a.contact_name ?? "",
                        email: a.email ?? "",
                        phone: a.phone ?? "",
                        address_line1: a.address_line1 ?? "",
                        city: a.city ?? "",
                        state: a.state ?? "",
                        postal_code: a.postal_code ?? "",
                        default_percent: String(a.default_percent ?? 0),
                        referral_percent: String(a.referral_percent ?? 0),
                        status: a.status ?? "active",
                        notes: a.notes ?? "",
                      })
                    }
                  >
                    Edit
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === "farmout" && <FarmOutTab affiliates={affiliates} />}
      {tab === "statements" && <StatementsTab affiliates={affiliates} />}
    </div>
  );
}

function FarmOutTab({ affiliates }: { affiliates: any[] }) {
  const qc = useQueryClient();
  const assign = useServerFn(assignRideToAffiliate);

  const ridesQuery = useQuery({
    queryKey: ["affiliate-farmout-rides"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("reservations")
        .select("*")
        .gte("pickup_at", new Date(Date.now() - 7 * 86400000).toISOString())
        .order("pickup_at", { ascending: true })
        .limit(150);
      if (error) throw error;
      return data ?? [];
    },
  });

  const mut = useMutation({
    mutationFn: (vars: { reservationId: string; affiliateId: string | null; payout?: number | undefined }) =>
      assign({ data: vars }),
    onSuccess: () => {
      toast.success("Ride updated");
      qc.invalidateQueries({ queryKey: ["affiliate-farmout-rides"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const rides = (ridesQuery.data ?? []) as any[];

  return (
    <div className="space-y-3">
      {!affiliates.length && <div className={card}>Add a partner first, then you can hand rides to them.</div>}
      {rides.map((r) => (
        <FarmOutRow key={r.id} ride={r} affiliates={affiliates} onSave={(v) => mut.mutate(v)} saving={mut.isPending} />
      ))}
      {!ridesQuery.isLoading && !rides.length && <div className={card}>No recent or upcoming rides.</div>}
    </div>
  );
}

function FarmOutRow({
  ride,
  affiliates,
  onSave,
  saving,
}: {
  ride: any;
  affiliates: any[];
  onSave: (v: { reservationId: string; affiliateId: string | null; payout?: number | undefined }) => void;
  saving: boolean;
}) {
  const [affiliateId, setAffiliateId] = useState<string>(ride.affiliate_id ?? "");
  const [payout, setPayout] = useState<string>(ride.affiliate_payout ? String(ride.affiliate_payout) : "");
  const total = fareTotal(ride, 0);

  return (
    <div className={card}>
      <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_minmax(0,420px)]">
        <div>
          <div className="flex flex-wrap items-center gap-2 text-sm font-semibold">
            <Link to="/rides/$id" params={{ id: ride.id }} className="text-brand">
              {ride.reference}
            </Link>
            <span className="text-muted-foreground">
              {new Date(ride.pickup_at).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" })}
            </span>
            {ride.affiliate_status && (
              <span className="rounded-md border border-border px-2 py-0.5 text-[11px] uppercase tracking-wide">
                {ride.affiliate_status}
              </span>
            )}
          </div>
          <div className="mt-1 text-xs text-muted-foreground">
            {ride.pickup_address} → {ride.dropoff_address}
          </div>
          <div className="mt-1 text-xs">Fare {money(total)}</div>
        </div>
        <div className="flex flex-wrap items-end gap-2">
          <label className="text-xs flex-1 min-w-[160px]">
            Partner
            <select className={input} value={affiliateId} onChange={(e) => setAffiliateId(e.target.value)}>
              <option value="">Not farmed out</option>
              {affiliates
                .filter((a) => a.kind !== "referral")
                .map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
            </select>
          </label>
          <label className="text-xs w-28">
            Payout $
            <input className={input} value={payout} onChange={(e) => setPayout(e.target.value)} placeholder="auto" />
          </label>
          <button
            disabled={saving}
            onClick={() =>
              onSave({
                reservationId: ride.id,
                affiliateId: affiliateId || null,
                payout: payout ? Number(payout) : undefined,
              })
            }
            className="rounded-md bg-brand px-3 py-2 text-sm font-medium text-brand-foreground disabled:opacity-60"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
}

function StatementsTab({ affiliates }: { affiliates: any[] }) {
  const qc = useQueryClient();
  const createStatement = useServerFn(createAffiliateStatement);
  const sendStatement = useServerFn(sendAffiliateStatement);
  const markPaid = useServerFn(markAffiliateStatementPaid);
  const syncReferrals = useServerFn(syncReferralCommissions);

  const firstId = affiliates[0]?.id ?? "";
  const [affiliateId, setAffiliateId] = useState(firstId);
  const selected = affiliateId || firstId;
  const now = new Date();
  const [from, setFrom] = useState(new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10));
  const [to, setTo] = useState(new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString().slice(0, 10));

  const statementsQuery = useQuery({
    queryKey: ["affiliate-statements", selected],
    enabled: Boolean(selected),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("affiliate_statements")
        .select("*")
        .eq("affiliate_id", selected)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const unbilledQuery = useQuery({
    queryKey: ["affiliate-unbilled", selected],
    enabled: Boolean(selected),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("affiliate_earnings")
        .select("amount")
        .eq("affiliate_id", selected)
        .is("statement_id", null);
      if (error) throw error;
      return data ?? [];
    },
  });

  const unbilled = useMemo(
    () => ((unbilledQuery.data ?? []) as any[]).reduce((sum, e) => sum + Number(e.amount ?? 0), 0),
    [unbilledQuery.data],
  );

  const run = (fn: () => Promise<any>, ok: string) =>
    fn()
      .then((res: any) => {
        if (res?.sent === false) toast.error(res.reason ?? "Email not sent");
        else toast.success(ok);
        qc.invalidateQueries({ queryKey: ["affiliate-statements", selected] });
        qc.invalidateQueries({ queryKey: ["affiliate-unbilled", selected] });
      })
      .catch((e: Error) => toast.error(e.message));

  if (!affiliates.length) return <div className={card}>Add a partner first to create statements.</div>;

  return (
    <div className="space-y-4">
      <div className={card}>
        <div className="grid gap-3 sm:grid-cols-4">
          <label className="text-xs">
            Partner
            <select className={input} value={selected} onChange={(e) => setAffiliateId(e.target.value)}>
              {affiliates.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                </option>
              ))}
            </select>
          </label>
          <label className="text-xs">
            From
            <input type="date" className={input} value={from} onChange={(e) => setFrom(e.target.value)} />
          </label>
          <label className="text-xs">
            To
            <input type="date" className={input} value={to} onChange={(e) => setTo(e.target.value)} />
          </label>
          <div className="text-xs">
            Unbilled
            <div className="mt-1 rounded-md border border-border bg-surface-2 px-3 py-2 text-sm font-semibold">
              {money(unbilled)}
            </div>
          </div>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            className="rounded-md border border-border px-3 py-2 text-sm"
            onClick={() =>
              run(
                () => syncReferrals({ data: { affiliateId: selected, from, to } }),
                "Referral commissions updated",
              )
            }
          >
            Add referral commissions for this period
          </button>
          <button
            className="rounded-md bg-brand px-3 py-2 text-sm font-medium text-brand-foreground"
            onClick={() =>
              run(() => createStatement({ data: { affiliateId: selected, from, to } }), "Statement created")
            }
          >
            Create statement
          </button>
        </div>
      </div>

      <div className="space-y-3">
        {((statementsQuery.data ?? []) as any[]).map((s) => (
          <div key={s.id} className={card}>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="font-semibold">{s.statement_number}</div>
                <div className="text-xs text-muted-foreground">
                  {s.period_start} – {s.period_end} · {s.status}
                  {s.sent_at ? ` · sent ${new Date(s.sent_at).toLocaleDateString("en-US")}` : ""}
                </div>
              </div>
              <div className="text-lg font-semibold">{money(Number(s.total ?? 0))}</div>
            </div>
            <div className="mt-3 flex flex-wrap gap-2 text-sm">
              <button
                className="rounded-md border border-border px-3 py-1.5"
                onClick={() => run(() => sendStatement({ data: { statementId: s.id } }), "Statement emailed")}
              >
                {s.sent_at ? "Resend statement" : "Email statement"}
              </button>
              {!s.paid_at && (
                <button
                  className="rounded-md border border-border px-3 py-1.5"
                  onClick={() => run(() => markPaid({ data: { statementId: s.id } }), "Marked paid")}
                >
                  Mark paid
                </button>
              )}
            </div>
          </div>
        ))}
        {!statementsQuery.isLoading && !((statementsQuery.data ?? []) as any[]).length && (
          <div className={card}>No statements yet for this partner.</div>
        )}
      </div>
    </div>
  );
}
