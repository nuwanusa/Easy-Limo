import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/SiteLayout";
import chauffeur from "@/assets/chauffeur.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Blackwave Transportation" },
      {
        name: "description",
        content:
          "Founded in 2023, Blackwave Transportation is a private chauffeur house serving executives, dignitaries, and discerning travelers.",
      },
      { property: "og:title", content: "About — Blackwave Transportation" },
      { property: "og:description", content: "A private chauffeur house. Discretion, precision, distinction." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <SiteLayout>
      <section className="pb-20 pt-40 lg:pt-48">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <p className="eyebrow mb-6">About</p>
          <h1 className="max-w-5xl font-display text-5xl leading-[1.05] md:text-7xl">
            A house of <span className="gold-text italic">drivers,</span> not a fleet of{" "}
            <span className="italic">cars.</span>
          </h1>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-32 lg:px-10">
        <div className="grid gap-16 lg:grid-cols-12">
          <div className="space-y-8 text-lg leading-relaxed text-muted-foreground lg:col-span-7">
            <p>
              Blackwave Transportation was founded in 2023 by{" "}
              <span className="text-foreground">Nuwan Karunaratne</span>, a career black car chauffeur
              with more than a decade behind the wheel for principals, executives, and visiting
              dignitaries.
            </p>
            <p>
              After ten-plus years driving for other houses, Nuwan built Blackwave around the standard
              he always wished his own clients received — quiet, exact, and unhurried. Today, we operate
              across the Northeast — serving New York, Connecticut, New Jersey, Washington DC, and
              Philadelphia. Our roster of clients is small and our roster of former clients is even
              smaller — almost no one leaves.
            </p>
            <p className="font-display text-2xl italic text-foreground">
              &ldquo;I spent ten years learning what the principal in the back actually wants. Blackwave
              is the answer.&rdquo;
            </p>
            <p className="font-mono text-sm uppercase tracking-[0.25em] text-gold">
              — Nuwan Karunaratne, Founder
            </p>
          </div>
          <div className="lg:col-span-5">
            <img
              src={chauffeur}
              alt="Chauffeur at the door of a black sedan"
              width={1280}
              height={1600}
              loading="lazy"
              className="w-full object-cover"
            />
          </div>
        </div>
      </section>

      <section className="border-y border-border bg-card py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-10">
          <p className="eyebrow mb-12 text-center">Our Tenets</p>
          <div className="grid gap-12 md:grid-cols-3">
            {[
              {
                t: "Discretion",
                d: "Our chauffeurs do not photograph you. They do not speak unless spoken to. They do not exist on social media.",
              },
              {
                t: "Precision",
                d: "We arrive seven minutes before you do. Always. The cabin is set to your preference before you reach the door.",
              },
              {
                t: "Distinction",
                d: "We turn away more business than we accept. The list is long because we keep it short.",
              },
            ].map((t) => (
              <div key={t.t}>
                <h3 className="font-display text-3xl text-gold">{t.t}</h3>
                <div className="hairline my-6 max-w-[80px]" />
                <p className="text-base leading-relaxed text-muted-foreground">{t.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
