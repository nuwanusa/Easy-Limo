import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { recalculateRideTolls } from "@/lib/ride-report.functions";
import { AppShell, PageHeading, StatusChip } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { FlightStatusCard } from "@/components/FlightStatusCard";
import { DriverInfoShare } from "@/components/DriverInfoShare";
import { FareAuthorization } from "@/components/FareAuthorization";
import { RideEmailShare } from "@/components/RideEmailShare";
import { CompletedRideRouteMap } from "@/components/CompletedRideRouteMap";
import { TrackLinkShare } from "@/components/TrackLinkShare";
import {
  clockTime,
  dayLabel,
  fareBreakdownRows,
  fareTotal,
  money,
  type Reservation,
  type ReservationStop,
} from "@/lib/dispatch";
import { waitingExempt, waitingLabel, WAITING_GRACE_MINUTES } from "@/lib/waiting-time";

export const Route = createFileRoute("/rides/$id")({
  head: () => ({
    meta: [
      { title: "Ride details — Blackwave Transportation LLC" },
      {
        name: "description",
        content:
          "Full detail for a single chauffeur ride: route, timing, fare, chauffeur note and uploaded receipts.",
      },
      { property: "og:title", content: "Ride details — Blackwave Transportation LLC" },
      {
        property: "og:description",
        content: "Route, timing, fare, chauffeur note and receipts for one reservation.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <AppShell>
      <RidePage />
    </AppShell>
  ),
});

type DriverReceipt = {
  id: string;
  reservation_id: string;
  kind: string;
  file_path: string;
  amount: number;
  created_at: string;
};

const RECEIPT_LABELS: Record<string, string> = {
  parking: "Parking receipt",
  airport: "Airport fee receipt",
  toll: "Toll receipt",
  other: "Other receipt",
};

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start gap-4 border-b border-border/60 py-2.5 last:border-0">
      <span className="w-24 shrink-0 pt-0.5 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
        {label}
      </span>
      <span className="min-w-0 flex-1 text-left font-cond text-[13px] leading-snug">{value}</span>
    </div>
  );
}

const toLocalInput = (iso: string | null) => {
  if (!iso) return "";
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

const fromLocalInput = (value: string) => (value ? new Date(value).toISOString() : null);

type EditableToll = { name: string; payment: string; amount: string; at: string | null };

type TripForm = {
  passenger_name: string;
  passenger_phone: string;
  pickup_at: string;
  dropoff_at: string;
  pickup_address: string;
  dropoff_address: string;
  distance_miles: string;
  base_rate: string;
  base_fare: string;
  hourly_rate: string;
  hours: string;
  minimum_hours: string;
  stop_fee: string;
  waiting_minutes: string;
  waiting_rate: string;
  airport_fee: string;
  meet_greet_fee: string;
  parking_fee: string;
  car_seat_count: string;
  car_seat_fee: string;
  gratuity: string;
  notes: string;
};

const EMPTY_TRIP_FORM: TripForm = {
  passenger_name: "",
  passenger_phone: "",
  pickup_at: "",
  dropoff_at: "",
  pickup_address: "",
  dropoff_address: "",
  distance_miles: "",
  base_rate: "",
  base_fare: "",
  hourly_rate: "",
  hours: "",
  minimum_hours: "",
  stop_fee: "",
  waiting_minutes: "",
  waiting_rate: "",
  airport_fee: "",
  meet_greet_fee: "",
  parking_fee: "",
  car_seat_count: "",
  car_seat_fee: "",
  gratuity: "",
  notes: "",
};

function EditField({
  label,
  value,
  onChange,
  type = "text",
  step,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  step?: string;
}) {
  return (
    <label className="grid gap-1">
      <span className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
        {label}
      </span>
      <input
        type={type}
        step={step}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="rounded-md border border-border bg-background px-3 py-1.5 font-cond text-[13px]"
      />
    </label>
  );
}

function RidePage() {
  const { id } = Route.useParams();

  const { data: ride, isLoading } = useQuery({
    queryKey: ["reservation", id],
    queryFn: async (): Promise<Reservation | null> => {
      const { data, error } = await supabase.from("reservations").select("*").eq("id", id).limit(1);
      if (error) throw error;
      return ((data ?? [])[0] as Reservation | undefined) ?? null;
    },
  });

  const queryClient = useQueryClient();
  const [recalculating, setRecalculating] = useState(false);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<TripForm>(EMPTY_TRIP_FORM);
  const [tollDrafts, setTollDrafts] = useState<EditableToll[]>([]);

  type TollCharge = {
    name: string;
    agency?: string;
    payment?: string;
    amount: number | null;
    at?: string;
  };
  type TollLeg = { label: string; distanceMiles: number; toll: number | null; tolls?: TollCharge[] };
  const tollLegs: TollLeg[] = Array.isArray((ride as { tolls_breakdown?: unknown } | null | undefined)?.tolls_breakdown)
    ? ((ride as unknown as { tolls_breakdown: TollLeg[] }).tolls_breakdown ?? [])
    : [];

  const recalcTolls = async () => {
    setRecalculating(true);
    try {
      const report = await recalculateRideTolls({ data: { reservation_id: id } });
      if (!report) {
        toast.error("Could not calculate tolls for this route.");
      } else {
        toast.success(`Distance ${report.miles} mi · tolls $${(report.tollTotal ?? 0).toFixed(2)}`);
        await queryClient.invalidateQueries();
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not calculate tolls.");
    } finally {
      setRecalculating(false);
    }
  };

  const startEdit = () => {
    if (!ride) return;
    const num = (v: unknown) => (Number(v ?? 0) > 0 ? String(Number(v)) : "");
    setForm({
      passenger_name: ride.passenger_name ?? "",
      passenger_phone: ride.passenger_phone ?? "",
      pickup_at: toLocalInput(ride.pickup_at),
      dropoff_at: toLocalInput(ride.dropoff_at),
      pickup_address: ride.pickup_address ?? "",
      dropoff_address: ride.dropoff_address ?? "",
      distance_miles: num(ride.distance_miles),
      base_rate: num(ride.base_rate),
      base_fare: num(ride.base_fare),
      hourly_rate: num(ride.hourly_rate),
      hours: num(ride.hours),
      minimum_hours: num(ride.minimum_hours),
      stop_fee: num(ride.stop_fee),
      waiting_minutes: num(ride.waiting_minutes),
      waiting_rate: num(ride.waiting_rate),
      airport_fee: num(ride.airport_fee),
      meet_greet_fee: num(ride.meet_greet_fee),
      parking_fee: num(ride.parking_fee),
      car_seat_count: num(ride.car_seat_count),
      car_seat_fee: num(ride.car_seat_fee),
      gratuity: num(ride.gratuity),
      notes: ride.notes ?? "",
    });
    setTollDrafts(
      tollLegs.flatMap((leg) =>
        (leg.tolls ?? []).map((t) => ({
          name: t.name ?? "",
          payment: t.payment ?? "",
          amount: t.amount !== null && t.amount > 0 ? String(t.amount) : "",
          at: t.at ?? null,
        })),
      ),
    );
    setEditing(true);
  };

  const saveEdit = async () => {
    if (!ride) return;
    setSaving(true);
    try {
      const moneyNum = (v: string) => (v.trim() === "" ? 0 : Number(v));
      const pickupIso = fromLocalInput(form.pickup_at ?? "");
      const dropoffIso = fromLocalInput(form.dropoff_at ?? "");
      if (!pickupIso) throw new Error("Pickup time is required");
      if (dropoffIso && new Date(dropoffIso) < new Date(pickupIso)) {
        throw new Error("Drop-off time cannot be earlier than pickup time");
      }
      const cleanTolls = tollDrafts
        .map((t) => ({ ...t, name: t.name.trim() }))
        .filter((t) => t.name !== "");
      const tollTotal = cleanTolls.reduce((sum, t) => sum + (moneyNum(t.amount) || 0), 0);
      const tollsBreakdown =
        cleanTolls.length > 0
          ? [
              {
                label: "Road actually driven",
                distanceMiles: moneyNum(form.distance_miles ?? "") || Number(ride.distance_miles ?? 0),
                toll: Math.round(tollTotal * 100) / 100,
                tolls: cleanTolls.map((t) => ({
                  name: t.name,
                  payment: t.payment || "E-ZPass",
                  amount: moneyNum(t.amount) || null,
                  ...(t.at ? { at: t.at } : {}),
                })),
              },
            ]
          : [];
      const { error } = await supabase
        .from("reservations")
        .update({
          passenger_name: form.passenger_name?.trim() || ride.passenger_name,
          passenger_phone: form.passenger_phone?.trim() || null,
          pickup_at: pickupIso,
          dropoff_at: dropoffIso,
          pickup_address: form.pickup_address?.trim() || ride.pickup_address,
          dropoff_address: form.dropoff_address?.trim() || "",
          distance_miles: moneyNum(form.distance_miles ?? ""),
          base_rate: moneyNum(form.base_rate ?? ""),
          base_fare: moneyNum(form.base_fare ?? ""),
          hourly_rate: moneyNum(form.hourly_rate ?? ""),
          hours: moneyNum(form.hours ?? ""),
          minimum_hours: moneyNum(form.minimum_hours ?? ""),
          stop_fee: moneyNum(form.stop_fee ?? ""),
          waiting_minutes: moneyNum(form.waiting_minutes ?? ""),
          waiting_rate: moneyNum(form.waiting_rate ?? ""),
          airport_fee: moneyNum(form.airport_fee ?? ""),
          meet_greet_fee: moneyNum(form.meet_greet_fee ?? ""),
          parking_fee: moneyNum(form.parking_fee ?? ""),
          car_seat_count: moneyNum(form.car_seat_count ?? ""),
          car_seat_fee: moneyNum(form.car_seat_fee ?? ""),
          gratuity: moneyNum(form.gratuity ?? ""),
          tolls: Math.round(tollTotal * 100) / 100,
          tolls_breakdown: tollsBreakdown,
          notes: form.notes ?? "",
        })
        .eq("id", ride.id);
      if (error) throw error;
      toast.success("Ride details saved");
      setEditing(false);
      await queryClient.invalidateQueries();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save changes.");
    } finally {
      setSaving(false);
    }
  };

  const { data: stops = [] } = useQuery({
    queryKey: ["reservation-stops", id],
    queryFn: async (): Promise<ReservationStop[]> => {
      const { data, error } = await supabase
        .from("reservation_stops")
        .select("*")
        .eq("reservation_id", id)
        .order("position", { ascending: true });
      if (error) throw error;
      return (data ?? []) as ReservationStop[];
    },
  });

  const { data: receipts = [] } = useQuery({
    queryKey: ["reservation-receipts", id],
    queryFn: async (): Promise<DriverReceipt[]> => {
      const { data, error } = await supabase
        .from("reservation_receipts")
        .select("*")
        .eq("reservation_id", id)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as DriverReceipt[];
    },
  });

  const { data: disputes = [], refetch: refetchDisputes } = useQuery({
    queryKey: ["ride-disputes", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ride_disputes")
        .select("*")
        .eq("reservation_id", id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const resolveDispute = async (disputeId: string) => {
    const { error } = await supabase
      .from("ride_disputes")
      .update({ status: "resolved", resolved_at: new Date().toISOString() })
      .eq("id", disputeId);
    if (error) toast.error(error.message);
    else {
      toast.success("Dispute marked resolved");
      refetchDisputes();
    }
  };

  const openReceipt = async (path: string) => {
    const { data, error } = await supabase.storage.from("ride-receipts").createSignedUrl(path, 3600);
    if (error || !data?.signedUrl) {
      toast.error(error?.message ?? "Could not open receipt");
      return;
    }
    window.open(data.signedUrl, "_blank", "noopener");
  };

  if (isLoading) {
    return <p className="px-6 py-10 font-cond text-sm text-muted-foreground">Loading ride…</p>;
  }

  if (!ride) {
    return (
      <div className="px-6 py-10">
        <p className="font-cond text-sm text-muted-foreground">This ride could not be found.</p>
        <Link
          to="/reservations"
          className="mt-4 inline-block font-cond text-xs uppercase tracking-widest text-brand"
        >
          Back to reservations
        </Link>
      </div>
    );
  }


  return (
    <>
      <PageHeading
        eyebrow={`${dayLabel(ride.pickup_at)} · ${clockTime(ride.pickup_at)}`}
        title={`Ride ${ride.reference}`}
      />

      <div className="mx-6 mb-6 flex flex-wrap items-center gap-4">
        <StatusChip status={ride.status} />
        <Link
          to="/reservations"
          search={{ edit: ride.id }}
          className="font-cond text-[11px] uppercase tracking-widest text-brand"
        >
          Edit ride
        </Link>
        <Link
          to="/reservations"
          className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground hover:text-brand"
        >
          Back to reservations
        </Link>
      </div>

      <div className="mx-6 mb-10 grid gap-4 lg:grid-cols-2">
        <div className="rounded-lg border border-border bg-card p-5">
          <div className="flex items-center justify-between gap-3">
            <div className="font-cond text-[10px] uppercase tracking-widest text-brand">Trip</div>
            {!editing && (
              <button
                type="button"
                onClick={startEdit}
                className="font-cond text-[11px] uppercase tracking-widest text-brand hover:underline"
              >
                Edit trip details
              </button>
            )}
          </div>
          {editing ? (
            <div className="mt-3 grid gap-4">
              <div className="grid gap-3 sm:grid-cols-2">
                <EditField
                  label="Passenger"
                  value={form.passenger_name}
                  onChange={(v) => setForm((f) => ({ ...f, passenger_name: v }))}
                />
                <EditField
                  label="Phone"
                  value={form.passenger_phone}
                  onChange={(v) => setForm((f) => ({ ...f, passenger_phone: v }))}
                />
                <EditField
                  label="Pickup time"
                  type="datetime-local"
                  value={form.pickup_at}
                  onChange={(v) => setForm((f) => ({ ...f, pickup_at: v }))}
                />
                <EditField
                  label="Drop-off time"
                  type="datetime-local"
                  value={form.dropoff_at}
                  onChange={(v) => setForm((f) => ({ ...f, dropoff_at: v }))}
                />
              </div>
              <EditField
                label="Pickup"
                value={form.pickup_address}
                onChange={(v) => setForm((f) => ({ ...f, pickup_address: v }))}
              />
              <EditField
                label="Drop-off"
                value={form.dropoff_address}
                onChange={(v) => setForm((f) => ({ ...f, dropoff_address: v }))}
              />
              <div className="grid gap-3 sm:grid-cols-3">
                <EditField
                  label="Distance driven (mi)"
                  type="number"
                  step="0.1"
                  value={form.distance_miles}
                  onChange={(v) => setForm((f) => ({ ...f, distance_miles: v }))}
                />
                <EditField
                  label="Base rate"
                  type="number"
                  step="0.01"
                  value={form.base_rate}
                  onChange={(v) => setForm((f) => ({ ...f, base_rate: v }))}
                />
                <EditField
                  label="Flat rate"
                  type="number"
                  step="0.01"
                  value={form.base_fare}
                  onChange={(v) => setForm((f) => ({ ...f, base_fare: v }))}
                />
                <EditField
                  label="Hourly rate"
                  type="number"
                  step="0.01"
                  value={form.hourly_rate}
                  onChange={(v) => setForm((f) => ({ ...f, hourly_rate: v }))}
                />
                <EditField
                  label="Hours"
                  type="number"
                  step="0.25"
                  value={form.hours}
                  onChange={(v) => setForm((f) => ({ ...f, hours: v }))}
                />
                <EditField
                  label="Minimum hours"
                  type="number"
                  step="0.25"
                  value={form.minimum_hours}
                  onChange={(v) => setForm((f) => ({ ...f, minimum_hours: v }))}
                />
                <EditField
                  label="Stop fee"
                  type="number"
                  step="0.01"
                  value={form.stop_fee}
                  onChange={(v) => setForm((f) => ({ ...f, stop_fee: v }))}
                />
                <EditField
                  label="Waiting minutes"
                  type="number"
                  step="1"
                  value={form.waiting_minutes}
                  onChange={(v) => setForm((f) => ({ ...f, waiting_minutes: v }))}
                />
                <EditField
                  label="Waiting rate /hr"
                  type="number"
                  step="0.01"
                  value={form.waiting_rate}
                  onChange={(v) => setForm((f) => ({ ...f, waiting_rate: v }))}
                />
                <EditField
                  label="Airport fee"
                  type="number"
                  step="0.01"
                  value={form.airport_fee}
                  onChange={(v) => setForm((f) => ({ ...f, airport_fee: v }))}
                />
                <EditField
                  label="Meet & greet fee"
                  type="number"
                  step="0.01"
                  value={form.meet_greet_fee}
                  onChange={(v) => setForm((f) => ({ ...f, meet_greet_fee: v }))}
                />
                <EditField
                  label="Parking fee"
                  type="number"
                  step="0.01"
                  value={form.parking_fee}
                  onChange={(v) => setForm((f) => ({ ...f, parking_fee: v }))}
                />
                <EditField
                  label="Car seats"
                  type="number"
                  step="1"
                  value={form.car_seat_count}
                  onChange={(v) => setForm((f) => ({ ...f, car_seat_count: v }))}
                />
                <EditField
                  label="Car seat fee"
                  type="number"
                  step="0.01"
                  value={form.car_seat_fee}
                  onChange={(v) => setForm((f) => ({ ...f, car_seat_fee: v }))}
                />
                <EditField
                  label="Gratuity"
                  type="number"
                  step="0.01"
                  value={form.gratuity}
                  onChange={(v) => setForm((f) => ({ ...f, gratuity: v }))}
                />
              </div>

              <div>
                <div className="flex items-center justify-between gap-3">
                  <span className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                    Tolls breakdown
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      setTollDrafts((rows) => [...rows, { name: "", payment: "E-ZPass", amount: "", at: null }])
                    }
                    className="font-cond text-[11px] uppercase tracking-widest text-brand hover:underline"
                  >
                    Add toll
                  </button>
                </div>
                <div className="mt-2 grid gap-2">
                  {tollDrafts.map((t, i) => (
                    <div key={i} className="grid grid-cols-[1fr_5.5rem_4.5rem_1.75rem] items-center gap-2">
                      <input
                        type="text"
                        value={t.name}
                        placeholder="Toll name"
                        onChange={(e) =>
                          setTollDrafts((rows) =>
                            rows.map((r, j) => (j === i ? { ...r, name: e.target.value } : r)),
                          )
                        }
                        className="min-w-0 rounded-md border border-border bg-background px-2 py-1.5 font-cond text-[12px]"
                      />
                      <input
                        type="text"
                        value={t.payment}
                        placeholder="E-ZPass"
                        onChange={(e) =>
                          setTollDrafts((rows) =>
                            rows.map((r, j) => (j === i ? { ...r, payment: e.target.value } : r)),
                          )
                        }
                        className="min-w-0 rounded-md border border-border bg-background px-2 py-1.5 font-cond text-[12px]"
                      />
                      <input
                        type="number"
                        step="0.01"
                        value={t.amount}
                        placeholder="0.00"
                        onChange={(e) =>
                          setTollDrafts((rows) =>
                            rows.map((r, j) => (j === i ? { ...r, amount: e.target.value } : r)),
                          )
                        }
                        className="min-w-0 rounded-md border border-border bg-background px-2 py-1.5 text-right font-cond text-[12px]"
                      />
                      <button
                        type="button"
                        onClick={() => setTollDrafts((rows) => rows.filter((_, j) => j !== i))}
                        className="text-destructive hover:opacity-70"
                        title="Remove toll"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                  {tollDrafts.length === 0 && (
                    <p className="font-cond text-[12px] text-muted-foreground">
                      No tolls — the saved toll total will be $0.00.
                    </p>
                  )}
                </div>
                <p className="mt-2 font-cond text-[12px] text-muted-foreground">
                  Tolls total on save:{" "}
                  {money(
                    tollDrafts.reduce((sum, t) => sum + (Number(t.amount) || 0), 0),
                  )}
                </p>
              </div>

              <label className="grid gap-1">
                <span className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                  Notes
                </span>
                <textarea
                  rows={3}
                  value={form.notes}
                  onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
                  className="rounded-md border border-border bg-background px-3 py-1.5 font-cond text-[13px]"
                />
              </label>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  disabled={saving}
                  onClick={saveEdit}
                  className="rounded-md bg-brand px-4 py-2 font-cond text-xs uppercase tracking-widest text-brand-foreground disabled:opacity-60"
                >
                  {saving ? "Saving…" : "Save changes"}
                </button>
                <button
                  type="button"
                  disabled={saving}
                  onClick={() => setEditing(false)}
                  className="font-cond text-[11px] uppercase tracking-widest text-muted-foreground hover:text-brand"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
          <div className="mt-2">
            <Row label="Passenger" value={ride.passenger_name || "—"} />
            <Row label="Phone" value={ride.passenger_phone || "—"} />
            {(Array.isArray((ride as { extra_passengers?: unknown }).extra_passengers)
              ? ((ride as { extra_passengers?: Array<{ name?: string; phone?: string }> }).extra_passengers ?? [])
              : []
            ).map((p, i) => (
              <Row
                key={i}
                label={`Passenger ${i + 2}`}
                value={[p.name, p.phone].filter(Boolean).join(" · ") || "—"}
              />
            ))}
            <Row label="Pickup time" value={`${dayLabel(ride.pickup_at)} · ${clockTime(ride.pickup_at)}`} />
            <Row
              label="Drop-off time"
              value={ride.dropoff_at ? `${dayLabel(ride.dropoff_at)} · ${clockTime(ride.dropoff_at)}` : "—"}
            />
            {ride.dropoff_at && !waitingExempt(ride) ? (
              <Row
                label="Waiting time"
                value={
                  Number(ride.waiting_minutes ?? 0) > 0
                    ? `${waitingLabel(Number(ride.waiting_minutes))} (after ${WAITING_GRACE_MINUTES} min grace)`
                    : `None (within ${WAITING_GRACE_MINUTES} min grace)`
                }
              />
            ) : null}

            <Row label="Pickup" value={ride.pickup_address || "—"} />
            {stops.map((s, i) => (
              <Row key={s.id} label={`Stop ${i + 1}`} value={s.address || "—"} />
            ))}
            <Row label="Drop-off" value={ride.dropoff_address || "—"} />
            <Row
              label="Distance driven"
              value={Number(ride.distance_miles ?? 0) > 0 ? `${Number(ride.distance_miles)} mi` : "—"}
            />
            <Row
              label="Tolls"
              value={Number(ride.tolls ?? 0) > 0 ? money(Number(ride.tolls)) : "$0.00"}
            />
            {tollLegs.length > 0 ? (
              <div className="border-b border-border/60 py-2 last:border-0">
                <div className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                  Tolls breakdown
                </div>
                <div className="mt-1 space-y-1">
                  {tollLegs.map((leg, i) => (
                    <div key={i}>
                      <div className="flex items-baseline justify-between gap-4">
                        <span className="font-cond text-[12px] text-muted-foreground">{leg.label}</span>
                        <span className="text-right font-cond text-[12px]">
                          {leg.toll !== null && leg.toll > 0
                            ? `${money(leg.toll)} · ${leg.distanceMiles} mi`
                            : `No tolls · ${leg.distanceMiles} mi`}
                        </span>
                      </div>
                      {(leg.tolls ?? []).map((t, j) => (
                        <div key={j} className="flex items-baseline justify-between gap-4">
                          <span className="min-w-0 flex-1 text-left font-cond text-[12px]">
                            {t.name}
                            {t.payment ? ` · ${t.payment}` : ""}
                            {t.at
                              ? ` · ${new Date(t.at).toLocaleTimeString("en-US", {
                                  hour: "numeric",
                                  minute: "2-digit",
                                  timeZone: "America/New_York",
                                })}`
                              : ""}
                          </span>
                          <span className="shrink-0 text-right font-cond text-[12px]">
                            {t.amount !== null && t.amount > 0 ? money(t.amount) : "—"}
                          </span>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            ) : null}
            <div className="pt-2">
              <button
                type="button"
                disabled={recalculating}
                onClick={recalcTolls}
                className="font-cond text-[11px] uppercase tracking-widest text-brand hover:underline disabled:opacity-50"
              >
                {recalculating ? "Calculating…" : "Recalculate distance & tolls"}
              </button>
            </div>
            <div className="mt-3 rounded-md border border-border bg-muted/30 p-3">
              <div className="font-cond text-[10px] uppercase tracking-widest text-brand">
                Fare breakdown
              </div>
              <div className="mt-2 space-y-1">
                {fareBreakdownRows(ride, stops.length).map((row, i) => (
                  <div key={i} className="flex items-baseline justify-between gap-4">
                    <span
                      className={`min-w-0 flex-1 text-left font-cond text-[12px] ${row.muted ? "pl-3 text-muted-foreground" : ""}`}
                    >
                      {row.label}
                    </span>
                    <span className="shrink-0 text-right font-cond text-[12px] tabular-nums">
                      {money(row.amount)}
                    </span>
                  </div>
                ))}
              </div>
              <div className="mt-2 flex items-baseline justify-between gap-4 border-t border-border pt-2">
                <span className="font-cond text-[12px] uppercase tracking-widest">Total fare</span>
                <span className="text-right font-cond text-[14px] font-semibold tabular-nums">
                  {money(fareTotal(ride, stops.length))}
                </span>
              </div>
            </div>
          </div>
          )}
          {ride.flight_number ? (
            <FlightStatusCard flightNumber={ride.flight_number} pickupAt={ride.pickup_at} />
          ) : null}
        </div>

        <div className="grid content-start gap-4">
          <FareAuthorization reservationId={ride.id} clientId={ride.client_id ?? null} />
          {ride.status === "completed" && (
            <div className="rounded-lg border border-border bg-card p-5">
              <div className="font-cond text-[10px] uppercase tracking-widest text-brand">
                Route driven
              </div>
              <p className="mb-3 mt-1 font-cond text-[13px] text-muted-foreground">
                GPS route from Passenger on board to Passenger dropped off. Uses Google's estimated route when GPS isn't available.
              </p>
              <CompletedRideRouteMap reservationId={ride.id} />
            </div>
          )}
          <TrackLinkShare
            reservationId={ride.id}
            token={(ride as any).track_token ?? null}
            reference={ride.reference}
          />
        </div>

        <div className="rounded-lg border border-border bg-card p-5">
          <div className="font-cond text-[10px] uppercase tracking-widest text-brand">
            Client disputes
          </div>
          {disputes.length === 0 ? (
            <p className="mt-2 font-cond text-[13px] text-muted-foreground">
              No client has questioned a charge on this ride.
            </p>
          ) : (
            <div className="mt-2 space-y-2">
              {disputes.map((d: any) => (
                <div key={d.id} className="rounded-md border border-border p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
                      {new Date(d.created_at).toLocaleString("en-US", { timeZone: "America/New_York" })}
                      {Number(d.amount) > 0 ? ` · $${Number(d.amount).toFixed(2)} in question` : ""}
                    </span>
                    <span
                      className={`font-cond text-[10px] uppercase tracking-widest ${
                        d.status === "resolved" ? "text-emerald-600" : "text-destructive"
                      }`}
                    >
                      {d.status}
                    </span>
                  </div>
                  <p className="mt-2 whitespace-pre-wrap font-cond text-[13px]">{d.message}</p>
                  {d.contact_email ? (
                    <p className="mt-1 font-cond text-[12px] text-muted-foreground">Reply to {d.contact_email}</p>
                  ) : null}
                  {d.status !== "resolved" && (
                    <button
                      onClick={() => resolveDispute(d.id)}
                      className="mt-2 rounded-md border border-border px-3 py-1.5 font-cond text-[10px] uppercase tracking-widest hover:border-brand hover:text-brand"
                    >
                      Mark resolved
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-lg border border-border bg-card p-5">
          <div className="font-cond text-[10px] uppercase tracking-widest text-brand">
            Chauffeur report
          </div>
          <DriverInfoShare
            driverId={ride.driver_id}
            vehicleId={ride.vehicle_id}
            passenger={ride.passenger_name}
            pickupAt={ride.pickup_at}
            reference={ride.reference}
          />
          {ride.driver_note ? (
            <p className="mt-3 whitespace-pre-wrap font-cond text-[13px]">{ride.driver_note}</p>
          ) : (
            <p className="mt-3 font-cond text-[13px] text-muted-foreground">
              No note from the chauffeur on this ride.
            </p>
          )}

          <div className="mt-5 font-cond text-[10px] uppercase tracking-widest text-muted-foreground">
            Receipts
          </div>
          {receipts.length === 0 ? (
            <p className="mt-2 font-cond text-[13px] text-muted-foreground">No receipts attached.</p>
          ) : (
            <div className="mt-2 space-y-1">
              {receipts.map((rc) => (
                <button
                  key={rc.id}
                  onClick={() => openReceipt(rc.file_path)}
                  className="flex w-full items-baseline justify-between gap-3 rounded-md border border-border px-3 py-1.5 text-left"
                >
                  <span className="font-cond text-[13px]">
                    {RECEIPT_LABELS[rc.kind] ?? rc.kind}
                  </span>
                  <span className="font-cond text-[12px] text-brand">
                    {Number(rc.amount) > 0 ? `$${Number(rc.amount).toFixed(2)} · ` : ""}View
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
        {ride.status === "completed" && (
          <div className="rounded-lg border border-border bg-card p-5 lg:col-span-2">
            <div className="font-cond text-[10px] uppercase tracking-widest text-brand">
              Share ride summary
            </div>
            {(() => {
              const total = money(fareTotal(ride, stops.length));
              const lines = [
                `Ride ${ride.reference} — completed`,
                `${dayLabel(ride.pickup_at)} · ${clockTime(ride.pickup_at)}`,
                `Passenger: ${ride.passenger_name || "—"}`,
                `Pickup: ${ride.pickup_address || "—"}`,
                ...stops.map((s, i) => `Stop ${i + 1}: ${s.address || "—"}`),
                `Drop-off: ${ride.dropoff_address || "—"}`,
                ride.dropoff_at
                  ? `Dropped off: ${dayLabel(ride.dropoff_at)} · ${clockTime(ride.dropoff_at)}`
                  : null,
                Number(ride.distance_miles ?? 0) > 0 ? `Distance: ${Number(ride.distance_miles)} mi` : null,
                `Total fare: ${total}`,
              ].filter(Boolean);
              const text = lines.join("\n");
              return (
                <>
                  <pre className="mt-2 whitespace-pre-wrap rounded-md border border-border/60 bg-muted/30 p-3 font-cond text-[12px] leading-relaxed">
                    {text}
                  </pre>
                  <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
                    <button
                      type="button"
                      onClick={() =>
                        navigator.clipboard
                          .writeText(text)
                          .then(() => toast.success("Ride summary copied"))
                          .catch(() => toast.error("Could not copy"))
                      }
                      className="rounded-md border border-border px-3 py-2 text-center font-cond text-[11px] uppercase tracking-widest text-brand hover:border-brand"
                    >
                      Copy
                    </button>
                    <a
                      href={`sms:?&body=${encodeURIComponent(text)}`}
                      className="rounded-md border border-border px-3 py-2 text-center font-cond text-[11px] uppercase tracking-widest text-brand hover:border-brand"
                    >
                      Text
                    </a>
                    <a
                      href={`https://wa.me/?text=${encodeURIComponent(text)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="rounded-md border border-border px-3 py-2 text-center font-cond text-[11px] uppercase tracking-widest text-brand hover:border-brand"
                    >
                      WhatsApp
                    </a>
                    <a
                      href={`mailto:?subject=${encodeURIComponent(`Ride ${ride.reference} — completed`)}&body=${encodeURIComponent(text)}`}
                      className="rounded-md border border-border px-3 py-2 text-center font-cond text-[11px] uppercase tracking-widest text-brand hover:border-brand"
                    >
                      Email
                    </a>
                  </div>
                  <RideEmailShare reservationId={ride.id} boxed />
                </>
              );
            })()}
          </div>
        )}
      </div>
    </>
  );
}
