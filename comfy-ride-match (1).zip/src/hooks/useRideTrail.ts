import { useEffect, useRef } from "react";
import { useServerFn } from "@tanstack/react-start";
import { recordDriverLocation } from "@/lib/driver.functions";

/**
 * Records the chauffeur's GPS breadcrumbs while a trip is under way, so the
 * tolls charged afterwards come from the road actually driven rather than from
 * a planned route.
 */
const ACTIVE = new Set(["en_route", "on_location", "passenger_on_board"]);

export function useRideTrail(
  reservationId: string | undefined,
  driverId: string | null | undefined,
  status: string | undefined,
) {
  const lastRef = useRef(0);
  const recordLocation = useServerFn(recordDriverLocation);

  useEffect(() => {
    if (!reservationId || !status || !ACTIVE.has(status)) return;
    if (typeof navigator === "undefined" || !navigator.geolocation) return;

    const save = (lat: number, lng: number, capturedAt: number) => {
      const now = Date.now();
      if (!Number.isFinite(capturedAt) || Math.abs(now - capturedAt) > 30_000) return;
      // One breadcrumb every 15 seconds is dense enough to catch a toll plaza.
      if (now - lastRef.current < 15_000) return;
      lastRef.current = now;
      void recordLocation({ data: { reservationId, lat, lng, capturedAt } }).catch(() => {
        // A later GPS fix retries automatically while the ride remains active.
      });
    };

    const watch = navigator.geolocation.watchPosition(
      (pos) => save(pos.coords.latitude, pos.coords.longitude, pos.timestamp),
      () => undefined,
      { enableHighAccuracy: true, maximumAge: 3_000, timeout: 20_000 },
    );

    // In the Android app, keep tracking while Waze is open or the phone is locked.
    let stopNative: (() => void) | null = null;
    void import("@/lib/native-location")
      .then((m) => m.startNativeBackgroundTracking(save))
      .then((stop) => {
        if (cancelled) stop?.();
        else stopNative = stop;
      })
      .catch(() => undefined);

    // Keep the screen awake during the trip — a sleeping phone stops sending GPS.
    type Lock = { release: () => Promise<void> };
    let lock: Lock | null = null;
    let cancelled = false;
    const requestLock = async () => {
      try {
        const wl = (navigator as unknown as { wakeLock?: { request: (t: "screen") => Promise<Lock> } }).wakeLock;
        if (!wl || document.visibilityState !== "visible") return;
        const l = await wl.request("screen");
        if (cancelled) void l.release();
        else lock = l;
      } catch {
        // Wake lock unsupported or denied (e.g. low battery mode).
      }
    };
    const onVisible = () => {
      if (document.visibilityState === "visible") void requestLock();
    };
    void requestLock();
    document.addEventListener("visibilitychange", onVisible);

    return () => {
      cancelled = true;
      stopNative?.();
      navigator.geolocation.clearWatch(watch);
      document.removeEventListener("visibilitychange", onVisible);
      void lock?.release().catch(() => undefined);
    };
  }, [reservationId, driverId, status, recordLocation]);
}
